package com.modak.components.scheduler;

import com.zaxxer.hikari.HikariDataSource;
import com.modak.components.Common.BotCommon;
import com.modak.utils.compression.StringCompression;
import com.modak.utils.encryption.EncryptionUtils;
import com.modak.utils.encryption.RSAEncryptionUtils;
import com.modak.components.Common.CPCommon;
import org.apache.commons.dbutils.handlers.ColumnListHandler;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import com.modak.utility.HashMapUtility;
import com.modak.utility.KafkaUtility;
import com.modak.utility.MiscUtility;
import com.modak.utility.db.JDBCUtility;
import com.modak.utility.json.JSONUtility;
import com.modak.utility.st.STTemplateFactory;
import org.quartz.Job;
import com.modak.utility.st.STTemplateRenderer;

import java.security.PublicKey;
import java.util.*;

public class CrawlerMessagesPublisher implements Job {

    private static final Logger logger = LogManager.getLogger(CrawlerMessagesPublisher.class);
    KafkaProducer producer = null;

    public void execute(JobExecutionContext jobExecutionContext) {
        try {
            JobDataMap jobDataMap = jobExecutionContext.getJobDetail().getJobDataMap();
            Map sourceDataMap = jobDataMap.getWrappedMap();
            HashMap<String, Object> sourceMap = (HashMap<String, Object>) sourceDataMap.get(CPCommon.DATA);
            String configFileLocation = jobDataMap.get(CPCommon.CONFIG_FILE_PATH).toString();
            HashMap<String, Object> templateConfigMap = (HashMap<String, Object>) sourceDataMap.get(CPCommon.TEMPLATE_CONFIG_MAP);
            STTemplateRenderer templateRenderer = STTemplateFactory.getTemplateRenderer(templateConfigMap);
            HikariDataSource hikariDataSource = (HikariDataSource) sourceDataMap.get(CPCommon.HIKARIDATASOURCE);
            JDBCUtility jdbcUtility = new JDBCUtility();
            String templateGroup = HashMapUtility.getString(sourceMap,CPCommon.OUTPUT_TEMPLATE_GROUP);
            HashMap<String, Object> inputMap = new HashMap<>();
            inputMap.put(CPCommon.DATAPLACE_ID, sourceMap.get(CPCommon.DATAPLACE_ID));
            inputMap.put(CPCommon.DATAPLACE_COMPONENT_TYPE_ID, sourceMap.get(CPCommon.DATAPLACE_COMPONENT_TYPE_ID));
            String queryJob = templateRenderer.renderTemplate(templateGroup, CPCommon.VALID_JOB, CPCommon.DATA, inputMap);
            List<String> valid_to_ts_list = jdbcUtility.executeSelectQuery(queryJob, hikariDataSource.getConnection(), true, new ColumnListHandler<>());
            String valid = valid_to_ts_list.get(0);
            if (!valid.contains("9999-12-31")) {
                logger.info(CPCommon.DATAPLACE_DELETION, HashMapUtility.get(inputMap, CPCommon.DATAPLACE_ID).toString());
            } else {
                publishInitialStartMessage(sourceMap, configFileLocation);
                if (jobExecutionContext.getNextFireTime() != null) {
                    logger.info(CPCommon.JOB_SCHEDULED + jobExecutionContext.getNextFireTime(),
                            HashMapUtility.getString(sourceMap, CPCommon.JOB_KEY));
                }
            }
        } catch (Exception e) {
            logger.error(CPCommon.FAILED_TO_PUBLISH_MESSAGE, e);
        } finally {
            try {
                if (producer != null) {
                    producer.close();
                }
            } catch (Exception e) {
                logger.error(CPCommon.FAILED_TO_CLOSE_KAFKA_PRODUCER, e);
            }
        }
    }

    public void publishInitialStartMessage(HashMap<String, Object> dataMap, String configFileLocation) {
        try {
            HashMap<String, Object> configMap = JSONUtility.loadJSONFile(configFileLocation);
            HashMap<String, Object> templateConfigMap = HashMapUtility.getMap(configMap, CPCommon.TEMPLATE_CONFIG);
            String templateGroup = HashMapUtility.getString(dataMap, CPCommon.OUTPUT_TEMPLATE_GROUP);
            String templateName = HashMapUtility.getString(dataMap, CPCommon.OUTPUT_TEMPLATE_NAME);
            STTemplateRenderer templateRenderer = STTemplateFactory.getTemplateRenderer(templateConfigMap);
            HashMap<String, Object> kafkaConfigMap = HashMapUtility.getMap(configMap, CPCommon.KAFKA_CONFIG);
            publishInitialCrawlerMessage(templateGroup, templateName, templateRenderer, dataMap, kafkaConfigMap);
        } catch (Exception e) {
            logger.info(CPCommon.FAILED_TO_PUBLISH_INITIAL_MESSAGE);
        }
    }

    private void publishInitialCrawlerMessage(String templateGroup, String templateName, STTemplateRenderer templateRenderer,
                                              HashMap<String, Object> dataMap,
                                              HashMap<String, Object> kafkaConfigMap) throws Exception {
        KafkaProducer kafkaProducer = null;
        try {
            KafkaUtility kafkaUtility = new KafkaUtility();
            kafkaProducer = kafkaUtility.createKafkaProducer(kafkaConfigMap);
            HashMap<String, Object> templateInputs = new HashMap<>();
            templateInputs.put(BotCommon.DATA, dataMap);
            String outputMessage = templateRenderer.renderTemplate(templateGroup, templateName, templateInputs);
            logger.info(CPCommon.OUTPUT_MESSAGE, MiscUtility.formatString(outputMessage, true));
            String outputMessageTopic = HashMapUtility.getString(dataMap, CPCommon.SCHEDULER_TOPIC);
            byte[] compressedBytes = StringCompression.compressUsingGZIP(outputMessage);
            String encryptKeyPath = HashMapUtility.getString(kafkaConfigMap, BotCommon.PUBLIC_KEY);
            PublicKey publicKey = RSAEncryptionUtils.getPublicKey(encryptKeyPath);
            byte[] encryptedBytes = EncryptionUtils.encryptLargeByteArrayUsingRSA(compressedBytes, publicKey);
            kafkaProducer.send(new ProducerRecord(String.valueOf(outputMessageTopic), encryptedBytes));
            logger.info(CPCommon.PUBLISHED_MESSAGE);
        } catch (Exception e) {
            logger.info(CPCommon.FAILED_TO_PUBLISH_MESSAGE, e);
        } finally {
            try {
                if (kafkaProducer != null) {
                    kafkaProducer.close();
                }
            } catch (Exception e) {
                logger.error(CPCommon.FAILED_TO_CLOSE_KAFKA_PRODUCER, e);
            }
        }
    }
}