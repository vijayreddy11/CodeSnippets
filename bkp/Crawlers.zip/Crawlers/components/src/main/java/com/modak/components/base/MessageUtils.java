package com.modak.components.base;

import com.modak.components.Common.BotCommon;
import com.modak.utility.HashMapUtility;
import com.modak.utility.MiscUtility;
import com.modak.utility.json.JSONUtility;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashMap;
import java.util.UUID;

public class MessageUtils {
    public static synchronized long generateId() {
        return System.nanoTime();
    }

    public static String buildJobStatusMessage(BotCommon.JobStatus jobStatus, HashMap<String, Object> jobMap, HashMap<String, Object> inputMap) throws Exception {
        HashMap<String, Object> msg = new HashMap<>();
        msg.put(BotCommon.KEY_JOB_ID, HashMapUtility.getLong(jobMap, BotCommon.KEY_JOB_ID));
        msg.put(BotCommon.KEY_JOB_NAME, HashMapUtility.getString(jobMap, BotCommon.KEY_JOB_NAME));
        msg.put(BotCommon.KEY_JOB_DESCRIPTION, HashMapUtility.getString(jobMap, BotCommon.KEY_JOB_DESCRIPTION));
        msg.put(BotCommon.KEY_TYPE_OF_JOB, HashMapUtility.getString(jobMap, BotCommon.KEY_TYPE_OF_JOB));
        msg.put(BotCommon.KEY_FUNCTIONAL_ID, HashMapUtility.getString(jobMap, BotCommon.KEY_FUNCTIONAL_ID));
        if (jobMap != null) {
            msg.put(BotCommon.KEY_JOB_METADATA, JSONUtility.object2JsonString(jobMap));
        }
        msg.put(BotCommon.KEY_JOB_STATUS, jobStatus);
        msg.put(BotCommon.KEY_STATE_ID, jobStatus.getStatusId());
        msg.put(BotCommon.MESSAGE_TYPE, BotCommon.MESSAGE_TYPE_JOB_STATUS);
        msg.put(BotCommon.KEY_BOT_NAME, HashMapUtility.getString(inputMap, BotCommon.KEY_BOT_NAME));
        msg.put(BotCommon.KEY_BOT_UUID, HashMapUtility.getString(inputMap, BotCommon.KEY_BOT_UUID));
        msg.putAll(statusMessageCommon());
        return JSONUtility.object2JsonString(msg);
    }

    private static HashMap<String, Object> statusMessageCommon() {
        HashMap<String, Object> msg = new HashMap<>();
        msg.put(BotCommon.MESSAGE_UUID, UUID.randomUUID().toString());
        msg.put(BotCommon.KEY_CREATED_TIMESTAMP, Timestamp.from(Instant.now()).toString());
        msg.put(BotCommon.KEY_HOSTNAME, MiscUtility.getCurrentHostName());
        return msg;
    }

}
