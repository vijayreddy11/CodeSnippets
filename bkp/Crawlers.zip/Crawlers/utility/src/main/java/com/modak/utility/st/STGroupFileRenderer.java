package com.modak.utility.st;

import com.modak.utility.UtilityCommon;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroupFile;
import org.stringtemplate.v4.StringRenderer;

import java.util.ArrayList;
import java.util.HashMap;

public class STGroupFileRenderer implements STTemplateRenderer {
    private static Logger logger = LoggerFactory.getLogger(STGroupFileRenderer.class);

    public void loadTemplateGroups(ArrayList<String> templateGroupNames) throws Exception {
        //
    }

    public String renderTemplate(String templateGroupName, String templateName, String attributeName, Object inputMap) {
        STGroupFile stfile = new STGroupFile(templateGroupName, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        stfile.registerRenderer(String.class, new StringRenderer());
        ST temp = stfile.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(
                    UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + " " + stfile.getFileName());

        }
        temp.add(attributeName, inputMap);
        return temp.render();
    }

    public String renderTemplate(String templateGroupName, String templateName, HashMap<String, Object> templateInputs) {
        STGroupFile stfile = new STGroupFile(templateGroupName, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        stfile.registerRenderer(String.class, new StringRenderer());
        ST temp = stfile.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(
                    UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + " " + stfile.getFileName());
        }
        if (templateInputs != null && templateInputs.size() > 0) {
            for (String attributeName : templateInputs.keySet()) {
                temp.add(attributeName, templateInputs.get(attributeName));
            }
        }
        return temp.render();
    }

    public String renderTemplate(String templateGroupName, String templateName) {
        return renderTemplate(templateGroupName, templateName, null);
    }
}