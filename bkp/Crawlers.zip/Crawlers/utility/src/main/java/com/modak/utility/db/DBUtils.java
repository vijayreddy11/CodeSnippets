package com.modak.utility.db;

import com.zaxxer.hikari.HikariDataSource;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.zaxxer.hikari.HikariDataSource;

import java.sql.*;
import java.util.*;

public class DBUtils {


    /**
     * Executes the sql query
     *
     * @param conn connection object on which sql to executed
     * @param sql  query
     * @return query result as list of hashmap
     * @throws Exception if connection is null  or if sql statement is null or if fail to execute query
     */

    public static List<LinkedHashMap<String, Object>> executeQuery(Connection conn, String sql) throws Exception {
        if (conn == null) {
            throw new NullPointerException("Null connection");
        }
        if (sql == null) {
            close(conn);
            throw new NullPointerException("Null SQL statement");
        }
        List<LinkedHashMap<String, Object>> listOfResult = new ArrayList<>();
        ResultSet rs = null;
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            stmt.setFetchSize(500);
            rs = stmt.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    int total_rows = rs.getMetaData().getColumnCount();
                    LinkedHashMap<String, Object> resultSet = new LinkedHashMap<>();
                    for (int i = 0; i < total_rows; i++) {
                        resultSet.put(rs.getMetaData().getColumnLabel(i + 1)
                                .toLowerCase(), rs.getObject(i + 1));
                    }
                    listOfResult.add(resultSet);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("query:" + sql);
            throw new Exception(e.getLocalizedMessage());
        } finally {
            if ((stmt != null) || (!stmt.isClosed())) {
                stmt.close();
            }
            if ((rs != null) || (!rs.isClosed())) {
                rs.close();
            }
        }
        return listOfResult;
    }

    /**
     * Executes the sql query
     *
     * @param conn connection object on which sql to executed
     * @param sql  query
     * @return resultsetMetaData object
     * @throws Exception if connection is null  or if sql statement is null or if fail to execute query
     */

    public ResultSetMetaData getResultsetMetaData(Connection conn, String sql) throws Exception {
        if (conn == null) {
            throw new NullPointerException("Null connection");
        }
        if (sql == null) {
            close(conn);
            throw new NullPointerException("Null SQL statement");
        }
        ResultSet rs = null;
        Statement stmt = null;
        ResultSetMetaData resultSetMetaData = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            resultSetMetaData = rs.getMetaData();
            close(rs);
            close(stmt);
            close(conn);
        } catch (Exception e) {
            throw new Exception("Failed to resultSet in metadata query : " + e.getMessage());
        } finally {
            close(rs);
            close(stmt);
            close(conn);
        }
        return resultSetMetaData;
    }


    /**
     * Executes the sql query
     *
     * @param conn connection object on which sql to executed
     * @param sql  query
     * @return resultSet object
     * @throws Exception if connection is null  or if sql statement is null or if fail to execute query
     */

    public ResultSet getResultset(Connection conn, String sql) throws Exception {
        if (conn == null) {
            throw new NullPointerException("Null connection");
        }
        if (sql == null) {
            close(conn);
            throw new NullPointerException("Null SQL statement");
        }
        ResultSet rs = null;
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            close(rs);
            close(stmt);
            close(conn);
        } catch (Exception e) {
            throw new Exception("Failed to resultset query : " + e.getMessage());
        } finally {
            close(rs);
            close(stmt);
            close(conn);
        }
        return rs;
    }

    /**
     * Executes the sql query
     *
     * @param dataSource HikariDataSource to get connection object
     * @param sql        query to be executed
     * @return query result as list of hashmap
     * @throws Exception if HikariDataSource is null  or if connection is null  or if sql statement is null or if fail
     *                   to execute query
     */
    public static List<LinkedHashMap<String, Object>> executeQuery(HikariDataSource dataSource, String sql) throws Exception {
        if (dataSource == null) {
            throw new NullPointerException("Null dataSource");
        }
        Connection conn = dataSource.getConnection();
        return executeQuery(conn, sql);
    }

    /**
     * It is used execute update/Insert kind of query
     *
     * @param conn connection object on which sql to executed
     * @param sql  query to be executed
     * @throws Exception if connection is null  or if sql statement is null or if fail to execute query
     */
    public static void executeUpdateQuery(Connection conn, String sql) throws Exception {
        if (conn == null) {
            throw new NullPointerException("Null connection");
        }
        if (sql == null) {
            close(conn);
            throw new NullPointerException("Null SQL statement");
        }
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            stmt.execute(sql);
            close(stmt);
            close(conn);
        } catch (Exception e) {
            throw new Exception("Failed to execute query : " + e.getMessage());
        } finally {
            close(stmt);
            close(conn);
        }
    }

    /**
     * @param dataSource dataSource HikariDataSource to get connection object
     * @param sql        query to be executed
     * @throws Exception if HikariDataSource is null  or if connection is null  or if sql statement is null or if fail
     *                   to execute update query
     */
    public static void executeUpdateQuery(HikariDataSource dataSource, String sql) throws Exception {
        if (dataSource == null) {
            throw new NullPointerException("Null dataSource");
        }
        Connection conn = dataSource.getConnection();
        executeUpdateQuery(conn, sql);
    }

    /**
     * Close a connection, avoid closing if null and catch any SQLExceptions that occur.
     *
     * @param conn Connection to close.
     */

    public static void close(Connection conn) {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Close a resultset, avoid closing if null and catch any SQLExceptions that occur.
     *
     * @param rs resultSet to close.
     */

    public static void close(ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    /**
     * Close a statement, avoid closing if null and catch any SQLExceptions that occur.
     *
     * @param stmt statement to close.
     */

    public static void close(Statement stmt) {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


}
