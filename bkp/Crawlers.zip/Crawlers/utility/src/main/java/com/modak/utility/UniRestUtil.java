package com.modak.utility;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.request.GetRequest;
import com.mashape.unirest.request.HttpRequestWithBody;
import com.mashape.unirest.request.body.RequestBodyEntity;
import com.modak.utility.json.JSONUtils;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONObject;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class UniRestUtil {

    public static Map<String, Object> requestResolver(String endPoint, Map<String, Object> headers, String payload, String outputType, String requestType) throws Exception {
        Map<String, String> headersMap = headers.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue().toString()));
        if (requestType.equalsIgnoreCase(UtilConfig.POST)) {
            return postRequestHandler(endPoint, headersMap, payload, outputType);
        } else if (requestType.equalsIgnoreCase(UtilConfig.GET)) {
            return getRequestHandler(endPoint, headersMap, outputType);
        } else {
            throw new Exception("Cannot execute Request Pattern : " + requestType);
        }
    }


    public static Map<String, Object> postRequest(String endPoint, Map<String, String> headers, String payload, String outputType) throws Exception {
        Map<String, Object> responseMap = new HashMap<>();
        HttpRequestWithBody post;
        CloseableHttpClient httpClient = makeClient();

        try {
            RequestBodyEntity postWithBody = Unirest.post(endPoint)
                    .headers(headers).body(payload);
            HttpResponse<String> httpResponse = postWithBody.asString();
            responseMap.put(UtilConfig.STATUS, httpResponse.getStatus());

            if (httpResponse.getStatus() == 200) {
                if (outputType.equalsIgnoreCase(UtilConfig.MAP)) {
                    responseMap.put(UtilConfig.RESPONSE, JSONUtils.jsonToMap(httpResponse.getBody()));
                } else if (outputType.equalsIgnoreCase(UtilConfig.LIST)) {
                    responseMap.put(UtilConfig.RESPONSE, JSONUtils.jsonToList(httpResponse.getBody()));
                } else if (outputType.equalsIgnoreCase(UtilConfig.STRING)) {
                    responseMap.put(UtilConfig.RESPONSE, httpResponse.getBody());
                } else if (outputType.equalsIgnoreCase(UtilConfig.JSONARRAY)) {
                    responseMap.put(UtilConfig.RESPONSE, new JSONObject(httpResponse.getBody()));
                } else if (outputType.equalsIgnoreCase(UtilConfig.JSON)) {
                    responseMap.put(UtilConfig.RESPONSE, JSONUtils.object2JsonString(postWithBody.getBody()));
                } else {
                    responseMap.put(UtilConfig.STATUS, 500);
                    responseMap.put(UtilConfig.RESPONSE, "Invalid responseType request for api: ");
                }
            } else {
                responseMap.put(UtilConfig.RESPONSE, postWithBody.getBody());
            }
        } catch (Exception e) {
            e.printStackTrace();
            responseMap.put(UtilConfig.STATUS, 500);
            responseMap.put(UtilConfig.RESPONSE, "Exception for request with Exceetion : " + e.getMessage());
        } finally {
            post = null;
            httpClient.close();
        }

        return responseMap;
    }


    public static Map<String, Object> getRequest(String endPoint, Map<String, String> headers, String outputType) throws Exception {
        Map<String, Object> responseMap = new HashMap<>();
        GetRequest get;
        CloseableHttpClient httpClient = makeClient();
        try {
            get = Unirest.get(endPoint)
                    .headers(headers);
            HttpResponse<String> httpResponse = get.asString();
            responseMap.put(UtilConfig.STATUS, httpResponse.getStatus());
            if (outputType.equalsIgnoreCase(UtilConfig.JSON)) {
                responseMap.put(UtilConfig.RESPONSE, JSONUtils.jsonToMap(httpResponse.getBody()));
            } else if (outputType.equalsIgnoreCase(UtilConfig.STRING)) {
                responseMap.put(UtilConfig.RESPONSE, get.asString().getBody());
            } else if (outputType.equalsIgnoreCase(UtilConfig.JSONARRAY)) {
                responseMap.put(UtilConfig.RESPONSE, JSONUtils.jsonToList(httpResponse.getBody()));
            } else {
                responseMap.put(UtilConfig.STATUS, 500);
                responseMap.put(UtilConfig.RESPONSE, "Invalid responseType request ");
            }
        } catch (Exception e) {
            e.printStackTrace();
            responseMap.put(UtilConfig.STATUS, 500);
            responseMap.put(UtilConfig.RESPONSE, "Excpetion for request with Excpetion : " + e.getMessage());
        } finally {
            get = null;
            httpClient.close();
        }

        return responseMap;
    }

    private static CloseableHttpClient makeClient() throws Exception {
        TrustManager[] trustAllCerts;
        SSLContext sslcontext;
        SSLConnectionSocketFactory sslsf;
        CloseableHttpClient httpclient;
        try {
            trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }

                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }

            }};
            sslcontext = SSLContext.getInstance("SSL");
            sslcontext.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sslcontext.getSocketFactory());
            sslsf = new SSLConnectionSocketFactory(sslcontext);
            httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();
            Unirest.setHttpClient(httpclient);
            return httpclient;
        } catch (Exception e) {
            throw new Exception("failed to execute with message: " + e.getMessage());
        } finally {
            trustAllCerts = null;
            sslcontext = null;
            sslsf = null;
            httpclient = null;
        }
    }

    public static Map<String, Object> postRequestHandler(String endPoint, Map<String, String> headers, String payload, String outputType) throws Exception {
        Map<String, Object> responseMap = new HashMap<>();
        try {
            HttpResponse httpsResponse = null;
            httpsResponse = Unirest.post(endPoint).headers(headers).body(payload).asJson();
            responseMap.put(UtilConfig.STATUS, httpsResponse.getStatus());
            responseMap.put(UtilConfig.RESPONSE, httpsResponse.getBody());
            return responseMap;
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    public static Map<String, Object> getRequestHandler(String endPoint, Map<String, String> headers, String outputType) throws Exception {
        Map<String, Object> responseMap = new HashMap<>();
        try {
            HttpResponse httpsResponse = null;
            httpsResponse = Unirest.get(endPoint).headers(headers).asJson();
            responseMap.put(UtilConfig.STATUS, httpsResponse.getStatus());
            responseMap.put(UtilConfig.RESPONSE, httpsResponse.getBody());
            return responseMap;
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

}

