package com.modak.utility.jwt;


import com.modak.utility.UtilConfig;
import com.modak.utility.MapUtils;
import com.modak.RSAEncryption.RSAEncryptDecrypt;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

import java.util.HashMap;

public class AuthTokenGenerator {
    public String generateAuthToken(HashMap<String, Object> jwtConfig, HashMap<String, Object> redisConfig, HashMap<String, Object> userdetails) {
        try {
            String jwtAuthClassNAme = "com.modak.utility.jwt.JWTHandler";
            AuthHandler jwtHandler = (AuthHandler) Class.forName(jwtAuthClassNAme).newInstance();
            jwtHandler.init(jwtConfig);
            Config config = new Config();
            String password = MapUtils.getString(redisConfig, UtilConfig.PASSWORD);
            String encrypted_password = MapUtils.getString(redisConfig, "encrypted_password");
            if (encrypted_password.equalsIgnoreCase("Y")) {
                String PrivateKeyPath = MapUtils.getString(redisConfig, "PrivateKey");
                password = RSAEncryptDecrypt.decrypt(password, PrivateKeyPath);
            }
            config.useSingleServer().setAddress(MapUtils.getString(redisConfig, UtilConfig.REDIS_URL)).setPassword(password);
            RedissonClient redisson = Redisson.create(config);
            String JWTToken = jwtHandler.generateToken(userdetails, redisson);
            HashMap<String, Object> outputDataMap = new HashMap<>();
            outputDataMap.put("jwt_token", JWTToken);
//            return JSONUtils.object2JsonString(outputDataMap);
            return JWTToken;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
