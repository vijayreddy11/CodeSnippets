package com.modak.utility.connector;

import com.modak.utility.UtilityCommon;
import com.modak.utils.JSONUtils;
import org.apache.commons.io.FilenameUtils;
import com.google.cloud.storage.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.auth.Credentials;
import com.google.auth.oauth2.GoogleCredentials;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class GCSConnector {

    Credentials getGoogleCloudStorageCredentials(Map<String, Object> gcsKeyJsonMap) throws IOException {
        return GoogleCredentials.fromStream(new ByteArrayInputStream(JSONUtils.map2JsonString(gcsKeyJsonMap).getBytes(StandardCharsets.UTF_8)));
    }

    public Storage getStorage(Map<String, Object> gcsKeyJsonMap) throws IOException {
        return StorageOptions.newBuilder().setCredentials(getGoogleCloudStorageCredentials(gcsKeyJsonMap))
                .setProjectId(getProjectId(gcsKeyJsonMap)).build().getService();
    }

    public String getProjectId(Map<String, Object> gcsKeyJson) {
        String projectID = (String) gcsKeyJson.get(UtilityCommon.PROJECT_ID);
        return projectID;
    }

    public List<Map<String, Object>> fetchFileStats(Storage storage, String bucketName, String absoultePath) {
        List<Map<String, Object>> fileStats = new ArrayList<>();
        Iterator blobIterable = storage.get(bucketName).list().iterateAll().iterator();
        while (blobIterable.hasNext()) {
            Blob blob = (Blob) blobIterable.next();
            if (blob.getName().equals(absoultePath)) {
                Map<String, Object> fileStat = getFileStats(blob, new HashMap<String, Object>(),bucketName);
                fileStats.add(fileStat);
                break;
            }
        }
        return fileStats;
    }

    public List<Map<String, Object>> fetchBlobStats(Storage storage, String bucketName, String absoultePath) {
        List<Map<String, Object>> fileStats = new ArrayList<>();
        Iterator blobIterable = storage.get(bucketName).list().iterateAll().iterator();
        while (blobIterable.hasNext()) {
            Blob blob = (Blob) blobIterable.next();
            if (getAbsoulteBlobName(blob.getName()).equals(absoultePath)) {
                Map<String, Object> fileStat = getFileStats(blob, new HashMap<String, Object>(),bucketName);
                fileStats.add(fileStat);
            }
        }
        return fileStats;
    }

    public List<Map<String, Object>> fetchBucketStats(Storage storage, String bucketName) throws Exception {
        List<Map<String, Object>> fileStats = new ArrayList<>();
        Iterator blobIterable = storage.get(bucketName).list().iterateAll().iterator();
        while (blobIterable.hasNext()) {
            Blob blob = (Blob) blobIterable.next();
            Map<String, Object> fileStat = getFileStats(blob, new HashMap<String, Object>(), bucketName);
            fileStats.add(fileStat);
        }
        return fileStats;
    }

    private Map<String, Object> getFileStats(Blob blob, Map<String, Object> stats,String bucketName) {
        String fileName = getFileNameInBucket(blob.getName());
        String relativePath=blob.getName();
        String absolutePath="gs://"+bucketName+UtilityCommon.FILE_SEPARATOR+relativePath;
        stats.put(UtilityCommon.FILE_NAME, fileName);
        stats.put(UtilityCommon.FILE_FORMAT, FilenameUtils.getExtension(fileName));
        stats.put(UtilityCommon.RELATIVE_PATH,relativePath );
        stats.put(UtilityCommon.ABSOLUTE_PATH,absolutePath);
        stats.put(UtilityCommon.FILE_MODIFIED_TIME, new Date(blob.getUpdateTime()));
        List<Acl> acls = blob.getAcl();
        StringBuffer owners = new StringBuffer("");
        for (Acl acl : acls) {
            Acl.Entity entity = acl.getEntity();
            if (entity.getType().equals(Acl.Entity.Type.USER)) {
                if (owners.length() != 0) owners.append("," + entity.toString());
                else owners.append(entity.toString());
            }
        }
        stats.put(UtilityCommon.FILE_OWNER, owners);
        stats.put(UtilityCommon.FILE_SIZE, blob.getSize());
        if (blob.getMetadata() != null) stats.put(UtilityCommon.ADDITIONAL_INFO, blob.getMetadata().toString());
        else stats.put(UtilityCommon.ADDITIONAL_INFO, null);
        return stats;
    }

    private String getFileNameInBucket(String name) {
        String[] names = name.split("/");
        if (names.length <= 1) return name;
        return names[names.length - 1];
    }

    private String getAbsoulteBlobName(String name) {
        String[] names = name.split("/");
        if (names.length <= 1) return name;
        StringBuffer fileBlob = new StringBuffer(names[0]);
        for (int i = 1; i < names.length - 1; i++) {
            fileBlob.append("/" + names[i]);
        }
        return fileBlob.toString();
    }
}
