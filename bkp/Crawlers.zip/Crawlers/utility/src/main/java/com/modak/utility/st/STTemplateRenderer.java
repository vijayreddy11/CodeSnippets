package com.modak.utility.st;

import java.util.ArrayList;
import java.util.HashMap;

public interface STTemplateRenderer {
    void loadTemplateGroups(ArrayList<String> templateGroupNames) throws Exception;

    String renderTemplate(String templateGroupName, String templateName, String atttributeName, Object inputMap) throws Exception;

    String renderTemplate(String templateGroupName, String templateName, HashMap<String, Object> templateInputs) throws Exception;

    String renderTemplate(String templateGroupName, String templateName) throws Exception;

}