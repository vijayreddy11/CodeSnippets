package com.modak.utility;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.regex.Pattern;

public class KafkaUtility {
    private static Logger logger = LoggerFactory.getLogger(KafkaUtility.class);

    public KafkaConsumer createKafkaConsumer(HashMap<String, Object> props) throws Exception {
        KafkaConsumer kafkaConsumer;
        try {
            String clientId = HashMapUtility.getString(props, UtilityCommon.CONSUMER_CLIENT_ID);
            clientId = StringUtils.defaultIfEmpty(clientId, UUID.randomUUID().toString());
            Properties kafkaConsumerProps = new Properties();
            kafkaConsumerProps.put(ConsumerConfig.CLIENT_ID_CONFIG, clientId);
            kafkaConsumerProps.putAll(props);
            ArrayList<String> topics = HashMapUtility.getArrayList(props, UtilityCommon.TOPIC_LIST);
            kafkaConsumer = new KafkaConsumer(kafkaConsumerProps);
            Boolean kafkaTopicContainsPattern = HashMapUtility.getBoolean(props, UtilityCommon.TOPIC_CONTAINS_PATTERN);
            if (BooleanUtils.isFalse(kafkaTopicContainsPattern)) {
                kafkaConsumer.subscribe(topics);
            } else {
                String topic = topics.get(0);
                kafkaConsumer.subscribe(Pattern.compile(topic), new ConsumerRebalanceListener() {
                    public void onPartitionsRevoked(Collection<TopicPartition> collection) {
                    }

                    public void onPartitionsAssigned(Collection<TopicPartition> collection) {
                    }
                });
                logger.info("kafka consumer subscribed to topic : {}", topic);
            }
        } catch (Exception e) {
            throw new Exception("Failed to construct kafka consumer", e);
        }
        return kafkaConsumer;
    }

    public KafkaProducer createKafkaProducer(HashMap<String, Object> props) throws Exception {
        KafkaProducer kafkaProducer;
        try {
            String clientId = HashMapUtility.getString(props, UtilityCommon.CONSUMER_CLIENT_ID);
            clientId = StringUtils.defaultIfEmpty(clientId, UUID.randomUUID().toString());
            Properties kafkaProducerProps = new Properties();
            kafkaProducerProps.put(ConsumerConfig.CLIENT_ID_CONFIG, clientId);
            kafkaProducerProps.putAll(props);
            kafkaProducer = new KafkaProducer(kafkaProducerProps);

        } catch (Exception e) {
            throw new Exception("Failed to construct kafka producer", e);
        }
        return kafkaProducer;
    }
}
