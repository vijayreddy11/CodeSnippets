package com.modak.utility.compression;

public class CompDecompGZIP {
}
