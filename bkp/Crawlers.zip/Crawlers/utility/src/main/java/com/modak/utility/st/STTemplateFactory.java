package com.modak.utility.st;

import com.modak.utility.HashMapUtility;
import com.modak.utility.UtilityCommon;

import java.util.HashMap;

public class STTemplateFactory {
    public static STTemplateRenderer getTemplateRenderer(HashMap<String, Object> templateConfigMap) {
        String renderType = HashMapUtility.getString(templateConfigMap, UtilityCommon.KEY_TEMPLATE_RENDER_TYPE);
        STTemplateRenderer renderer = null;
        if (renderType.equalsIgnoreCase(UtilityCommon.KEY_GROUP_FILE_RENDERER)) {
            renderer = new STGroupFileRenderer();
        } else if (renderType.equalsIgnoreCase(UtilityCommon.KEY_ENDPOINT_RENDERER)) {
            String restEndPoint = HashMapUtility.getString(templateConfigMap, UtilityCommon.KEY_REST_END_POINT);
            renderer = new STRestEndPointRenderer(restEndPoint);
        }
        return renderer;
    }
}
