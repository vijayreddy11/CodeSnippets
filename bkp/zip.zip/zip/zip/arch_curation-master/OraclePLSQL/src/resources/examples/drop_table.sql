DROP TABLE employee;
DROP TABLE employee PURGE;
