create public synonym emp for hr.employees
