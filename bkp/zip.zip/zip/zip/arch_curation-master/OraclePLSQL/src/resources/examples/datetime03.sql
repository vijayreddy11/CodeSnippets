select
timestamp '2009-10-29 01:30:00' at time zone 'us/pacific'from dual

