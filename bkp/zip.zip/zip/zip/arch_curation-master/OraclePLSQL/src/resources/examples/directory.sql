CREATE DIRECTORY mydir AS '/scratch/data/file_data';

CREATE OR REPLACE DIRECTORY bfile_dir AS '/usr/bin/bfile_dir';
