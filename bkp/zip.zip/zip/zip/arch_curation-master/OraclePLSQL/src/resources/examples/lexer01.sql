select * from dual where 1 < > 2 and 1 ! = 2 and 1 ^ /*aaa */ = 2

