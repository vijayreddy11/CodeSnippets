with a as (select * from dual order by 1) select * from a
