select
case (STaTUS)
when 'N' then 1
when 'B' then 2
when 'a' then 3
end as STaTE
from VaLUE
where KID=:B2 and RID=:B1

