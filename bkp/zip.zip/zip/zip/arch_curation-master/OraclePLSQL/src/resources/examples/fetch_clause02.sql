Select *
fROM green_table
offset 1 rows
fetch NEXT 20 percent ROW ONLY
