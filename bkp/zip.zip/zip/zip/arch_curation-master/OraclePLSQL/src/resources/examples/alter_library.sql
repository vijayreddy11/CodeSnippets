ALTER LIBRARY hr.my_ext_lib COMPILE;
