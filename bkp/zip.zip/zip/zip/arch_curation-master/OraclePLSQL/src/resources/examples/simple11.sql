select a.* from dual
