select d1.*, d2.* from dual cross join dual 
