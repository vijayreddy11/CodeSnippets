Select *
fROM green_table
offset 1 rows
fetch FIRST 1 ROWS ONLY;
