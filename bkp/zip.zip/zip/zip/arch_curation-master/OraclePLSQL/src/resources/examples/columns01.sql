select a, b,
a d,
ddd as ddd,
ddd as "dfdf",
to_date('2020-10-20') + 1/24 as sub,
decode('X','X',1,'Y',2,'Z',3,4) as x1,
lower('XXX') as lx,
x as
from dual;


