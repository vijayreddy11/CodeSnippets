Select *
fROM green_table
offset 1 row;
