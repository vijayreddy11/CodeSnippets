select *
from
	table
	(
		function_name()
	)
