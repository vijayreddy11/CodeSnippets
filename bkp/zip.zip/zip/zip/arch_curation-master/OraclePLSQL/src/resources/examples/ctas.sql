create table junk as select sysdate from dual;

create table junk1 INITRANS 10 as select sysdate from dual;
