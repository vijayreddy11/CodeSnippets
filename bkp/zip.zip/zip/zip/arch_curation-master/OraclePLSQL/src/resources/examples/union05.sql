select * from dual
union all
(
	select * from dual
)
union all
(
	select * from dual
)
union all
(
	select * from dual
)
union all
(
	select * from dual
)
union all
(
	select * from dual
)
union all
(
	select * from dual
)
union all
(
	select * from dual
)
order by 1 asc, 2 asc
