SELECT 

 MAX (DISTINCT miles),
 MAX (ALL miles)
 
FROM Flights