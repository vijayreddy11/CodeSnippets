import org.apache.spark.sql.Row

val environment = sc.getConf.get("spark.driver.args")
val input = sc.getConf.get("spark.driver.input").split(",")
val tables = sc.getConf.get("spark.driver.tables").split(",")
val data_store = "integrated"

val ark_db = input(0)
val bkp_db = input(1)
val delta_db = input(2)

tables.foreach { table =>
    var table1 = ark_db + "." + table
    var table2 = bkp_db + "." + table
    val set_name = table + "_delta"
    println("Comparing the tables " + table1 + " and " + table2)

    if(!spark.catalog.tableExists(table1)){
        print(s"Table : $set_name not found in ark database")
    }
    else if (!spark.catalog.tableExists(table2)){
        print(s"Table : $set_name is creating for the first time. No Backup table found")
        var df1 = spark.table(table1)
        var lineage_colX = df1.select("LINEAGE.*").drop("TIMESTAMP","VERSION").columns
        for( z <- 0 to lineage_colX.size-1){
            lineage_colX(z) =  "LINEAGE." + lineage_colX(z)
        }
        val colX = df1.drop("LINEAGE").columns ++ lineage_colX
        val res = df1.withColumn("MODAK_UID", md5(concat(colX.map(x => coalesce(col(x).cast("string"), lit("nirhf84@$%9f4f44"))): _*))).withColumn("FLAG",lit("N"))
        
        res.write.mode("OVERWRITE").option("format", "parquet").option("path", "s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+delta_db+".db/"+set_name).saveAsTable(delta_db +"."+set_name)
    }
    else{
        var df1 = spark.table(table1)
        var lineage_colX = df1.select("LINEAGE.*").drop("TIMESTAMP","VERSION").columns
        for( z <- 0 to lineage_colX.size-1){
            lineage_colX(z) =  "LINEAGE." + lineage_colX(z)
        }
        val colX = df1.drop("LINEAGE").columns ++ lineage_colX
        df1 = df1.withColumn("MODAK_UID", md5(concat(colX.map(x => coalesce(col(x).cast("string"), lit("nirhf84@$%9f4f44"))): _*)))
        spark.catalog.dropTempView("table_n")
        df1.createOrReplaceTempView("table_n")

        var df2 = spark.table(table2)
        var lineage_colY = df2.select("LINEAGE.*").drop("TIMESTAMP","VERSION").columns
        for( z <- 0 to lineage_colY.size-1){
            lineage_colY(z) =  "LINEAGE." + lineage_colY(z)
        }
        val colY = df2.drop("LINEAGE").columns ++ lineage_colY
        df2 = df2.withColumn("MODAK_UID", md5(concat(colY.map(x => coalesce(col(x).cast("string"), lit("nirhf84@$%9f4f44"))): _*)))
        spark.catalog.dropTempView("table_o")
        df2.createOrReplaceTempView("table_o")

        var col_set1 = df1.columns.toSet
        var col_set2 = df2.columns.toSet
        if (col_set1.contains("METADATA")){
            val meta = df1.select("metadata.*").columns.toSet
            val meta2 = df2.select("metadata.*").columns.toSet
            col_set1 = col_set1 ++ meta
            col_set2 = col_set2 ++ meta2
        }
        col_set1 = col_set1.map(x => x.toUpperCase())
        col_set2 = col_set2.map(x => x.toUpperCase())

        if (!col_set1.equals(col_set2)){
            print(s"Table : $set_name is creating without CDC. Columns got changed")
            var res = df1.withColumn("MODAK_UID", md5(concat(df1.drop("lineage").columns.map(x => coalesce(col(x).cast("string"), lit("nirhf84@$%9f4f44"))): _*))).withColumn("FLAG",lit("N"))
            
            res.write.mode("OVERWRITE").option("format", "parquet").option("path", "s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+delta_db+".db/"+set_name).saveAsTable(delta_db +"."+set_name)
            //Need to handle deleted
        }
        else{
            /*Flag  'A' for newly added rows
                    'U' for changed/updated rows
                    'D' for deleted rows 
                    'E' for existing/unaltered rows */
            var result_df1, result_df2 = spark.emptyDataFrame
            if (table.contains("relationship")){
                result_df1 = spark.sql("""select a.*, 'A' as FLAG 
                                        from (select distinct * from table_n) a left outer join (select distinct * from table_o) b
                                        on a.MODAK_UID = b.MODAK_UID
                                        where b.MODAK_UID is null""")

                result_df2 = spark.sql("""select a.*, 'D' as FLAG 
                                        from (select distinct * from table_o) a left outer join (select distinct * from table_n) b
                                        on a.MODAK_UID = b.MODAK_UID
                                        where b.MODAK_UID is null """)
                }
            else{
                result_df1 = spark.sql("""select a.*, case when a.MODAK_UID <> b.MODAK_UID then 'U' when b.MODAK_UID is null then 'A' else 'E' end as FLAG 
                                        from (select distinct * from table_n) a left outer join (select distinct * from table_o) b
                                        on a.ID = b.ID""")
                result_df1 = result_df1.filter("FLAG <> 'E'")
                
                result_df2 = spark.sql("""select a.*, 'D' as FLAG 
                                        from (select distinct * from table_o) a left outer join (select distinct * from table_n) b
                                        on a.ID = b.ID
                                        where b.ID is null """)
            }

            result_df1.write.mode("OVERWRITE").option("format", "parquet").partitionBy("FLAG").option("path", "s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+delta_db+".db/"+set_name).saveAsTable(delta_db +"."+set_name)
            result_df2.write.mode("APPEND").option("format", "parquet").partitionBy("FLAG").option("path", "s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+delta_db+".db/"+set_name).saveAsTable(delta_db +"."+set_name)
        }
    }
}
