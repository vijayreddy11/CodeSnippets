import org.apache.spark.sql.types.{StringType,StructField,StructType,DoubleType,LongType}
import org.apache.spark.sql.Row

val environment = sc.getConf.get("spark.driver.args")
val data_store = "integrated"
val db_name = "dev_ark"
val set_name = "ark_tables_cdc_metrics"

val ark_db = "ark"
val bkp_db = "bkp_ark"
val tables = sc.getConf.get("spark.driver.tables").split(",")

var finalArray : Array[org.apache.spark.sql.Row] = Array()
tables.foreach { table =>
	var table1 = ark_db + "." + table
	var table2 = bkp_db + "." + table
	println("Comparing the tables " + table1 + " and " + table2)

	var df_ark = spark.table(table1)
	var lineage_colX = df_ark.select("LINEAGE.*").drop("TIMESTAMP","VERSION").columns
	for( z <- 0 to lineage_colX.size-1){
		lineage_colX(z) =  "LINEAGE." + lineage_colX(z)
	}
	val colX = df_ark.drop("LINEAGE").columns ++ lineage_colX
	df_ark = df_ark.withColumn("MODAK_UID", md5(concat(colX.map(x => coalesce(col(x).cast("string"), lit("nirhf84@$%9f4f44"))): _*))).distinct()

	var df_bkp = spark.table(table2)
	var lineage_colY = df_bkp.select("LINEAGE.*").drop("TIMESTAMP","VERSION").columns
	for( z <- 0 to lineage_colY.size-1){
		lineage_colY(z) =  "LINEAGE." + lineage_colY(z)
	}
	val colY = df_bkp.drop("LINEAGE").columns ++ lineage_colY
	df_bkp = df_bkp.withColumn("MODAK_UID", md5(concat(colY.map(x => coalesce(col(x).cast("string"), lit("nirhf84@$%9f4f44"))): _*))).distinct()
    
    var joined_df = spark.emptyDataFrame
    if (table.contains("relationship")){
	joined_df = df_ark.join(df_bkp,df_ark("MODAK_UID")===df_bkp("MODAK_UID"),"full")
			.agg(lit(table1).as("ark_table"),
			     lit(table2).as("prev_ark_table"),
			     count(when(df_ark("MODAK_UID") === df_bkp("MODAK_UID"), 1)).as("matched_count"),
			     count(when(df_ark("MODAK_UID") =!= df_bkp("MODAK_UID") or df_ark("MODAK_UID").isNull or df_bkp("MODAK_UID").isNull, 1)).as("unmatched_count"),
			     count(df_ark("MODAK_UID")).as("ark_rows"),
			     count(df_bkp("MODAK_UID")).as("prev_ark_rows"),
			     count(when(lit(1)===1, 1)).as("total_rows"),
			     count(when(df_ark("MODAK_UID") =!= df_bkp("MODAK_UID") or df_bkp("MODAK_UID").isNull, 1)).as("added_rows"),
			     count(when(df_ark("MODAK_UID") =!= df_bkp("MODAK_UID") or df_ark("MODAK_UID").isNull, 1)).as("deleted_rows"),
			     lit(null).as("updated_rows"))
    }
    else{
        joined_df = df_ark.join(df_bkp,df_ark("ID")===df_bkp("ID"),"full")
			.agg(lit(table1).as("ark_table"),
			     lit(table2).as("prev_ark_table"),
			     count(when(df_ark("MODAK_UID") === df_bkp("MODAK_UID"), 1)).as("matched_count"),
			     count(when(df_ark("MODAK_UID") =!= df_bkp("MODAK_UID") or df_ark("MODAK_UID").isNull or df_bkp("MODAK_UID").isNull, 1)).as("unmatched_count"),
			     count(df_ark("MODAK_UID")).as("ark_rows"),
			     count(df_bkp("MODAK_UID")).as("prev_ark_rows"),
			     count(when(lit(1)===1, 1)).as("total_rows"),
			     count(when(df_bkp("MODAK_UID").isNull, 1)).as("added_rows"),
			     count(when(df_ark("MODAK_UID").isNull, 1)).as("deleted_rows"),
			     count(when(df_ark("MODAK_UID") =!= df_bkp("MODAK_UID"), 1)).as("updated_rows"))
    }
	var result_df = joined_df.withColumn("matched",col("matched_count")*1.0/col("total_rows")*100).withColumn("unmatched",col("unmatched_count")*1.0/col("total_rows")*100)
	finalArray = finalArray :+ result_df.first
	
}

val schema = StructType(Array(
    StructField("ark_table", StringType, true),
    StructField("prev_ark_table", StringType, true),
    StructField("matched_count", LongType, true),
    StructField("unmatched_count", LongType, true),
    StructField("ark_rows", LongType, true),
    StructField("prev_ark_rows", LongType, true),
    StructField("total_rows", LongType, true),
    StructField("added_rows", LongType, true),
    StructField("deleted_rows", LongType, true),
    StructField("updated_rows", LongType, true),
    StructField("matched", DoubleType, true),
    StructField("unmatched", DoubleType, true)
  ))
  
val rdd = sc.parallelize(finalArray.toSeq)
var newDf = spark.createDataFrame(rdd, schema)
newDf = newDf.withColumn("valid_from_ts", current_timestamp()).withColumn("valid_to_ts", to_timestamp(lit("9999-12-31")))
newDf.write.mode("OVERWRITE").parquet("s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name + "_tmp")
if(spark.catalog.tableExists(db_name + "." + set_name)){
    var oldDf = spark.table(db_name + "." + set_name)
    oldDf = oldDf.withColumn("valid_to_ts", when(col("valid_to_ts")===to_timestamp(lit("9999-12-31")), current_timestamp()).otherwise(col("valid_to_ts")))
    oldDf.write.mode("APPEND").parquet("s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name + "_tmp")
}

val finalDf = spark.read.parquet("s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name + "_tmp")
finalDf.coalesce(1).write.mode("OVERWRITE").option("format", "parquet").option("path", "s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
