import json
import boto3
from smart_open import open
import pyspark
import re
import requests
import logging
import json
from pyspark.context import SparkContext
from pyspark.sql import HiveContext, SparkSession
import io
import os
import sys
import pandas as pspd
import traceback
import time

start_time=time.time()
COLUMN_NAMES=['rsid', 'ref_genome','contig','chromosome','spdi_position','spdi_ref_allele','spdi_alt_allele','hgvs_position','hgvs_allele_change','hgvs','variant_type','locus']
chr
batch_size=100000
doAppend=False
batch_count=0
rs_list = []

spark = SparkSession \
    .builder \
    .appName("dbSNP_minimum") \
    .enableHiveSupport() \
    .getOrCreate()


def dbSnpDFOverwrite(rs_list,bucket_name,dest_key,chr):
    rs_list_df = pspd.DataFrame(rs_list, columns = COLUMN_NAMES)
    print('\nChromosome : '+ str(chr)+ ', Df row_count : '+str(rs_list_df.shape[0])+', DF column_count : '+str(rs_list_df.shape[1]))
    try:   
        sparkDF=spark.createDataFrame(rs_list_df)
        dest_write_path = "s3a://"+bucket_name+"/"+dest_key
        sparkDF.write.options(header=True).mode("overwrite").format("csv").save(dest_write_path)
        print('\nChromosome : '+ str(chr)+ ', Data overwritten.')
    except:
        traceback.print_exc()
        print('\nChromosome : '+ str(chr)+ ', Object not created.')
        sys.exit(1)

def dbSnpDFAppend(rs_list,bucket_name,dest_key,chr):	
    rs_list_df = pspd.DataFrame(rs_list, columns = COLUMN_NAMES)
    print('\nChromosome : '+ str(chr)+ ', Df row_count : '+str(rs_list_df.shape[0])+', DF column_count : '+str(rs_list_df.shape[1]))
    try:   
        sparkDF=spark.createDataFrame(rs_list_df)
        dest_write_path = "s3a://"+bucket_name+"/"+dest_key
        sparkDF.write.options(header=True).mode("append").format("csv").save(dest_write_path)
        print('\nChromosome : '+ str(chr)+ ', Data appended.')
    except:
        traceback.print_exc()
        print('\nChromosome : '+ str(chr)+ ', Object not created.')
        sys.exit(1)

def printPlacements(info,rs,type,locus,bucket_name,dest_key):
    '''
    rs genomic positions
    '''
    global chr
    global doAppend
    global batch_count
    global batch_size
    global rs_list
    
    for alleleinfo in info:        
        rs_list_t=[]
        if alleleinfo['is_ptlp'] and \
                len(alleleinfo['placement_annot']
                    ['seq_id_traits_by_assembly']) > 0:
            (assembly_name,spdi_ref, spdi_alt, spdi_pos, seq_id) = ("NULL","NULL", "NULL", "NULL", "NULL")
            assembly_name = (alleleinfo['placement_annot']
                                       ['seq_id_traits_by_assembly']
                                       [0]['assembly_name'])
            for a in alleleinfo['alleles']:
                spdi = a['allele']['spdi']
                if spdi['inserted_sequence'] != spdi['deleted_sequence']:
                    (spdi_ref, spdi_alt, spdi_pos, seq_id) = (spdi['deleted_sequence'],
                                               spdi['inserted_sequence'],
                                               spdi['position'],
                                               spdi['seq_id'])
                    if spdi_alt == "":
                        spdi_alt = "-"
                    if spdi_ref == "":
                        spdi_ref = "-"
                     
                    hgvs = a['hgvs']
                    grp = re.search('^NC_.*:[gm]\.(\d+)([A-Z\-]+>[A-Z\-]+)$', hgvs)

                    grp2 = re.search('^NC_.*:[gm]\.(\d+)(\_\d+(=|del))$', hgvs)

                    grp3 = re.search('^NC_.*:[gm]\.(\d+)(del)$', hgvs)

                    grp4 = re.search('^NC_.*:[gm]\.(\d+)(dup)$', hgvs)

                    grp5 = re.search('^NC_.*:[gm]\.(\d+)([A-Z\-]+\[\d+\])$', hgvs)
                    grp5 = re.search('^NC_.*:[gm]\.(\d+)([\w+\[\d+\]]+)$', hgvs)

                    grp6 = re.search('^NC_.*:[gm]\.(\d+)(\_\d+ins[A-Z]+)$', hgvs)

                    grp7 = re.search('^NC_.*:[gm]\.(\d+)(\_\d+dup+)$', hgvs)

                    grp8 = re.search('^NC_.*:[gm]\.(\d+)(\_\d+[\w+\[\d+\]]+)$', hgvs)

                    if (grp):
                        hgvs_pos = grp.group(1)
                        hgvs_sig = grp.group(2)
                    elif(grp2):
                        hgvs_pos = grp2.group(1)
                        hgvs_sig = grp2.group(2)
                    elif(grp3):
                        hgvs_pos = grp3.group(1)
                        hgvs_sig = grp3.group(2)
                    elif(grp4):
                        hgvs_pos = grp4.group(1)
                        hgvs_sig = grp4.group(2)
                    elif(grp5):
                        hgvs_pos = grp5.group(1)
                        hgvs_sig = grp5.group(2)
                    elif(grp6):
                        hgvs_pos = grp6.group(1)
                        hgvs_sig = grp6.group(2)
                    elif(grp7):
                        hgvs_pos = grp7.group(1)
                        hgvs_sig = grp7.group(2)
                    elif(grp8):
                        hgvs_pos = grp8.group(1)
                        hgvs_sig = grp8.group(2)
                    else:
                        print('\nChromosome : '+ str(chr)+ ', ERROR: Issue with pattern match, alleleinfo is : '+str(alleleinfo)+'  HGVS Value is : ' + str(hgvs))
                        sys.exit(1)
                    rs_list_t = [rs,assembly_name,seq_id,chr,spdi_pos,spdi_ref,spdi_alt,hgvs_pos,hgvs_sig,hgvs,type,locus]
                    rs_list.append(rs_list_t)
                    if(len(rs_list)>=batch_size):
                        if(doAppend==False):
                            batch_count=batch_count+1
                            end_time=time.time()
                            elapsed_time=(end_time-start_time)/60
                            print('\nChromosome : '+ str(chr)+ ', batch: '+str(batch_count)+', Length : '+str(len(rs_list))+', Overwriting data if already exists'+', Time Elapsed : ' + str(elapsed_time) + ' Mins ')
                            dbSnpDFOverwrite(rs_list,bucket_name,dest_key,chr)
                            doAppend=True
                            rs_list=[]
                        elif(doAppend==True):
                            batch_count=batch_count+1
                            end_time=time.time()
                            elapsed_time=(end_time-start_time)/60
                            print('\nChromosome : '+ str(chr)+ ', batch: '+str(batch_count)+', Length : '+str(len(rs_list))+', Appending data'+', Time Elapsed : ' + str(elapsed_time) + ' Mins ')
                            dbSnpDFAppend(rs_list,bucket_name,dest_key,chr)
                            rs_list=[]



def dbSNPparsing(file,session,bucket_name,destination_prefix):
    s3 = session.resource('s3')
    global rs_list
    global doAppend
    global batch_count
    global chr
    file_name = re.search("[ \w-]+?(?=\.json)", file).group()
    chr=re.search("(?<=refsnp-chr)\S+", file_name).group()
    dest_key = destination_prefix+file_name+'_staging.csv'
    with open(file, transport_params={'session': s3}) as f_in:
        for line in f_in:
            rs_obj = json.loads(line)
            locus = ""
            try:
                locus = rs_obj['primary_snapshot_data']["allele_annotations"][0]["assembly_annotation"][0]["genes"][0]["locus"]
            except:
                pass
            if 'primary_snapshot_data' in rs_obj:
                printPlacements(
                    rs_obj['primary_snapshot_data']['placements_with_allele'],"rs" + rs_obj['refsnp_id'], rs_obj['primary_snapshot_data']['variant_type'],locus,bucket_name,dest_key)
    if(len(rs_list)!=0):
        if(doAppend==False):
            batch_count=batch_count+1
            print('\nChromosome : '+ str(chr)+ ', batch: '+str(batch_count)+', Length : '+str(len(rs_list))+', Overwriting data if already exists. END OF THE LOOP')
            dbSnpDFOverwrite(rs_list,bucket_name,dest_key,chr)
        else:
            batch_count=batch_count+1
            print('\nChromosome : '+ str(chr)+ ', batch: '+str(batch_count)+', Length : '+str(len(rs_list))+', Appending data. END OF THE LOOP')
            dbSnpDFAppend(rs_list,bucket_name,dest_key,chr) 


if __name__ == "__main__":
    args = spark.conf.get("spark.driver.args").split(" ")
    environment=args[0]
    file_name = args[1]
    bucket_name = 'arch-'+environment+'-datalake'
    destination_prefix = "data/unstructured/rsa/Genomics_dbSNP/dbSNP_STAGING_V0.2/"
    source_prefix = "data/unstructured/rsa/Genomics_dbSNP/snp/latest_release/JSON/"
    session = boto3.Session()
    file_path=source_prefix+file_name
    s3 = session.resource('s3') 
    bucket_name = 'arch-'+environment+'-datalake'
    bucket = s3.Bucket(bucket_name)
    print("source bucket name : "+bucket_name+", source prefix : "+file_path+"\n")
    for object_summary in bucket.objects.filter(Prefix=file_path):
        file ="s3a://"+bucket_name+"/"+object_summary.key
        print("Parsing "+file)
        dbSNPparsing(file,session,bucket_name,destination_prefix)
    end_time=time.time()
    elapsed_time=(end_time-start_time)/60
    print('\nChromosome : '+ str(chr)+ ', Time Elapsed : ' + str(elapsed_time) + ' Mins ')
    spark.stop()
    sys.exit(0)
