import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;


val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "dbsnp"
val set_name = "dbsnp_minimum"
val almaren = Almaren("dbSNP INT")

val csv_df = spark.read.option("header","true").option("inferSchema","true").csv("s3a://arch-"+environment+"-datalake/data/unstructured/rsa/Genomics_dbSNP/dbSNP_STAGING_V0.2/refsnp-chr*_staging.csv/*.csv")


csv_df.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name);
