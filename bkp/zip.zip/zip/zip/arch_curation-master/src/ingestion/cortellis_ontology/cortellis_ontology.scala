import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL;
import org.apache.spark.sql.{AnalysisException, Column, DataFrame, SparkSession}
import org.apache.hadoop.fs.{FileSystem, Path}
import java.util.zip.{ZipEntry, ZipOutputStream, ZipInputStream}
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ListBuffer
import java.net.URI
import org.apache.hadoop.conf.Configuration
import java.io.{File, FileInputStream, FileOutputStream}
import org.apache.spark.sql.types._


val args = sc.getConf.get("spark.driver.args").split("\\s+")
val bucket_name = args(0)
val data_store = args(1)
val db_name = args(2)
val set_name = args(3)
val almaren = Almaren(set_name)

def zipFile(out: String,
            basePath: String,
            fsn: FileSystem,
            zip: ZipInputStream) = {
  zip.getNextEntry() 
  val out_stream = fsn.create(new Path(out),true)
  val buf = new scala.Array[Byte](1024)
  var len = zip.read(buf)
  while (len >= 0) {
    out_stream.write(buf, 0, len)
    len = zip.read(buf)
  }
  out_stream.close
  zip.closeEntry()
}
def zip(inputPath: String, outputPath: String) = {
  var fileList: ListBuffer[String] = new ListBuffer()
  val fileSystem = FileSystem
                  .get(URI.create(inputPath), new Configuration())
  print(inputPath)
  val fileStatusListIterator =
    fileSystem.listFiles(new Path(inputPath), true)
  val inputStream =
    fileSystem.open(new Path(s"$inputPath"))
  val zip = new ZipInputStream(inputStream)
  zipFile(outputPath, inputPath, fileSystem, zip)
  zip.close()
}
  
  
val input_path = s"s3a://"+bucket_name+"/data/unstructured/rsa/Genomics_Clarivate_Cortellis_Ontology/CortellisOntology.zip"
val output_path = s"s3a://"+bucket_name+"/data/unstructured/rsa/Genomics_Clarivate_Cortellis_Ontology_unzip/CortellisOntology.xml"
zip(input_path, output_path)

val df = spark.read.format("com.databricks.spark.xml").option("rowTag", "Entity").load("s3a://"+bucket_name+"/data/unstructured/rsa/Genomics_Clarivate_Cortellis_Ontology_unzip/CortellisOntology.xml")

val ChildTermSchema = "array<struct<Source:string,VALUE:string>>"

val EntityRelationshipSchema = "array<struct<ENTITY_ID:string,ENTITY_TYPE:string,MPS:bigint,RELATIONSHIP_TYPE:string,Source:string,VALUE:string>>"

val NameSchema = "array<struct<DATE_ADDED: string,DESINATION: string,DESTINATION: string,ENTITY_SUBTYPE: string,NAME_TYPE: string,ORIGIN: string,TERM_ID: string,TERM_TYPE: string,VALUE: string>>"

val ParentTermSchema = "array<struct<Source:string,VALUE:string>>"

val TermMappingSchema = "array<struct<MapType: string,Organism: string,Source: string,VALUE: string,Validation: string>>"

val df2 = df.select($"ChildTerm".cast(ChildTermSchema), $"EntityRelationship".cast(EntityRelationshipSchema), $"EntityType", $"Name".cast(NameSchema), $"ParentTerm".cast(ParentTermSchema), $"TermMapping".cast(TermMappingSchema), $"TreeCode")
  
df2.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://"+bucket_name+"/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name);

