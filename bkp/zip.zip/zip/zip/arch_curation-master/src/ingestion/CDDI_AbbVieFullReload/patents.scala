import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL;
import org.apache.spark.sql.{AnalysisException, Column, DataFrame, SparkSession}
import org.apache.hadoop.fs.{FileSystem, Path}
import java.util.zip.{ZipEntry, ZipOutputStream, ZipInputStream}
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ListBuffer
import java.net.URI
import org.apache.hadoop.conf.Configuration
import java.io.{File, FileInputStream, FileOutputStream}
import org.apache.spark.sql.types._
import java.util.Calendar

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val bucket_name = args(0)
val data_store = args(1)
val db_name = args(2)
val set_name = args(3)
val almaren = Almaren(set_name)

val cal = Calendar.getInstance()
val Year = cal.get(Calendar.YEAR)
val Month = cal.get(Calendar.MONTH) + 1

val CDDI_Latest = "CDDI-AbbVie_Full_Reload-" + Year + Month + "01"

val df_old = spark.read
  .format("com.databricks.spark.xml")
  .option("inferSchema", true)
  .option("samplingRatio", 0.1)
  .option("rowTag", "Patent")
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/CDDI-AbbVie_Full_Reload-20221101/patents.xml"
  )

val df = spark.read
  .format("com.databricks.spark.xml")
  .option("inferSchema", true)
  .option("samplingRatio", 0.1)
  .option("rowTag", "Patent")
  .schema(df_old.schema)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/" + CDDI_Latest + "/patents.xml"
  )
val df2 = df.repartition(1000)

df2.printSchema()

val df3 = df2
  .withColumn(
    "Applicant_NNN",
    when(
      $"Applicant".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("string"),
          lit(null).cast("string"),
          lit(null).cast("long"),
          lit(null).cast("string")
        )
      ).cast(
        "array<struct<_VALUE:string,_city:string,_country_region:string,_id:long,_state_province:string>>"
      )
    ).otherwise(col("Applicant"))
  )
  .withColumn(
    "Conditions_NNN",
    when(
      $"Conditions".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string"))).cast(
        "array<struct<_VALUE:string,_id:string>>"
      )
    ).otherwise(col("Conditions.Condition"))
  )
  .withColumn(
    "Inventor_NNN",
    when(
      $"Inventor".isNull,
      array(lit(null).cast("string")).cast("array<string>")
    ).otherwise(col("Inventor"))
  )
  .withColumn(
    "Patents_NNN",
    when(
      $"Patents".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("string"),
          lit(null).cast("string"),
          lit(null).cast("long")
        )
      ).cast(
        "array<struct<_VALUE:string,_basic_patent:string,_country:string,_publication_date:long>>"
      )
    ).otherwise(col("Patents.Patent"))
  )
  .withColumn(
    "Priority_Data_NNN",
    when(
      $"Priority_Data".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("string"),
          lit(null).cast("long"),
          lit(null).cast("long")
        )
      ).cast(
        "array<struct<_VALUE:string,_country:string,_priority_date:long,_year:long>>"
      )
    ).otherwise(col("Priority_Data.Priority"))
  )
  .withColumn(
    "Related_Biomarker_Uses_NNN",
    when(
      $"Related_Biomarker_Uses".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string"))).cast(
        "array<struct<_VALUE:string,_id:string>>"
      )
    ).otherwise(col("Related_Biomarker_Uses.Related_Biomarker_Use_Record"))
  )
  .withColumn(
    "Related_Biomarkers_NNN",
    when(
      $"Related_Biomarkers".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long"))).cast(
        "array<struct<_VALUE:string,_id:long>>"
      )
    ).otherwise(col("Related_Biomarkers.Related_Biomarker_Record"))
  )
  .withColumn(
    "Related_Experimental_Models_NNN",
    when(
      $"Related_Experimental_Models".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long"))).cast(
        "array<struct<_VALUE:string,_id:long>>"
      )
    ).otherwise(
      col("Related_Experimental_Models.Related_Experimental_Model_Record")
    )
  )
  .withColumn(
    "Related_Experimental_Pharmacology_NNN",
    when(
      $"Related_Experimental_Pharmacology".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long"))).cast(
        "array<struct<_VALUE:string,_id:long>>"
      )
    ).otherwise(
      col(
        "Related_Experimental_Pharmacology.Related_Experimental_Pharmacology_Record"
      )
    )
  )
  .withColumn(
    "Related_GenesTargets_NNN",
    when(
      $"Related_GenesTargets".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string"))).cast(
        "array<struct<_VALUE:string,_id:string>>"
      )
    ).otherwise(col("Related_GenesTargets.Related_GeneTarget_Record"))
  )
  .withColumn(
    "Related_Lead_Compounds_NNN",
    when(
      $"Related_Lead_Compounds".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_entry_number:long>>")
    ).otherwise(col("Related_Lead_Compounds.Related_Lead_Compound_Record"))
  )
  .withColumn(
    "Related_Organizations_NNN",
    when(
      $"Related_Organizations".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(col("Related_Organizations.Related_Organization_Record"))
  )
  .withColumn(
    "Related_Pharmacokinetics_NNN",
    when(
      $"Related_Pharmacokinetics".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(col("Related_Pharmacokinetics.Related_Pharmacokinetics_Record"))
  )
  .withColumn(
    "Related_Products_NNN",
    when(
      $"Related_Products".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_entry_number:long>>")
    ).otherwise(col("Related_Products.Related_Product_Record"))
  )
  .withColumn(
    "Subject_Matters_NNN",
    when(
      $"Subject_Matters".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(col("Subject_Matters.Subject_Matter"))
  )
df3.printSchema()

val df4 = df3
  .withColumn("Exp_Inventor", explode_outer($"Inventor_NNN"))
  .withColumn("Exp_Priority_Data", explode_outer($"Priority_Data_NNN"))
  .withColumn("Exp_Applicant", explode_outer($"Applicant_NNN"))
  .withColumn(
    "zip_Arr",
    explode_outer(
      arrays_zip(
        $"Applicant_NNN",
        $"Conditions_NNN",
        $"Patents_NNN",
        $"Related_Biomarker_Uses_NNN",
        $"Related_Biomarkers_NNN",
        $"Related_Experimental_Models_NNN",
        $"Related_Experimental_Pharmacology_NNN",
        $"Related_GenesTargets_NNN",
        $"Related_Lead_Compounds_NNN",
        $"Related_Organizations_NNN",
        $"Related_Pharmacokinetics_NNN",
        $"Related_Products_NNN",
        $"Subject_Matters_NNN"
      )
    )
  )
  .select(
    $"_id".alias("internal_patent_family_id"),
    $"CDDI_Link",
    $"Last_Updated_Date",
    $"Available_Since_Date",
    $"Drug_Discovery_Abstract",
    $"Title",
    $"Original_Abstract",
    $"zip_Arr.Applicant_NNN",
    $"zip_Arr.Conditions_NNN",
    $"zip_Arr.Patents_NNN",
    $"zip_Arr.Related_Biomarker_Uses_NNN",
    $"zip_Arr.Related_Biomarkers_NNN",
    $"zip_Arr.Subject_Matters_NNN",
    $"zip_Arr.Related_GenesTargets_NNN",
    $"zip_Arr.Related_Organizations_NNN",
    $"zip_Arr.Related_Experimental_Pharmacology_NNN",
    $"zip_Arr.Related_Pharmacokinetics_NNN",
    $"zip_Arr.Related_Experimental_Models_NNN",
    $"Exp_Applicant._VALUE".alias("Applicant_Name"),
    $"Exp_Applicant._id".alias("Applicant_id"),
    $"Exp_Applicant._country_region".alias("Applicant_Country"),
    $"Exp_Applicant._state_province".alias("Applicant_State"),
    $"Exp_Inventor".alias("Inventor"),
    $"Exp_Priority_Data._VALUE".alias("Priority_NUMBER"),
    $"Exp_Priority_Data._country".alias("Priority_Country"),
    $"Exp_Priority_Data._year".alias("Priority_Year"),
    $"Exp_Priority_Data._priority_date".alias("Priority_Date")
  )

df4.printSchema()
val df5 = df4
  .groupBy(
    $"internal_patent_family_id",
    $"CDDI_Link",
    $"Last_Updated_Date",
    $"Available_Since_Date",
    $"Inventor",
    $"Drug_Discovery_Abstract",
    $"Title",
    $"Original_Abstract",
    $"Applicant_Name",
    $"Applicant_id",
    $"Applicant_Country",
    $"Applicant_State",
    $"Priority_NUMBER",
    $"Priority_Country",
    $"Priority_Year",
    $"Priority_Date"
  )
  .agg(
    concat_ws(";", collect_list($"Patents_NNN._VALUE")).alias("Patent_Number"),
    concat_ws(";", collect_list($"Patents_NNN._publication_date"))
      .alias("Publication_Date"),
    concat_ws(";", collect_list($"Patents_NNN._basic_patent"))
      .alias("Basic_Patent"),
    concat_ws(";", collect_list($"Patents_NNN._country"))
      .alias("Patents_Country"),
    concat_ws(";", collect_list($"Subject_Matters_NNN._VALUE"))
      .alias("Subject_Matters"),
    concat_ws(";", collect_list($"Conditions_NNN._VALUE")).alias("Conditions"),
    concat_ws(";", collect_list($"Related_Biomarkers_NNN._id"))
      .alias("Biomarkers"),
    concat_ws(";", collect_list($"Related_Biomarker_Uses_NNN._id"))
      .alias("Biomarker_Uses"),
    concat_ws(";", collect_list($"Related_GenesTargets_NNN._id"))
      .alias("Genes_And_Targets"),
    concat_ws(";", collect_list($"Related_Organizations_NNN._id"))
      .alias("Organizations"),
    concat_ws(";", collect_list($"Related_Experimental_Pharmacology_NNN._id"))
      .alias("Experimental_Pharmacology"),
    concat_ws(";", collect_list($"Related_Pharmacokinetics_NNN._id"))
      .alias("Pharmacokinetics"),
    concat_ws(";", collect_list($"Related_Experimental_Models_NNN._id"))
      .alias("Experimental_Models")
  )
df5.printSchema()
val df6 = df5.repartition(1000)
df6.write
  .mode("OVERWRITE")
  .option("format", "parquet")
  .option(
    "path",
    "s3a://" + bucket_name + "/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name
  )
  .saveAsTable(db_name + "." + set_name);
