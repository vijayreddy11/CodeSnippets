from concurrent.futures import ThreadPoolExecutor
import threading
from time import sleep
import zipfile
from io import BytesIO
import boto3
import argparse
import requests
import logging
import re
from datetime import date
from pyspark.sql import SparkSession

spark = SparkSession \
    .builder \
    .appName("CDDI_AbbVieFullReload") \
    .enableHiveSupport() \
    .getOrCreate()

class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())


def unzip(s3_resource,bucket,file_key,src_prefix,dest_key):
    zip_obj = s3_resource.Object(bucket_name=bucket, key=file_key)
    print (str(threading.get_ident()) + ' : source : '+str(zip_obj.key))
    dest_path = zip_obj.key.replace(src_prefix,dest_key,1).replace('.zip','',1).replace('.ZIP','',1).replace('.ZIP','',1).replace('//','/',1)
    buffer = BytesIO(zip_obj.get()["Body"].read())

    z = zipfile.ZipFile(buffer)

    for filename in z.namelist():
        file_info = z.getinfo(filename)
        dest_file_key = dest_path + '/' + f'{filename}'
        s3_resource.meta.client.upload_fileobj(
            z.open(filename),
            Bucket=bucket,
            Key=dest_file_key)
        print(str(threading.get_ident()) + ' : Unzipped_key : '+dest_file_key )


if __name__ == '__main__':
    args = spark.conf.get("spark.driver.args").split(" ")
    token = spark.conf.get("spark.nabu.token")
    endpoint = spark.conf.get("spark.nabu.fireshots_url")
    print(args)
    bucket = args[0]
    src_cred_id = args[1]
    src_cred_type = args[2]
    file_key_para = args[3]
    todays_date = date.today()
    file_key= file_key_para+"CDDI-AbbVie_Full_Reload-"+str(todays_date.year)+str(f"{todays_date.month:02d}")+"01.zip"
    
    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(token, src_cred_id, src_cred_type, endpoint)

    access_id = dict_pass["data"]["access_id"]
    secret_access_key = dict_pass["data"]["secret_access_key"]
    
    print("successfully collected the credentials")

    src_prefix = 'data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/'
    dest_key = 'data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/'

    session = boto3.Session(
        aws_access_key_id=access_id,
        aws_secret_access_key=secret_access_key
    )
    
    print("successfully created the s3 session..................")
    s3_resource = session.resource('s3')
    print("collected the keys of the zipped content...................")
    print("started unzipping the content...................")
    unzip(s3_resource,bucket,file_key,src_prefix,dest_key)
     
    print("....................END of the code...................")

    
