import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL;
import org.apache.spark.sql.{AnalysisException, Column, DataFrame, SparkSession}
import org.apache.hadoop.fs.{FileSystem, Path}
import java.util.zip.{ZipEntry, ZipOutputStream, ZipInputStream}
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ListBuffer
import java.net.URI
import org.apache.hadoop.conf.Configuration
import java.io.{File, FileInputStream, FileOutputStream}
import org.apache.spark.sql.types._
import java.util.Calendar
import java.text.SimpleDateFormat

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val bucket_name = args(0)
val data_store = args(1)
val db_name = args(2)
val set_name = args(3)
val almaren = Almaren(set_name)

val cal = Calendar.getInstance()
val Year = cal.get(Calendar.YEAR)
val Month =cal.get(Calendar.MONTH )+1
val dateFormat = new SimpleDateFormat("MM")
val month = dateFormat.format(Month)

val CDDI_Latest= "CDDI-AbbVie_Full_Reload-"+Year+month+"01"

val df_old = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "Targetscapes")
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/CDDI-AbbVie_Full_Reload-20221101/targetscapes.xml"
  )

val df = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "Targetscapes")
  .schema(df_old.schema)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/" + CDDI_Latest + "/targetscapes.xml"
  )

val df2 = df.withColumn("targetscape", explode_outer($"Targetscape"))
val df3 = df2
  .withColumn("targetscape_condition", explode_outer($"targetscape.Condition"))
  .select(
    $"targetscape.Name".alias("Targetscapes_Title"),
    $"targetscape._id".alias("Targetscapes_Id"),
    $"targetscape_condition._VALUE".alias("Conditions_Value"),
    $"targetscape_condition._id".alias("Conditions_Id")
  )
df3.write
  .mode("OVERWRITE")
  .option("format", "parquet")
  .option(
    "path",
    "s3a://" + bucket_name + "/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name
  )
  .saveAsTable(db_name + "." + set_name);
