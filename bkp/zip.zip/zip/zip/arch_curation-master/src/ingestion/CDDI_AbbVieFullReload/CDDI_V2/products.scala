import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL;
import org.apache.spark.sql.{AnalysisException, Column, DataFrame, SparkSession}
import org.apache.hadoop.fs.{FileSystem, Path}
import java.util.zip.{ZipEntry, ZipOutputStream, ZipInputStream}
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ListBuffer
import java.net.URI
import org.apache.hadoop.conf.Configuration
import java.io.{File, FileInputStream, FileOutputStream}
import org.apache.spark.sql.types._
import java.util.Calendar
import java.text.SimpleDateFormat

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val bucket_name = args(0)
val data_store = args(1)
val db_name = args(2)
val set_name = args(3)
val almaren = Almaren(set_name)

val cal = Calendar.getInstance()
val Year = cal.get(Calendar.YEAR)
val Month =cal.get(Calendar.MONTH )+1
val dateFormat = new SimpleDateFormat("MM")
val month = dateFormat.format(Month)

val CDDI_Latest= "CDDI-AbbVie_Full_Reload-"+Year+month+"01"

val dffile = spark.read
  .format("com.databricks.spark.xml")
  .option("inferSchema", true)
  .option("samplingRatio", 0.01)
  .option("rowTag", "Product")
  .option("valueTag", "value")
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/"+CDDI_Latest+"/products.xml"
  )

val df = dffile.repartition(1000)
df.printSchema()
val finaldf2 = df
  .withColumnRenamed("_entry_number", "Entry_Number")

val finaldf = finaldf2.repartition(1000)
finaldf.printSchema

finaldf.write
  .mode("OVERWRITE")
  .option("format", "parquet")
  .option(
    "path",
    "s3a://" + bucket_name + "/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name
  )
  .saveAsTable(db_name + "." + set_name);
