import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL;
import org.apache.spark.sql.{AnalysisException, Column, DataFrame, SparkSession}
import org.apache.hadoop.fs.{FileSystem, Path}
import java.util.zip.{ZipEntry, ZipOutputStream, ZipInputStream}
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ListBuffer
import java.net.URI
import org.apache.hadoop.conf.Configuration
import java.io.{File, FileInputStream, FileOutputStream}
import org.apache.spark.sql.types._
import java.util.Calendar
import java.text.SimpleDateFormat

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val bucket_name = args(0)
val data_store = args(1)
val db_name = args(2)
val set_name = args(3)
val almaren = Almaren(set_name)

val cal = Calendar.getInstance()
val Year = cal.get(Calendar.YEAR)
val Month =cal.get(Calendar.MONTH )+1
val dateFormat = new SimpleDateFormat("MM")
val month = dateFormat.format(Month)

val CDDI_Latest= "CDDI-AbbVie_Full_Reload-"+Year+month+"01"

val df_old = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "Literature")
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/CDDI-AbbVie_Full_Reload-20221101/references.xml"
  )

val df = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "Literature")
  .schema(df_old.schema)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/" + CDDI_Latest + "/references.xml"
  )

val df2 = df.repartition(1000)
df2.printSchema()
val df3 = df2.select(
  $"AbstractNumber".alias("Abstractnumber"),
  $"Authors.Author".alias("Authors"),
  $"Conference_Information.City".alias("City"),
  $"Conference_Information.Country._VALUE".alias("Country"),
  $"Conference_Information.Edition".alias("Edition_Number"),
  $"Conference_Information.Name._VALUE".alias("Source_Name"),
  $"Conference_Information.conferenceEndDate".alias("End_Date"),
  $"Conference_Information.conferenceStartDate".alias("Start_Date"),
  $"DOI",
  $"ISBN",
  $"ISSN",
  $"Issue",
  $"Page",
  $"Publication_Types.Type".alias("Publication_type"),
  $"Publisher",
  $"Publishing_Year",
  $"Pubmed_id",
  $"Pubmed_url",
  $"Texts.Text",
  $"Title",
  $"Volume",
  $"_id".alias("Internal_Reference_Id"),
  concat(
    col("Publication._VALUE"),
    lit('\u0028'),
    col("Publication._Id"),
    lit('\u0029')
  ).alias("Source_Name_with_id")
)
val finaldf = df3.repartition(1000)
finaldf.printSchema()

finaldf.write
  .mode("OVERWRITE")
  .option("format", "parquet")
  .option(
    "path",
    "s3a://" + bucket_name + "/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name
  )
  .saveAsTable(db_name + "." + set_name)
