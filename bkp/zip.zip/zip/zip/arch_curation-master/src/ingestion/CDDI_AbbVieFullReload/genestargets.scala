//PDB Identfier is missing in schema

import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL;
import org.apache.spark.sql.{AnalysisException, Column, DataFrame, SparkSession}
import org.apache.hadoop.fs.{FileSystem, Path}
import java.util.zip.{ZipEntry, ZipOutputStream, ZipInputStream}
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ListBuffer
import java.net.URI
import org.apache.hadoop.conf.Configuration
import java.io.{File, FileInputStream, FileOutputStream}
import org.apache.spark.sql.types._
import java.util.Calendar

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val bucket_name = args(0)
val data_store = args(1)
val db_name = args(2)
val set_name = args(3)
val almaren = Almaren(set_name)

val cal = Calendar.getInstance()
val Year = cal.get(Calendar.YEAR)
val Month = cal.get(Calendar.MONTH) + 1

val CDDI_Latest = "CDDI-AbbVie_Full_Reload-" + Year + Month + "01"

val original_df_old = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "GeneTarget")
  .option("inferSchema", true)
  .option("samplingRatio", 0.0001)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/CDDI-AbbVie_Full_Reload-20221101/genestargets.xml"
  )

val original_df01 = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "GeneTarget")
  .option("inferSchema", true)
  .option("samplingRatio", 0.0001)
  .schema(original_df_old.schema)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/" + CDDI_Latest + "/genestargets.xml"
  )

val original_df = original_df01.repartition(10000)

original_df.printSchema

val description_df_old = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "GeneTarget")
  .option("inferSchema", true)
  .option("samplingRatio", 0.1)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/CDDI-AbbVie_Full_Reload-20221101/genestargets.xml"
  )

val description_df = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "GeneTarget")
  .option("inferSchema", true)
  .option("samplingRatio", 0.1)
  .schema(description_df_old.schema)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/" + CDDI_Latest + "/genestargets.xml"
  )

val description_df2 = description_df.select(
  $"_id".alias("description_Genes_and_Targets_Internal_ID"),
  $"Description"
)

val genes_targets_df = original_df
  .withColumn(
    "External_Identifiers_type",
    concat_ws(
      ",",
      when(col("External_Identifiers.EMBL").isNotNull, "EMBL")
        .otherwise(lit("null")),
      when(col("External_Identifiers.Ensembl_Gene").isNotNull, "Ensembl_Gene")
        .otherwise(lit("null")),
      when(
        col("External_Identifiers.Ensembl_Protein").isNotNull,
        "Ensembl_Protein"
      ).otherwise(lit("null")),
      when(
        col("External_Identifiers.Ensembl_Transcript").isNotNull,
        "Ensembl_Transcript"
      ).otherwise(lit("null")),
      when(
        col("External_Identifiers.Entrez_Gene_Id").isNotNull,
        "Entrez_Gene_Id"
      ).otherwise(lit("null")),
      when(col("External_Identifiers.HUGO").isNotNull, "HUGO")
        .otherwise(lit("null")),
      when(
        col("External_Identifiers.Human_Protein_Atlas").isNotNull,
        "Human_Protein_Atlas"
      ).otherwise(lit("null")),
      when(col("External_Identifiers.Kegg").isNotNull, "Kegg")
        .otherwise(lit("null")),
      when(col("External_Identifiers.OMIM").isNotNull, "OMIM")
        .otherwise(lit("null")),
      when(col("External_Identifiers.Uniprot_Id").isNotNull, "Uniprot_Id")
        .otherwise(lit("null"))
    )
  )
  .withColumn(
    "External_Identifiers_Id",
    concat_ws(
      ",",
      when(
        col("External_Identifiers.EMBL").isNotNull,
        col("External_Identifiers.EMBL")
      ).otherwise(lit("null")),
      when(
        col("External_Identifiers.Ensembl_Gene").isNotNull,
        col("External_Identifiers.Ensembl_Gene")
      ).otherwise(lit("null")),
      when(
        col("External_Identifiers.Ensembl_Protein").isNotNull,
        col("External_Identifiers.Ensembl_Protein")
      ).otherwise(lit("null")),
      when(
        col("External_Identifiers.Ensembl_Transcript").isNotNull,
        col("External_Identifiers.Ensembl_Transcript")
      ).otherwise(lit("null")),
      when(
        col("External_Identifiers.Entrez_Gene_Id").isNotNull,
        col("External_Identifiers.Entrez_Gene_Id")
      ).otherwise(lit("null")),
      when(
        col("External_Identifiers.HUGO").isNotNull,
        col("External_Identifiers.HUGO")
      ).otherwise(lit("null")),
      when(
        col("External_Identifiers.Human_Protein_Atlas").isNotNull,
        col("External_Identifiers.Human_Protein_Atlas")
      ).otherwise(lit("null")),
      when(
        col("External_Identifiers.Kegg").isNotNull,
        col("External_Identifiers.Kegg")
      ).otherwise(lit("null")),
      when(
        col("External_Identifiers.OMIM").isNotNull,
        col("External_Identifiers.OMIM")
      ).otherwise(lit("null")),
      when(
        col("External_Identifiers.Uniprot_Id").isNotNull,
        col("External_Identifiers.Uniprot_Id")
      ).otherwise(lit("null"))
    )
  )
  .withColumn(
    "Targetscapes_explode",
    explode_outer($"Related_Targetscapes.Related_Targetscape_Record")
  )
  .select(
    concat_ws(
      "/",
      col("Targetscapes_explode._id"),
      col("Targetscapes_explode._VALUE")
    ).as("Targetscapes"),
    $"_id".alias("Genes_and_Targets_Internal_ID"),
    $"CDDI_Link",
    $"Available_Since",
    $"Last_Updated_Date",
    $"Name",
    $"GeneSymbol",
    $"Synonyms.Synonym".alias("Synonyms"),
    $"Organism",
    $"Metacore_Id",
    $"Transcript_Isoforms_Information.Transcript_Isoform_Information.Ref_Seq_Transcript"
      .alias("ref_seq_transcript"),
    $"Transcript_Isoforms_Information.Transcript_Isoform_Information.Protein_Name"
      .alias("protein_name"),
    $"Transcript_Isoforms_Information.Transcript_Isoform_Information.Ref_Seq_Protein"
      .alias("ref_seq_protein"),
    $"Transcript_Isoforms_Information.Transcript_Isoform_Information.EC_Classification"
      .alias("EC_Classification"),
    $"Drug_Targets",
    $"External_Identifiers_type",
    $"External_Identifiers_Id"
  )

val genes_targets_df2 = genes_targets_df
  .withColumn(
    "Drug_Targets_explode",
    explode_outer($"Drug_Targets.Drug_Target")
  )
  .select(
    $"Drug_Targets_explode.Mechanism_Of_Action._VALUE"
      .alias("Mechanism_Of_Action"),
    $"Drug_Targets_explode.Target_Type".alias("Target_Type"),
    $"Drug_Targets_explode.Related_Products.Related_Product_Record"
      .alias("Drugs_and_Biologics2"),
    $"Targetscapes",
    $"Genes_and_Targets_Internal_ID",
    $"CDDI_Link",
    $"Available_Since",
    $"Last_Updated_Date",
    $"Name",
    $"GeneSymbol",
    $"Synonyms",
    $"Organism",
    $"Metacore_Id",
    $"ref_seq_transcript",
    $"protein_name",
    $"ref_seq_protein",
    $"EC_Classification",
    $"External_Identifiers_type",
    $"External_Identifiers_Id"
  )

val genes_targets_df3 = genes_targets_df2
  .withColumn(
    "Drugs_and_Biologics_explode",
    explode_outer($"Drugs_and_Biologics2")
  )
  .select(
    concat_ws(
      "/",
      col("Drugs_and_Biologics_explode._VALUE"),
      col("Drugs_and_Biologics_explode._entry_number")
    ).as("Drugs_and_Biologics"),
    $"Mechanism_Of_Action",
    $"Target_Type",
    $"Targetscapes",
    $"Genes_and_Targets_Internal_ID",
    $"CDDI_Link",
    $"Available_Since",
    $"Last_Updated_Date",
    $"Name",
    $"GeneSymbol",
    $"Synonyms",
    $"Organism",
    $"Metacore_Id",
    $"ref_seq_transcript",
    $"protein_name",
    $"ref_seq_protein",
    $"EC_Classification",
    $"External_Identifiers_type",
    $"External_Identifiers_Id"
  )

val Drug_Condition_Phase_Development_Combined_df = original_df
  .withColumn(
    "Condition_Highest_Phase_NNN",
    when(
      $"Drug_Condition_Phase_Development.Condition_Highest_Phase".isNull,
      array(
        struct(
          struct(lit(null).cast("string"), lit(null).cast("bigint")),
          lit(null).cast("string")
        )
      ).cast(
        "array<struct<Condition:struct<_VALUE:string,_id:bigint>,Highest_Phase:string>>"
      )
    ).otherwise(col("Drug_Condition_Phase_Development.Condition_Highest_Phase"))
  )
  .withColumn(
    "Condition_Highest_Phase_UAD_NNN",
    when(
      $"Drug_Condition_Phase_Development.Condition_Highest_Phase_UAD".isNull,
      array(
        struct(
          struct(lit(null).cast("string"), lit(null).cast("bigint")),
          lit(null).cast("string")
        )
      ).cast(
        "array<struct<Condition:struct<_VALUE:string,_id:bigint>,Highest_Phase_UAD:string>>"
      )
    ).otherwise(
      col("Drug_Condition_Phase_Development.Condition_Highest_Phase_UAD")
    )
  )

val Drug_Condition_Phase_Development_Combined_zip_df =
  Drug_Condition_Phase_Development_Combined_df.withColumn(
    "zip_Arr",
    explode_outer(
      arrays_zip(
        $"Condition_Highest_Phase_NNN",
        $"Condition_Highest_Phase_UAD_NNN"
      )
    )
  )

val Drug_Condition_Phase_Development_df =
  Drug_Condition_Phase_Development_Combined_zip_df
    .groupBy($"_id".alias("Drug_Genes_and_Targets_Internal_ID"))
    .agg(
      concat_ws(
        ";",
        collect_list($"zip_Arr.Condition_Highest_Phase_NNN.Highest_Phase")
      ).alias("Highest_Phase"),
      concat_ws(
        ";",
        collect_list(
          $"zip_Arr.Condition_Highest_Phase_UAD_NNN.Highest_Phase_UAD"
        )
      ).alias("Highest_Phase_UAD"),
      concat_ws(
        ";",
        collect_list(
          $"zip_Arr.Condition_Highest_Phase_UAD_NNN.Condition._VALUE"
        )
      ).alias("Highest_Phase_UAD_Condition"),
      concat_ws(
        ";",
        collect_list($"zip_Arr.Condition_Highest_Phase_NNN.Condition._VALUE")
      ).alias("Highest_Phase_Condition")
    )

val Combined_df = original_df
  .withColumn(
    "Other_Related_Conditions_NNN",
    when(
      $"Other_Related_Conditions".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long"))).cast(
        "array<struct<_VALUE:string,_id:long>>"
      )
    ).otherwise(col("Other_Related_Conditions.Condition"))
  )
  .withColumn(
    "Related_GenesTargets_NNN",
    when(
      $"Related_GenesTargets".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string"))).cast(
        "array<struct<_VALUE:string,_id:string>>"
      )
    ).otherwise(col("Related_GenesTargets.Related_GeneTarget_Record"))
  )
  .withColumn(
    "Related_Biomarkers_NNN",
    when(
      $"Related_Biomarkers".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string"))).cast(
        "array<struct<_VALUE:string,_id:string>>"
      )
    ).otherwise(col("Related_Biomarkers.Related_Biomarker_Record"))
  )
  .withColumn(
    "Related_Biomarker_Uses_NNN",
    when(
      $"Related_Biomarker_Uses".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string")))
        .cast("array<struct<_VALUE:string,_id:string>>")
    ).otherwise(col("Related_Biomarker_Uses.Related_Biomarker_Use_Record"))
  )
  .withColumn(
    "Related_Literature_NNN",
    when(
      $"Related_Literature".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(col("Related_Literature.Related_Literature_Record"))
  )
  .withColumn(
    "Related_Experimental_Pharmacology_NNN",
    when(
      $"Related_Experimental_Pharmacology".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(
      col(
        "Related_Experimental_Pharmacology.Related_Experimental_Pharmacology_Record"
      )
    )
  )
  .withColumn(
    "Related_Experimental_Models_NNN",
    when(
      $"Related_Experimental_Models".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(
      col("Related_Experimental_Models.Related_Experimental_Model_Record")
    )
  )
  .withColumn(
    "Related_Patents_NNN",
    when(
      $"Related_Patents".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(col("Related_Patents.Related_Patent_Record"))
  )

val Combined_zip_df = Combined_df.withColumn(
  "zip_Arr",
  explode_outer(
    arrays_zip(
      $"Other_Related_Conditions_NNN",
      $"Related_GenesTargets_NNN",
      $"Related_Biomarkers_NNN",
      $"Related_Biomarker_Uses_NNN",
      $"Related_Literature_NNN",
      $"Related_Experimental_Pharmacology_NNN",
      $"Related_Experimental_Models_NNN",
      $"Related_Patents_NNN"
    )
  )
)

val Combined_zip_df2 = Combined_zip_df
  .groupBy($"_id".alias("zip_Genes_and_Targets_Internal_ID"))
  .agg(
    concat_ws(";", collect_list($"zip_Arr.Other_Related_Conditions_NNN._VALUE"))
      .alias("Other_Related_Conditions"),
    concat_ws(";", collect_list($"zip_Arr.Related_GenesTargets_NNN._id"))
      .alias("Related_GenesTargets"),
    concat_ws(";", collect_list($"zip_Arr.Related_Biomarkers_NNN._id"))
      .alias("Biomarkers"),
    concat_ws(";", collect_list($"zip_Arr.Related_Biomarker_Uses_NNN._id"))
      .alias("Biomarker_Uses"),
    concat_ws(";", collect_list($"zip_Arr.Related_Literature_NNN._id"))
      .alias("Literature"),
    concat_ws(
      ";",
      collect_list($"zip_Arr.Related_Experimental_Pharmacology_NNN._id")
    ).alias("Experimental_Pharmacology"),
    concat_ws(";", collect_list($"zip_Arr.Related_Experimental_Models_NNN._id"))
      .alias("Experimental_Models"),
    concat_ws(";", collect_list($"zip_Arr.Related_Patents_NNN._id"))
      .alias("Patents")
  )

val genes_targets_df4 = genes_targets_df3
  .join(
    description_df2,
    genes_targets_df3("Genes_and_Targets_Internal_ID") === description_df2(
      "description_Genes_and_Targets_Internal_ID"
    ),
    "inner"
  )
  .join(
    Combined_zip_df2,
    genes_targets_df3("Genes_and_Targets_Internal_ID") === Combined_zip_df2(
      "zip_Genes_and_Targets_Internal_ID"
    ),
    "inner"
  )
  .join(
    Drug_Condition_Phase_Development_df,
    genes_targets_df3(
      "Genes_and_Targets_Internal_ID"
    ) === Drug_Condition_Phase_Development_df(
      "Drug_Genes_and_Targets_Internal_ID"
    ),
    "inner"
  )
  .drop("description_Genes_and_Targets_Internal_ID")
  .drop("zip_Genes_and_Targets_Internal_ID")
  .drop("Drug_Genes_and_Targets_Internal_ID")

genes_targets_df4.printSchema

val final_df = genes_targets_df4.repartition(10000)

final_df.write
  .mode("OVERWRITE")
  .option("format", "parquet")
  .option(
    "path",
    "s3a://" + bucket_name + "/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name
  )
  .saveAsTable(db_name + "." + set_name);
