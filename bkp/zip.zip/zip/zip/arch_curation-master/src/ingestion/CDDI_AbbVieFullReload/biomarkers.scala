import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL;
import org.apache.spark.sql.{AnalysisException, Column, DataFrame, SparkSession}
import org.apache.hadoop.fs.{FileSystem, Path}
import java.util.zip.{ZipEntry, ZipOutputStream, ZipInputStream}
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ListBuffer
import java.net.URI
import org.apache.hadoop.conf.Configuration
import java.io.{File, FileInputStream, FileOutputStream}
import org.apache.spark.sql.types._
import java.util.Calendar

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val bucket_name = args(0)
val data_store = args(1)
val db_name = args(2)
val set_name = args(3)
val almaren = Almaren(set_name)

val cal = Calendar.getInstance()
val Year = cal.get(Calendar.YEAR)
val Month = cal.get(Calendar.MONTH) + 1

val CDDI_Latest = "CDDI-AbbVie_Full_Reload-" + Year + Month + "01"

val dffile_old = spark.read
  .format("com.databricks.spark.xml")
  .option("inferSchema", true)
  .option("samplingRatio", 1)
  .option("rowTag", "Biomarker_Use")
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/CDDI-AbbVie_Full_Reload-20221101/biomarkers.xml"
  )

val dffile = spark.read
  .format("com.databricks.spark.xml")
  .option("inferSchema", true)
  .option("samplingRatio", 1)
  .option("rowTag", "Biomarker_Use")
  .schema(dffile_old.schema)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/" + CDDI_Latest + "/biomarkers.xml"
  )
val df = dffile.repartition(10000)

df.printSchema()

val dffile2_old = spark.read
  .format("com.databricks.spark.xml")
  .option("inferSchema", true)
  .option("samplingRatio", 0.01)
  .option("rowTag", "Biomarker_Use")
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/CDDI-AbbVie_Full_Reload-20221101/biomarkers.xml"
  )
val dffile2 = spark.read
  .format("com.databricks.spark.xml")
  .option("inferSchema", true)
  .option("samplingRatio", 0.01)
  .option("rowTag", "Biomarker_Use")
  .schema(dffile2_old.schema)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/" + CDDI_Latest + "/biomarkers.xml"
  )
val df2 = dffile2.repartition(10000)

df2.printSchema()
val Biomarker_Use_df2 = df2
  .withColumn(
    "External_Identifiers_NNN",
    when(
      $"Biomarker_Information.External_Identifiers".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string")))
        .cast("array<struct<_VALUE:string,_type:string>>")
    ).otherwise(col("Biomarker_Information.External_Identifiers.Identifier"))
  )
  .withColumn(
    "Related_GenesTargets_NNN",
    when(
      $"Biomarker_Information.Related_GenesTargets".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string")))
        .cast("array<struct<_VALUE:string,_id:string>>")
    ).otherwise(
      col(
        "Biomarker_Information.Related_GenesTargets.Related_GeneTarget_Record"
      )
    )
  )
  .withColumn(
    "Sources_Patents_NNN",
    when(
      $"Use_Sources.Use_Patents".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit("string").cast("long"),
          lit(null).cast("long")
        )
      ).cast("array<struct<_VALUE:string,_evidenceType:string,_id:long>>")
    ).otherwise(col("Use_Sources.Use_Patents.Patent"))
  )
  .withColumn(
    "Sources_References_NNN",
    when(
      $"Use_Sources.Use_References".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("string"),
          lit(null).cast("long"),
          lit(null).cast("long")
        )
      ).cast(
        "array<struct<_VALUE:string,_evidenceType:string,_id:long,_pubmed_id:long>>"
      )
    ).otherwise(col("Use_Sources.Use_References.Reference"))
  )

val Biomarker_Use_df3 = Biomarker_Use_df2
  .withColumn(
    "Clinical_Studyid",
    explode_outer($"Use_Clinical_Studies.Clinical_Study_Id")
  )
  .withColumn(
    "zip_Arr",
    explode_outer(
      arrays_zip(
        $"External_Identifiers_NNN",
        $"Related_GenesTargets_NNN",
        $"Sources_Patents_NNN",
        $"Sources_References_NNN"
      )
    )
  )
  .select(
    $"Use_Indication._VALUE".alias("Indication"),
    $"Use_Indication_Type._VALUE".alias("Indication_Type"),
    $"Use_Role._VALUE".alias("Role"),
    $"Use_Parameter".alias("Parameter"),
    $"Use_Population".alias("Population"),
    $"Use_Substrate".alias("Substrate"),
    $"Use_Technique".alias("Technique"),
    $"Use_Validity._VALUE".alias("Validity"),
    $"Biomarker_Information.Available_Since_Date".alias("Added_Date"),
    $"Biomarker_Information.Biomarker.Main_Name".alias("Main_Name"),
    $"Biomarker_Information.Biomarker._id".alias("Biomarker_Id"),
    $"Biomarker_Information.Description".alias("Description"),
    $"Biomarker_Information.Highest_Validity".alias("Highest_Validity"),
    $"Biomarker_Information.Last_Update_Date".alias("Last_Updated_Date"),
    $"Biomarker_Information.Synonyms.Synonym".alias("Synonyms"),
    $"Biomarker_Information.Types.Type".alias("Types"),
    $"CDDI_Link",
    $"Biomarker_Information.Metacore.Metacore_Id",
    $"zip_Arr.External_Identifiers_NNN",
    $"zip_Arr.Related_GenesTargets_NNN",
    $"Clinical_Studyid._VALUE".alias("Clinical_Study_Id"),
    $"Clinical_Studyid._identifier".alias("Clinical_Study_Identifier"),
    $"_id".alias("Biomarker_Use_Id"),
    $"zip_Arr.Sources_Patents_NNN",
    $"zip_Arr.Sources_References_NNN"
  )

val Biomarker_Use_df31 = Biomarker_Use_df3
  .groupBy(
    $"Indication",
    $"Indication_Type",
    $"Role",
    $"Substrate",
    $"Parameter",
    $"Population",
    $"Technique",
    $"Validity",
    $"Biomarker_Use_Id",
    $"Added_Date",
    $"Main_Name",
    $"Biomarker_Id",
    $"Description",
    $"Highest_Validity",
    $"Last_Updated_Date",
    $"Synonyms",
    $"Types",
    $"CDDI_Link",
    $"Metacore_Id",
    $"Clinical_Study_Id",
    $"Clinical_Study_Identifier"
  )
  .agg(
    concat_ws(",", collect_list($"External_Identifiers_NNN._VALUE"))
      .alias("External_Identifiers_Id"),
    concat_ws(",", collect_list($"Related_GenesTargets_NNN._id"))
      .alias("Related_GenesTargets_Id"),
    concat_ws(",", collect_list($"Related_GenesTargets_NNN._VALUE"))
      .alias("Related_GenesTargets_VALUE"),
    concat_ws(",", collect_list($"External_Identifiers_NNN._type"))
      .alias("External_Identifiers_Type"),
    concat_ws(";", collect_list($"Sources_Patents_NNN._VALUE"))
      .alias("Source_Patents_VALUE"),
    concat_ws(";", collect_list($"Sources_Patents_NNN._evidenceType"))
      .alias("Source_Patents_evidenceType"),
    concat_ws(";", collect_list($"Sources_Patents_NNN._id"))
      .alias("Source_Patents_id"),
    concat_ws(";", collect_list($"Sources_References_NNN._VALUE"))
      .alias("Source_References_VALUE"),
    concat_ws(";", collect_list($"Sources_References_NNN._evidenceType"))
      .alias("Source_References_evidenceType"),
    concat_ws(";", collect_list($"Sources_References_NNN._id"))
      .alias("Source_References_id"),
    concat_ws(";", collect_list($"Sources_References_NNN._pubmed_id"))
      .alias("Source_References_pubmed_id")
  )

val Biomarker_Use_df4 = Biomarker_Use_df31
  .withColumn(
    "External_Identifiers_Id",
    when(col("External_Identifiers_Id") === "", lit(null).cast("string"))
      .otherwise(col("External_Identifiers_Id"))
  )
  .withColumn(
    "External_Identifiers_Type",
    when(col("External_Identifiers_Type") === "", lit(null).cast("string"))
      .otherwise(col("External_Identifiers_Type"))
  )
  .withColumn(
    "Related_GenesTargets_Id",
    when(col("Related_GenesTargets_Id") === "", lit(null).cast("string"))
      .otherwise(col("Related_GenesTargets_Id"))
  )
  .withColumn(
    "Related_GenesTargets_VALUE",
    when(col("Related_GenesTargets_VALUE") === "", lit(null).cast("string"))
      .otherwise(col("Related_GenesTargets_VALUE"))
  )
  .withColumn(
    "Source_Patents_VALUE",
    when(col("Source_Patents_VALUE") === "", lit(null).cast("string"))
      .otherwise(col("Source_Patents_VALUE"))
  )
  .withColumn(
    "Source_Patents_evidenceType",
    when(col("Source_Patents_evidenceType") === "", lit(null).cast("string"))
      .otherwise(col("Source_Patents_evidenceType"))
  )
  .withColumn(
    "Source_Patents_id",
    when(col("Source_Patents_id") === "", lit(null).cast("string"))
      .otherwise(col("Source_Patents_id"))
  )
  .withColumn(
    "Source_References_id",
    when(col("Source_References_id") === "", lit(null).cast("string"))
      .otherwise(col("Source_References_id"))
  )
  .withColumn(
    "Source_References_VALUE",
    when(col("Source_References_VALUE") === "", lit(null).cast("string"))
      .otherwise(col("Source_References_VALUE"))
  )
  .withColumn(
    "Source_References_evidenceType",
    when(col("Source_References_evidenceType") === "", lit(null).cast("string"))
      .otherwise(col("Source_References_evidenceType"))
  )
  .withColumn(
    "Source_References_pubmed_id",
    when(col("Source_References_pubmed_id") === "", lit(null).cast("string"))
      .otherwise(col("Source_References_pubmed_id"))
  )

val DRUG_GROUP_df4 = df
  .withColumn("Drug_Group", explode_outer($"Use_Drug_Groups.Drug_Group"))
  .select(
    $"_id".alias("DRUG_GROUP_df4_Biomarker_Use_Id"),
    $"Drug_Group.References".alias("Drug_Group_References"),
    $"Drug_Group.Patents".alias("Drug_Group_Patents"),
    $"Drug_Group._id".alias("Drug_Group_id"),
    $"Drug_Group._name".alias("Drug_Group_name"),
    $"Drug_Group._type".alias("Drug_Group_type"),
    $"Drug_Group._VALUE".alias("Drug_Group_VALUE")
  )

val DRUG_GROUP_df5 = DRUG_GROUP_df4
  .withColumn(
    "Drug_Group_References_NNN",
    when(
      $"Drug_Group_References".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("long"),
          lit(null).cast("long")
        )
      ).cast("array<struct<_VALUE:string,_id:long,_pubmed_id:long>>")
    ).otherwise(col("Drug_Group_References.Reference"))
  )
  .withColumn(
    "Drug_Group_Patents_NNN",
    when(
      $"Drug_Group_Patents".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("string"),
          lit(null).cast("long")
        )
      ).cast("array<struct<_VALUE:string,_evidenceType:long,_id:long>>")
    ).otherwise(col("Drug_Group_Patents.Patent"))
  )
  .withColumn(
    "zip_Drug_Group",
    explode_outer(
      arrays_zip($"Drug_Group_References_NNN", $"Drug_Group_Patents_NNN")
    )
  )

val DRUG_GROUP_df6 = DRUG_GROUP_df5
  .groupBy(
    $"DRUG_GROUP_df4_Biomarker_Use_Id",
    $"Drug_Group_id",
    $"Drug_Group_name",
    $"Drug_Group_type",
    $"Drug_Group_VALUE"
  )
  .agg(
    concat_ws(
      ";",
      collect_list($"zip_Drug_Group.Drug_Group_References_NNN._id")
    ).alias("Drug_Group_References_Id"),
    concat_ws(
      ";",
      collect_list($"zip_Drug_Group.Drug_Group_References_NNN._VALUE")
    ).alias("Drug_Group_References_VALUE"),
    concat_ws(
      ";",
      collect_list($"zip_Drug_Group.Drug_Group_References_NNN._pubmed_id")
    ).alias("Drug_Group_References_pubmed_id"),
    concat_ws(";", collect_list($"zip_Drug_Group.Drug_Group_Patents_NNN._id"))
      .alias("Drug_Group_Patents_Id"),
    concat_ws(
      ";",
      collect_list($"zip_Drug_Group.Drug_Group_Patents_NNN._evidenceType")
    ).alias("Drug_Group_Patents_evidenceType"),
    concat_ws(
      ";",
      collect_list($"zip_Drug_Group.Drug_Group_Patents_NNN._VALUE")
    ).alias("Drug_Group_Patents_VALUE")
  )

val DRUG_GROUP_df7 = DRUG_GROUP_df6
  .withColumn(
    "Drug_Group_References_Id",
    when(col("Drug_Group_References_Id") === "", lit(null).cast("string"))
      .otherwise(col("Drug_Group_References_Id"))
  )
  .withColumn(
    "Drug_Group_References_VALUE",
    when(col("Drug_Group_References_VALUE") === "", lit(null).cast("string"))
      .otherwise(col("Drug_Group_References_VALUE"))
  )
  .withColumn(
    "Drug_Group_References_pubmed_id",
    when(
      col("Drug_Group_References_pubmed_id") === "",
      lit(null).cast("string")
    ).otherwise(col("Drug_Group_References_pubmed_id"))
  )
  .withColumn(
    "Drug_Group_Patents_Id",
    when(col("Drug_Group_Patents_Id") === "", lit(null).cast("string"))
      .otherwise(col("Drug_Group_Patents_Id"))
  )
  .withColumn(
    "Drug_Group_Patents_evidenceType",
    when(
      col("Drug_Group_Patents_evidenceType") === "",
      lit(null).cast("string")
    ).otherwise(col("Drug_Group_Patents_evidenceType"))
  )
  .withColumn(
    "Drug_Group_Patents_VALUE",
    when(col("Drug_Group_Patents_VALUE") === "", lit(null).cast("string"))
      .otherwise(col("Drug_Group_Patents_VALUE"))
  )

val DRUG_df4 = df
  .withColumn("Drug", explode_outer($"Use_Drugs.Drug"))
  .select(
    $"_id".alias("DRUG_df4_Biomarker_Use_Id"),
    $"Drug.References".alias("Drug_References"),
    $"Drug.Patents".alias("Drug_Patents"),
    $"Drug._id".alias("Drug_id"),
    $"Drug._name".alias("Drug_name"),
    $"Drug._type".alias("Drug_type"),
    $"Drug._VALUE".alias("Drug_VALUE")
  )

val DRUG_df5 = DRUG_df4
  .withColumn(
    "Drug_References_NNN",
    when(
      $"Drug_References".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("long"),
          lit(null).cast("long")
        )
      ).cast("array<struct<_VALUE:string,_id:long,_pubmed_id:long>>")
    ).otherwise(col("Drug_References.Reference"))
  )
  .withColumn(
    "Drug_Patents_NNN",
    when(
      $"Drug_Patents".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("string"),
          lit(null).cast("long")
        )
      ).cast("array<struct<_VALUE:string,_evidenceType:long,_id:long>>")
    ).otherwise(col("Drug_Patents.Patent"))
  )
  .withColumn(
    "zip_Drug",
    explode_outer(arrays_zip($"Drug_References_NNN", $"Drug_Patents_NNN"))
  )

val DRUG_df6 = DRUG_df5
  .groupBy(
    $"DRUG_df4_Biomarker_Use_Id",
    $"Drug_id",
    $"Drug_name",
    $"Drug_type",
    $"Drug_VALUE"
  )
  .agg(
    concat_ws(";", collect_list($"zip_Drug.Drug_References_NNN._id"))
      .alias("Drug_References_Id"),
    concat_ws(";", collect_list($"zip_Drug.Drug_References_NNN._VALUE"))
      .alias("Drug_References_VALUE"),
    concat_ws(";", collect_list($"zip_Drug.Drug_References_NNN._pubmed_id"))
      .alias("Drug_References_pubmed_id"),
    concat_ws(";", collect_list($"zip_Drug.Drug_Patents_NNN._id"))
      .alias("Drug_Patents_Id"),
    concat_ws(";", collect_list($"zip_Drug.Drug_Patents_NNN._evidenceType"))
      .alias("Drug_Patents_evidenceType"),
    concat_ws(";", collect_list($"zip_Drug.Drug_Patents_NNN._VALUE"))
      .alias("Drug_Patents_VALUE")
  )

val DRUG_df61 = DRUG_df6.select(
  $"DRUG_df4_Biomarker_Use_Id",
  $"Drug_References_Id",
  $"Drug_References_VALUE",
  $"Drug_References_pubmed_id",
  $"Drug_Patents_Id",
  $"Drug_Patents_evidenceType",
  $"Drug_Patents_VALUE",
  $"Drug_type",
  $"Drug_VALUE",
  concat(col("Drug_id"), lit('\u0028'), col("Drug_name"), lit('\u0029')).as(
    "Drug_in_use_study"
  )
)

val DRUG_df7 = DRUG_df61
  .withColumn(
    "Drug_References_Id",
    when(col("Drug_References_Id") === "", lit(null).cast("string")).otherwise(
      col("Drug_References_Id")
    )
  )
  .withColumn(
    "Drug_References_VALUE",
    when(col("Drug_References_VALUE") === "", lit(null).cast("string"))
      .otherwise(col("Drug_References_VALUE"))
  )
  .withColumn(
    "Drug_References_pubmed_id",
    when(col("Drug_References_pubmed_id") === "", lit(null).cast("string"))
      .otherwise(col("Drug_References_pubmed_id"))
  )
  .withColumn(
    "Drug_Patents_Id",
    when(col("Drug_Patents_Id") === "", lit(null).cast("string"))
      .otherwise(col("Drug_Patents_Id"))
  )
  .withColumn(
    "Drug_Patents_evidenceType",
    when(col("Drug_Patents_evidenceType") === "", lit(null).cast("string"))
      .otherwise(col("Drug_Patents_evidenceType"))
  )
  .withColumn(
    "Drug_Patents_VALUE",
    when(col("Drug_Patents_VALUE") === "", lit(null).cast("string"))
      .otherwise(col("Drug_Patents_VALUE"))
  )

val Gene_Variant_df4 = df
  .withColumn("Gene_Variant", explode_outer($"Use_Gene_Variants.Gene_Variant"))
  .select(
    $"_id".alias("Gene_Variant_df4_Biomarker_Use_Id"),
    $"Gene_Variant.References".alias("Gene_Variant_References"),
    $"Gene_Variant.Patents".alias("Gene_Variant_Patents"),
    $"Gene_Variant._id".alias("Gene_Variant_id"),
    $"Gene_Variant._name".alias("Gene_Variant_name"),
    $"Gene_Variant.Gene_Name".alias("Gene_Variant_Gene_Name"),
    $"Gene_Variant.Entrez_Gene._Id".alias("Gene_Variant_Entrez_Gene_Id"),
    $"Gene_Variant.Entrez_Gene._VALUE"
      .alias("Gene_Variant_Entrez_Gene_URL_Link")
  )

val Gene_Variant_df5 = Gene_Variant_df4
  .withColumn(
    "Gene_Variant_References_NNN",
    when(
      $"Gene_Variant_References".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("long"),
          lit(null).cast("long")
        )
      ).cast("array<struct<_VALUE:string,_id:long,_pubmed_id:long>>")
    ).otherwise(col("Gene_Variant_References.Reference"))
  )
  .withColumn(
    "Gene_Variant_Patents_NNN",
    when(
      $"Gene_Variant_Patents".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("string"),
          lit(null).cast("long")
        )
      ).cast("array<struct<_VALUE:string,_evidenceType:long,_id:long>>")
    ).otherwise(col("Gene_Variant_Patents.Patent"))
  )
  .withColumn(
    "zip_Gene_Variant",
    explode_outer(
      arrays_zip($"Gene_Variant_References_NNN", $"Gene_Variant_Patents_NNN")
    )
  )

val Gene_Variant_df6 = Gene_Variant_df5
  .groupBy(
    $"Gene_Variant_df4_Biomarker_Use_Id",
    $"Gene_Variant_id",
    $"Gene_Variant_name",
    $"Gene_Variant_Gene_Name"
  )
  .agg(
    concat_ws(
      ";",
      collect_list($"zip_Gene_Variant.Gene_Variant_References_NNN._id")
    ).alias("Gene_Variant_References_Id"),
    concat_ws(
      ";",
      collect_list($"zip_Gene_Variant.Gene_Variant_References_NNN._VALUE")
    ).alias("Gene_Variant_References_VALUE"),
    concat_ws(
      ";",
      collect_list($"zip_Gene_Variant.Gene_Variant_References_NNN._pubmed_id")
    ).alias("Gene_Variant_References_pubmed_id"),
    concat_ws(
      ";",
      collect_list($"zip_Gene_Variant.Gene_Variant_Patents_NNN._id")
    ).alias("Gene_Variant_Patents_Id"),
    concat_ws(
      ";",
      collect_list($"zip_Gene_Variant.Gene_Variant_Patents_NNN._evidenceType")
    ).alias("Gene_Variant_Patents_evidenceType"),
    concat_ws(
      ";",
      collect_list($"zip_Gene_Variant.Gene_Variant_Patents_NNN._VALUE")
    ).alias("Gene_Variant_Patents_VALUE")
  )

val Gene_Variant_df7 = Gene_Variant_df6
  .withColumn(
    "Gene_Variant_References_Id",
    when(col("Gene_Variant_References_Id") === "", lit(null).cast("string"))
      .otherwise(col("Gene_Variant_References_Id"))
  )
  .withColumn(
    "Gene_Variant_References_VALUE",
    when(col("Gene_Variant_References_VALUE") === "", lit(null).cast("string"))
      .otherwise(col("Gene_Variant_References_VALUE"))
  )
  .withColumn(
    "Gene_Variant_References_pubmed_id",
    when(
      col("Gene_Variant_References_pubmed_id") === "",
      lit(null).cast("string")
    ).otherwise(col("Gene_Variant_References_pubmed_id"))
  )
  .withColumn(
    "Gene_Variant_Patents_Id",
    when(col("Gene_Variant_Patents_Id") === "", lit(null).cast("string"))
      .otherwise(col("Gene_Variant_Patents_Id"))
  )
  .withColumn(
    "Gene_Variant_Patents_evidenceType",
    when(
      col("Gene_Variant_Patents_evidenceType") === "",
      lit(null).cast("string")
    ).otherwise(col("Gene_Variant_Patents_evidenceType"))
  )
  .withColumn(
    "Gene_Variant_Patents_VALUE",
    when(col("Gene_Variant_Patents_VALUE") === "", lit(null).cast("string"))
      .otherwise(col("Gene_Variant_Patents_VALUE"))
  )

val Gene_df4 = df
  .withColumn("Gene", explode_outer($"Use_Genes.Gene"))
  .select(
    $"_id".alias("Gene_df4_Biomarker_Use_Id"),
    $"Gene.References".alias("Gene_References"),
    $"Gene.Patents".alias("Gene_Patents"),
    $"Gene._id".alias("Gene_id"),
    $"Gene._name".alias("Gene_name"),
    $"Gene.Entrez_Gene._Id".alias("Gene_Entrez_Gene_Id"),
    $"Gene.Entrez_Gene._VALUE".alias("Gene_Entrez_Gene_URL_Link")
  )

val Gene_df5 = Gene_df4
  .withColumn(
    "Gene_References_NNN",
    when(
      $"Gene_References".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("long"),
          lit(null).cast("long")
        )
      ).cast("array<struct<_VALUE:string,_id:long,_pubmed_id:long>>")
    ).otherwise(col("Gene_References.Reference"))
  )
  .withColumn(
    "Gene_Patents_NNN",
    when(
      $"Gene_Patents".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("string"),
          lit(null).cast("long")
        )
      ).cast("array<struct<_VALUE:string,_evidenceType:long,_id:long>>")
    ).otherwise(col("Gene_Patents.Patent"))
  )
  .withColumn(
    "zip_Gene",
    explode_outer(arrays_zip($"Gene_References_NNN", $"Gene_Patents_NNN"))
  )

val Gene_df6 = Gene_df5
  .groupBy($"Gene_df4_Biomarker_Use_Id", $"Gene_id", $"Gene_name")
  .agg(
    concat_ws(";", collect_list($"zip_Gene.Gene_References_NNN._id"))
      .alias("Gene_References_Id"),
    concat_ws(";", collect_list($"zip_Gene.Gene_References_NNN._VALUE"))
      .alias("Gene_References_VALUE"),
    concat_ws(";", collect_list($"zip_Gene.Gene_References_NNN._pubmed_id"))
      .alias("Gene_References_pubmed_id"),
    concat_ws(";", collect_list($"zip_Gene.Gene_Patents_NNN._id"))
      .alias("Gene_Patents_Id"),
    concat_ws(";", collect_list($"zip_Gene.Gene_Patents_NNN._evidenceType"))
      .alias("Gene_Patents_evidenceType"),
    concat_ws(";", collect_list($"zip_Gene.Gene_Patents_NNN._VALUE"))
      .alias("Gene_Patents_VALUE")
  )

val Gene_df7 = Gene_df6
  .withColumn(
    "Gene_References_Id",
    when(col("Gene_References_Id") === "", lit(null).cast("string")).otherwise(
      col("Gene_References_Id")
    )
  )
  .withColumn(
    "Gene_References_VALUE",
    when(col("Gene_References_VALUE") === "", lit(null).cast("string"))
      .otherwise(col("Gene_References_VALUE"))
  )
  .withColumn(
    "Gene_References_pubmed_id",
    when(col("Gene_References_pubmed_id") === "", lit(null).cast("string"))
      .otherwise(col("Gene_References_pubmed_id"))
  )
  .withColumn(
    "Gene_Patents_Id",
    when(col("Gene_Patents_Id") === "", lit(null).cast("string"))
      .otherwise(col("Gene_Patents_Id"))
  )
  .withColumn(
    "Gene_Patents_evidenceType",
    when(col("Gene_Patents_evidenceType") === "", lit(null).cast("string"))
      .otherwise(col("Gene_Patents_evidenceType"))
  )
  .withColumn(
    "Gene_Patents_VALUE",
    when(col("Gene_Patents_VALUE") === "", lit(null).cast("string"))
      .otherwise(col("Gene_Patents_VALUE"))
  )

val Kit_df4 = df
  .withColumn("Kit", explode_outer($"Use_Kits.Kit"))
  .select(
    $"_id".alias("Kit_df4_Biomarker_Use_Id"),
    $"Kit.Description".alias("Kit_Description"),
    $"Kit.Number".alias("Kit_Number"),
    $"Kit.Synonyms.Synonym".alias("Kit_Synonym"),
    $"Kit._NameMain".alias("Kit_NameMain"),
    $"Kit._id".alias("Kit_id"),
    $"Kit.Kit_Development_Program.Program".alias("Kit_Development_Program"),
    $"Kit.Kit_Organizations.Organization"
      .cast("array<struct<name:string,id:bigint>>")
      .alias("Kit_Organization")
  )

val Kit_df5 = Kit_df4
  .withColumn(
    "Kit_Development_Program_Exp",
    explode_outer($"Kit_Development_Program")
  )
  .select(
    $"Kit_df4_Biomarker_Use_Id",
    $"Kit_Description",
    $"Kit_Number",
    $"Kit_Synonym",
    $"Kit_NameMain",
    $"Kit_id",
    $"Kit_Organization",
    $"Kit_Development_Program_Exp"
  )

val Kit_df6 = Kit_df5
  .withColumn(
    "Kit_References",
    explode_outer($"Kit_Development_Program_Exp.References.Reference")
  )
  .select(
    $"Kit_df4_Biomarker_Use_Id",
    $"Kit_Description",
    $"Kit_Number",
    $"Kit_Synonym",
    $"Kit_NameMain",
    $"Kit_id",
    $"Kit_Organization",
    $"Kit_Development_Program_Exp.Country"
      .alias("Kit_Development_Program_Country"),
    $"Kit_Development_Program_Exp.Organization"
      .cast("struct<name:string,id:bigint>")
      .alias("Kit_Development_Program_Organization"),
    $"Kit_Development_Program_Exp.Qualifier"
      .alias("Kit_Development_Program_Qualifier"),
    $"Kit_References._id".alias("Kit_Development_Program_References")
  )

val finaldf21 = Biomarker_Use_df4
  .join(
    DRUG_GROUP_df7,
    Biomarker_Use_df4("Biomarker_Use_Id") === DRUG_GROUP_df7(
      "DRUG_GROUP_df4_Biomarker_Use_Id"
    ),
    "inner"
  )
  .join(
    DRUG_df7,
    Biomarker_Use_df4("Biomarker_Use_Id") === DRUG_df7(
      "DRUG_df4_Biomarker_Use_Id"
    ),
    "inner"
  )
  .join(
    Gene_Variant_df7,
    Biomarker_Use_df4("Biomarker_Use_Id") === Gene_Variant_df7(
      "Gene_Variant_df4_Biomarker_Use_Id"
    ),
    "inner"
  )
  .join(
    Gene_df7,
    Biomarker_Use_df4("Biomarker_Use_Id") === Gene_df7(
      "Gene_df4_Biomarker_Use_Id"
    ),
    "inner"
  )
  .join(
    Kit_df6,
    Biomarker_Use_df4("Biomarker_Use_Id") === Kit_df6(
      "Kit_df4_Biomarker_Use_Id"
    ),
    "inner"
  )
  .drop("DRUG_df4_Biomarker_Use_Id")
  .drop("DRUG_GROUP_df4_Biomarker_Use_Id")
  .drop("Gene_df4_Biomarker_Use_Id")
  .drop("Kit_df4_Biomarker_Use_Id")
  .drop("Sources_df4_id")
  .drop("Sources")

val finaldf2 = finaldf21
  .withColumnRenamed("Biomarker_Use_Id", "Use_Id")
  .withColumnRenamed("Related_GenesTargets_Id", "GenesTargets_Id")
  .withColumnRenamed("Related_GenesTargets_VALUE", "GenesTargets_VALUE")
  .withColumnRenamed("Related_GenesTargets_Id", "GenesTargets_Id")

val finaldf = finaldf2.repartition(10000)
finaldf.printSchema

finaldf.write
  .mode("OVERWRITE")
  .option("format", "parquet")
  .option(
    "path",
    "s3a://" + bucket_name + "/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name
  )
  .saveAsTable(db_name + "." + set_name);
