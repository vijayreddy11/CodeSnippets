import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL;
import org.apache.spark.sql.{AnalysisException, Column, DataFrame, SparkSession}
import org.apache.hadoop.fs.{FileSystem, Path}
import java.util.zip.{ZipEntry, ZipOutputStream, ZipInputStream}
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ListBuffer
import java.net.URI
import org.apache.hadoop.conf.Configuration
import java.io.{File, FileInputStream, FileOutputStream}
import org.apache.spark.sql.types._
import java.util.Calendar

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val bucket_name = args(0)
val data_store = args(1)
val db_name = args(2)
val set_name = args(3)
val almaren = Almaren(set_name)

val cal = Calendar.getInstance()
val Year = cal.get(Calendar.YEAR)
val Month = cal.get(Calendar.MONTH) + 1

val CDDI_Latest = "CDDI-AbbVie_Full_Reload-" + Year + Month + "01"

val df_old = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "Clinical_Study")
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/CDDI-AbbVie_Full_Reload-20221101/clinical.xml"
  )

val df = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "Clinical_Study")
  .schema(df_old.schema)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/" + CDDI_Latest + "/clinical.xml"
  )

val finaldf = df
  .withColumn("Conditions", explode_outer($"Conditions.Condition"))
  .withColumn("Designs", explode_outer($"Designs.Design"))
  .withColumn("Intervention_Types", explode_outer($"Intervention_Types.Type"))
  .withColumn(
    "Related_Biomarker_Uses",
    explode_outer($"Related_Biomarker_Uses.Related_Biomarker_Use_Record")
  )
  .withColumn(
    "Related_Products",
    explode_outer($"Related_Products.Related_Product_Record")
  )
  .withColumn("Treatments", explode_outer($"Treatments.Treatment"))
  .select(
    $"Available_Since_Date",
    $"CDDI_Link".alias("Link"),
    $"Conclusions",
    $"NCT_Identifier".alias("Identifier"),
    $"PubMed_Id".alias("Pubmed_ID"),
    $"Study_Name",
    $"Designs",
    $"_id".alias("Clinical_Study_Id"),
    $"Conditions._VALUE".alias("Conditions"),
    $"Intervention_Types._VALUE".alias("Intervention_Type"),
    $"Population._VALUE".alias("Population"),
    $"Population._Total".alias("Population_Number"),
    $"Related_Biomarker_Uses._id".alias("Biomarker_Use"),
    concat(
      col("Related_Biomarker_Uses._Biomarker_Name"),
      lit('\u0028'),
      col("Related_Biomarker_Uses._Biomarker_Id"),
      lit('\u0029')
    ).as("Biomarkers"),
    $"Related_Products._entry_number".alias("Related_drugs_and_biologics_id"),
    $"source._id".alias("Reference"),
    $"Treatments._VALUE".alias("Treatments")
  )

finaldf.printSchema()

finaldf.write
  .mode("OVERWRITE")
  .option("format", "parquet")
  .option(
    "path",
    "s3a://" + bucket_name + "/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name
  )
  .saveAsTable(db_name + "." + set_name);
