import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL;
import org.apache.spark.sql.{AnalysisException, Column, DataFrame, SparkSession}
import org.apache.hadoop.fs.{FileSystem, Path}
import java.util.zip.{ZipEntry, ZipOutputStream, ZipInputStream}
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ListBuffer
import java.net.URI
import java.util.Calendar

import org.apache.hadoop.conf.Configuration
import java.io.{File, FileInputStream, FileOutputStream}
import org.apache.spark.sql.types._

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val bucket_name = args(0)
val data_store = args(1)
val db_name = args(2)
val set_name = args(3)
val almaren = Almaren(set_name)

val cal = Calendar.getInstance()
val Year = cal.get(Calendar.YEAR)
val Month = cal.get(Calendar.MONTH) + 1

val CDDI_Latest = "CDDI-AbbVie_Full_Reload-" + Year + Month + "01"

val originaldf1_old = spark.read
  .format("com.databricks.spark.xml")
  .option("inferSchema", true)
  .option("samplingRatio", 0.1)
  .option("rowTag", "Product")
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/CDDI-AbbVie_Full_Reload-20221101/products.xml"
  )

val originaldf1 = spark.read
  .format("com.databricks.spark.xml")
  .option("inferSchema", true)
  .option("samplingRatio", 0.1)
  .option("rowTag", "Product")
  .schema(originaldf1_old.schema)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/" + CDDI_Latest + "/products.xml"
  )

val originaldf = originaldf1.repartition(15000)

originaldf.printSchema()

val productsdf = originaldf
  .withColumn("Organizations", explode_outer($"Organizations.Organization"))
  .select(
    $"_entry_number".alias("Entry_Number"),
    $"CDDI_Link".alias("Link_to_CDDI"),
    $"Available_Since_Date".alias("Available_Since"),
    $"Last_Updated_Date",
    $"New_Molecular_Entity._VALUE".alias("New_Molecular_Entity"),
    $"Update_History.Change".alias("Change_History_Details"),
    $"Main_Name",
    $"Generic_Names.Generic_Name".alias("Generic_Names"),
    $"Brand_Names.Name".alias("Brand_Name"),
    $"Chemical_Names.Name".alias("Chemical_Names"),
    $"Descriptions.Description".alias("Descriptions"),
    $"Molecular_Formula",
    $"Molecular_Weight",
    $"InChI",
    $"InChIKey",
    $"Smiles",
    $"ChimeString",
    $"Product_Summary",
    $"Highest_Phase._VALUE".alias("Highest_Phase"),
    $"Highest_Phase._year".alias("Year_Phase"),
    $"Under_Active_Development",
    $"Drug_Is_Lead",
    $"Organizations._VALUE".alias("Organization"),
    $"Organizations._qualifier".alias("Organization_Qualifier")
  )

val productsdf2 = originaldf
  .withColumn(
    "Development_Status",
    explode_outer($"Development_Status.Devstatus_Line")
  )
  .select(
    $"_entry_number".alias("products2_Entry_Number"),
    $"Development_Status.Country._VALUE".alias("Development_Status_Country"),
    $"Development_Status.Area._VALUE".alias("Development_Status_Area"),
    $"Development_Status._under_active_development"
      .alias("Development_Status_UAD"),
    $"Development_Status.Phase._VALUE".alias("Phase"),
    $"Development_Status.Phase._year".alias("Phase_year"),
    $"Development_Status.Organization._VALUE"
      .alias("Development_Status_Organization"),
    $"Development_Status.Brand_Name".alias("Development_Status_Brand_Name"),
    $"Development_Status.Condition._VALUE"
      .alias("Development_Status_Condition"),
    $"Development_Status.Indication".alias("Indication"),
    $"Development_Status.Administration_Route".alias("Route_of_Administartion"),
    $"Development_Status.Formulation".alias("Formulation"),
    $"Related_Patents.Related_Patent_Record".alias("Related_Patents"),
    $"Related_Products.Related_Product_Record".alias("Related_Products")
  )
val combined_df = originaldf
  .withColumn(
    "Code_Names_NNN",
    when(
      $"Code_Names".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string"))).cast(
        "array<struct<_VALUE:string,_qualifier:string>>"
      )
    ).otherwise(col("Code_Names.Code"))
  )
  .withColumn(
    "CAS_Numbers_NNN",
    when(
      $"CAS_Numbers".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string"))).cast(
        "array<struct<_VALUE:string,_qualifier:string>>"
      )
    ).otherwise(col("CAS_Numbers.Number"))
  )
  .withColumn(
    "Product_Categories_NNN",
    when(
      $"Product_Categories".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long"))).cast(
        "array<struct<_VALUE:string,_id:long>>"
      )
    ).otherwise(col("Product_Categories.Category"))
  )
  .withColumn(
    "Therapeutic_Groups_NNN",
    when(
      $"Therapeutic_Groups".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long"))).cast(
        "array<struct<_VALUE:string,_id:long>>"
      )
    ).otherwise(col("Therapeutic_Groups.Group"))
  )
  .withColumn(
    "Conditions_NNN",
    when(
      $"Conditions".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long"))).cast(
        "array<struct<_VALUE:string,_id:long>>"
      )
    ).otherwise(col("Conditions.Condition"))
  )
  .withColumn(
    "Prescription_Types_NNN",
    when(
      $"Prescription_Types".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string"))).cast(
        "array<struct<_VALUE:string,_date:string>>"
      )
    ).otherwise(col("Prescription_Types.Type"))
  )
  .withColumn(
    "Related_GenesTargets_NNN",
    when(
      $"Related_GenesTargets".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string"))).cast(
        "array<struct<_VALUE:string,_id:string>>"
      )
    ).otherwise(col("Related_GenesTargets.Related_GeneTarget_Record"))
  )
  .withColumn(
    "Related_Experimental_Pharmacology_NNN",
    when(
      $"Related_Experimental_Pharmacology".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(
      col(
        "Related_Experimental_Pharmacology.Related_Experimental_Pharmacology_Record"
      )
    )
  )
  .withColumn(
    "Related_Pharmacokinetics_NNN",
    when(
      $"Related_Pharmacokinetics".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(col("Related_Pharmacokinetics.Related_Pharmacokinetics_Record"))
  )
  .withColumn(
    "Related_Clinical_Studies_NNN",
    when(
      $"Related_Clinical_Studies".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(col("Related_Clinical_Studies.Related_Clinical_Study_Record"))
  )
  .withColumn(
    "Mechanisms_of_Action_NNN",
    when(
      $"Mechanisms_of_Action".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("long"),
          lit(null).cast("string")
        )
      ).cast("array<struct<_VALUE:string,_id:long,_type:string>>")
    ).otherwise(col("Mechanisms_of_Action.Mechanism"))
  )
  .withColumn(
    "Related_Literature_NNN",
    when(
      $"Related_Literature".isNull,
      array(
        struct(
          lit(null).cast("string"),
          lit(null).cast("long"),
          lit(null).cast("long")
        )
      ).cast("array<struct<_VALUE:string,_id:long,_pubmed_id:long>>")
    ).otherwise(col("Related_Literature.Related_Literature_Record"))
  )

val combined_zip_df = combined_df.withColumn(
  "zip_Arr",
  explode_outer(
    arrays_zip(
      $"Code_Names_NNN",
      $"CAS_Numbers_NNN",
      $"Product_Categories_NNN",
      $"Therapeutic_Groups_NNN",
      $"Conditions_NNN",
      $"Prescription_Types_NNN",
      $"Related_GenesTargets_NNN",
      $"Related_Experimental_Pharmacology_NNN",
      $"Related_Pharmacokinetics_NNN",
      $"Related_Clinical_Studies_NNN",
      $"Mechanisms_of_Action_NNN",
      $"Related_Literature_NNN"
    )
  )
)

val combined_zip_df2 = combined_zip_df
  .groupBy($"_entry_number".alias("products_zip_Entry_Number"))
  .agg(
    concat_ws(";", collect_list($"zip_Arr.Code_Names_NNN._VALUE"))
      .alias("Code_Name"),
    concat_ws(";", collect_list($"zip_Arr.CAS_Numbers_NNN._VALUE"))
      .alias("CAS_Registry_Number"),
    concat_ws(";", collect_list($"zip_Arr.Product_Categories_NNN._VALUE"))
      .alias("Product_Categories"),
    concat_ws(";", collect_list($"zip_Arr.Therapeutic_Groups_NNN._VALUE"))
      .alias("Therapeutic_Groups"),
    concat_ws(",", collect_list($"zip_Arr.Conditions_NNN._VALUE"))
      .alias("Conditions"),
    concat_ws(";", collect_list($"zip_Arr.Prescription_Types_NNN._VALUE"))
      .alias("Prescription_Type"),
    concat_ws(";", collect_list($"zip_Arr.Related_GenesTargets_NNN._id"))
      .alias("Genes_and_Targets"),
    concat_ws(
      ";",
      collect_list($"zip_Arr.Related_Experimental_Pharmacology_NNN._id")
    ).alias("Experimental_Pharmacology"),
    concat_ws(";", collect_list($"zip_Arr.Related_Pharmacokinetics_NNN._id"))
      .alias("Pharmacokinetics"),
    concat_ws(";", collect_list($"zip_Arr.Related_Clinical_Studies_NNN._id"))
      .alias("Clinical_Studies"),
    concat_ws("/", collect_list($"zip_Arr.Mechanisms_of_Action_NNN._VALUE"))
      .alias("Mechanisms_of_Action"),
    concat_ws("/", collect_list($"zip_Arr.Mechanisms_of_Action_NNN._type"))
      .alias("Mechanism_Type"),
    concat_ws(";", collect_list($"zip_Arr.Related_Literature_NNN._id"))
      .alias("Literature")
  )

val milestonedf = originaldf
  .withColumn("Milestones", explode_outer($"Milestones.Milestone_Hit"))
  .select(
    $"_entry_number".alias("Milestone_Entry_Number"),
    $"Milestones.Drug_Name".alias("Milestones_Brand_Name"),
    $"Milestones.Condition._VALUE".alias("Milestones_Condition"),
    $"Milestones.Milestone_Date._VALUE".alias("Milestone_Date"),
    $"Milestones.Milestone._VALUE".alias("Milestone"),
    $"Milestones.Notes".alias("Notes"),
    $"Milestones.Area".alias("Milestone_Area"),
    $"Milestones.Country".alias("Milestone_Country"),
    $"Milestones.Organization".alias("Milestone_Organization")
  )

val milestone_zip_df2 = milestonedf
  .withColumn(
    "Milestones_Area_NNN",
    when(
      $"Milestone_Area".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(col("Milestone_Area"))
  )
  .withColumn(
    "Milestones_Country_NNN",
    when(
      $"Milestone_Country".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("string")))
        .cast("array<struct<_VALUE:string,_id:string>>")
    ).otherwise(col("Milestone_Country"))
  )
  .withColumn(
    "Milestones_Organization_NNN",
    when(
      $"Milestone_Organization".isNull,
      array(struct(lit(null).cast("string"), lit(null).cast("long")))
        .cast("array<struct<_VALUE:string,_id:long>>")
    ).otherwise(col("Milestone_Organization"))
  )

val milestone_zip_df3 = milestone_zip_df2.withColumn(
  "milestone_zip_Arr",
  explode_outer(
    arrays_zip(
      $"Milestones_Area_NNN",
      $"Milestones_Country_NNN",
      $"Milestones_Organization_NNN"
    )
  )
)

val milestone_zip_combined_df = milestone_zip_df3
  .groupBy(
    $"Milestone_Entry_Number",
    $"Milestones_Brand_Name",
    $"Milestones_Condition",
    $"Milestone_Date",
    $"Milestone",
    $"Notes"
  )
  .agg(
    concat_ws(
      ";",
      collect_list($"milestone_zip_Arr.Milestones_Organization_NNN._VALUE")
    ).alias("Milestone_Organization"),
    concat_ws(
      ";",
      collect_list($"milestone_zip_Arr.Milestones_Country_NNN._VALUE")
    ).alias("Milestone_Country"),
    concat_ws(
      ";",
      collect_list($"milestone_zip_Arr.Milestones_Area_NNN._VALUE")
    ).alias("Milestone_Area")
  )

val naturalsourcesdf = originaldf
  .withColumn("Natural_Sources", explode_outer($"Natural_Sources.Source"))
  .select(
    $"_entry_number".alias("Natural_Sources_Entry_Number"),
    $"Natural_Sources.Scientific_Name".alias("Scientific_Name"),
    $"Natural_Sources.Other_Names.Name".alias("Common_Name"),
    $"Natural_Sources.Geographic_Area".alias("Geographic_Area"),
    $"Natural_Sources.External_links".alias("Natural_Sources_Extrenal_links")
  )

val natural_source_zip_df2 = naturalsourcesdf.withColumn(
  "Natural_Sources_Link_NNN",
  when(
    $"Natural_Sources_Extrenal_links.Link".isNull,
    array(struct(lit(null).cast("string"), lit(null).cast("string")))
      .cast("array<struct<_VALUE:string,_type:string>>")
  ).otherwise(col("Natural_Sources_Extrenal_links.Link"))
)

val natural_source_zip_df3 = natural_source_zip_df2.withColumn(
  "Natural_Sources_zip_Arr",
  explode_outer(arrays_zip($"Natural_Sources_Link_NNN"))
)

val natural_source_zip_combined_df = natural_source_zip_df3
  .groupBy(
    $"Natural_Sources_Entry_Number",
    $"Scientific_Name",
    $"Common_Name",
    $"Geographic_Area"
  )
  .agg(
    concat_ws(
      ";",
      collect_list($"Natural_Sources_zip_Arr.Natural_Sources_Link_NNN._VALUE")
    ).alias("External_Links")
  )

val productsfinaldf = productsdf
  .join(
    productsdf2,
    productsdf("Entry_Number") === productsdf2("products2_Entry_Number"),
    "inner"
  )
  .join(
    combined_zip_df2,
    productsdf("Entry_Number") === combined_zip_df2(
      "products_zip_Entry_Number"
    ),
    "inner"
  )
  .join(
    milestone_zip_combined_df,
    productsdf("Entry_Number") === milestone_zip_combined_df(
      "Milestone_Entry_Number"
    ),
    "inner"
  )
  .join(
    natural_source_zip_combined_df,
    productsdf("Entry_Number") === natural_source_zip_combined_df(
      "Natural_Sources_Entry_Number"
    ),
    "inner"
  )
  .drop("products_zip_Entry_Number")
  .drop("Milestone_Entry_Number")
  .drop("Natural_Sources_Entry_Number")
  .drop("products2_Entry_Number")
productsfinaldf.printSchema()

val finaldf = productsfinaldf.repartition(15000)

finaldf.write
  .mode("OVERWRITE")
  .option("format", "parquet")
  .option(
    "path",
    "s3a://" + bucket_name + "/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name
  )
  .saveAsTable(db_name + "." + set_name);
