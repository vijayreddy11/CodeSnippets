//Pubmed ID  column - data N/A in file

import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL;
import org.apache.spark.sql.{AnalysisException, Column, DataFrame, SparkSession}
import org.apache.hadoop.fs.{FileSystem, Path}
import java.util.zip.{ZipEntry, ZipOutputStream, ZipInputStream}
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ListBuffer
import java.net.URI
import org.apache.hadoop.conf.Configuration
import java.io.{File, FileInputStream, FileOutputStream}
import org.apache.spark.sql.types._
import java.util.Calendar

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val bucket_name = args(0)
val data_store = args(1)
val db_name = args(2)
val set_name = args(3)
val almaren = Almaren(set_name)

val cal = Calendar.getInstance()
val Year = cal.get(Calendar.YEAR)
val Month = cal.get(Calendar.MONTH) + 1

val CDDI_Latest = "CDDI-AbbVie_Full_Reload-" + Year + Month + "01"

val df_old = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "Pharmacokinetics")
  .option("inferSchema", true)
  .option("samplingRatio", 0.001)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/CDDI-AbbVie_Full_Reload-20221101/pharmacokinetics.xml"
  )

val df = spark.read
  .format("com.databricks.spark.xml")
  .option("rowTag", "Pharmacokinetics")
  .option("inferSchema", true)
  .option("samplingRatio", 0.001)
  .schema(df_old.schema)
  .load(
    "s3a://" + bucket_name + "/data/unstructured/rsa/Genomics_Clarivate_CDDI_datafeed/" + CDDI_Latest + "/pharmacokinetics.xml"
  )

val df2 = df.repartition(1000)

df2.printSchema()

val df3 = df2.withColumn(
  "Condition_NNN",
  when(
    $"Model.Conditions".isNull,
    array(struct(lit(null).cast("string"), lit(null).cast("long")))
      .cast("array<struct<_VALUE:string,_id:long>>")
  ).otherwise(col("Model.Conditions.Condition"))
)

df3.printSchema()

val df4 = df3
  .withColumn("zip_Arr", explode_outer(arrays_zip($"Condition_NNN")))
  .withColumn("Administration", explode_outer($"Administered_products.product"))
  .select(
    $"_id".alias("Study_ID"),
    $"Model.Organism".alias("Organism"),
    $"Model.Sex".alias("Sex"),
    $"Model.Age".alias("Age_Group"),
    $"Model.Race".alias("Race"),
    $"Model.Food_Inake".alias("Food_Intake"),
    $"zip_Arr.Condition_NNN._VALUE".alias("Conditions"),
    $"Model.Hepatic_Failure".alias("Hepatic_Failure_State"),
    $"Model.Renal_Failure".alias("Renal_Failure_State"),
    $"Administration._entry_number".alias("Administration_drug_entry_number"),
    $"Administration.main_name".alias("Administration_drug_name"),
    $"Administration.Formulation".alias("Administration_formulation"),
    $"Administration.Administration_Route".alias("Administration_Route"),
    $"Administration.dose._VALUE".alias("Administration_dose_value"),
    $"Administration.dose._unit".alias("Administration_dose_value_unit"),
    $"Administration.regimen".alias("Administration_regime"),
    $"Administration.duration._VALUE".alias("Administration_duration"),
    $"Administration.duration._unit".alias("Administration_duration_units"),
    $"Administration.Interacting_Agents"
      .alias("Administration_Interacting_Agents"),
    $"Measured_Product._entry_number".alias("Measurment_Drug_Entry_Number"),
    $"Measured_Product._VALUE".alias("Measurment_Drug_Name"),
    $"Parameter".alias("Measurment_Parameter"),
    $"Compartment".alias("Measurment_Compartment"),
    $"Technique".alias("Measurment_Technique"),
    $"Operator".alias("Measurment_Operator"),
    $"Value1".alias("Measurment_value1"),
    $"Range".alias("Measurment_range"),
    $"Value2".alias("Measurment_value2"),
    $"Unit_Given".alias("Measurment_Unit_Given"),
    $"Source._VALUE".alias("Source_id"),
    $"Source._Type".alias("Source_type")
  )

df4.printSchema()

val df5 = df4
  .groupBy(
    "Study_ID",
    "Organism",
    "Sex",
    "Age_Group",
    "Race",
    "Food_Intake",
    "Hepatic_Failure_State",
    "Renal_Failure_State",
    "Administration_drug_entry_number",
    "Administration_drug_name",
    "Administration_formulation",
    "Administration_Route",
    "Administration_dose_value",
    "Administration_dose_value_unit",
    "Administration_regime",
    "Administration_duration",
    "Administration_duration_units",
    "Administration_Interacting_Agents",
    "Measurment_Drug_Entry_Number",
    "Measurment_Drug_Name",
    "Measurment_Parameter",
    "Measurment_Compartment",
    "Measurment_Technique",
    "Measurment_Operator",
    "Measurment_value1",
    "Measurment_range",
    "Measurment_value2",
    "Measurment_Unit_Given",
    "Source_id",
    "Source_type"
  )
  .agg(concat_ws(";", collect_list($"Conditions")).alias("Conditions"))

val df6 = df5.withColumn(
  "Conditions",
  when(col("Conditions") === "", lit(null).cast("string"))
    .otherwise(col("Conditions"))
)

val finaldf = df6.repartition(1000)

finaldf.printSchema()

finaldf.write
  .mode("OVERWRITE")
  .option("format", "parquet")
  .option(
    "path",
    "s3a://" + bucket_name + "/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name
  )
  .saveAsTable(db_name + "." + set_name);
