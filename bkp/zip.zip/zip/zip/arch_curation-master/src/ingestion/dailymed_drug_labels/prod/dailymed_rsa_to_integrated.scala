import  sys.process._;
val rsa_path = "s3://arch-prod-datalake/data/unstructured/rsa/dailymed_nlmdata/"
val integrated_path = "s3://arch-prod-datalake/data/unstructured/integrated/dailymed_nlmdata/"
s"sh /opt/nabu/nabu-almaren-jobs/arch_curation/src/ingestion/dailymed_drug_labels/prod/dailymed_rsa_to_integrated.sh $rsa_path $integrated_path".!
