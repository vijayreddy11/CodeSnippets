import boto3
import zipfile
from io import BytesIO
from pyspark.sql.types import ArrayType, StructField, StructType, StringType, IntegerType

bucket = 'arch-prod-datalake'
src_prefix = 'data/unstructured/rsa/DailyMed_Drug_Labels/nlmdata/.dailymed/'
src_append_str = 'dm_spl_daily_update'
dest_key = 'data/unstructured/rsa/DailyMed_Drug_Labels/staging/'
s3 = boto3.client('s3', use_ssl=False)
zipped_keys =  s3.list_objects_v2(Bucket=bucket, Prefix=(src_prefix+src_append_str), Delimiter = "/")
src_file_list = []
for key in zipped_keys['Contents']:
    if key.get('Key').endswith('.zip'):
        src_file_list.append(key['Key'])
s3_resource = boto3.resource('s3')
for file in src_file_list:
    zip_obj = s3_resource.Object(bucket_name=bucket, key=file)
    print ('source : '+zip_obj.key)
    dest_path = zip_obj.key.replace(src_prefix,dest_key,1).replace('.zip','',1)
    buffer = BytesIO(zip_obj.get()["Body"].read())
    z = zipfile.ZipFile(buffer)
    for filename in z.namelist():
        file_info = z.getinfo(filename)
        dest_file_key = dest_path + '/' + f'{filename}'
        s3_resource.meta.client.upload_fileobj(
            z.open(filename),
            Bucket=bucket,
            Key=dest_file_key)
        print('Unzipped_key : '+dest_file_key)
        
        
        
