import boto3
import zipfile
from io import BytesIO
from pyspark.sql.types import ArrayType, StructField, StructType, StringType, IntegerType

bucket = 'arch-dev-datalake'
src_prefix = 'data/unstructured/rsa/DailyMed_Drug_Labels/staging/'
dest_key = 'data/unstructured/rsa/dailymed_nlmdata/'


s3_resource = boto3.resource('s3')
src_zip_file_list = []
src_other_file_list = []
our_bucket = s3_resource.Bucket(bucket)
for obj in our_bucket.objects.filter(Prefix=src_prefix):
    if obj.key.endswith('.zip'):
        src_zip_file_list.append(obj.key)
    else:
        src_other_file_list.append(obj.key)


for key in src_other_file_list:
    old_key = key
    if old_key.endswith('/'):
        print('Skipped key : '+old_key)
    else:
        old_source = { 'Bucket': bucket,'Key': old_key}
        new_key = old_key.replace(src_prefix, dest_key, 1)
        new_obj = our_bucket.Object(new_key)
        new_obj.copy(old_source)
        print('copied ', old_key, 'to', new_key)


for file in src_zip_file_list:
    zip_obj = s3_resource.Object(bucket_name=bucket, key=file)
    print ('source : '+zip_obj.key)
    dest_path = zip_obj.key.replace(src_prefix,dest_key,1).replace('.zip','',1)
    buffer = BytesIO(zip_obj.get()["Body"].read())
    z = zipfile.ZipFile(buffer)
    for filename in z.namelist():
        file_info = z.getinfo(filename)
        dest_file_key = dest_path + '/' + f'{filename}'
        s3_resource.meta.client.upload_fileobj(
            z.open(filename),
            Bucket=bucket,
            Key=dest_file_key)
        print('Unzipped_key : '+dest_file_key)





