#export PYSPARK_PYTHON=python3
from datetime import date
import boto3
import argparse
import requests
import logging
import re
from datetime import date
import sys
from pyspark.sql import SparkSession

spark = SparkSession \
    .builder \
    .appName("drug_concept_v") \
    .enableHiveSupport() \
    .getOrCreate()

class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())



if __name__ == "__main__":
    args = spark.conf.get("spark.driver.args").split(" ")
    token = spark.conf.get("spark.nabu.token")
    endpoint = spark.conf.get("spark.nabu.fireshots_url")
    environment = args[0]
    cred_id = args[1]
    cred_type = args[2]
    url = args[3]
    #table_name = args[4]
    
    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(token,cred_id,cred_type,endpoint)
    
    username = dict_pass["data"]["username"]
    password = dict_pass["data"]["password"]
    
    
    #url = "jdbc:postgresql://pp-data-ingestion.caurfctzkbwj.us-east-1.rds.amazonaws.com:5432/arch_staging"
   
    #set_name = "drug_concept_v"
    
    #fetching data from postgres
    query = "(SELECT * from academe_staging.drug_concept_v) my_tab"
    
    df = spark.read \
        .format("jdbc") \
        .option("url", url) \
        .option("dbtable", query) \
        .option("user", username) \
        .option("password", password) \
        .option("driver", "org.postgresql.Driver") \
        .load()
    
df.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/integrated/academe.db/arch_staging/academe_staging/drug_concept_v").saveAsTable("academe.drug_concept_v")

