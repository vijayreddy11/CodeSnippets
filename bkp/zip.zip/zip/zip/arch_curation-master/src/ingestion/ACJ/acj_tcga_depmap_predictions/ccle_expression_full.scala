import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "acj_tcga_depmap_predictions"
val set_name = "ccle_expression_full"
val almaren = Almaren(set_name)

val text_df = spark.read.option("header", "true").text("s3a://arch-"+environment+"-datalake/data/unstructured/rsa/acj_tcga_depmap_predictions/CCLE_expression_full.csv")
val df1 = text_df.withColumn("rn", monotonically_increasing_id()).withColumn("lines", when($"rn" <= 0, regexp_replace($"value","[\\-|\\.|\\(\\ ]","_")).otherwise($"value"))

val df2 = df1.select("lines")
val df3 = df2.withColumn("rn", monotonically_increasing_id()).withColumn("lines1", when($"rn" <= 0, regexp_replace($"lines","[\\)]","")).otherwise($"lines"))
val df4 = df3.select("lines1")
val df5 = df4.withColumn("rn", monotonically_increasing_id()).withColumn("lines2", when($"rn" <= 0, regexp_replace($"lines1","__","_")).otherwise($"lines1"))
val df6 = df5.select("lines2")

df6.repartition(1).write.option("header", "true").mode("overwrite").text("s3a://arch-"+environment+"-datalake/data/unstructured/rsa/"+set_name+"_temp")

val df7 = spark.read.option("maxColumns", 60000).option("header", "true").csv("s3a://arch-"+environment+"-datalake/data/unstructured/rsa/"+set_name+"_temp")

df7.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name);

