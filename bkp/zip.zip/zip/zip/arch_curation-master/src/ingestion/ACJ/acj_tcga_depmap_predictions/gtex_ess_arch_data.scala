import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "acj_tcga_depmap_predictions"
val set_name = "gtex_ess_arch_data"
val almaren = Almaren(set_name)

val df= almaren.builder.sourceFile("csv","s3a://arch-"+environment+"-datalake/data/unstructured/rsa/acj_tcga_depmap_predictions/GTEX_ess_ARCH_data.tsv",Map("header" -> "false","delimiter" -> "\t")).batch

df.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name);

