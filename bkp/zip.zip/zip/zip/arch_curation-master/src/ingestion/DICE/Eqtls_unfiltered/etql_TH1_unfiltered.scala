import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL


val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "dice"
val set_name = "eqtl_TH1_unfiltered"
val almaren = Almaren("RWD_Concerto_Ingestion")


val df= spark.read.text("s3a://arch-"+environment+"-datalake/data/unstructured/rsa/database_of_immune_cell_eqtls/downloads/DICE_DB_1/eqtl/unfiltered/TH1.vcf.gz")

val df2=df.withColumn("Index",monotonically_increasing_id).filter('Index >6).drop("Index")

df2.write.mode("overwrite").text("s3a://arch-"+environment+"-datalake/development/data/unstructured/rsa/database_of_immune_cell_eqtls/downloads/DICE_DB_1/eqtl/unfiltered/"+set_name+"_temp")

val df3=spark.read.format("csv").option("header", "true").option("delimiter", "\t").option("inferSchema", "true").load("s3a://arch-"+environment+"-datalake/development/data/unstructured/rsa/database_of_immune_cell_eqtls/downloads/DICE_DB_1/eqtl/unfiltered/"+set_name+"_temp")


val df4 = df3.columns.foldLeft(df3)((df3, colName) => df3.withColumnRenamed(colName, colName.replace("#","")))

df4.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)





