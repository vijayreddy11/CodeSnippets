import requests
import json

url1 = "https://federationdev.abbvie.com/as/token.oauth2"
header1 = {"Content-Type": "application/x-www-form-urlencoded"}
ipdata = {
"client_id" : "abbvie.cosmosrim",
"client_secret" : "O0ZRg1gbhIeymbkrB3jJ9ZdT8GtlwUxotm7IcJBkz3QoYe79N65rvsEIgpbk71pK",
"grant_type" : "client_credentials"
}

response1 = requests.post(url1, headers=header1, data=ipdata)

if(response1.status_code!=200):
	print("Request failed. ", response1.json())
	sys.exit(1)

access_data= response1.json()
print(access_data)

access_token = access_data['access_token']

header2 = {"Authorization": "Bearer " + access_token , "Content-Type": "application/json"}

url2 = "https://api-pq.abbvie.com/COSMOS/querydata/EDRAPROD"

ip2 = {"query": "SELECT c.r_object_id, c.object_name,c.study_number,c.r_version_label,c.ectd_title,c.authors,c.i_folder_id, f.r_folder_path, c.r_modify_date, c.a_content_type FROM rd_document c, dm_folder f WHERE c.r_modify_date > DATE('02/01/2022 13:00:00','MM/DD/YYYY hh:mm:ss') and c.i_folder_id = f.r_object_id and c.i_folder_id = f.r_object_id and r_folder_path != ' ' and classification_group='Study Protocol' and classification_domain in ('Clinical') and document_status in ('Internally Approved') and c.a_content_type='pdf' ENABLE (ROW_BASED)"}

response2 = requests.post(url2, headers=header2, json=ip2)

if(response2.status_code!=200):
	print("Request failed. ", response2.json())
	sys.exit(1)

objects_info = response2.json()
objects = objects_info['rows']

for object in objects:
	object_id = object['properties']['r_object_id']
	print(object_id)
	object_name = object['properties']['object_name'].strip().replace(" ", "_") +".pdf"
	print(object_name)
	header3 = {"Authorization": "Bearer " + access_token , "Content-Type": "application/pdf"}
	
	url3 = "https://api-pq.abbvie.com/COSMOS/export/EDRAPROD/"+object_id+"/pdf?"
	
	response3 = requests.get(url3, headers=header3)
	
	open(object_name, 'wb').write(response3.content)

print('done')
