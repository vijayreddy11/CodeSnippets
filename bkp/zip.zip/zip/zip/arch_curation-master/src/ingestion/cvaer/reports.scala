import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL


val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "cvaer"
val set_name = "reports"
val almaren = Almaren(set_name)

val df= almaren.builder.sourceFile("csv","s3a://arch-"+environment+"-datalake/data/unstructured/rsa/cvaer/content/cvponline_extract_20210630/reports.txt",Map("header" -> "false","delimiter" -> "$")).batch

val quenyaDsl= QuenyaDSL

val dsl= quenyaDsl.compile("""_c0$REPORT_ID:LongType
|_c0$REPORT_NO:StringType
|_c0$VERSION_NO:IntegerType
|_c0$DATRECEIVED:TimestampType
|_c0$DATINTRECEIVED:TimestampType
|_c0$MAH_NO:StringType
|_c0$REPORT_TYPE_CODE:StringType
|_c0$REPORT_TYPE_ENG:StringType
|_c0$REPORT_TYPE_FR:StringType
|_c0$GENDER_CODE:StringType
|_c0$GENDER_ENG:StringType
|_c0$GENDER_FR:StringType
|_c0$AGE:StringType
|_c0$AGE_Y:StringType
|_c0$AGE_UNIT_ENG:StringType
|_c0$AGE_UNIT_FR:StringType
|_c0$OUTCOME_CODE:StringType
|_c0$OUTCOME_ENG:StringType
|_c0$OUTCOME_FR:StringType
|_c0$WEIGHT:StringType
|_c0$WEIGHT_UNIT_ENG:StringType
|_c0$WEIGHT_UNIT_FR:StringType
|_c0$HEIGHT:StringType
|_c0$HEIGHT_UNIT_ENG:StringType
|_c0$HEIGHT_UNIT_FR:StringType
|_c0$SERIOUSNESS_CODE:StringType
|_c0$SERIOUSNESS_ENG:StringType
|_c0$SERIOUSNESS_FR:StringType
|_c0$DEATH:StringType
|_c0$DISABILITY:StringType
|_c0$CONGENITAL_ANOMALY:StringType
|_c0$LIFE_THREATENING:StringType
|_c0$HOSP_REQUIRED:StringType
|_c0$OTHER_MEDICALLY_IMP_COND:StringType
|_c0$REPORTER_TYPE_ENG:StringType
|_c0$REPORTER_TYPE_FR:StringType
|_c0$SOURCE_CODE:StringType
|_c0$SOURCE_ENG:StringType
|_c0$SOURCE_FR:StringType
|_c0$E2B_IMP_SAFETYREPORT_ID:StringType
|_c0$AUTHORITY_NUMB:StringType
|_c0$COMPANY_NUMB:StringType""".stripMargin)

val finalDf = quenyaDsl.execute(dsl,df)

finalDf.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name);

