import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL


val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "cvaer"
val set_name = "outcome_lx"
val almaren = Almaren(set_name)

val df= almaren.builder.sourceFile("csv","s3a://arch-"+environment+"-datalake/data/unstructured/rsa/cvaer/content/cvponline_extract_20210630/outcome_lx.txt",Map("header" -> "false","delimiter" -> "$")).batch

val quenyaDsl= QuenyaDSL

val dsl= quenyaDsl.compile("""_c0$OUTCOME_LX_ID:LongType
|_c1$OUTCOME_CODE:StringType
|_c2$OUTCOME_EN:StringType
|_c3$OUTCOME_FR:StringType""".stripMargin)

val finalDf = quenyaDsl.execute(dsl,df)

finalDf.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name);

