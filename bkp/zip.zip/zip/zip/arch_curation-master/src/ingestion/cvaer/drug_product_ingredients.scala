import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "cvaer"
val set_name = "drug_product_ingredients"
val almaren = Almaren(set_name)

val df= almaren.builder.sourceFile("csv","s3a://arch-"+environment+"-datalake/data/unstructured/rsa/cvaer/content/cvponline_extract_20210630/drug_product_ingredients.txt",Map("header" -> "false","delimiter" -> "$")).batch

val quenyaDsl= QuenyaDSL

val dsl= quenyaDsl.compile("""_c0$DRUG_PRODUCT_INGREDIENT_ID:LongType
|_c1$DRUG_PRODUCT_ID:IntegerType
|_c2$DRUGNAME:StringType
|_c3$ACTIVE_INGREDIENT_ID:IntegerType
|_c4$ACTIVE_INGREDIENT_NAME:StringType""".stripMargin)

val finalDf = quenyaDsl.execute(dsl,df)

finalDf.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name);

