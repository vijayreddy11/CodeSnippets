import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL


val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "cvaer"
val set_name = "report_drug"
val almaren = Almaren(set_name)

val df= almaren.builder.sourceFile("csv","s3a://arch-"+environment+"-datalake/data/unstructured/rsa/cvaer/content/cvponline_extract_20210630/report_drug.txt",Map("header" -> "false","delimiter" -> "$")).batch

val quenyaDsl= QuenyaDSL

val dsl= quenyaDsl.compile("""_c0$REPORT_DRUG_ID:LongType
|_c1$REPORT_ID:LongType
|_c2$DRUG_PRODUCT_ID:LongType
|_c3$DRUGNAME:StringType
|_c4$DRUGINVOLV_ENG:StringType
|_c5$DRUGINVOLV_FR:StringType
|_c6$ROUTEADMIN_ENG:StringType
|_c7$ROUTEADMIN_FR:StringType
|_c8$UNIT_DOSE_QTY:StringType
|_c9$DOSE_UNIT_ENG:StringType
|_c10$DOSE_UNIT_FR:StringType
|_c11$FREQUENCY:IntegerType
|_c12$FREQ_TIME:StringType
|_c13$FREQUENCY_TIME_ENG:StringType
|_c14$FREQUENCY_TIME_FR:StringType
|_c15$FREQ_TIME_UNIT_ENG:StringType
|_c16$FREQ_TIME_UNIT_FR:StringType
|_c17$THERAPY_DURATION:StringType
|_c18$THERAPY_DURATION_UNIT_ENG:StringType
|_c19$THERAPY_DURATION_UNIT_FR:StringType
|_c20$DOSAGEFORM_ENG:StringType
|_c21$DOSAGEFORM_FR:StringType""".stripMargin)

val finalDf = quenyaDsl.execute(dsl,df)

finalDf.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name);

