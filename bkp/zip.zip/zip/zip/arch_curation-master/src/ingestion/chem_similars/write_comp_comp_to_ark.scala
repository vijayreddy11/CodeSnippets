import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_compound_relationships"
val almaren = Almaren(set_name)

val df = spark.read.option("mergeSchema", "true").parquet("s3a://arch-"+environment+"-datalake/data/warehouse/integrated/ark.db/t_compound_compound_relationships_test/t_compound_compound_relationships/")
df.write.format("parquet").partitionBy("TILESRC").mode("OVERWRITE").option("path","s3a://arch-dev-datalake/data/warehouse/integrated/ark.db/t_compound_compound_relationships").saveAsTable("ark.t_compound_compound_relationships")