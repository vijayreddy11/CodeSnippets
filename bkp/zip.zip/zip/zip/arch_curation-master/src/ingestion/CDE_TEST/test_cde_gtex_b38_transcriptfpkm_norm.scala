import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val environment = "dev"
val data_store = "rsa"
val db_name = "ingestion_test"
val set_name = "test_cde_gtex_b38_transcriptfpkm_norm"
val almaren = Almaren(set_name)
val res = almaren.builder.sourceSql("""
SELECT
DISTINCT tr.abbv_uid as abbvie_transcript_uid,
tf.sample_index,
tf.transcript_index,
log2((tf.fpkm*sa.tpm_scaling_factor)+0.1) as log2TPM,
tf.count
FROM gtex_b38.transcriptfpkm tf
left join gtex_b38.transcriptannotation ta
on tf.transcript_index = ta.transcript_index
left join academe.transcript_er_v8_0_16nov2021 tr
on split(ta.gene_id,'[\.]')[0] = tr.ensembl_gene_stable_ID
left join gtex_b38.samples sa
on tf.sample_index = sa.sample_index
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/development/data/warehouse/"+data_store+"/"+db_name+"/"+set_name).saveAsTable(db_name+"."+set_name);




