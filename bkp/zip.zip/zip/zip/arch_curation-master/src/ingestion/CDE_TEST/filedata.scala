val df = spark.sql("select id,name,uploaded_by,mimetype from rsa_ddmlcnp1_mdm_disc.filedata");

df.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-prod-datalake/data/warehouse/integrated/ddmlcnp1_mdm_disc.db/filedata").saveAsTable("ddmlcnp1_mdm_disc.filedata");
