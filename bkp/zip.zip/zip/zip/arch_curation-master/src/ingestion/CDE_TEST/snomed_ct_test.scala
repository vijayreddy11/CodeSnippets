import java.net.URI
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.conf.Configuration
import scala.collection.mutable.ListBuffer

var listOfFiles = new ListBuffer[String]()
val environment = "dev"
val data_store = "integrated"
val db_name = "snomed_ct"

val path = "s3a://arch-dev-datalake/data/unstructured/rsa/SNOMED_CT_Codes/SnomedCT_USEditionRF2_PRODUCTION_20210901T120000Z/"
val fileSystem = FileSystem.get(URI.create(path), new Configuration())
val it = fileSystem.listFiles(new Path(path), true)
while (it.hasNext()) {
    val f_path = it.next().getPath().toString
    if(f_path.contains("Readme")){
    }
    else{
    listOfFiles += f_path
    }
}
val filesList = listOfFiles.toList
for( file <- filesList) {
	val file_path = file.toString
	val file_name = file_path.split("/").last.toString
	val set_name = file_name.replace(".txt","").replace("-","_")
    val df = spark.read.format("csv").option("delimiter", "\t").option("header", "true").load(file_path)
    df.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name);
}


