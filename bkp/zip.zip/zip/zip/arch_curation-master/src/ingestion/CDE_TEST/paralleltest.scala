import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren
import org.apache.spark.sql.SaveMode
import java.util
import java.util.{ArrayList, List}
import com.modak.HashPartitionJDBCUtils
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{AnalysisException, Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import scala.collection.JavaConverters._
import scala.collection.mutable.ListBuffer
import scala.util.Random
import java.util.Base64
import com.modak.common._
import com.modak.common.credential.Credential

println(
  "......................................Start of the Execution....................................."
)

def getUniqueID: Long = {
  val rn = new Random();
  System.currentTimeMillis() * 10000 + rn.nextInt(9999);
}

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val endpoint = sc.getConf.get("spark.nabu.fireshots_url")
val token = sc.getConf.get("spark.nabu.token")
val cred_id = args(0).toInt
val cred_type = args(1).toInt
val almaren = Almaren("jdbcparallel-almaren")

val CredentialResult = Credential.getCredentialData(
  CredentialPayload(s"$token", cred_id, cred_type, s"$endpoint")
)

val ldap = CredentialResult.data match {
  case ldap: ldap => ldap
  case _ =>
    throw new Exception("Currently unable avalible for other credentials Types")
}

val hostUser = ldap.username
val hostPassword = ldap.password
val set_name = args(2)
val parallelCount = args(3).toInt
val environment =  args(4)
val data_store =  args(5)
val db_name =  args(6)
val destFilePath =
  "s3a://arch-" + environment + "-datalake/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name
var t1 = System.currentTimeMillis()
val destTablename = db_name + "." + set_name
val tableSelectQuery = "SELECT inchi_key as inchi_key, primary_source as primary_source, primary_identifier as primary_identifier, ctab as ctab, direct_mol as direct_mol, anumber as anumber, canonical_smiles as canonical_smiles FROM ABV_FEDERATED_DATA.FD_STRUCTURE "
println("tableSelectQuery : " + tableSelectQuery)
val hostUrl = "jdbc:oracle:thin:@uq00606p.abbvienet.com:1521:aidxunp1"
println("hostUrl : " + hostUrl)

val hostDriver = "oracle.jdbc.OracleDriver"
println("hostDriver : " + hostDriver)
//Parallelize the query

var queryList: util.List[String] =
  HashPartitionJDBCUtils.createHashPartitionSQLQueries(
    hostUrl,
    hostDriver,
    tableSelectQuery,
    hostUser,
    hostPassword,
    parallelCount
  );

if (queryList == null) {
  queryList = new util.ArrayList[String]
  queryList.add(tableSelectQuery);
  println("Query is not parallelized")
}

println("queryList --------- +\n" + queryList)
var qList = queryList.asScala.toList.par

val df = almaren.builder.sourceJdbcParallel(hostUrl, hostDriver, qList, 8, Option(hostUser), Option(hostPassword)).batch
df.repartition(200).write.format("parquet").mode("overwrite").option("path", destFilePath).saveAsTable(destTablename)

