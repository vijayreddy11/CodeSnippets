import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL

val almaren = Almaren("FAERS_ODD_RATIOS_STATS")

var FAERS_ODD_RATIOS_STATS = almaren.builder.sourceSql("""
with setup
as
(
select f.pref_ai, 
       f.pt, 
       f.cc_wd_wr as A, 
       f.cc_wd_wor as B,
       f.cc_wod_wr as C,
       f.cc_wod_wor as D,
       f.cc_d as R1,
       f.cc_wod as R2,
       f.cc_r as C1,
       f.cc_wor as C2,
       f.cc as N
from app_spotfire.faers_odd_ratios f
where 1=1 
)
, setup2 as 
(
select pref_ai,
       pt,
       A,
       B,
       C,
       D,
       ((A/B)/(C/D)) as O_R,
       log10((A/B)/(C/D)) as L10OR,
       ln((A/B)/(C/D)) as LNOR,
       (R1*C1/N) as Ax,
       (R1*C2/N) as Bx,
       (R2*C1/N) as Cx,
       (R2*C2/N) as Dx
from setup
where 1=1 
)
,setup3 as
(
Select pref_ai,
       pt,
       A,
       B,
       C,
       D,
       O_R,
       L10OR,
       LNOR,
       sqrt(1/A + 1/B + 1/C + 1/D) as SE_LNOR,
       (power((A-Ax),2)/Ax) + (power((B-Bx),2)/Bx) + (power((C-Cx),2)/Cx) + (power((C-Cx),2)/Cx) as CHI_SQUARE
from setup2
where 1=1 
)
INSERT OVERWRITE TABLE app_spotfire.FAERS_ODD_RATIOS_STATS
select pref_ai,
       pt,
       A,
       B,
       C,
       D,
       O_R,
       L10OR,
       LNOR,
       SE_LNOR,
       exp(LNOR - 1.96*SE_LNOR) as 95PCT_CI_LOWERLIMIT,
       exp(LNOR + 1.96*SE_LNOR) as 95PCT_CI_UPPERLIMIT,
       LNOR/SE_LNOR as Z_STAT,
       CHI_SQUARE
from setup3
where 1=1 
""").batch


println("Successfully inserted data into app_spotfire.FAERS_ODD_RATIOS_STATS ")

