CREATE EXTERNAL TABLE `app_spotfire`.`faers_odd_ratios`(
`pref_ai` string,
`pt` string,
`cc_wd_wr` bigint,
`cc_d` bigint,
`cc_r` bigint,
`cc` bigint,
`cc_wd_wor` bigint,
`cc_wod_wr` bigint,
`cc_wod_wor` bigint,
`aftermarket_reports_wd_wr` bigint,
`aftermarket_reports_wd` bigint,
`cc_wod` bigint,
`cc_wor` bigint)
ROW FORMAT SERDE                                   
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'  
STORED AS INPUTFORMAT                              
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'  
OUTPUTFORMAT                                       
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat' 
LOCATION                                           
   's3a://arch-prod-datalake/data/warehouse/integrated/app_spotfire.db/faers_odd_ratios'
