import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL

val almaren = Almaren("FAERS_ODD_RATIOS")

var FAERS_ODD_RATIOS = almaren.builder.sourceSql("""
WITH final_versions as
(
select de.caseid||max(de.caseversion) FINAL_PRIMARY_ID
from faers.faers_demographics de
group by de.caseid
)
, case_records as 
(
SELECT 
       de.fda_dt,
       nvl(di.activeingredname, dr.prod_ai) pref_ai,
       di.trade_name_aers,
       di.activeingredname SCOPIA_PROD_AI,
       dr.prod_ai FAERS_PROD_AI,
       dr.drugname,
       de.primaryid,
       dr.drug_seq,
       dr.val_vbm,
       dr.route,
       dr.dose_form,
       r.pt
FROM final_versions fv
join faers.faers_demographics de on fv.FINAL_PRIMARY_ID = de.primaryid
INNER JOIN faers.faers_drugs dr ON de.primaryid = dr.primaryid
INNER JOIN faers.faers_reactions r ON de.primaryid = r.primaryid
left join scopiarx.drug_index di on upper(dr.drugname) = upper(di.trade_name_aers)
WHERE 1 = 1
  AND dr.role_cod IN ('PS','SS')
)
,  cc as
(
select count(distinct cr.primaryid) CC
from case_records cr
)
, cc_d as 
(
select cr.pref_ai, count(distinct cr.primaryid) CC_D
from case_records cr
GROUP BY cr.pref_ai
)
, cc_r as 
(
select cr.pt, count(distinct cr.primaryid) CC_R
from case_records cr
GROUP BY cr.pt
)
, cc_d_r as 
(
select cr.pref_ai, cr.pt, count(distinct cr.primaryid) CC_D_R
from case_records cr
group by cr.pref_ai, cr.pt
)
INSERT OVERWRITE TABLE app_spotfire.FAERS_ODD_RATIOS
SELECT cc_d_r.pref_ai,
       cc_d_r.pt,
       cc_d_r.cc_d_r as CC_WD_WR,
       cc_d.cc_d,
       cc_r.cc_r,
       cc.cc,
       (cc_d.cc_d - cc_d_r.cc_d_r) as CC_WD_WOR,
       (cc_r.cc_r - cc_d_r.cc_d_r) as CC_WOD_WR,
       (cc.cc - cc_d.cc_d - cc_r.cc_r + cc_d_r.cc_d_r) as CC_WOD_WOR,
       cc_d_r.cc_d_r as aftermarket_reports_WD_WR,
       cc_d.cc_d as aftermarket_reports_WD,
       (cc.cc-cc_d.cc_d) cc_wod,
       (cc.cc - cc_r.cc_r) cc_wor
FROM cc_d_r
JOIN cc_d ON cc_d_r.pref_ai = cc_d.pref_ai
JOIN cc_r ON cc_d_r.pt = cc_r.pt
CROSS JOIN cc
""").batch

println("Successfully inserted data into app_spotfire.FAERS_ODD_RATIO ")
