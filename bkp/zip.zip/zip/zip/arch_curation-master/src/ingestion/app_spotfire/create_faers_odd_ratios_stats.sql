CREATE EXTERNAL TABLE `app_spotfire`.`faers_odd_ratios_stats`(
`pref_ai` string,
`pt` string,
`a` bigint,
`b` bigint,
`c` bigint,
`d` bigint,
`o_r` double,
`l10or` double,
`lnor` double,
`se_lnor` double,
`95pct_ci_lowerlimit` double,
`95pct_ci_upperlimit` double,
`z_stat` double,
`chi_square` double)
ROW FORMAT SERDE                                   
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'  
STORED AS INPUTFORMAT                              
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'  
OUTPUTFORMAT                                       
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat' 
LOCATION                                           
   's3a://arch-prod-datalake/data/warehouse/integrated/app_spotfire.db/faers_odd_ratios_stats'
