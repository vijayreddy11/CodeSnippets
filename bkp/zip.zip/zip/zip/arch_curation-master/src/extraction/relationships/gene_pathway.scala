import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_gene_pathway_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    t1.gene_uid as ENTITY1,
    ":Gene" as ENTITY1_TYPE,
    t1.pathway_uid as ENTITY2,
    ":Pathway" as ENTITY2_TYPE,
    "IS_MEMBER_OF" as REL_TYPE,
    1 as STRENGTH,
    cast(1.0 as float) as RESULT,
    "Confidence" as RESULT_TYPE,
    1.0 as CONFIDENCE,
    "IPA" as SOURCE,
    named_struct(
        "RULESETS",array(),
        "SOURCES",array("arch_normalized.ingenuity_pathwaynodes_norm","academe.pathways_er_v2_17dec2021","academe.gte_gene_v"),
        "FILTERS",array(),
        "TIMESTAMP",current_timestamp(),
        "VERSION","1.5.0"
    ) as LINEAGE,
    named_struct(
            "PATHWAY_ID",t1.pathway_id,
            "PATHWAY_NAME",t1.pathway_name,
            "PATHWAY_CLASSIFICATIONS",split(t1.pathway_classification,"[|]"),
            "PATHWAY_NODE_ID",t1.pathway_node_id,
            "PATHWAY_NODE_NAME",t1.pathway_node_name,
            "NODE_NAME",t1.node_name,
            "GENE_FAMILY",t1.gene_family,
            "HUMAN_ENTREZGENE_ID",t1.human_entrezgene_id
    ) as METADATA
FROM arch_normalized.ingenuity_pathwaynodes_norm t1
WHERE t1.gene_uid is not null and t1.pathway_uid is not null
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
