import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_gene_gene_form_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
WITH intermediate_rel_table_lm AS(
SELECT 
	Gene_UID as ENTITY1, 
	':Gene' as ENTITY1_TYPE,
	entity2 as ENTITY2, 
	':GeneForm' as ENTITY2_TYPE,
	'HAS_FORM' as REL_TYPE,
	1 as STRENGTH, 
	1 as RESULT,
	'Existence' as RESULT_TYPE,
	1 as CONFIDENCE,
	named_struct(
		"RULESETS","",
		"SOURCES",array("arch_normalized.termite_lut_norm","academe.gte_gene_v"),
		"FILTERS",array("result>0","corp_id is not null","corp_id like 'A-%' or corp_id like 'PR-%' or corp_id like 'DC-%'"),
		"TIMESTAMP",unix_timestamp(),
		"VERSION",'1.2.0') 
	as LINEAGE,
	named_struct(
		"GENE_ID", Gene_id,
		"GENE_FORM_ID",entity2,
		"SOURCE",Source) 
	as METADATA
FROM arch_normalized.termite_lut_norm termit)
,partitioned_filter_tbl_1 as (
SELECT *,ROW_NUMBER() OVER(PARTITION BY ENTITY1,ENTITY2 ORDER BY ENTITY1) AS ROWNUM 
FROM intermediate_rel_table_lm
)
,intermediate_rel_table_sm AS(
SELECT 
	abbvie_gene_uid as ENTITY1, 
	':Gene' as ENTITY1_TYPE,
	protein as ENTITY2, 
	':GeneForm' as ENTITY2_TYPE,
	'HAS_FORM' as REL_TYPE,
	1 as STRENGTH, 
	1 as RESULT,
	'Existence' as RESULT_TYPE,
	1 as CONFIDENCE,
	named_struct(
		"RULESETS","",
		"SOURCES",array("arch_normalized.ddmlcnp1_tdb_dm_invitro_stats_all_norm","preclinical.termite_lut_tdb","academe.compounds_v","academe.gte_gene_v"),
		"FILTERS",array("result>0","corp_id is not null","corp_id like 'A-%' or corp_id like 'PR-%' or corp_id like 'DC-%'"),
		"TIMESTAMP",unix_timestamp(),
		"VERSION",'1.2.0') 
	as LINEAGE,
	named_struct(
		"GENE_ID", Gene_id,
		"GENE_FORM_ID",protein,
		"SOURCE",Source) 
	as METADATA
FROM arch_normalized.ddmlcnp1_tdb_dm_invitro_stats_all_norm tdb_norm
)
,partitioned_filter_tbl_2 as (
SELECT *,ROW_NUMBER() OVER(PARTITION BY ENTITY1,ENTITY2 ORDER BY ENTITY1) AS ROWNUM 
FROM intermediate_rel_table_sm
)
SELECT 
	ENTITY1,
	ENTITY1_TYPE,
	ENTITY2,
	ENTITY2_TYPE,
	REL_TYPE,
	STRENGTH,
	RESULT,
	RESULT_TYPE,
	CONFIDENCE,
	LINEAGE,
	METADATA 
FROM partitioned_filter_tbl_1 
WHERE ROWNUM=1 and ENTITY1 is NOT NULL
UNION
SELECT 
	ENTITY1,
	ENTITY1_TYPE,
	ENTITY2,
	ENTITY2_TYPE,
	REL_TYPE,
	STRENGTH,
	RESULT,
	RESULT_TYPE,
	CONFIDENCE,
	LINEAGE,
	METADATA 
FROM partitioned_filter_tbl_2 
WHERE ROWNUM=1 and ENTITY1 is NOT NULL
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)  
