import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_pkpairing_measured_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
with compound_pkpairing as (
	SELECT 
	ENTITY2 as ENTITY1,
	':Compound' as ENTITY1_TYPE,
	concat(ENTITY1,'|',ENTITY2) as ENTITY2,
	':PKPairing' as ENTITY2_TYPE,
	'As Measured' as REL_TYPE,
	1 as STRENGTH,
	1 as RESULT,
	'Membership' as RESULT_TYPE,
	1 as CONFIDENCE,
	named_struct(
		"RULESETS",array(""),
		"SOURCES",array("arch_normalized.pk_combined_view_norm","academe.compounds_v"),
		"FILTERS",array("result>0"),
		"TIMESTAMP",unix_timestamp(),
		"VERSION","1.2.0"
	) as LINEAGE,
	named_struct(
		"RACE" , RACE,
		"AGE_GROUPS" , AGE_GROUPS,
		"REGIMEN" , REGIME,
		"STUDY_ID", STUDY_ID,
		"SOURCE",source,
		"DOSED_ID",ENTITY1_ID,
		"MEASURED_ID",ENTITY2_ID
	) as METADATA 
	from arch_normalized.pk_combined_view_norm
)
SELECT 
ENTITY1,
ENTITY1_TYPE,
ENTITY2,
ENTITY2_TYPE,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
LINEAGE,
METADATA 
from (SELECT *,ROW_NUMBER() OVER(PARTITION BY ENTITY1,ENTITY2 ORDER BY ENTITY1) AS ROWNUM
from compound_pkpairing) x
where ROWNUM=1
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
