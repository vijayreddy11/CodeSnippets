import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_gene_adverseevent_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""with gene_ae_norm as (
select
split(gene,'\:')[0] as gene,
split(gene,'\:')[1] as modality,
ae.ae as ae,
ae.contingency_table as contingency_table,
ae.ct_d,
ae.ct_c,
ae.ct_b,
ae.ct_a,
concat('[',concat_ws(',',concat('[',concat_ws(',',cast(ae.ct_d as string),cast(ae.ct_c as string)),']'),concat('[',concat_ws(',',cast(ae.ct_b as string),cast(ae.ct_a as string)),']')),']') as  ct_table,
ae.drug_count as drug_count,
ae.ae_count as ae_count,
ae.drugs_with_ae as drugs_with_ae,
ae.bioactive_drugs as bioactive_drugs,
ae.chi2 as chi2,
ae.odds_ratio as odds_ratio,
log10(ae.odds_ratio) as log_odds,
ae.p_value as p_value,
ae.fisher_p,
ae.delta,
ae.ci,
ae.corrected_ci,
ae.fdr_p,
ae.fdr_corrected as fdr_corrected,
ae.ae_uid as ae_uid,
aer.abbv_code as ae_code,
aer.meddra_socs as meddra_socs,
ae.gene_uid as gene_uid
from acj_target_mediated_adverse_events.t_gene_ae_relationships  ae
left outer join 
academe.health_condition_v aer
on trim(ae.ae) = aer.abbv_term
where ae.thresholdset = '11'
--and ae.bioactive_drugs = 146 
)

,gene_ae_relationships as (
select 
aen.gene as gene,
aen.modality as modality,
aen.ae as ae,
aen.contingency_table as contingency_table,
aen.ct_d,
aen.ct_c,
aen.ct_b,
aen.ct_a,
aen.ct_table,
aen.drug_count as drug_count,
aen.ae_count as ae_count,
aen.drugs_with_ae as drugs_with_ae,
aen.bioactive_drugs as bioactive_drugs,
aen.chi2 as chi2,
aen.odds_ratio as odds_ratio,
aen.log_odds as log_odds,
aen.p_value as p_value,
aen.fisher_p,
aen.delta,
aen.ci,
aen.corrected_ci,
aen.fdr_corrected fdr_corrected,
aen.ae_uid as ae_uid,
aen.ae_code as ae_code,
aen.gene_uid as gene_uid,
aen.meddra_socs as meddra_socs,
CASE 
    WHEN bioactive_drugs < 10 THEN 0.0
    WHEN p_value > 1e-2 THEN  0.0
    WHEN p_value < 1e-9 THEN 0.9
    WHEN p_value < 1e-8 THEN 0.8
    WHEN p_value < 1e-7 THEN  0.7
    WHEN p_value <= 1e-6 THEN  0.6
    WHEN p_value < 1e-5 THEN 0.5
    WHEN p_value < 1e-4 THEN  0.4
    WHEN p_value <= 1e-3 THEN  0.3
    WHEN p_value <= 1e-2 THEN  0.2
END as confidence,
CASE
    WHEN bioactive_drugs < 10 THEN 0
    WHEN p_value > 1e-2 THEN  0
    WHEN abs(log_odds) > 1.5 then 3
    WHEN abs(log_odds) > 1 then 2
    ELSE 1
END as strength,
CASE
    WHEN bioactive_drugs < 10 THEN "COULD_NOT_BE_DETERMINED"
    WHEN p_value > 1e-2 THEN "NOT_SIGNIFICANTLY_ASSOCIATED_WITH"
    WHEN odds_ratio > 1 THEN "ASSOCIATED_WITH_INCREASED_RISK"
    ELSE "ASSOCIATED_WITH_DECREASED_RISK"
END as relationship,
CASE 
    WHEN bioactive_drugs < 10 THEN "Stats unreliable bioactive_drugs < 10"
    WHEN p_value > 1e-2 THEN "Not significant"
    WHEN p_value < 1e-9 THEN "significant after FDR correction"
    WHEN p_value < 1e-8 THEN "significant after FDR correction"
    WHEN p_value < 1e-7 THEN "significant after FDR correction"
    WHEN p_value <= 1e-6 THEN "significant after FDR correction"
    WHEN p_value < 1e-5 THEN "trend only - not significant after FDR correction"
    WHEN p_value < 1e-4 THEN "trend only - not significant after FDR correction"
    WHEN p_value <= 1e-3 THEN "trend only - not significant after FDR correction"
    WHEN p_value <= 1e-2 THEN "trend only - not significant after FDR correction"
END as stats_comment
from gene_ae_norm aen )

SELECT DISTINCT
gene_uid as ENTITY1,
':Gene' as ENTITY1_TYPE,
ae_uid as ENTITY2,
':Patient Adverse Event' as ENTITY2_TYPE,
relationship as REL_TYPE,
STRENGTH,
1 as RESULT,
"Membership" as RESULT_TYPE,
CONFIDENCE,
named_struct(
             "RULESETS",array(""),
             "SOURCES",array("acj_target_mediated_adverse_events.t_gene_ae_relationships"),
             "FILTERS",array(""),
             "TIMESTAMP",unix_timestamp(),
             "VERSION","2.1.0"
             ) as LINEAGE,
named_struct(
            "GENE",gaer.gene,
            "MODALITY",gaer.modality,
            "AE",gaer.ae,
            "CT_D",gaer.ct_d,
			"CT_C",gaer.ct_c,
			"CT_B",gaer.ct_b,
			"CT_A",gaer.ct_a,
			"CONTINGENCY_TABLE",ct_table,
            "DRUG_COUNT",gaer.drug_count,
            "AE_COUNT",gaer.ae_count,
            "DRUGS_WITH_AE",gaer.drugs_with_ae,
            "BIOACTIVE_DRUGS",gaer.bioactive_drugs,
            "CHI2",gaer.chi2,
            "ODDS_RATIO",gaer.odds_ratio,
            "LOG_ODDS",gaer.log_odds,
            "P_VALUE",gaer.p_value,
            "FDR_CORRECTED",gaer.fdr_corrected,
            "AE_CODE",gaer.ae_code,
            "MEDDRA_SOCS", gaer.meddra_socs,
            "STATS_COMMENT",gaer.stats_comment,
            "SOURCE", "ACJ") as METADATA
from gene_ae_relationships gaer """).batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
