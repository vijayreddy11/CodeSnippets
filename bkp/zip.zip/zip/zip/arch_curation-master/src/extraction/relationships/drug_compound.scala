import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_drug_compound_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
with comp as (
select 
component, abbv_uid as drug_uid, abbv_num_comp as drug_num_comp, abbv_term_source as drug_term_source, abbv_term as drug_abbv_term
from academe.drug_concept_v
lateral view explode(abbv_comp_names) x as component
-- the where clause limits the selection to only for multi-component drugs (abbv_num_comp > 1) and the example cortellis drug cetirizine + pseudoephedrine 
-- edit/remove/comment the where clause as needed.  If omitted it could be used for relationship mapping for all drugs regardless of abbv_num_comp
--where abbv_num_comp > 1 
--and abbv_uid = 'e9777ac1375adb60df88c5e68374e8ca'
)
SELECT DISTINCT 
t1.drug_uid as ENTITY1,
":Drug" as ENTITY1_TYPE,
t1.id as ENTITY2,
":Compound" as ENTITY2_TYPE,
"CONTAINS" as REL_TYPE,
    1 as STRENGTH,
    1 as CONFIDENCE,
    1 as RESULT,
    "Membership" as RESULT_TYPE,
    named_struct(
        "RULESETS",array(),
        "SOURCES",array("academe.drug_concept_v","ark.t_compound_entities"),
        "FILTERS",array(),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.0"
    ) as LINEAGE,
    named_struct(
        "SOURCE",t1.sources,
        "INCHI_KEY",t1.inchi_key
    ) as METADATA
FROM (
select abbv_uid as component_drug_uid, abbv_num_comp as comp_num_comp, abbv_term_source as comp_term_source, abbv_term as comp_abbv_term, chembl_code_exploded as comp_chembl_id,
comp.drug_uid as drug_uid, comp.drug_num_comp as drug_num_comp,  drug_term_source, drug_abbv_term, cmpd.id,cmpd.sources,cmpd.inchi_key
from (
  select *
  from academe.drug_concept_v dc 
  lateral view explode(split(chembl_code,'\\|')) y as chembl_code_exploded
  ) dc
join comp on lower(abbv_term) = lower(comp.component)
join (select id,chembl_id,inchi_key,collect_set(primarysource) as sources from ark.t_compound_entities group by id,chembl_id,inchi_key) cmpd on trim(dc.chembl_code_exploded) = cmpd.chembl_id
-- Here we are intentionally selecting the single-component drug that a single component of the multi-component drug matches to and so we limit it to singletons with abbv_num_comp = 1
where comp.component is not null and abbv_num_comp = 1) t1
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
