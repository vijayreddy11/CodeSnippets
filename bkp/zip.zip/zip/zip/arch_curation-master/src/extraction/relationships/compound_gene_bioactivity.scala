import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_gene_bioactivity_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
with GBRS_norm_rel as (
select distinct
    COMPOUND_ID as ENTITY1,
    'HAS_RECOGNIZED_ANTIGEN' as Relationship,
     GENE_UID as ENTITY2,
    4 as Strength,
    1.0 as Confidence,
    MONIKER,
    ALTERNATE_NAME,
    GENE_SYMBOL,
    SPECIES,
    REPORTED_MOA,
    'GBRS' as SOURCE,
    inchi_key
from 
   arch_normalized.ddmlcnp1_gbrs_snp_norm
where MONIKER like 'PR-%' or MONIKER like 'DC-%'
) 
,biacore as (
select 
    b.entity1 as entity1,
    b.entity2 as gene_form,
    b.rel_type as relationship,
    b.result as Result,
    b.result_type as Result_Type,
    g.entity1 as entity2,
    b.metadata,
    CASE 
        WHEN b.metadata.species like 'Cynomolgus%' or b.metadata.species rlike 'Monkey' THEN 'Monkey'
        WHEN b.metadata.species like 'Bovine%' THEN 'Cow'
        WHEN b.metadata.species like 'Homo sapiens%' THEN 'Human'
        WHEN b.metadata.species like 'Rattus%' THEN 'Rat'
        WHEN b.metadata.species like 'Mus musculus%' THEN 'Mouse'
        WHEN b.metadata.species like 'Canis%' THEN 'Dog'
        WHEN b.metadata.species like 'Gallus%' THEN 'Chicken'
        ELSE b.metadata.species 
    END as SPECIES
from 
    ark.t_compound_gene_form_relationship b, 
    ark.t_gene_gene_form_relationships g
    where b.result_type = 'Kd' and b.entity2 = g.entity2
)
,result_rule as (
select 
    entity1,
    gene_form,
    relationship,
    -log10(Result) as Result,
    'pKd' as Result_Type,
    entity2,
    SPECIES,
    1.0 as confidence,
    metadata
from 
    biacore
)
,strength_rule as (
select 
    entity1,
    gene_form,
    relationship,
    Result,
    Result_Type,
    entity2,
    SPECIES,
    confidence,
    metadata,
    case
        when result>8 then 4
        when result>7 then 3
        when result>6 then 2
        when result>5 then 1
        else 0
    end as strength
from result_rule
)
,first_occurrence as (
select * ,
row_number() over(partition by ENTITY1,ENTITY2 order by Result desc) as flag
from strength_rule
)
,keep_properties as (
select 
    entity1, 
    relationship, 
    entity2, 
    Strength, 
    Confidence, 
    Species,
    result, 
    result_type,
    gene_form, 
    metadata
from first_occurrence
where flag = 1
)
,gbrs_biacore as (
select *, count(*) over (partition by entity1,entity2,species) as flag
from(
    select 
        entity1, 
        entity2, 
        relationship,
        Strength, 
        null as result, 
        null as result_type,
        Confidence, 
        REPORTED_MOA,
        species,
        cast(null as string) as gene_form,
        named_struct(
	    "ALTERNATE_NAME",cast(ALTERNATE_NAME as string),
	    "MODALITY","Binding",
            "CATEGORY", cast(null as string),
            "RESULT_UNITS", cast(null as string),
            "SPECIES",cast(null as string),
            "QUALIFIER", cast(null as string),
            "ASSAY_NAME", cast(null as string),
            "SOURCE", SOURCE,
            "MOLECULE_LOT", cast(null as string),
            "ANTIGEN_LOT", cast(null as string),
	    "INCHI_KEY",inchi_key
        ) as metadata
    from GBRS_norm_rel where entity1 is not null and entity2 is not null
    UNION 
    select 
        entity1, 
        entity2, 
        relationship,
        Strength, 
        result, 
        result_type,
        Confidence, 
        cast(null as string) as REPORTED_MOA,
        species,
        gene_form,
        named_struct(
	    "ALTERNATE_NAME", cast(null as string),
	    "MODALITY","Binding",
            "CATEGORY", metadata.category,
            "RESULT_UNITS", metadata.result_units,
            "SPECIES", metadata.species,
            "QUALIFIER", metadata.qualifier,
            "ASSAY_NAME", metadata.assay_name,
            "SOURCE", metadata.source,
            "MOLECULE_LOT", metadata.molecule_lot,
            "ANTIGEN_LOT", metadata.antigen_lot,
	    "INCHI_KEY",metadata.inchi_key
        ) as metadata
     from keep_properties where entity1 is not null and entity2 is not null
) x
)
,merge_data as(
select 
    entity1, 
    entity2,
    species, 
    relationship,
    Strength,
    Confidence, 
    result, 
    result_type,
    REPORTED_MOA,
    gene_form,
    metadata
from(
    select
    ROW_NUMBER() OVER(PARTITION BY gb.entity1,gb.entity2,gb.species ORDER BY gb.relationship) AS ROWNUM,
    gb.entity1,
    gb.entity2,
    gb.species,
    gb.relationship,
    gb.strength,
    gb.confidence,
    max(gb.result) over(partition by gb.entity1,gb.entity2,gb.species order by gb.entity1) as result,
    max(gb.result_type) over(partition by gb.entity1,gb.entity2,gb.species order by gb.entity1) as result_type,
    max(gb.REPORTED_MOA) over(partition by gb.entity1,gb.entity2,gb.species order by gb.entity1) as REPORTED_MOA,
    max(gb.gene_form) over(partition by gb.entity1,gb.entity2,gb.species order by gb.entity1) as gene_form,
    max(gb.metadata) over(partition by gb.entity1,gb.entity2,gb.species order by gb.entity1) as metadata
from gbrs_biacore gb
    where flag>1
) y
where ROWNUM = 2
UNION
select 
    entity1, 
    entity2,
    species, 
    relationship,
    Strength,
    Confidence, 
    result, 
    result_type,
    REPORTED_MOA,
    gene_form,
    metadata
from gbrs_biacore
    where flag = 1
)
,num_measurements_in_merge_data as
(
select *,count(result) over (partition by entity1,entity2,metadata.modality) as num_measurements from merge_data
) 
,compound_gene_bioactivity as(
select
    m.entity1 as ENTITY1,
    ':Compound' as ENTITY1_TYPE,
    m.entity2 as ENTITY2,
    ':Gene' as ENTITY2_TYPE,
    m.relationship as REL_TYPE,
    m.strength as STRENGTH,
    m.result as RESULT,
    m.result_type as RESULT_TYPE,
    m.confidence as CONFIDENCE,
    named_struct(
        "RULESETS",array(""),		
	"SOURCES",array("arch_normalized.ddmlcnp1_gbrs_snp_norm","ark.t_compound_gene_form_relationship","ark.t_gene_gene_form_relationships","academe.gte_gene_v"),
        "FILTERS",array(""),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.4.0"
    ) as LINEAGE,
    named_struct(
        "ALTERNATE_NAME",metadata.alternate_name,
    	"MODALITY",metadata.modality,
	"NUM_MEASUREMENTS",num_measurements,
        "CATEGORY", metadata.category,
        "RESULT_UNITS", metadata.result_units,
        "SPECIES", m.species,
        "QUALIFIER", metadata.qualifier,
        "ASSAY_NAME", metadata.assay_name,
        "SOURCE", metadata.source,
        "MOLECULE_LOT", metadata.molecule_lot,
        "ANTIGEN_LOT", metadata.antigen_lot,
        "REPORTED_MOA", m.REPORTED_MOA,
        "GENE_FORM", m.gene_form,
	"INCHI_KEY",metadata.inchi_key
    ) as METADATA
from num_measurements_in_merge_data m
)
,compound_gene_bioactivity_filter as(
SELECT DISTINCT
    t.ENTITY1,
    t.ENTITY1_TYPE,
    t.ENTITY2,
    t.ENTITY2_TYPE,
    t.REL_TYPE,
    t.STRENGTH,
    t.RESULT,
    t.RESULT_TYPE,
    t.CONFIDENCE,
    t.LINEAGE,
    t.METADATA,   
    ROW_NUMBER() OVER(PARTITION BY t.ENTITY1,t.ENTITY2 ORDER BY t.STRENGTH DESC,t.METADATA.REPORTED_MOA NULLS LAST) AS ROWNUM
from compound_gene_bioactivity t
)
SELECT
    ENTITY1,
    ENTITY1_TYPE,
    ENTITY2,
    ENTITY2_TYPE,
    REL_TYPE,
    STRENGTH,
    RESULT,
    RESULT_TYPE,
    CONFIDENCE,
    LINEAGE,
    METADATA
from compound_gene_bioactivity_filter
where ROWNUM=1
""").batch


res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
