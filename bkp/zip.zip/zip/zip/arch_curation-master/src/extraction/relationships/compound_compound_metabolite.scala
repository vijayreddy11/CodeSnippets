import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_compound_metabolite_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
with first_occurence_filter_table as (
  select Entity1,Entity1_ID,Entity2,Species,RACE, AGE_GROUPS, REGIME, STUDY_ID, 
    case
      when locate("A-",entity1_id)>0 and locate(".",entity1_id)>0 then split(entity1_id,'\\.')[0]
      else entity1_id
    end as Entity1_Parent_ID,
    case
      when locate("A-",entity2_id)>0 and locate(".",entity2_id)>0 then split(entity2_id,'\\.')[0]
      else entity2_id
    end as Entity2_ID
  from 
  (
    SELECT *, row_number() over(PARTITION BY Entity1,Entity2,Species order by entity1) ROWNUM
    from arch_normalized.pk_combined_view_norm
  ) a where ROWNUM = 1 and 
    (((locate('A-',entity1_id)>0) or (locate('DC-',entity1_id)>0) or (locate('PR-',entity1_id)>0)) and 
    ((locate('A-',entity2_id)>0) or (locate('DC-',entity2_id)>0) or (locate('PR-',entity2_id)>0)))
), 
metabolite_triple as (
  select 
  Entity1,
  Entity1_Parent_ID as Entity1_ID,
  Entity1_Parent_ID,
  Entity2,Entity2_id,Species,
  'Has metabolite' as Relationship,
  1 as Strength,
  RACE, 
  AGE_GROUPS, 
  REGIME, 
  STUDY_ID,
  'PK Studies' as source
  from first_occurence_filter_table where Entity1_Parent_ID <> Entity2_ID
),
metabolite_relationship as (
  select 
    ENTITY1,
	':Compound' as ENTITY1_TYPE,
    ENTITY2,
	':Compound' as ENTITY2_TYPE,
    RELATIONSHIP as REL_TYPE,
    STRENGTH,
    1 as RESULT,'Existence' as RESULT_TYPE,
    1 as CONFIDENCE,
    named_struct(
      "RULESETS",array(""),
      "SOURCES",array("arch_normalized.pk_combined_view_norm","academe.compounds_v"),
      "FILTERS",array("result>0"),
      "TIMESTAMP",unix_timestamp(),
      "VERSION","1.2.0"
    ) as LINEAGE,
    named_struct(
      "SPECIES",SPECIES,
      "ENTITY1_PARENT_ID", ENTITY1_PARENT_ID,
      "ENTITY1_ID",ENTITY1_ID,
      "ENTITY2_ID",ENTITY2_ID,
      "RACE" , RACE,
      "AGE_GROUPS" , AGE_GROUPS,
      "REGIMEN" , REGIME,
      "STUDY_ID", STUDY_ID,
      "SOURCE",SOURCE
    ) as METADATA
  from metabolite_triple
)
select 
  ENTITY1,
  ENTITY1_TYPE,
  ENTITY2,
  ENTITY2_TYPE,
  REL_TYPE,
  STRENGTH,
  RESULT,
  RESULT_TYPE,
  CONFIDENCE,
  LINEAGE,
  METADATA
from (
  select *,row_number() over(PARTITION BY ENTITY1,ENTITY2,METADATA.SPECIES order by ENTITY1) as ROWNUM from metabolite_relationship
) b where ROWNUM = 1
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
