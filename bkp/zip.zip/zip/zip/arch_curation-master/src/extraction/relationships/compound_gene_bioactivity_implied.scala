import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_gene_bioactivity_implied_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
 WITH dc_dg AS
  (SELECT dc.entity1 AS drug_uid,
          dc.entity2 AS comp_uid,
          dg.entity2 AS gene_uid
   FROM ark.t_drug_compound_relationships dc
   INNER JOIN ark.t_drug_gene_relationships dg ON 1=1
   AND dc.entity1 = dg.entity1
   WHERE dc.rel_type = 'CONTAINS'
     AND dg.rel_type = 'HAS_MOA' ),
  
   compound_gene_bioactivity AS
  (SELECT DISTINCT dc_dg.comp_uid AS ENTITY1,
                   dc_dg.gene_uid AS ENTITY2
   FROM dc_dg
   LEFT OUTER JOIN
     (SELECT *
      FROM ark.t_compound_gene_bioactivity_relationships
      WHERE rel_type='HAS_RECOGNIZED_ANTIGEN') cg ON 1=1
   AND dc_dg.comp_uid = cg.entity1
   AND dc_dg.gene_uid = cg.entity2
   WHERE cg.entity1 IS NULL
     AND cg.entity2 IS NULL),
	
    compound_gene AS
    (SELECT DISTINCT entity1, entity2 
    FROM ark.t_compound_gene_relationships
    WHERE  upper(METADATA.reported_moa) = "YES")

SELECT distinct cgb.* from (SELECT ENTITY1,
       ':Compound' AS ENTITY1_TYPE,
       ENTITY2,
       ':Gene' AS ENTITY2_TYPE,
       'HAS_RECOGNIZED_ANTIGEN' AS REL_TYPE,
       4 AS STRENGTH,
       cast(NULL AS int) AS RESULT,
       cast(NULL AS string) AS RESULT_TYPE,
       1.0 AS CONFIDENCE,
       named_struct("RULESETS", array(""), "SOURCES", array("ark.t_drug_gene_relationships", "ark.t_drug_compound_relationships","ark.t_compound_gene_relationships"), "FILTERS", array(""), "TIMESTAMP", unix_timestamp(), "VERSION", "2.0.0-hf1") AS LINEAGE,
       named_struct("MODALITY", "Activity", "NUM_MEASUREMENTS", 0, "SPECIES", "Human", "SOURCE", "IMPLIED", "REPORTED_MOA", "Yes") AS METADATA
FROM compound_gene_bioactivity)cgb
LEFT OUTER JOIN compound_gene cg
ON 1=1
   AND cgb.entity1 = cg.entity1
   AND cgb.entity2 = cg.entity2
WHERE cg.entity1 IS NULL
AND cg.entity2 IS NULL
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
