import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_gene_phenotype_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
select 
  	t1.abbvie_phenotype_uid as ENTITY1,
  	":Phenotype" as ENTITY1_TYPE,
  	t1.abbvie_gene_uid as ENTITY2,
	":Gene" as ENTITY2_TYPE,
	"ASSOCIATED_WITH" as REL_TYPE,
	3 as STRENGTH,
	TRUE as RESULT,
	"boolean" as RESULT_TYPE,
	1 as CONFIDENCE,
	named_struct(
		"RULESETS",array("OMIM_STRENGTH_RULE"),
		"SOURCES",array("arch_normalized.genemap2_norm","omim.mim2gene","academe.gte_gene_v","academe.t_VARIANTS_lookup_v2_core_ukbb_finngen_omim_gwas_02202021","academe.health_condition_v"),
		"FILTERS",array(),
		"TIMESTAMP",unix_timestamp(),
		"VERSION","1.2.0")
	as LINEAGE,
  named_struct(
	"ABBVIE_VARIANT_UID", t1.abbvie_variant_uid, 
	"VARIANT",concat(t1.chromosome,":",t1.genomic_position_start,"-",t1.genomic_position_end),
	"CYTO_LOCATION",t1.cyto_location,
	"COMPUTED_CYTO_LOCATION",t1.computed_cyto_location,
	"COMMENTS",t1.comments,
	"SOURCE","OMIM"
  ) as METADATA
FROM (select * from arch_normalized.genemap2_norm 
where abbvie_phenotype_uid is not null and abbvie_gene_uid is not null) t1
inner join omim.mim2gene t2
on t1.mim_number=t2.mim_number
where not ((t1.approved_symbol is null or trim(t1.approved_symbol) ='')
	and (t1.entrez_gene_id is null or trim(t1.entrez_gene_id) =''))
	and t2.mim_entry_type='phenotype'
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
