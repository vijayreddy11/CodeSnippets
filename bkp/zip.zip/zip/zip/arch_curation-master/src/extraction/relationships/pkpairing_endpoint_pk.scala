import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_pkpairing_endpoint_pk_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
select distinct
	concat(entity1,'|',entity2) as ENTITY1,
	':PKPairing' as ENTITY1_TYPE,
	concat(RESULT_CATEGORY,'|',RESULT_TYPE) as ENTITY2,
	':Endpoint:PK' as ENTITY2_TYPE,
	'Has Property' as REL_TYPE,
	1 as STRENGTH,
	CAST(RESULT as double) as RESULT,
	'Result Measurement' as RESULT_TYPE,
	1 as CONFIDENCE,
	named_struct(
	      "RULESETS",array(""),
	      "SOURCES",array("arch_normalized.pk_combined_view_norm","ark.t_compound_entities"),
	      "FILTERS",array("result>0"),
	      "TIMESTAMP",unix_timestamp(),
	      "VERSION","1.2.0"
    	) as LINEAGE,
	named_struct(
		"MEASURED_AS_TOTAL_MAB" , MEASURED_AS_TOTAL_MAB,
		"DOSED_ID" , ENTITY1_ID,
		"MEASURED_ID" , ENTITY2_ID,
		"RESULT_CATEGORY" , RESULT_CATEGORY,
		"RESULT_TYPE" , RESULT_TYPE,
		"RESULT_UNIT" , RESULT_UNIT,
		"SPECIES" , SPECIES,
		"ROUTE" , ROUTE,
		"DOSE" , CAST(DOSE as double),
		"DOSE_UNIT" , DOSE_UNIT,
		"SAMPLE" , SAMPLE,
		"FOOD_INTAKE" , FOOD_INTAKE,
		"SEX" , SEX,
		"RACE" , RACE,
		"AGE_GROUPS" , AGE_GROUPS,
		"REGIMEN" , REGIME,
		"STUDY_ID", STUDY_ID,
		"SOURCE" , Source
		) as METADATA
from arch_normalized.pk_combined_view_norm
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
