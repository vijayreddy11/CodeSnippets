import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_drug_gene_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    t1.abbv_drug_uid as ENTITY1,
    ':Drug' as ENTITY1_TYPE,
    t1.abbv_gene_uid as ENTITY2,
    ':Gene' as ENTITY2_TYPE,
    'HAS_MOA' as REL_TYPE,
    4 as STRENGTH,
    1 as RESULT,
    'Activity' as RESULT_TYPE,
    1.0 as CONFIDENCE,
    named_struct(
        "RULESETS",array(""),
        "SOURCES",array("arch_normalized.r_moa_ids_norm","academe.gte_gene_v","academe.drug_concept_v"),
        "FILTERS",array(""),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.3.0"
    ) as LINEAGE,
    named_struct(
	"MODALITY","Activity",
	"PARENT_ID",PARENT_ID,
	"MOLECULE_ID",MOLECULE_ID,
	"TARGET",TARGET,
	"ACTION_TYPE",ACTION_TYPE,
	"MOA",MOA,
	"SOURCE",SOURCE
    ) as METADATA
FROM arch_normalized.r_moa_ids_norm t1 where t1.abbv_drug_uid is not null and t1.abbv_gene_uid is not null
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
