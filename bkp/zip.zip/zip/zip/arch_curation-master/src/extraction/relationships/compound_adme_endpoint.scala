import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_endpoint_adme_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
select 
ENTITY1
,ENTITY1_TYPE
,ENTITY2
,ENTITY2_TYPE
,Relationship as REL_TYPE
,1 as STRENGTH
,1 as CONFIDENCE
,RESULT
,adme_assay as RESULT_TYPE
,named_struct(
		"RULESETS","",
        "SOURCES",array("ddmlcnp1_ppilot_rad.ddp_updated_adme,ark.t_compound_entities"),
        "FILTERS",array("data_group <> 'PK',col NOT LIKE '%WithNV%'"),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.1.0"
    ) as LINEAGE
,named_struct(
          "ADME_ASSAY",adme_assay,
          "ADME_GROUP",adme_group,
          "ADME_SUBGROUP",adme_subgroup,
	  "INCHI_KEY",inchi_key,
          "SPECIES",species,
		  "RESULT_DETAIL",Result_Detail,
          "SOURCE","FDB"
     ) as METADATA
from arch_normalized.ddp_updated_adme_norm
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
