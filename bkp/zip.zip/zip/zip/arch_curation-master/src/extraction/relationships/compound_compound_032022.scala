import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_compound_relationships_032022"
val almaren = Almaren(set_name)

var df=spark.sql("show partitions ark.t_compound_compound_relationships_032022")
df = df.sort()
val tilesrc_list= df.select("partition").map(r => r.getString(0).split("=")(1).trim()).collect.toList 
var cnt = 0

for(tilesrc <- tilesrc_list){ 
var res = almaren.builder.sourceSql(s"""
select distinct 
	comps.compound_uid as ENTITY1,
	chem.ENTITY1_TYPE,
	comps2.compound_uid as ENTITY2,
	chem.ENTITY2_type,
	chem.REL_TYPE,
	chem.STRENGTH,
	chem.RESULT,
	chem.RESULT_TYPE,
	chem.CONFIDENCE,
	chem.LINEAGE,
	chem.METADATA,
	chem.TILESRC 
from (select * from ark.t_compound_compound_relationships_032022 where tilesrc = '${tilesrc}') chem 
LEFT JOIN academe.compounds_v comps ON
	chem.ENTITY1 = comps.INCHI_KEY 
LEFT JOIN academe.compounds_v comps2 ON
	chem.ENTITY2 = comps2.INCHI_KEY 
""").batch

if(cnt == 0){
	res.repartition(1).write.mode("OVERWRITE").option("format", "parquet").partitionBy("TILESRC").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
	cnt = 1
}
else{
	res.repartition(1).write.mode("APPEND").option("format", "parquet").partitionBy("TILESRC").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
}
}
