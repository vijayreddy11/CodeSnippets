import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_drug_drug_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT 
ABBVIE_DRUG1_UID as ENTITY1, 
':Drug' as ENTITY1_TYPE, 
ABBVIE_DRUG2_UID as ENTITY2, 
':Drug' as ENTITY2_TYPE, 
RELATIONSHIP as REL_TYPE, 
STRENGTH, 
CONFIDENCE,
SCORE AS RESULT,
'ScopiaRX Score' AS RESULT_TYPE,
named_struct(
	"RULESETS","",
	"SOURCES",array("scopiarx.di_main_db","academe.drug_concept_v"),
	"FILTERS",array(),
	"TIMESTAMP",unix_timestamp(),
	"VERSION","1.5"
	) as LINEAGE,
named_struct(
	"AI_DI",AI_DI,
	"AI_DPS",AI_DPS,
	"EMBL_DI",EMBL_DI,
	"EMBL_DPS",EMBL_DPS,
	"DI_ROUTE",DI_ROUTE,
	"DPS_ROUTE",DPS_ROUTE,
	"AE",AE,
	"AE_ID",AE_ID,
	"SEVERITY", SEVERITY,
	"MAGNITUDE", MAGNITUDE,
	"EXPLICIT_INTERACTION", EXPLICIT_INTERACTION,
	"CLASS_EFFECT", CLASS_EFFECT,
	"SOURCE_RXCLASS_1", SOURCE_RXCLASS_1,
	"EXPLICIT_FLAG_1", EXPLICIT_FLAG_1,
	"SOURCE_RXCLASS_2", SOURCE_RXCLASS_2,
	"EXPLICIT_FLAG_2", EXPLICIT_FLAG_2,
	"SOURCE_LABEL_1", SOURCE_LABEL_1,
	"INTERACTION_CODE_1", INTERACTION_CODE_1,
	"SOURCE_LABEL_2", SOURCE_LABEL_2,
	"INTERACTION_CODE_2", INTERACTION_CODE_2,
	"INTERACTION_TYPE_1", INTERACTION_TYPE_1,
	"INTERACTION_TYPE_2", INTERACTION_TYPE_2,
	"SOURCE", 'ScopiaRx - DI'
	) as METADATA
 from 
(SELECT *,row_number() over(partition by ai_di,ai_dps order by CONFIDENCE DESC) as ROWNUM from 
(SELECT *,
CASE WHEN INTERACTION_TYPE_1 ='DEC' OR INTERACTION_TYPE_2 = 'DEC' THEN 'DECREASES_THE_EFFECT_OF'
	WHEN INTERACTION_TYPE_1 = 'INC' OR INTERACTION_TYPE_2 = 'INC' THEN 'INCREASES_THE_EFFECT_OF'
	ELSE 'HAS_AN_INTERACTION_WITH' END as RELATIONSHIP,
CASE WHEN INTERACTION_CODE_1 ='min' OR INTERACTION_CODE_2 = 'min' THEN 'Minor'
	WHEN INTERACTION_CODE_1 = 'mod' OR INTERACTION_CODE_2 = 'mod' THEN 'Moderate'
	WHEN INTERACTION_CODE_1 = 'sev' OR INTERACTION_CODE_2 = 'sev' THEN 'Severe'
	WHEN INTERACTION_CODE_1 = 'contra' OR INTERACTION_CODE_2 = 'contra' THEN 'Contra-indicated'
	ELSE 'Not Specified in Label' END as MAGNITUDE,
CASE WHEN INTERACTION_CODE_1 ='w' OR INTERACTION_CODE_2 = 'w' THEN 'Warning'
	WHEN INTERACTION_CODE_1 = 'bw' OR INTERACTION_CODE_2 = 'bw' THEN 'Box Warning'
	WHEN INTERACTION_CODE_1 = 'ca' OR INTERACTION_CODE_2 = 'ca' THEN 'Caution'
	WHEN INTERACTION_CODE_1 = 'contra' OR INTERACTION_CODE_2 = 'contra' THEN 'Contra-indicated'
	ELSE 'Not Specified in Label' END as SEVERITY,
CASE WHEN INTERACTION_CODE_1 ='contra' OR INTERACTION_CODE_2 = 'contra' THEN 4
	WHEN INTERACTION_CODE_1 = 'sev' OR INTERACTION_CODE_2 = 'sev' THEN 3
	WHEN INTERACTION_CODE_1 = 'mod' OR INTERACTION_CODE_2 = 'mod' THEN 2
	ELSE 1 END as STRENGTH,
CASE WHEN EXPLICIT_FLAG_1 = 't' or EXPLICIT_FLAG_2 = 't' THEN 'Yes'
	ELSE 'No' END as EXPLICIT_INTERACTION,
CASE WHEN LENGTH(SOURCE_RXCLASS_1) > 0 and LENGTH(SOURCE_RXCLASS_2) > 0 THEN concat(SOURCE_RXCLASS_1,'|',SOURCE_RXCLASS_2)
	WHEN LENGTH(SOURCE_RXCLASS_1) > 0 THEN SOURCE_RXCLASS_1
	WHEN LENGTH(SOURCE_RXCLASS_2) > 0 THEN SOURCE_RXCLASS_2
	ELSE '' END as CLASS_EFFECT,
CASE WHEN EXPLICIT_FLAG_1 = 't' and EXPLICIT_FLAG_2 = 't' THEN 1.0
	WHEN EXPLICIT_FLAG_1 = 't' and EXPLICIT_FLAG_2 = 'f' THEN 0.9
	WHEN EXPLICIT_FLAG_1 = 't' THEN 0.8
	WHEN EXPLICIT_FLAG_1 = 'f' and EXPLICIT_FLAG_2 = 't' THEN 0.9
	WHEN EXPLICIT_FLAG_1 = 'f' and EXPLICIT_FLAG_2 = 'f' THEN 0.8
	WHEN EXPLICIT_FLAG_1 = 'f' THEN 0.8
	ELSE 0.7 END as CONFIDENCE
FROM arch_normalized.scopiarx_di_main_db_norm 
where NUM_IDS1 = 1 and NUM_IDS2 = 1 and ABBVIE_DRUG1_UID is not null and ABBVIE_DRUG2_UID is not null) t1 ) t2
where ROWNUM = 1 
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
