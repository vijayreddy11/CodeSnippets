import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_cv_endpoint_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
select DISTINCT
    cvr.ENTITY1,
    ":Compound" as ENTITY1_TYPE,
    CONCAT(cvr.ASSAY,', ',cvr.ENTITY2) as ENTITY2, 
    cvr.ENTITY2_TYPE, 
    cvr.RELATIONSHIP as REL_TYPE, 
    cast(cvr.STRENGTH as int) as STRENGTH, 
    cast(cvr.RESULT as Double) as RESULT, 
    cvr.RESULT_TYPE, 
    1.0 as CONFIDENCE,
    named_struct(
        "RULESETS","",
        "SOURCES",array("dependency.v_cv_result","aidxunp1_abv_fd2.fd_structure"),
        "FILTERS","",
        "TIMESTAMP",current_timestamp(),
        "VERSION",'1.5.0') as LINEAGE,
    named_struct(
        "SPECIES",cvr.SPECIES,
        "DOSE",cvr.DOSE,
	"INCHI_KEY",cvr.INCHI_KEY,
        "DOSE_UNITS",cvr.DOSE_UNITS,
        "MEASUREMENT_TIME",cvr.MEASUREMENT_TIME,
        "MEASUREMENT_TIME_UNITS",cvr.MEASUREMENT_TIME_UNITS,
        "DRUG_LEVEL",cvr.DRUG_LEVEL,
        "DRUG_LEVEL_QUAL",cvr.DRUG_LEVEL_QUAL,
        "FOLD_OVER_THRESHOLD", cast(cvr.FOLD_OVER_THRESHOLD as double),
        "MEASUREMENT_AREA",cvr.MEASUREMENT_AREA,
	"MEDDRA_ID", ep.meddra_id,
	"MEDDRA_NAME", ep.meddra_name,
        "SOURCE","CV SAFETY DATA",    "LINK",concat("http://spotdisc-lc.abbvienet.com:8333/spotfire/wp/OpenAnalysis?file=72bde15a-f1b4-4e27-befc-75a9b57185e1&ConfigurationBlock=ROOT=%22",fds.primary_identifier,"%22")
    ) as METADATA
from dependency.v_cv_result cvr
left outer join aidxunp1_abv_fd2.fd_structure fds on cvr.inchi_key=fds.inchi_key
left outer join dependency.pcs_meddra_endpoints ep on  
 lower(cvr.RELATIONSHIP) = lower(ep.effect) and
 --cvr.entity2 = concat(ep.endpoint_type,', ', ep.endpoint)
 cvr.entity2 = ep.endpoint --added join condition as suggested by Lynn (ARCHO-2458)
 --regexp_replace(regexp_replace(cvr.entity2,'\\P{ASCII}',''),'\@50','') = regexp_replace(ep.endpoint,'\\P{ASCII}','') --used regex function to remove non ascii values from the data
 and ep.destination = 'CV'
where 
    cvr.STRENGTH is not null 
    and cast(cvr.STRENGTH as double) is not null
    AND cvr.DOSE is not null 
    and cast(cvr.DOSE as float) is not null
    AND cvr.RESULT is not null 
    and cast(cvr.RESULT as double) is not null
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
