import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_gene_form_relationship"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
	t.ENTITY1,
	t.ENTITY1_TYPE,
	t.ENTITY2,
	t.ENTITY2_TYPE,
	t.REL_TYPE,
	t.STRENGTH,
	t.RESULT,
	t.RESULT_TYPE,
	t.CONFIDENCE,
	t.LINEAGE,
  t.METADATA
FROM(	
SELECT 
  gpsc.ENTITY1,
  ':Compound' as ENTITY1_TYPE,
  gpsc.ENTITY2,
  ':GeneForm' as ENTITY2_TYPE,
  concat('HAS_',gpsc.Category) as REL_TYPE,
  1 as STRENGTH,
  1 as CONFIDENCE,
  gpsc.RESULT,
  gpsc.RESULT_TYPE,
  named_struct(
    "RULESETS","",
    "SOURCES",array("academe.compounds_v","ddmlcnp1_ppilot_rad.biacore_gpsc"),
    "FILTERS",array("result>0","corp_id is not null","corp_id like 'A-%' or corp_id like 'PR-%' or corp_id like 'DC-%'"),
    "TIMESTAMP",unix_timestamp(),
    "VERSION",'1.2.0') 
  as LINEAGE,
  named_struct(
    "CATEGORY",gpsc.Category,
    "RESULT_UNITS",gpsc.result_units,
    "SPECIES",gpsc.species,
    "QUALIFIER",gpsc.qualifier,
    "ASSAY_NAME",gpsc.assay_name,
    "SOURCE",gpsc.source,
    "MOLECULE_LOT",gpsc.lot_number,
    "ANTIGEN_LOT",gpsc.bio_ent_lot_num,
    "LOT_NUMBER",gpsc.lot_number,
    "INCHI_KEY",gpsc.inchi_key,
    "BIO_ENT_LOT_NUM",gpsc.bio_ent_lot_num) 
  as METADATA
from (
select *,
Case 
	when Assay_Name in ('Biacore Kinetics') THEN 'BINDING_KINETICS'
	when locate('Stability', Assay_Name)>0  THEN 'STABILITY'
	when (Assay_Name in('DSC') OR Assay_Name in ('DSF')) THEN 'STABILITY'
	ELSE 'OTHER'
END as Category
from arch_normalized.biacore_gpsc_norm)gpsc
UNION
SELECT 
  invs.ID as ENTITY1,
  ':Compound' as ENTITY1_TYPE,
  invs.PROTEIN as ENTITY2,
  ':GeneForm' as ENTITY2_TYPE,
  concat('HAS_',invs.Category) as REL_TYPE,
  1 as STRENGTH,
  1 as CONFIDENCE,
  cast(invs.RESULT as double) as RESULT,
  invs.RESULT_TYPE,
  named_struct(
    "RULESETS","",
    "SOURCES",array("academe.compounds_v","ddmlcnp1_tdb_dm.invitro_stats_all","academe.gene_er_v8_0_16nov2021"),
    "FILTERS",array("result>0","corp_id is not null","corp_id like 'A-%' or corp_id like 'PR-%' or corp_id like 'DC-%'"),
    "TIMESTAMP",unix_timestamp(),
    "VERSION",'1.2.0')
  as LINEAGE,
  named_struct(
    "CATEGORY",invs.Category,
    "RESULT_UNITS",invs.result_units,
    "SPECIES",invs.species,
    "QUALIFIER",invs.qualifier,
    "ASSAY_NAME",invs.assay_name,
    "SOURCE",invs.source,
    "MOLECULE_LOT",invs.lot_number,
    "ANTIGEN_LOT",invs.bio_ent_lot_num,
    "LOT_NUMBER",invs.lot_number,
    "INCHI_KEY",invs.inchi_key,
    "BIO_ENT_LOT_NUM",invs.bio_ent_lot_num) 
  as METADATA
from (
select *,
Case 
	when Assay_Name in ('Biacore Kinetics') THEN 'BINDING_KINETICS'
	when locate('Stability', Assay_Name)>0  THEN 'STABILITY'
	when (Assay_Name in('DSC') OR Assay_Name in ('DSF')) THEN 'STABILITY'
	ELSE 'OTHER'
END as Category
from arch_normalized.ddmlcnp1_tdb_dm_invitro_stats_all_norm)invs
)t
where ENTITY1 is not null and ENTITY2 is not null
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
