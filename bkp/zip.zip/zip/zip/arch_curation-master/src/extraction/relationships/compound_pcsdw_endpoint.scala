import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_endpoint_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT 
  ENTITY1,
  ENTITY1_TYPE,
  ENTITY2,
  ENTITY2_TYPE,
  REL_TYPE,
  pcs.CONFIDENCE,
  cast(STRENGTH as int) as STRENGTH,
  RESULT,
  RESULT_TYPE,
  LINEAGE,
  named_struct(
    "STUDY_ID",pcs.metadata.STUDY_ID,
    "STUDY",pcs.metadata.STUDY,
    "DURATION_DAYS",pcs.metadata.DURATION_DAYS,
    "STUDY_GROUP_ID",pcs.metadata.STUDY_GROUP_ID,
    "DAY_OF_PHASE",pcs.metadata.DAY_OF_PHASE,
    "PHASE",pcs.metadata.PHASE,
    "VEHICLE",pcs.metadata.VEHICLE,
    "SEX",pcs.metadata.SEX,
    "DOSE_GROUP",pcs.metadata.DOSE_GROUP,
    "CONDITION",pcs.metadata.CONDITION,
    "SPECIES",pcs.metadata.SPECIES,
    "DOSE",pcs.metadata.DOSE,
    "ROUTE",pcs.metadata.ROUTE,
    "UNITS",pcs.metadata.UNITS,
    "CHANGE",pcs.metadata.CHANGE,
    "FOLD_OVER_THRESHOLD",pcs.metadata.FOLD_OVER_THRESHOLD,
    "LINK",pcs.metadata.LINK,
    "MEDDRA_ID", ep.meddra_id,
    "MEDDRA_NAME", ep.meddra_name,
    "INCHI_KEY",pcs.inchi_key,
    "SOURCE","PCSDW",
    "TKPK_DOSED_CMPD",e.dosed_cmpd,
    "TKPK_MEASURED_CMPD",e.measured_cmpd,
    "PROJECTED_CMAX_UM_PCS_DOSE",cast(e.projected_cmax_um_pcs_dose as double),
    "PROJECTED_AUC_UM_PCS_DOSE",cast(e.projected_auc_um_pcs_dose as double),
    "TKPK_CONFIDENCE",cast(e.confidence as double),
    "TKPK",e.tkpk
  ) as METADATA
FROM dependency.v_pcsdw_result pcs
left outer join dependency.pcs_meddra_endpoints ep on  
 lower(pcs.rel_type) = lower(ep.effect) and
 pcs.entity2 = concat(ep.endpoint_type,', ', ep.endpoint)
 and ep.destination = 'PCS'
LEFT outer JOIN 
(select * from ddmlcnp1_ppilot_rad.pcs_exposure_arch
WHERE dosed_cmpd = measured_cmpd) e 
ON pcs.metadata.study = e.pcs_study_number 
and pcs.metadata.study_group_id = e.study_group_id
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
