import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_gene_gene_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    t1.SOURCE_GENE_UID as ENTITY1,
    ":Gene" as ENTITY1_TYPE,
    t1.TARGET_GENE_UID as ENTITY2,
    ":Gene" as ENTITY2_TYPE,
    "SHARES_PATHWAY_WITH" as REL_TYPE,
    1 as STRENGTH,
    cast(t1.CONFIDENCE as float) as RESULT,
    "Confidence" as RESULT_TYPE,
    cast(t1.CONFIDENCE as float) as CONFIDENCE,
    "CPDB" as SOURCE,
    named_struct(
        "RULESETS",array(),
        "SOURCES",array("arch_normalized.consensuspathdb_norm","academe.gte_gene_v"),
        "FILTERS",array(),
        "TIMESTAMP",current_timestamp(),
        "VERSION","1.5.0"
    ) as LINEAGE,
    named_struct(
            "PMIDS",SPLIT(cast(t1.PMIDS as string),';'),
            "SOURCE",coalesce(t1.DATA_SOURCE, "CPDB"),
            "NUM_FINDINGS",cast(null as bigint),
            "FINDINGS",array(),
            "DIRECTNESS",array(),
            "VISUALIZATION_METHODS",array(),
            "EXTRACTION_METHODS",array(),
            "ENTITY1_GENE_FORM",cast(null as string),
            "ENTITY2_GENE_FORM",cast(null as string)
    ) as METADATA
FROM arch_normalized.consensuspathdb_norm t1
WHERE t1.SOURCE<>t1.TARGET and SOURCE_GENE_UID is not null and TARGET_GENE_UID is not null
UNION
SELECT DISTINCT
    t2.gene1_uid as ENTITY1,
    ":Gene" as ENTITY1_TYPE,
    t2.gene2_uid as ENTITY2,
    ":Gene" as ENTITY2_TYPE,
    case
      when t2.effect='directionality not applicable' then upper(regexp_replace(t2.relationship," ","_"))
      else upper(regexp_replace(concat(t2.effect,' ',t2.relationship)," ","_"))
    end as REL_TYPE,
    1 as STRENGTH,
    cast(1.0 as float) as RESULT,
    "Confidence" as RESULT_TYPE,
    cast(1.0 as float) as CONFIDENCE,
    "IPA" as SOURCE,
    named_struct(
        "RULESETS",array(),
        "SOURCES",array("arch_normalized.ingenuity_gene_gene_data_norm","academe.gte_gene_v"),
        "FILTERS",array(),
        "TIMESTAMP",current_timestamp(),
        "VERSION","1.5.0"
    ) as LINEAGE,
    named_struct(
            "PMIDS",collect_set(cast(t2.pubmed_id as string)),
            "SOURCE","IPA",
            "NUM_FINDINGS",count(distinct t2.finding_id),
            "FINDINGS",collect_set(t2.finding_id),
            "DIRECTNESS",collect_set(t2.directness),
            "VISUALIZATION_METHODS",collect_set(t2.experimental_visualization_method),
            "EXTRACTION_METHODS",collect_set(t2.extraction_method),
            "ENTITY1_GENE_FORM",t2.gene1_form,
            "ENTITY2_GENE_FORM",t2.gene2_form
    ) as METADATA
FROM arch_normalized.ingenuity_gene_gene_data_norm t2
WHERE t2.gene1_uid is not null and t2.gene2_uid is not null
GROUP BY t2.gene1_uid,t2.gene1_form,t2.gene2_uid,t2.gene2_form,t2.effect,t2.relationship
""").batch
res.write.mode("OVERWRITE").partitionBy("SOURCE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
