import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_gene_tissue_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT 
t.ENTITY1,
t.ENTITY1_TYPE,
t.ENTITY2,
t.ENTITY2_TYPE,
t.REL_TYPE,
t.STRENGTH,
t.RESULT,
t.RESULT_TYPE,
t.CONFIDENCE,
t.LINEAGE,
t.METADATA from (
SELECT abbvie_gene_uid as ENTITY1,
":Gene" as ENTITY1_TYPE,
abbvie_tissue_uid as ENTITY2,
":Tissue" as ENTITY2_TYPE,
"IS_EXPRESSED_IN" as REL_TYPE,
CASE 
WHEN log2TPM >= 10 THEN 3
WHEN log2TPM >= 5 and log2TPM < 10 THEN 2
WHEN log2TPM >= 0 and log2TPM < 5 THEN 1
WHEN log2TPM < 0 THEN 0
ELSE null
End AS STRENGTH,
log2TPM as RESULT,
"LOG2TPM" as RESULT_TYPE,
1 as CONFIDENCE,
named_struct(
"RULESETS",array(""),
"SOURCES",array("arch_normalized.ccle_b38_gc33_genefpkm_norm","academe.gte_gene_v","academe.tissue_v"),
"FILTERS",array(""),
"TIMESTAMP",unix_timestamp(),
"VERSION","1.4.0"
) as LINEAGE,
named_struct(
"ABBVIE_GENE_NAME", abbvie_gene_name,
"TISSUE",Tissue,
"LOG2TPM",log2TPM,
 "SOURCE", "CCLE") as METADATA
FROM (
select * 
from arch_normalized.ccle_b38_gc33_genefpkm_norm 
where abbvie_gene_uid is not null and abbvie_tissue_uid is not null
)ccle
)t
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
