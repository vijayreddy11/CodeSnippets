import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_variant_phenotype_relationships"
val almaren = Almaren(set_name)
 
val res = almaren.builder.sourceSql("""
SELECT DISTINCT
	t.ENTITY1,
	t.ENTITY1_TYPE,
	t.ENTITY2,
	t.ENTITY2_TYPE,
	t.REL_TYPE,
	t.STRENGTH,
	t.RESULT,
	t.RESULT_TYPE,
	t.CONFIDENCE,
	t.LINEAGE,
    	t.METADATA
FROM(
	SELECT
	    abbvie_variant_uid as ENTITY1,
	    ":Variant" as ENTITY1_TYPE,
	    abbvie_phenotype_uid as ENTITY2, 
	    ":Phenotype" as ENTITY2_TYPE,
	    "ASSOCIATED_WITH" as REL_TYPE,
	    case 
		when o_r <= 1.3 then 1
		when o_r > 1.3  and o_r < 2.0 then 2
		when o_r >= 2.0 then 3 
		end as STRENGTH,
            -log(pval) as RESULT,
            "-log(pval)" as RESULT_TYPE,
	    case
		when pval < pow(10,-9) then 0.9
		when pval > pow(10,-9) and pval < pow(10,-7) then 0.5
		when pval > pow(10,-7)  then 0.1 
		end as CONFIDENCE,
	    named_struct(
		"RULESETS",array("UKBB_STRENGTH_RULE"),
		"SOURCES",array("arch_normalized.ukb_200k_exome_20200217_norm","academe.gte_gene_v","academe.t_VARIANTS_lookup_v2_core_ukbb_finngen_omim_gwas_02202021","academe.health_condition_v"),
		"FILTERS",array("pval<10x^-6"),
		"TIMESTAMP",unix_timestamp(),
		"VERSION","1.2.0"
	    ) as lineage,
	    named_struct(
		"ABBVIE_GENE_UID", abbvie_gene_uid, 
		"PVAL", pval, 
		"BETA", beta, 
		"SEBETA", sebeta,
		"ODDS_RATIO",o_r,
		"MAF", maf,
		"NEAREST_GENES",nearest_genes,
		"SOURCE","UKBB"
	    ) as METADATA
	FROM  arch_normalized.ukb_200k_exome_20200217_norm
	    WHERE
		pval < pow(10,-6)
	UNION
	SELECT
	    abbvie_variant_uid as ENTITY1,
	    ":Variant" as ENTITY1_TYPE,
	    abbvie_phenotype_uid as ENTITY2,
	    ":Phenotype" as ENTITY2_TYPE,
	    "ASSOCIATED_WITH" as REL_TYPE,
	   case 
		when o_r <= 1.3 then 1
		when o_r > 1.3  and o_r < 2.0 then 2
		when o_r >= 2.0 then 3 
		end as STRENGTH,
            -log(pval) as RESULT,
            "-log(pval)" as RESULT_TYPE,
	    case
		when pval < pow(10,-9) then 0.9
		when pval > pow(10,-9) and pval < pow(10,-7) then 0.5
		when pval > pow(10,-7)  then 0.1 
		end as CONFIDENCE,
	    named_struct(
		"RULESETS",array("FINNGEN_STRENGTH_RULE"),
		"SOURCES",array("arch_normalized.finngen_full_norm","academe.gte_gene_v","academe.t_VARIANTS_lookup_v2_core_ukbb_finngen_omim_gwas_02202021","academe.health_condition_v"),
		"FILTERS",array("pval<10x^-6"),
		"TIMESTAMP",unix_timestamp(),
		"VERSION","1.2.0"
	    ) as lineage,
	    named_struct(
		"ABBVIE_GENE_UID", abbvie_gene_uid, 
		"PVAL", pval, 
		"BETA", beta, 
		"SEBETA", sebeta,
		"ODDS_RATIO",o_r,
		"MAF", maf,
		"NEAREST_GENES",nearest_genes,
		"SOURCE","FINNGEN"
	    ) as METADATA
	FROM arch_normalized.finngen_full_norm
	    WHERE
		pval < pow(10,-6)
)t
where ENTITY1 is not null and ENTITY2 is not null
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
