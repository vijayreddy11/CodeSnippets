import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_gene_gene_bioprofile_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""with gene_gene_bioprofile as (
select gg.gene1
,gg.gene2
,cast(gg.bioactivity_tanimoto as double) as bioactivity_tanimoto
,cast(gg.pearson_correlation as double) as pearson_correlation
,cast(gg.activity_profile_tanimoto as double) as activity_profile_tanimoto
,cast(gg.pharma_interaction as double)  as pharma_interaction
,cast(gg.scaled_shannon_entropy as float) as scaled_shannon_entropy
,cast(gg.shared_activity_count as int) as shared_activity_count
from  acj_arch_bioactivity_similarity_comparisons.t_gene_gene_similarity gg
--where gg.gene1 = '0007927f3c976244996ca1a3336c4f70'
)

SELECT *
FROM (
SELECT
ggg.gene1 as ENTITY1,
':Gene' as ENTITY1_TYPE,
ggg.gene2 as ENTITY2,
':Gene' as ENTITY2_TYPE,
'HAS_BIOACTIVITY_SIMILARITY' as REL_TYPE,
ggg.scaled_shannon_entropy as CONFIDENCE,
CASE 
    WHEN ggg.pearson_correlation >= 0.75 or ggg.activity_profile_tanimoto >= 0.85 THEN 3
    WHEN ggg.pearson_correlation >= 0.60 or ggg.activity_profile_tanimoto >= 0.70 THEN 2
    WHEN ggg.pearson_correlation >= 0.45 or ggg.activity_profile_tanimoto >= 0.55 THEN 1
    ELSE 0
END AS STRENGTH,
CASE
	WHEN (ggg.pearson_correlation >= 0.75 and ggg.activity_profile_tanimoto >= 0.85)
	or (ggg.pearson_correlation >= 0.60 and ggg.activity_profile_tanimoto >= 0.70 )
	or (ggg.pearson_correlation >= 0.45 and ggg.activity_profile_tanimoto >= 0.55) THEN  pearson_correlation
	WHEN ggg.activity_profile_tanimoto >= 0.55 THEN activity_profile_tanimoto
	WHEN ggg.pearson_correlation >= 0.45 THEN pearson_correlation
	ELSE pearson_correlation
END AS 	RESULT,

CASE
	WHEN (ggg.pearson_correlation >= 0.75 and ggg.activity_profile_tanimoto >= 0.85)
	or (ggg.pearson_correlation >= 0.60 and ggg.activity_profile_tanimoto >= 0.70 )
	or (ggg.pearson_correlation >= 0.45 and ggg.activity_profile_tanimoto >= 0.55) THEN  'bioprofile Pearson correlation'
	WHEN ggg.activity_profile_tanimoto >= 0.55  THEN 'bio profile tanimoto similarity'
	WHEN ggg.pearson_correlation >= 0.45  THEN 'bioprofile Pearson correlation'
	ELSE 'bioprofile Pearson correlation'
END AS 	RESULT_TYPE,
named_struct(
	"RULESETS",array(""),
	"SOURCES",array("acj_arch_bioactivity_similarity_comparisons.t_gene_gene_similarity"),
	"FILTERS",array(""),
	"TIMESTAMP",unix_timestamp(),
	"VERSION","1.0"
) as LINEAGE,
named_struct(
    "BIJ",ggg.bioactivity_tanimoto ,
    "RIJ",ggg.pearson_correlation ,
    "TANIMOTO",ggg.activity_profile_tanimoto ,
    "PIJ",ggg.pharma_interaction ,
    "SIJ",ggg.scaled_shannon_entropy ,
    "COUNT", ggg.shared_activity_count ,
    "SOURCE", "ACJ") 
as METADATA
from gene_gene_bioprofile ggg )X
where STRENGTH > 0 """).batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
