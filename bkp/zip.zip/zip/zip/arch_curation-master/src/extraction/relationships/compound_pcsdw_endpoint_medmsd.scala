import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_endpoint_medmsd_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
select * from (
    select * from dependency.v_pcsdw_medmsd
    union
    select * from dependency.v_pcsdw_noeffect_relationships
)
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
