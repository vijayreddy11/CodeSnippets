import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_drug_disease_open_targets_relationships"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
	t.ENTITY1,
	t.ENTITY1_TYPE,
	t.ENTITY2,
	t.ENTITY2_TYPE,
	t.REL_TYPE,
	t.STRENGTH,
	t.RESULT,
	t.RESULT_TYPE,
	t.CONFIDENCE,
	t.LINEAGE,
	named_struct (
	"EFONAME",t.METADATA.EFONAME,
	"MAXPHASEFORINDICATION",t.METADATA.MAXPHASEFORINDICATION,
	"DISEASE",t.METADATA.DISEASE,
	"APPROVED",split(t.METADATA.APPROVED,','),
	"DRUG_ID",t.METADATA.DRUG_ID,
	"SOURCE",t.METADATA.SOURCE
	) as METADATA
FROM(	
SELECT
t1.ENTITY1,
t1.ENTITY1_TYPE,
t1.ENTITY2,
t1.ENTITY2_TYPE,
t1.REL_TYPE,
t1.STRENGTH,
t1.RESULT,
t1.RESULT_TYPE,
t1.CONFIDENCE,
t1.LINEAGE,
t1.METADATA
from (
SELECT 
abbvie_drug_uid as ENTITY1,
":Drug" as ENTITY1_TYPE,
abbvie_disease_uid as ENTITY2,
":Disease" as ENTITY2_TYPE,
row_number() over (partition by abbvie_drug_uid,abbvie_disease_uid order by cast(maxPhaseForIndication as int) desc) as rownum, -- Added row_number() to remove duplicate drug indications as mentioned in jira ARCHO-3150
CASE
	WHEN cast(maxPhaseForIndication as int) = 4 THEN "APPROVED_TREATMENT_FOR"
	ELSE "TESTED_IN_CLINICAL_TRIALS_FOR"
END AS REL_TYPE,
cast(maxPhaseForIndication as int) as STRENGTH,
1 as RESULT,
"Membership" as RESULT_TYPE,
1.0 as CONFIDENCE,
named_struct(
	"RULESETS",array(""),
	"SOURCES",array("academe.drug_concept_v,academe.health_condition_v,arch_normalized.open_targets_drug_indications_norm"),
	"FILTERS",array(""),
	"TIMESTAMP",unix_timestamp(),
	"VERSION","1.4.0"
) as LINEAGE,
named_struct(
	"EFONAME",efoName,
	"MAXPHASEFORINDICATION",cast(maxPhaseForIndication as int),
	"DISEASE",disease,
	"APPROVED",concat_ws(',',approved),
	"DRUG_ID",drug_id,
	"SOURCE","OpenTargets"
) as METADATA 
FROM arch_normalized.open_targets_drug_indications_norm
)t1 where rownum = 1
)t
where entity1 is not null and entity2 is not null
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
