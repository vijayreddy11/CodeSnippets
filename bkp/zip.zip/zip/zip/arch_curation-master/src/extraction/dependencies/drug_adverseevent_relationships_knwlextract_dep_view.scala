import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL

val almaren = Almaren("scopia_drug_ae_relationships_knwlextract_dep_view")
val res = almaren.builder.sourceSql("""
create or replace view dependency.v_scopia_drug_ae_relationships_knwlextract_dep as
with NORM as (
SELECT 
    regexp_replace(aedb.embl_code,"&","|") as ENTITY1_ID,
    ":Drug" as ENTITY1_TYPE,
    aedb.abbvie_drug_uid as ENTITY1,
    concat("MDR",split(cast(aedb.meddra_code as string),'\\.')[0]) as ENTITY2_ID,
    aedb.abbvie_disease_uid as ENTITY2,
    ":Patient Adverse Event" as ENTITY2_TYPE,
	aedb.ai as AI,
	aedb.ae as AE,
    aedb.embl_code as EMBL_CODE,
    aedb.meddra_code as MEDDRA_CODE,
    aedb.SCORE as SCORE,
    aedb.CODES as CODES,
    cast(aedb.total_aftermarket_reports_for_drug as integer) as NUM_REPORTS,
    cast(aedb.total_reports_for_drug_and_adverse_event as integer) as NUM_AE_REPORTS,
    cast(replace(aedb.aftermarket_reporting_freq,'%','') as double) as RESULT,
    aedb.grade_3_percent as GRADE_3_PERCENT,
    aedb.grade_4_percent as GRADE_4_PERCENT,
    aedb.grade_3or4_percent as GRADE_3OR4_PERCENT,
    LENGTH(regexp_replace(aedb.ai,'[^;]',''))+1 as NUM_COMPONENTS,
    LENGTH(regexp_replace(aedb.ai,'[^&]',''))+1 as NUM_IDS,
    -1 as STRENGTH,
    'N' as ONLABEL
FROM arch_normalized.scopiarx_ae_main_db_norm aedb
where 1=1
)
,STRENGTH_RULE_1 as (
select 
    ENTITY1_ID,
    ENTITY1_TYPE,
    ENTITY1,
    ENTITY2_ID,
    ENTITY2,
    ENTITY2_TYPE,
	AI,
	AE,
    EMBL_CODE,
    MEDDRA_CODE,
    SCORE,
    CODES,
    GRADE_3_PERCENT,
    GRADE_4_PERCENT,
    GRADE_3OR4_PERCENT,
    NUM_REPORTS,
    NUM_AE_REPORTS,
    NUM_COMPONENTS,
    NUM_IDS,
    RESULT,
    case 
        when STRENGTH < 0 and  array_contains(split(CODES," "),'vc') THEN 'Y'
        when STRENGTH < 0 and  array_contains(split(CODES," "),'c') THEN 'Y'
        when array_contains(split(CODES," "),'bw') THEN 'Y'
        when array_contains(split(CODES," "),'w') THEN 'Y'
        when array_contains(split(CODES," "),'ca') THEN 'Y'
        else ONLABEL
    end as ONLABEL,
    /* Assign Frequency and Severity from label */
    case 
        when array_contains(split(CODES," "),'bw') THEN 'Box Warning'
        when array_contains(split(CODES," "),'w') THEN 'Warning'
        when array_contains(split(CODES," "),'ca') THEN 'Caution'
    end as SEVERITY,
    /* Assign Frequency and Severity from label */
    case
        when STRENGTH < 0 and  array_contains(split(CODES," "),'vc') THEN 'Very Common'
        when STRENGTH < 0 and  array_contains(split(CODES," "),'c') THEN 'Common'
    end as FREQUENCY,
    concat("Code =",".",CODES) as COMMENT,
    case 
        when STRENGTH < 0 and  array_contains(split(CODES," "),'vc') THEN 3
        when STRENGTH < 0 and  array_contains(split(CODES," "),'c') THEN 2
        else STRENGTH
    end as STRENGTH
from NORM n
)
,STRENGTH_RULE_2 as(
Select 
    ENTITY1_ID,
    ENTITY1_TYPE,
    ENTITY1,
    ENTITY2_ID,
    ENTITY2,
    ENTITY2_TYPE,
	AI,
	AE,
    EMBL_CODE,
    MEDDRA_CODE,
    SCORE,
    CODES,
    GRADE_3_PERCENT,
    GRADE_4_PERCENT,
    GRADE_3OR4_PERCENT,
    NUM_REPORTS,
    NUM_AE_REPORTS,
    NUM_COMPONENTS,
    NUM_IDS,
    ONLABEL,
    RESULT,
    SEVERITY,
    COMMENT,
    /* Warning with no frequency on label - default strength to 1 */
    case
        when STRENGTH < 0 and ONLABEL = 'Y' THEN "not specified in label"
        else FREQUENCY
    end as FREQUENCY,
    /* Warning with no frequency on label - default strength to 1 */
    case
        when STRENGTH < 0 and ONLABEL = 'Y' THEN 1
        else STRENGTH
    end as STRENGTH
from STRENGTH_RULE_1 sr1
)
,RESULT_RULE_1 as (
select 
    ENTITY1_ID,
    ENTITY1_TYPE,
    ENTITY1,
    ENTITY2_ID,
    ENTITY2,
    ENTITY2_TYPE,
	AI,
	AE,
    EMBL_CODE,
    MEDDRA_CODE,
    SCORE,
    CODES,
    GRADE_3_PERCENT,
    GRADE_4_PERCENT,
    GRADE_3OR4_PERCENT,
    NUM_REPORTS,
    NUM_AE_REPORTS,
    NUM_COMPONENTS,
    NUM_IDS,
    STRENGTH,
    ONLABEL,
    SEVERITY,
    FREQUENCY,
    COMMENT,
    /* Calc Result if P4 available */
    CASE 
        WHEN NUM_REPORTS is not null and cast(NUM_REPORTS as double) is not null THEN 100*NUM_AE_REPORTS/NUM_REPORTS 
        else RESULT 
    end as RESULT,
    CASE 
        WHEN NUM_REPORTS is not null and cast(NUM_REPORTS as double) is not null THEN  "Reporting Frequency (%)" 
    end as RESULT_TYPE
from STRENGTH_RULE_2 sr2
)
,RESULT_RULE_2 as (
select 
    ENTITY1_ID,
    ENTITY1_TYPE,
    ENTITY1,
    ENTITY2_ID,
    ENTITY2,
    ENTITY2_TYPE,
	AI,
	AE,
    EMBL_CODE,
    MEDDRA_CODE,
    SCORE,
    CODES,
    GRADE_3_PERCENT,
    GRADE_4_PERCENT,
    GRADE_3OR4_PERCENT,
    NUM_REPORTS,
    NUM_AE_REPORTS,
    NUM_COMPONENTS,
    NUM_IDS,
    ONLABEL,
    SEVERITY,
    RESULT_TYPE,
    COMMENT,
    RESULT,
    case 
        when RESULT is not null and STRENGTH < 0 then "post-market reports"
        else FREQUENCY
    end as FREQUENCY,
    /* Assign strength from result for all non-label P4 reports */
    case 
        when RESULT is not null and STRENGTH < 0 THEN    
    ( case 
    when RESULT >= 10 Then 3 
    when RESULT >= 1 Then 2
    when RESULT >= 0.1 THEN 1
    else 0
      end
    )
        else STRENGTH
    end as STRENGTH
from RESULT_RULE_1 rr1
)
,CONFIDENCE_RULE as (
select 
    ENTITY1_ID,
    ENTITY1_TYPE,
    ENTITY1,
    ENTITY2_ID,
    ENTITY2,
    ENTITY2_TYPE,
	AI,
	AE,
    EMBL_CODE,
    MEDDRA_CODE,
    SCORE,
    CODES,
    GRADE_3_PERCENT,
    GRADE_4_PERCENT,
    GRADE_3OR4_PERCENT,
    NUM_REPORTS,
    NUM_AE_REPORTS,
    NUM_COMPONENTS,
    NUM_IDS,
    ONLABEL,
    RESULT,
    SEVERITY,
    FREQUENCY,
    COMMENT,
    STRENGTH,
    RESULT_TYPE,
    case 
        when ONLABEL = 'Y' then 1.0
        when (RESULT is not null and cast(RESULT as double) is not null) then 
          case 
          when 0.5 * Sqrt(Power(Log10(NUM_AE_REPORTS) / Log10(10),2) + Power(Log10(NUM_REPORTS) / Log10(10000),2))<=0.9 then 0.5 * Sqrt(Power(Log10(NUM_AE_REPORTS) / Log10(10),2) + Power(Log10(NUM_REPORTS) / Log10(10000),2))
          else 0.9
          end
    end as CONFIDENCE
FROM RESULT_RULE_2
where NUM_COMPONENTS = NUM_IDS
)
,ENTITY1_ID_FILTER as (
select *
from CONFIDENCE_RULE c
where 1=1
and ((ENTITY1_ID is not null and length(ENTITY1_ID) > 0) and (ENTITY2_ID is not null and length(ENTITY2_ID) > 0))
and strength>=0
)
,PROPERTY_LIST as (
select 
ENTITY1,
ENTITY1_ID,
ENTITY1_TYPE,
ENTITY2,
ENTITY2_ID,
ENTITY2_TYPE,
AI,
AE,
EMBL_CODE,
MEDDRA_CODE,
SCORE,
CODES,
STRENGTH,
CONFIDENCE,
FREQUENCY,
SEVERITY,
COMMENT,
RESULT,
RESULT_TYPE,
NUM_AE_REPORTS,
NUM_REPORTS,
ONLABEL,
NUM_COMPONENTS,
GRADE_3_PERCENT,
GRADE_4_PERCENT,
GRADE_3OR4_PERCENT
from ENTITY1_ID_FILTER
)
, ENTITY2_ADVERSEEVENT as (
SELECT ENTITY2_ID from PRECLINICAL.R_ADVERSEEVENT_EXCLUSIONS
)
, JOINER as (
select pl.* 
from PROPERTY_LIST pl left outer join ENTITY2_ADVERSEEVENT ea
on pl.ENTITY2_ID = ea.ENTITY2_ID
where ea.ENTITY2_ID is null
)
, ENTITY2_FILTER as (
select * from JOINER
where ENTITY2 != 'noae'
)
,DRUG_ADVERSEEVENT as (
select 
ENTITY1,
ENTITY1_TYPE,
ENTITY2,
ENTITY2_TYPE,
'HAS_SIDE_EFFECT' as REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
named_struct(
      "RULESETS",array(""),
      "SOURCES",array("arch_normalized.scopiarx_ae_main_db_norm","preclinical.t_adverseevent_exclusions","academe.drug_metadata_v","academe.drug_synonyms_v","academe.health_condition_disease_v6_0_08dec2021"),
      "FILTERS",array("strength>0"),
      "TIMESTAMP",unix_timestamp(),
      "VERSION","1.3.0"
) as LINEAGE,
named_struct(
"AI",AI,
"AE",AE,
"EMBL_CODE",EMBL_CODE,
"MEDDRA_CODE",MEDDRA_CODE,
"SCORE",SCORE,
"CODES",CODES,
"COMMENT",COMMENT,
"SOURCE","Scopia",
"ONLABEL",ONLABEL,
"GRADE_3_PERCENT",GRADE_3_PERCENT,
"GRADE_4_PERCENT",GRADE_4_PERCENT,
"GRADE_3OR4_PERCENT",GRADE_3OR4_PERCENT,
"REPORTS",NUM_REPORTS,
"AES",NUM_AE_REPORTS,
"SEVERITY",SEVERITY,
"FREQUENCY",FREQUENCY
) as METADATA
from ENTITY2_FILTER
)
select 
ENTITY1,
ENTITY1_TYPE,
ENTITY2,
ENTITY2_TYPE,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
LINEAGE,
METADATA
from 
DRUG_ADVERSEEVENT
""").batch
