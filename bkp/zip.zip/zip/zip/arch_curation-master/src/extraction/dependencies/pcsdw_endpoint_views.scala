import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL

val almaren = Almaren("PCSDW_VIEWS")
var res = almaren.builder.sourceSql("""create or replace view dependency.v_pcsdw_sgc as
select distinct
        STUDY_NUMBER,
        SRC_GROUP_NUMBER,
        ISCONTROL,
        SRC_GROUP_TYPE,
        TEST_ARTICLE,
        TA_DOSE,
        TA_UNITS,
        TA_LOT,
        VEHICLE,
        V_DOSE,
        V_UNITS,
        COMPOUND_ID_V,
        ARTICLE_USAGE,
        ARTICLE,
        DOSE,
        UNITS,
        LOT,
        COMPOUND_ID_ART,
        ABT_NUMBER_ART,
        CORP_IDENT_ID_ART,
        ROUTE,
        CORPERATE_IDENTIFIER,
        STUDY_GROUP_ID,
        size(collect_set(article) over (partition by STUDY_GROUP_ID )) as ARTICLE_COUNT
      from ddmlcnp1_pcsdw.study_group_compound_vw
      where ISCONTROL='Y' or (ISCONTROL='N' AND DOSE>0)
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_pcsdw_lastseen_dop as
select
  STUDY_GROUP_ID,
  MEASUREMENT_ID,
  PHASE_ID,
  max(cast(DAY_OF_PHASE as int)) ls_dop
from ddmlcnp1_pcsdw.studygroup_dop_summary_vw
group by STUDY_GROUP_ID, MEASUREMENT_ID, PHASE_ID
""").batch


res = almaren.builder.sourceSql("""create or replace view dependency.v_pcsdw_sds_baseline as
select distinct
  sds_b.STUDY_GROUP_ID,
  sds_b.MEASUREMENT_ID,
  sds_b.PHASE_ID,
  sds_b.AVG_VALUE,
  sds_b.MIN_VALUE,
  sds_b.MAX_VALUE,
  sds_b.STDDEV_VALUE,
  sds_b.COUNT_VALUE,
  sds_b.COUNT_ANIMAL
from ddmlcnp1_pcsdw.studygroup_dop_summary_vw sds_b
left join dependency.v_pcsdw_lastseen_dop lastseen_dop_b on 
    sds_b.STUDY_GROUP_ID = lastseen_dop_b.STUDY_GROUP_ID and 
    sds_b.MEASUREMENT_ID = lastseen_dop_b.MEASUREMENT_ID and 
    sds_b.DAY_OF_PHASE = lastseen_dop_b.ls_dop and 
    sds_b.phase_id = lastseen_dop_b.phase_id
""").batch


res = almaren.builder.sourceSql("""create or replace view dependency.v_pcsdw_vctrl as
select distinct
  s.STUDY_ID, 
  s.STUDY_NUMBER,
  spc.SPECIES_NAME, 
  sg.SEX,
  sg.SRC_GROUP_TYPE,
  sg.SRC_GROUP_NUMBER,
  m.measurement_id, 
  m.MEASUREMENT_AREA meas_area, 
  m.MEASUREMENT_NAME meas_name, 
  m.ABBREVIATION, 
  m.MEASUREMENT_UNIT,
  p.PHASE_NAME phase, 
  p.phase_id,
  sds.DAY_OF_PHASE,
  sum(AVG_VALUE*COUNT_VALUE) over (partition by s.study_id, m.MEASUREMENT_ID, sg.sex, p.phase_id ) / 
    sum(COUNT_VALUE) over (partition by s.study_id, m.MEASUREMENT_ID, sg.sex, p.phase_id ) vctrl_avg_value,
  --sum(variance_value) over (partition by s.study_id, m.MEASUREMENT_ID, sg.sex, p.phase_id ) vctrl_sum_variance,
  sum(COUNT_VALUE) over (partition by s.study_id, m.MEASUREMENT_ID, sg.sex, p.phase_id ) vctrl_value_count,
  sum(COUNT_ANIMAL) over (partition by s.study_id, m.MEASUREMENT_ID, sg.sex, p.phase_id ) vctrl_animal_count,
  size(collect_set(sg.study_group_id)  over (partition by s.study_id, m.MEASUREMENT_ID, sg.sex, p.phase_id )) as vctrl_group_count
from ddmlcnp1_pcsdw.study s
join ddmlcnp1_pcsdw.species spc on 
  s.SPECIES_ID = spc.SPECIES_ID
join ddmlcnp1_pcsdw.study_group sg on 
  s.STUDY_ID = sg.STUDY_ID and 
  sg.SRC_GROUP_TYPE = 'Vehicle Control'
join ddmlcnp1_pcsdw.studygroup_dop_summary_vw sds on 
  sg.STUDY_GROUP_ID = sds.STUDY_GROUP_ID
left outer join ddmlcnp1_pcsdw.phase sds_p on
  sds.PHASE_ID = sds_p.PHASE_ID and
  sds_p.PHASE_NAME<>'Baseline'
left outer join ddmlcnp1_pcsdw.phase p on
  sds.PHASE_ID = p.PHASE_ID
join ddmlcnp1_pcsdw.measurement m on 
  sds.MEASUREMENT_ID = m.MEASUREMENT_ID
join dependency.v_pcsdw_lastseen_dop lsdop on 
  sg.STUDY_GROUP_ID = lsdop.STUDY_GROUP_ID and 
  sds.MEASUREMENT_ID = lsdop.MEASUREMENT_ID and 
  sds.DAY_OF_PHASE= lsdop.ls_dop and 
  sds.PHASE_ID = lsdop.phase_id
where 
  (m.MEASUREMENT_AREA in ('Chemistry Measurement','Hematology Measurement','Urinalysis Measurement') OR
  (m.MEASUREMENT_AREA in ('Organ Weights') AND m.ABBREVIATION in ('AD','EP','HT','KD','LI','OV','PIF','PR','SP','TE','TM','TDF','UT')) OR
  (m.MEASUREMENT_AREA in ('Body Weights','Food Consumption'))) 
order by 
  s.study_number,
  sg.src_group_number,
  sg.sex,
  meas_area,
  meas_name,
  phase,
  sds.DAY_OF_PHASE
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_pcsdw_summary as
select 
    s.STUDY_ID, 
    s.STUDY_NUMBER, 
    CASE
        when s.DURATION_DAYS is null then sds.DAY_OF_PHASE
        else s.DURATION_DAYS
    END as DURATION_DAYS,
    sg.STUDY_GROUP_ID, 
    spc.SPECIES_NAME, 
    sg.SEX, 
    sg.ISCONTROL, 
    sg.SRC_GROUP_NUMBER, 
    sg.SRC_GROUP_TYPE,
    m.MEASUREMENT_AREA meas_area, 
    m.MEASUREMENT_NAME meas_name, 
    m.ABBREVIATION, 
    m.MEASUREMENT_UNIT,
    p.PHASE_NAME phase,
    sds.DAY_OF_PHASE, 
    sds.AVG_VALUE, 
    sds.MIN_VALUE, 
    sds.MAX_VALUE, 
    sds.STDDEV_VALUE, 
    sds.COUNT_VALUE, 
    sds.COUNT_ANIMAL,
    sds_b.AVG_VALUE baseline_avg_value, 
    sds_b.MIN_VALUE baseline_min_value, 
    sds_b.MAX_VALUE baseline_max_value,  
    sds.AVG_VALUE - sds_b.AVG_VALUE delta_from_baseline, 
    case 
      when sds_b.AVG_VALUE !=0 then ((sds.AVG_VALUE - sds_b.AVG_VALUE)/sds_b.AVG_VALUE)*100 
      else null 
    end delta_pct_from_baseline,
    sds_b.STDDEV_VALUE baseline_stddev, 
    sds_b.COUNT_VALUE baseline_value_count, 
    sds_b.COUNT_ANIMAL baseline_animal_count, 
    vc.vctrl_AVG_VALUE vc_avg_value, 
    sds.avg_value - vc.vctrl_AVG_VALUE delta_from_vc, 
    case
      when vc.vctrl_AVG_VALUE !=0 then ((sds.avg_value - vc.vctrl_AVG_VALUE)/ vc.vctrl_AVG_VALUE)*100 
      else null 
    end DELTA_PCT_FROM_VC, 
--vc.vctrl_STDDEV vc_stddev, 
    vc.vctrl_VALUE_COUNT vc_value_count, 
    vc.vctrl_ANIMAL_COUNT vc_animal_count,
    vc.vctrl_AVG_VALUE-sds_b.AVG_VALUE delta_vc_from_baseline,
    case 
      when sds_b.AVG_VALUE is not null and sds_b.AVG_VALUE !=0 then ((vc.vctrl_AVG_VALUE-sds_b.AVG_VALUE)/sds_b.AVG_VALUE)*100 
      else null 
    end delta_pct_vc_from_baseline,    
    sgc.TEST_ARTICLE, 
    sgc.TA_DOSE, 
    sgc.TA_UNITS, 
    sgc.TA_LOT,
    sgc.VEHICLE, 
    sgc.V_DOSE, 
    sgc.V_UNITS, 
    sgc.COMPOUND_ID_V, 
    sgc.ARTICLE_USAGE, 
    sgc.ARTICLE, 
    sgc.DOSE, 
    sgc.UNITS, 
    sgc.LOT, 
    sgc.COMPOUND_ID_ART,
    sgc.ABT_NUMBER_ART, 
    sgc.CORP_IDENT_ID_ART, 
    sgc.ROUTE, 
    sgc.CORPERATE_IDENTIFIER, 
    m.MEASUREMENT_ID,
    count(sg.STUDY_GROUP_ID) over (partition by s.study_id, sg.study_group_id,m.MEASUREMENT_ID ) sg_cnt
from ddmlcnp1_pcsdw.study s
join ddmlcnp1_pcsdw.species spc on 
  s.SPECIES_ID = spc.SPECIES_ID
join ddmlcnp1_pcsdw.study_group sg on 
  s.STUDY_ID = sg.STUDY_ID and 
  sg.SRC_GROUP_TYPE != 'Vehicle Control' 
join ddmlcnp1_pcsdw.studygroup_dop_summary_vw sds on 
  sg.STUDY_GROUP_ID = sds.STUDY_GROUP_ID and 
  sds.PHASE_ID != 2  
join ddmlcnp1_pcsdw.measurement m on 
  sds.MEASUREMENT_ID = m.MEASUREMENT_ID and 
  m.isvisible = 'Y'
join ddmlcnp1_pcsdw.phase p on 
  sds.PHASE_ID = p.PHASE_ID 
join dependency.v_pcsdw_sgc sgc on 
  sg.STUDY_GROUP_ID = sgc.STUDY_GROUP_ID and 
  sgc.article_count = 1            
join dependency.v_pcsdw_lastseen_dop lastseen_dop on 
  sg.STUDY_GROUP_ID = lastseen_dop.STUDY_GROUP_ID and 
  sds.MEASUREMENT_ID = lastseen_dop.MEASUREMENT_ID and 
  sds.DAY_OF_PHASE= lastseen_dop.ls_dop and 
  sds.PHASE_ID = lastseen_dop.phase_id
left outer join dependency.v_pcsdw_sds_baseline sds_b on 
  sg.STUDY_GROUP_ID = sds_b.STUDY_GROUP_ID and 
  m.measurement_id = sds_b.measurement_id and 
  sds_b.PHASE_ID = 2
left outer join dependency.v_pcsdw_vctrl vc on 
  sg.STUDY_ID = vc.study_id and 
  sds.MEASUREMENT_ID = vc.measurement_id and 
  sds.phase_id = vc.phase_id and 
  sg.sex = vc.sex                   
where  
  (m.MEASUREMENT_AREA in ('Chemistry Measurement','Hematology Measurement','Urinalysis Measurement') OR
  (m.MEASUREMENT_AREA in ('Organ Weights') AND m.ABBREVIATION in ('AD','EP','HT','KD','LI','OV','PIF','PR','SP','TE','TM','TDF','UT')) OR
  (m.MEASUREMENT_AREA in ('Body Weights','Food Consumption'))) and 
  s.PROTOCOL_STATUS  in ('Completed','Closed') 
  and spc.SPECIES_NAME in  ('Dog','Monkey','Rat','Mouse')
order by 
  s.study_number, 
  sg.SRC_GROUP_NUMBER, 
  sg.SEX, 
  MEAS_AREA, 
  MEAS_NAME, 
  phase, 
  sds.DAY_OF_PHASE
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_pcsdw_result as
select distinct
  comps.compound_uid as ENTITY1,
  comps.inchi_key,
  ":Compound" as ENTITY1_TYPE,
  case
    when t1.CHANGE<0 and greatest(t1.CHANGE/nvl(th.PCUTOFF,th.NCUTOFF),t1.CHANGE/nvl(th.NCUTOFF,th.PCUTOFF))>0 then "DECREASES"
    when t1.CHANGE>0 and greatest(t1.CHANGE/nvl(th.PCUTOFF,th.NCUTOFF),t1.CHANGE/nvl(th.NCUTOFF,th.PCUTOFF))>0 then "INCREASES"
    else "DOES_NOT_SIGNIFICANTLY_AFFECT"
  end as REL_TYPE,
  concat(t1.MEAS_AREA,', ',t1.MEAS_NAME) as ENTITY2,
  concat(":Endpoint:",t1.MEAS_AREA) as ENTITY2_TYPE,
  case
    when t1.SPECIES_NAME='Human' then 1.0
    else 0.75
  end as CONFIDENCE,
  cast(t1.CHANGE as double) as RESULT,
  t1.CHANGE_TYPE as RESULT_TYPE,
  case
    when greatest(t1.CHANGE/nvl(th.PCUTOFF,th.NCUTOFF),t1.CHANGE/nvl(th.NCUTOFF,th.PCUTOFF))>=3 then 3
    when greatest(t1.CHANGE/nvl(th.PCUTOFF,th.NCUTOFF),t1.CHANGE/nvl(th.NCUTOFF,th.PCUTOFF))>=2 and greatest(t1.CHANGE/nvl(th.PCUTOFF,th.NCUTOFF),t1.CHANGE/nvl(th.NCUTOFF,th.PCUTOFF))<3 then 2
    when greatest(t1.CHANGE/nvl(th.PCUTOFF,th.NCUTOFF),t1.CHANGE/nvl(th.NCUTOFF,th.PCUTOFF))>=1 and greatest(t1.CHANGE/nvl(th.PCUTOFF,th.NCUTOFF),t1.CHANGE/nvl(th.NCUTOFF,th.PCUTOFF))<2 then 1
    else 0
  end as STRENGTH,
  named_struct(
      "RULESETS",array("PCSDW_COMPOUND_ENDPOINT_CONFIDENCE","PCSDW_COMPOUND_ENDPOINT_STRENGTH"),
      "SOURCES",array("dependency.v_pcsdw_summary","dependency.pcsdw_thresholds","ark.t_compound_entities"),
      "FILTERS",array(""),
      "TIMESTAMP",unix_timestamp(),
      "VERSION","1.2.0"
  ) as LINEAGE,
  named_struct(
    "STUDY_ID",t1.STUDY_ID,
    "STUDY",t1.STUDY,
    "DURATION_DAYS",cast(t1.DURATION_DAYS as integer),
    "STUDY_GROUP_ID",t1.STUDY_GROUP_ID,
    "DAY_OF_PHASE",cast(t1.DAY as integer),
    "PHASE",cast(t1.PHASE as integer),
    "VEHICLE",t1.VEHICLE,
    "SEX",t1.SEX,
    "DOSE_GROUP",cast(t1.DOSE_GROUP as integer),
    "CONDITION",t1.CONDITION,
    "SPECIES",t1.SPECIES_NAME,
    "DOSE",cast(t1.DOSE as double),
    "ROUTE",t1.ROUTE,
    "UNITS",t1.DOSE_UNITS,
    "CHANGE",cast(t1.CHANGE as double),
    "FOLD_OVER_THRESHOLD",cast(greatest(t1.CHANGE/nvl(th.PCUTOFF,th.NCUTOFF),t1.CHANGE/nvl(th.NCUTOFF,th.PCUTOFF)) as double),
    "LINK",t1.LINK,
    "SOURCE","PCSDW"
  ) as METADATA
from (
  select
    case
      when pcsdw.species_name in ('Rat','Mouse') and cast(pcsdw.delta_pct_from_vc as double) is not null then "%Change From Control"
      when pcsdw.species_name in ('Dog','Monkey') and cast(pcsdw.delta_pct_from_baseline as double) is not null then "%Change From Baseline"
      when pcsdw.species_name in ('Dog','Monkey') and cast(pcsdw.delta_pct_from_baseline as double) is null and cast(pcsdw.delta_pct_from_vc as double) is not null then "%Change From Control"
      else Null
    end as CHANGE_TYPE,
    case
      when pcsdw.species_name in ('Rat','Mouse') and cast(pcsdw.delta_pct_from_vc as double) is not null then cast(pcsdw.delta_pct_from_vc as double)/100
      when pcsdw.species_name in ('Dog','Monkey') and cast(pcsdw.delta_pct_from_baseline as double) is not null then cast(pcsdw.delta_pct_from_baseline as double)/100
      when pcsdw.species_name in ('Dog','Monkey') and cast(pcsdw.delta_pct_from_baseline as double) is null and cast(pcsdw.delta_pct_from_vc as double) is not null then cast(pcsdw.delta_pct_from_vc as double)/100
      else Null
    end as CHANGE,
    case
      when pcsdw.corperate_identifier is not null and pcsdw.corperate_identifier>'' then
      case
        when pcsdw.corperate_identifier='ABT-888' then 'A-861695.0'
        when pcsdw.corperate_identifier='ABBV-3748' then 'A-1739723.0'
        when pcsdw.corperate_identifier='ABT-408' then 'A-1402484.0'
        else pcsdw.corperate_identifier
      end
      else
      case
        when pcsdw.article='ABT-888' then 'A-861695.0'
        when pcsdw.article='ABBV-3748' then 'A-1739723.0'
        when pcsdw.article='ABT-408' then 'A-1402484.0'
        when locate("A-",split(trim(pcsdw.article)," ")[0])>0 and locate(".",split(trim(pcsdw.article)," ")[0])>0 then split(trim(pcsdw.article)," ")[0]
        when locate("A-",split(trim(pcsdw.article)," ")[0])>0 and locate(".",split(trim(pcsdw.article)," ")[0])=0 then concat(split(trim(pcsdw.article)," ")[0],".0")
        when locate("PR-",split(trim(pcsdw.article)," ")[0])>0 then split(trim(pcsdw.article)," ")[0]
        when locate("DC-",split(trim(pcsdw.article)," ")[0])>0 then split(trim(pcsdw.article)," ")[0]
        when locate("ABT-",split(trim(pcsdw.article)," ")[0])>0 then split(trim(pcsdw.article)," ")[0]
        when locate("ABBV-",split(trim(pcsdw.article)," ")[0])>0 then split(trim(pcsdw.article)," ")[0]
        else null
      end
    end as MOLECULE_ID,
    case
      when pcsdw.corperate_identifier is not null and pcsdw.corperate_identifier>'' then
      case
        when pcsdw.corperate_identifier='ABT-888' then 'Small Molecule'
        when pcsdw.corperate_identifier='ABBV-3748' then 'Small Molecule'
        when pcsdw.corperate_identifier='ABT-408' then 'Small Molecule'
        when locate("A-",pcsdw.corperate_identifier)>0 then 'Small Molecule'
        else 'Biologic'
      end
      else
      case
        when pcsdw.article='ABT-888' then 'Small Molecule'
        when pcsdw.article='ABBV-3748' then 'Small Molecule'
        when pcsdw.article='ABT-408' then 'Small Molecule'
        when locate("A-",split(trim(pcsdw.article)," ")[0])>0 then 'Small Molecule'
        when locate("PR-",split(trim(pcsdw.article)," ")[0])>0 then 'Protein'
        when locate("DC-",split(trim(pcsdw.article)," ")[0])>0 then 'Drug Conjugate'
        when locate("ABT-",split(trim(pcsdw.article)," ")[0])>0 then 'Small Molecule'
        when locate("ABBV-",split(trim(pcsdw.article)," ")[0])>0 then 'Small Molecule'
        else null
      end
    end as MOLECULE_TYPE,    
    case
      when pcsdw.corperate_identifier is not null and pcsdw.corperate_identifier>'' then split(split(pcsdw.corperate_identifier,"-")[1],"\\.")[0]
      when pcsdw.article='ABT-888' then '861695'
      when pcsdw.article='ABBV-3748' then '1739723'
      when pcsdw.article='ABT-408' then '1402484'
      when pcsdw.article is not null and pcsdw.article>'' then split(split(pcsdw.article,"-")[1],"\\.")[0]
      else null
    end as ROOT_ID,    
    case
      when pcsdw.corperate_identifier is not null and pcsdw.corperate_identifier>'' then
      case
        when pcsdw.corperate_identifier='ABT-888' then 'A-861695.0'
        when pcsdw.corperate_identifier='ABBV-3748' then 'A-1739723.0'
        when pcsdw.corperate_identifier='ABT-408' then 'A-1402484.0'
        else pcsdw.corperate_identifier
      end
    end as CORPERATE_IDENTIFIER,
    case
      when pcsdw.corperate_identifier is null or pcsdw.corperate_identifier='' then
      case
        when pcsdw.article='ABT-888' then 'A-861695.0'
        when pcsdw.article='ABBV-3748' then 'A-1739723.0'
        when pcsdw.article='ABT-408' then 'A-1402484.0'
        else pcsdw.article
      end
    end as ARTICLE,
    concat(pcsdw.study_number,'; ',pcsdw.species_name,'; dose group ',pcsdw.src_group_number,'; Day ',pcsdw.day_of_phase) as CONDITION,
    pcsdw.meas_area as MEAS_AREA,
    pcsdw.meas_name as MEAS_NAME,
    pcsdw.src_group_number as DOSE_GROUP,
    pcsdw.species_name as SPECIES_NAME,
    pcsdw.dose as DOSE,
    pcsdw.units as DOSE_UNITS,
    pcsdw.day_of_phase as DAY,
    pcsdw.study_number as STUDY,
    pcsdw.study_id as STUDY_ID,
    pcsdw.study_group_id as STUDY_GROUP_ID,
    case
        when pcsdw.duration_days is null then pcsdw.day_of_phase
        else pcsdw.duration_days
    end as DURATION_DAYS,
    pcsdw.phase as PHASE,
    pcsdw.sex as SEX,
    pcsdw.vehicle as VEHICLE,
    pcsdw.route as ROUTE,
    pcsdw.measurement_id as MEASUREMENT_ID,
    concat("https://spotdisc-lc.abbvienet.com/spotfire/wp/analysis?file=/AbbVie/06.%20Dashboards/Tox%20Dashboard%20Parameterized%20for%20Study%20Number&waid=MVY5AbdpP0eITsi65gwvY-0213138404m77y&wavid=0&configurationBlock=STUDY_NUMBER%3D%22",pcsdw.study_number,"%22;") as LINK
  from dependency.v_pcsdw_summary pcsdw
  where 
    pcsdw.article is not null and pcsdw.article>'' and
    pcsdw.dose>0 and
    locate("Dose",pcsdw.src_group_type)>0 and
    ((pcsdw.species_name in ('Rat','Mouse') and cast(pcsdw.delta_pct_from_vc as double) is not null)
    or
    (pcsdw.species_name in ('Dog','Monkey') and (cast(pcsdw.delta_pct_from_vc as double) is not null or cast(pcsdw.delta_pct_from_baseline as double) is not null))) and
    (
      (pcsdw.corperate_identifier is not null and pcsdw.corperate_identifier>'') or
      pcsdw.article in ('ABT-888','ABBV-3748','ABT-408') or
      locate("A-",split(trim(pcsdw.article)," ")[0])>0 or
      locate("PR-",split(trim(pcsdw.article)," ")[0])>0 or
      locate("DC-",split(trim(pcsdw.article)," ")[0])>0 or
      locate("ABT-",split(trim(pcsdw.article)," ")[0])>0 or
      locate("ABBV-",split(trim(pcsdw.article)," ")[0])>0
    )
) t1
left join academe.compounds_v comps on
  t1.MOLECULE_ID=comps.ABBVIE_ID
left join dependency.pcsdw_thresholds th on
  upper(t1.SPECIES_NAME)=upper(th.SPECIES) and
  (
    (t1.MEAS_AREA=th.MEAS_AREA and t1.MEAS_NAME=th.MEAS_NAME and th.MEAS_AREA is not null and th.MEAS_NAME is not null) or
    (t1.MEAS_AREA=th.MEAS_AREA and th.MEAS_NAME is null) or
    (th.MEAS_AREA is null and t1.MEAS_NAME=th.MEAS_NAME)
  )
where t1.CHANGE is not null and (th.PCUTOFF is not null or th.NCUTOFF is not null) and comps.compound_uid is not null
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_pcsdw_msd as
select 
 t.entity1,
 t.entity2,
 t.inchi_key,
 t.entity2_type,
 t.result_type,
 t.species,
 t.study,
 t.units,
 t.duration_days,
 t.result,
 t.strength,
 t.fold_over_threshold,
 t.dose,
 t.r
from (
        select 
            entity1,
	    inchi_key,
            entity2,
            entity2_type,
            result_type,
            metadata.species,
            metadata.STUDY,
            metadata.units,
            metadata.duration_days,
            cast(RESULT as double) as RESULT,
            cast(STRENGTH as double) as STRENGTH,
            cast(metadata.FOLD_OVER_THRESHOLD as double) as FOLD_OVER_THRESHOLD,
            cast(metadata.DOSE as double) as DOSE,
            rank() over (partition by inchi_key,entity2,entity2_type,result_type,metadata.species,metadata.STUDY,metadata.units,metadata.duration_days order by cast(metadata.DOSE as double) asc,cast(metadata.FOLD_OVER_THRESHOLD as double) desc) as R
        from dependency.v_pcsdw_result
        where
        cast(STRENGTH as double)>0 
) t where t.r=1
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_pcsdw_med as
select 
    t.entity1,
    t.entity2,
    t.inchi_key,
    t.entity2_type,
    t.result_type,
    t.species,
    t.study,
    t.units,
    t.duration_days,
    t.result,
    t.strength,
    t.fold_over_threshold,
    t.dose,
    t.r
from (
        select 
            entity1,
            entity2,
            inchi_key,
            entity2_type,
            result_type,
            metadata.species,
            metadata.STUDY,
            metadata.units,
            metadata.duration_days,
            cast(RESULT as double) as RESULT,
            cast(STRENGTH as double) as STRENGTH,
            cast(metadata.FOLD_OVER_THRESHOLD as double) as FOLD_OVER_THRESHOLD,
            cast(metadata.DOSE as double) as DOSE,
            rank() over (partition by inchi_key,entity2,entity2_type,result_type,metadata.species,metadata.STUDY,metadata.units,metadata.duration_days order by cast(metadata.FOLD_OVER_THRESHOLD as double) desc,cast(metadata.DOSE as double) desc) as R
        from dependency.v_pcsdw_result
) t where t.r=1
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_pcsdw_noeffect as
    select 
     t.entity1,
     t.inchi_key,
     'No Significant Effects' as entity2,
     ':Endpoint:No Effect' as entity2_type,
     t.result_type,
     t.species,
     t.study,
     t.units,
     t.duration_days,
     t.result,
     t.strength,
     t.fold_over_threshold,
     t.dose,
     t.strength_sum
     from (
        select 
            entity1,
            inchi_key,
            result_type,
            metadata.species,
            metadata.STUDY,
            metadata.units,
            metadata.duration_days,
            metadata.dose,
            max(result) over ( partition by inchi_key,result_type,metadata.species,metadata.STUDY,metadata.units,metadata.duration_days,metadata.dose)as result,
            max(strength) over ( partition by inchi_key,result_type,metadata.species,metadata.STUDY,metadata.units,metadata.duration_days,metadata.dose) as strength,
            max(metadata.FOLD_OVER_THRESHOLD) over ( partition by inchi_key,result_type,metadata.species,metadata.STUDY,metadata.units,metadata.duration_days,metadata.dose) as FOLD_OVER_THRESHOLD,
            sum(strength) over ( partition by inchi_key,result_type,metadata.species,metadata.STUDY,metadata.units,metadata.duration_days,metadata.dose) as strength_sum
        from dependency.v_pcsdw_result
        ) t where t.strength_sum=0
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_pcsdw_medmsd as
select DISTINCT 
    pcs.entity1 as ENTITY1
    ,":Compound" as ENTITY1_TYPE
    , pcs.entity2 as ENTITY2
    , pcs.entity2_type as ENTITY2_TYPE
    , 'IMPACT_ON' as REL_TYPE
    , case when med.strength>msd.strength then cast(med.strength as int) else cast(msd.strength as int) end as STRENGTH
    , case when med.strength>msd.strength then med.result else msd.result end as RESULT
    , pcs.result_type as RESULT_TYPE
    , 1.0 as CONFIDENCE
    ,named_struct(
    "RULESETS",array(""),
    "SOURCES",array("dependency.v_pcsdw_result","dependency.v_pcsdw_med","dependency.v_pcsdw_msd"),
    "FILTERS",array(""),
    "TIMESTAMP",current_timestamp(),
    "VERSION","1.4.0"
    ) as LINEAGE,
    named_struct(
    "STUDY",pcs.metadata.study,
    "SPECIES",pcs.metadata.species,
    "DURATION_DAYS",cast(pcs.metadata.duration_days as integer),
    "MINIMUM_SIGNIFICANT_DOSE", cast(msd.dose as double),
    "MSD_UNITS",msd.units,
    "EFFECT_AT_MSD",cast(msd.result as double)*100.0,
    "STRENGTH_AT_MSD",cast(msd.strength as int),
    "FOLDOVER_AT_MSD",cast(msd.fold_over_threshold as double),
    "MAXIMUM_EFFECT_DOSE",cast(med.dose as double),
    "MAXIMUM_EFFECT_AT_MED",cast(med.result as double)*100.0,
    "MED_UNITS",med.units,
    "MAXIMUM_STRENGTH_AT_MED",cast(med.STRENGTH as int),
    "MAXIMUM_FOLDOVER_AT_MED",cast(med.fold_over_threshold as double),
    "SOURCE","PCSDW",
    "INCHI_KEY",pcs.inchi_key,
    "LINK",concat("https://spotdisc-lc.abbvienet.com/spotfire/wp/analysis?file=/AbbVie/06.%20Dashboards/Tox%20Dashboard%20Parameterized%20for%20Study%20Number&waid=MVY5AbdpP0eITsi65gwvY-0213138404m77y&wavid=0&configurationBlock=STUDY_NUMBER%3D%22",pcs.metadata.study,"%22;")
    ) as METADATA
from dependency.v_pcsdw_result pcs
left join dependency.v_pcsdw_med med on
    pcs.entity1=med.entity1 and
    pcs.entity2=med.entity2 and
    pcs.result_type=med.result_type and
    pcs.metadata.study=med.study
left join dependency.v_pcsdw_msd msd on
    pcs.entity1=msd.entity1 and
    pcs.entity2=msd.entity2 and
    pcs.result_type=msd.result_type and
    pcs.metadata.study=msd.study
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_pcsdw_noeffect_relationships as
select DISTINCT 
    ENTITY1
    ,":Compound" as ENTITY1_TYPE
    , ENTITY2
    , ENTITY2_TYPE
    ,'HAS_NO_EFFECT' as REL_TYPE
    ,cast(strength as int) as STRENGTH
    , cast(null as double) as RESULT
    , cast(null as string) as RESULT_TYPE
    , 1.0 as CONFIDENCE,
    named_struct(
    "RULESETS",array(""),
    "SOURCES",array("dependency.v_pcsdw_noeffect"),
    "FILTERS",array(""),
    "TIMESTAMP",current_timestamp(),
    "VERSION","1.4.0"
    ) as LINEAGE,
    named_struct(
    "STUDY",study,
    "SPECIES",species,
    "DURATION_DAYS",duration_days,
    "MINIMUM_SIGNIFICANT_DOSE", cast(null as double),
    "MSD_UNITS",cast(null as string),
    "EFFECT_AT_MSD",cast(null as double),
    "STRENGTH_AT_MSD",cast(null as int),
    "FOLDOVER_AT_MSD",cast(null as double),
    "MAXIMUM_EFFECT_DOSE",dose,
    "MAXIMUM_EFFECT_AT_MED",result*100.0,
    "MED_UNITS",units,
    "MAXIMUM_STRENGTH_AT_MED",strength,
    "MAXIMUM_FOLDOVER_AT_MED",fold_over_threshold,
    "SOURCE","PCSDW",
    "INCHI_KEY",inchi_key,
    "LINK",concat("https://spotdisc-lc.abbvienet.com/spotfire/wp/analysis?file=/AbbVie/06.%20Dashboards/Tox%20Dashboard%20Parameterized%20for%20Study%20Number&waid=MVY5AbdpP0eITsi65gwvY-0213138404m77y&wavid=0&configurationBlock=STUDY_NUMBER%3D%22",study,"%22;")
    ) as METADATA
from dependency.v_pcsdw_noeffect
""").batch
