import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL

val almaren = Almaren("CV_VIEWS")
var res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_source_tbl as
select
    i.compound_uid as ENTITY1,
    i.INCHI_KEY,
    i.EFFICACY_DESCRIPTION as ENTITY2,
    concat(":Endpoint:",i.ASSAY) as ENTITY2_TYPE,
    cast(RESULT_VALUE as double) as RESULT,
    i.variablename as RESULT_TYPE,
    i.species_id as SPECIES,
    cast(i.dose as double) as DOSE,
    i.DOSE_UNITS,
    i.DRUG_LEVEL,
    i.DRUG_LEVEL_QUAL,
    i.EFFICACY_DESCRIPTION,
    i.ASSAY,
    i.MEASUREMENT_AREA,
    i.MEASUREMENT_TIME,
    i.MEASUREMENT_TIME_UNITS,
    i.EXPTID,
    i.LSW_ID
from arch_normalized.ddmlcnp1_tdb_dm_invivo_full_seurat_norm i 
where 
    cast(i.dose as double) > 0
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_result_type_filter as
select 
    * 
from dependency.v_cv_source_tbl
where
    (
        RESULT_TYPE = "% Delta" 
        AND (
            ENTITY2 = "Mean Arterial Pressure" 
            OR ENTITY2 = "Heart Rate" 
            OR ENTITY2 = "Left Ventricular Contractility@50" 
            OR ENTITY2 = "Systolic Arterial Pressure" 
            OR ENTITY2 = "Diastolic Arterial Pressure" 
            OR ENTITY2 = "Max Left Ventricular Contractility" 
            OR ENTITY2 = "Systemic Vascular Resistance"
        )
    )
    OR (
        RESULT_TYPE = "Delta" 
        AND (
            ENTITY2 = "PR-Interval" 
            OR ENTITY2 = "QRS-Interval" 
            OR ENTITY2 = "Corrected QT Interval (Van de Water)" 
            OR ENTITY2 = "Corrected QT Interval (Fridericia)" 
            OR ENTITY2 = "Heart Rate (ECG)"
        )
    )
""").batch


res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_cutoff_rule as
 select 
    cvrt.*,
    cvt.PCUTOFF,
    cvt.NCUTOFF
from dependency.v_cv_result_type_filter cvrt
left join academe.cv_thresholds cvt ON
    cvrt.ENTITY2 = cvt.MEAS_AREA and
    (
        upper(cvrt.SPECIES) = upper(cvt.SPECIES) OR
        (
            upper(cvrt.SPECIES) NOT IN (
                'RAT','DOG'
            ) AND
            cvt.SPECIES IS NULL
        )
    )
""").batch


res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_fold_over_threshold_rule as
select 
    *,
    CASE 
        WHEN PCUTOFF is null and cast(NCUTOFF as Double) is not null THEN (RESULT/cast(NCUTOFF as Double))
        WHEN NCUTOFF is null and cast(PCUTOFF as Double) is not null THEN (RESULT/cast(PCUTOFF as Double))
        WHEN (cast(PCUTOFF as Double) is not null and cast(NCUTOFF as Double) is not null) and (ABS(RESULT/cast(PCUTOFF as double)) > ABS(Result/cast(NCUTOFF as double))) THEN  ABS(Result/cast(PCUTOFF as double))
        WHEN (cast(PCUTOFF as Double) is not null and cast(NCUTOFF as Double) is not null) THEN ABS(Result/cast(NCUTOFF as double))
        ELSE null
    END AS FOLD_OVER_THRESHOLD
from dependency.v_cv_cutoff_rule
""").batch


res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_strength_rule as
select 
    *,
    CASE 
        when cast(FOLD_OVER_THRESHOLD as Double) is not null THEN 
            CASE
                WHEN FOLD_OVER_THRESHOLD >= 3.0 THEN 3
                WHEN FOLD_OVER_THRESHOLD >= 2.0 THEN 2
                WHEN FOLD_OVER_THRESHOLD >= 1.0 THEN 1
                ELSE 0
            END
        ELSE 0 --updated code (added ELSE 0 condition)
    END AS STRENGTH
from dependency.v_cv_fold_over_threshold_rule
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_relationship_rule as
select 
    *,
    CASE
        WHEN cast(FOLD_OVER_THRESHOLD as Double) is not null THEN
            CASE 
                WHEN RESULT < 0.0 and STRENGTH > 0 THEN "DECREASES"
                WHEN RESULT > 0.0 and STRENGTH > 0 THEN "INCREASES"
                ELSE "DOES_NOT_SIGNIFICANTLY_AFFECT"
            END 
    END as RELATIONSHIP
from dependency.v_cv_strength_rule where FOLD_OVER_THRESHOLD is not null
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_result as
select DISTINCT
    ENTITY1,
    ENTITY2,
    INCHI_KEY,
    ENTITY2_TYPE,
    RELATIONSHIP,
    STRENGTH,
    RESULT,
    RESULT_TYPE,
    SPECIES,
    DOSE,
    DOSE_UNITS,
    ASSAY,
    DRUG_LEVEL,
    DRUG_LEVEL_QUAL,
    MEASUREMENT_AREA,
    MEASUREMENT_TIME,
    MEASUREMENT_TIME_UNITS,
    EXPTID,
    LSW_ID,
    PCUTOFF,
    NCUTOFF,
    FOLD_OVER_THRESHOLD
from dependency.v_cv_relationship_rule
where 
    STRENGTH is not null 
    and cast(STRENGTH as double) is not null
    AND DOSE is not null 
    and cast(DOSE as float) is not null
    AND RESULT is not null 
    and cast(RESULT as double) is not null
order by DOSE, MEASUREMENT_TIME
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_med as
select 
 t.entity1,
 t.entity2,
 t.inchi_key,
 t.entity2_type,
 t.strength,
 t.result,
 t.species,
 t.fold_over_threshold,
 t.dose,
 t.r
from (
        select 
            entity1,
            inchi_key,
            entity2,
            entity2_type,
            species,
            cast(RESULT as double) as RESULT,
            cast(STRENGTH as double) as STRENGTH,
            cast(FOLD_OVER_THRESHOLD as double) as FOLD_OVER_THRESHOLD,
            cast(DOSE as double) as DOSE,
            rank() over (partition by inchi_key,entity2,entity2_type,species order by cast(FOLD_OVER_THRESHOLD as double) desc,cast(DOSE as double) desc) as R
        from dependency.v_cv_result
        --where strength>0 
) t where t.r=1
""").batch


res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_msd as
select 
 t.entity1,
 t.entity2,
 t.inchi_key,
 t.entity2_type,
 t.strength,
 t.result,
 t.species,
 t.dose,
 t.fold_over_threshold,
 t.r
from (
        select 
            entity1,
            inchi_key,
            entity2,
            entity2_type,
            species,
            cast(RESULT as double) as RESULT,
            cast(STRENGTH as double) as STRENGTH,
            cast(FOLD_OVER_THRESHOLD as double) as FOLD_OVER_THRESHOLD,
            cast(DOSE as double) as DOSE,
            rank() over (partition by inchi_key,entity2,entity2_type,species order by cast(DOSE as double) asc,cast(FOLD_OVER_THRESHOLD as double) desc) as R
        from dependency.v_cv_result
        where
        strength>0 
) t where t.r=1
""").batch


res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_noeffect as
select DISTINCT
    t.entity1 as ENTITY1,
    'No Significant Effects' as ENTITY2,
    t.entity2_type as ENTITY2_TYPE,
	t.inchi_key,
    'HAS_NO_EFFECT' as RELATIONSHIP,
    0 as STRENGTH,
    0.0 as RESULT,
    "" as RESULT_TYPE,
    t.species as SPECIES,
    t.dose as DOSE,
    t.dose_units as DOSE_UNITS,
    t.assay as ASSAY,
    cast(null as double) as DRUG_LEVEL,
    cast(null as string) as DRUG_LEVEL_QUAL,
    cast(null as string) as MEASUREMENT_AREA,
    cast(null as int) as MEASUREMENT_TIME,
    cast(null as string) as MEASUREMENT_TIME_UNITS,
    cast(null as double) as PCUTOFF,
    cast(null as double) as NCUTOFF,
    cast(null as double) as FOLD_OVER_THRESHOLD
FROM (
        select 
            cv.entity1,
			cv.inchi_key,
            cv.entity2_type,
            cv.species,
            cv.DOSE_UNITS,
            cv.ASSAY,
            max(cast(cv.RESULT as double))  over (partition by cv.entity1,cv.entity2_type,cv.species,cv.DOSE_UNITS,cv.ASSAY,cv.DOSE )as RESULT,
            SUM(cast(cv.STRENGTH as int)) over (partition by cv.entity1,cv.entity2_type,cv.species,cv.DOSE_UNITS,cv.ASSAY,cv.DOSE ) as STRENGTH_SUM,
            max(cast(cv.FOLD_OVER_THRESHOLD as double)) over (partition by cv.entity1,cv.entity2_type,cv.species,cv.DOSE_UNITS,cv.ASSAY,cv.DOSE) as FOLD_OVER_THRESHOLD,
            cast(cv.DOSE as double) as DOSE
        from dependency.v_cv_result cv
    ) t 
where t.strength_sum=0	
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_medmsd_relationships as
select DISTINCT 
    cv.entity1 as ENTITY1
    , ':Compound' as ENTITY1_TYPE
    , concat(cv.assay,", ",cv.entity2) as ENTITY2
    , cv.entity2_type as ENTITY2_TYPE
    , 'IMPACT_ON' as REL_TYPE
    , case 
        when med.strength>msd.strength then cast(med.strength as int) 
        when msd.strength is not null then cast(msd.strength as int)
        when med.strength is not null then cast(med.strength as int)
        else 0 
    end as STRENGTH
    , case 
        when med.strength>msd.strength then med.result
        when msd.strength is not null then msd.result
        when med.strength is not null then med.result
        else 0.0
    end as RESULT
    , cv.result_type as RESULT_TYPE
    , 1.0 as CONFIDENCE
    ,named_struct(
    "RULESETS",array(""),
    "SOURCES",array("dependency.v_cv_result","dependency.v_cv_med","dependency.v_cv_msd"),
    "FILTERS",array(""),
    "TIMESTAMP",current_timestamp(),
    "VERSION","1.5.0"
    ) as LINEAGE,
    named_struct(
    "EFFECT_TYPE","",
    "SPECIES",cv.species,
    "FOLD_OVER_THRESHOLD", case when med.strength>msd.strength then cast(med.fold_over_threshold as double) else cast(msd.fold_over_threshold as double) end,
    "MINIMUM_SIGNIFICANT_DOSE", cast(msd.dose as double),
    "EFFECT_AT_MSD",cast(msd.result as double),
    "STRENGTH_AT_MSD",cast(msd.strength as int),
    "FOLDOVER_AT_MSD",cast(msd.fold_over_threshold as double),
    "MAXIMUM_EFFECT_DOSE",cast(med.dose as double),
    "MAXIMUM_EFFECT_AT_MED",cast(med.result as double),
    "MAXIMUM_STRENGTH_AT_MED",cast(med.STRENGTH as int),
    "MAXIMUM_FOLDOVER_AT_MED",cast(med.fold_over_threshold as double),
    "INCHI_KEY",cv.inchi_key,
    "SOURCE","CV SAFETY DATA",
    "LINK",""
    ) as METADATA
from dependency.v_cv_result cv
left outer join dependency.v_cv_med med on
    cv.entity1=med.entity1 and
    cv.entity2=med.entity2 and
    cv.entity2_type=med.entity2_type and
    cv.species=med.species
left outer join dependency.v_cv_msd msd on
    cv.entity1=msd.entity1 and
    cv.entity2=msd.entity2 and
    cv.entity2_type=msd.entity2_type and
    cv.species=msd.species
where med.dose is not null or msd.dose is not null
""").batch

res = almaren.builder.sourceSql("""create or replace view dependency.v_cv_noeffect_relationships as
select  
    ENTITY1
    ,":Compound" as ENTITY1_TYPE
    , concat(cv.ASSAY,", ",cv.ENTITY2) as ENTITY2
    , ENTITY2_TYPE
    ,'HAS_NO_EFFECT' as REL_TYPE
    ,cast(strength as int) as STRENGTH
    , cast(null as double) as RESULT
    , cast(null as string) as RESULT_TYPE
    , 1.0 as CONFIDENCE,
    named_struct(
    "RULESETS",array(""),
    "SOURCES",array("dependency.v_cv_noeffect"),
    "FILTERS",array(""),
    "TIMESTAMP",current_timestamp(),
    "VERSION","1.5.0"
    ) as LINEAGE,
    named_struct(
    "EFFECT_TYPE","",
    "SPECIES",cv.species,
    "FOLD_OVER_THRESHOLD", cast(null as double),
    -- "MINIMUM_SIGNIFICANT_DOSE",cast(cv.dose as double),
    "MINIMUM_SIGNIFICANT_DOSE",cast(null as double),
    "EFFECT_AT_MSD",cast(null as double),
    "STRENGTH_AT_MSD",cast(null as integer),
    "FOLDOVER_AT_MSD",cast(null as double),
    -- "MAXIMUM_EFFECT_DOSE",cast(null as double),
    -- "MAXIMUM_EFFECT_AT_MED",cast(null as double),
    -- "MAXIMUM_STRENGTH_AT_MED",cast(null as integer),
    -- "MAXIMUM_FOLDOVER_AT_MED",cast(null as double),
    "MAXIMUM_EFFECT_DOSE",cast(cv.dose as double),
    "MAXIMUM_EFFECT_AT_MED",cast(cv.result*100.0 as double),
    "MAXIMUM_STRENGTH_AT_MED",cv.strength,
    "MAXIMUM_FOLDOVER_AT_MED",cv.fold_over_threshold,
    "INCHI_KEY",cv.inchi_key,
    "SOURCE","CV SAFETY DATA",
     "LINK",""
    ) as METADATA
from dependency.v_cv_noeffect cv
""").batch
