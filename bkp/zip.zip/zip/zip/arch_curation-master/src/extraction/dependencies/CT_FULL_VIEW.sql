--impala SQL syntax for CT_FULL_VIEW


DROP VIEW IF EXISTS ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_VW;
DROP VIEW IF EXISTS ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_INDICATIONS_AGG_VW;
DROP VIEW IF EXISTS ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_COMPANIES_VW;
DROP VIEW IF EXISTS ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_ELIGIBILITY_VW;
DROP VIEW IF EXISTS ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_INTERV_DETAILS_VW;
DROP VIEW IF EXISTS ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_CANDIDATE_COLUMNS_VW;
DROP VIEW IF EXISTS ABCXUNP1_ABV_ANALYZER_USER.CT_FULL_VIEW_VW;


--CLIN_TRIALS_VW

CREATE VIEW ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_VW AS
SELECT                                                                            /*count (DISTINCT t.trial_id),*/
             t.TRIAL_ID,
             trid.ID AS DRUG_ID,
             trid.NAME,
             GROUP_CONCAT(DISTINCT ide.IDENTIFIER_VALUE,';') AS IDENTIFIER_VALUE,
             t.phase,
             t.TITLE_DISPLAY,
             t.TITLE_OFFICIAL,
             t.NUMBER_OF_SITES,
             t.PATIENT_COUNT_ENROLLMENT,
             t.PATIENT_COUNT_EVALUABLE,
             t.ENDPOINTS_ACHIEVED,
             t.DATE_START,
             t.DATE_END,
             t.DATE_END_TYPE,
             t.DATE_ENROLLMENT_END,
             t.PRIMARY_COMPLETION_DATE,
             t.OUTCOMES_AVAILABLE,
             t.RECRUITMENT_STATUS_NAME,
             --       intv.INTERVENTION_NAME,
             --       t_int.INTERVENTION_NAME,
             GROUP_CONCAT(DISTINCT t_int.INTERVENTION_TYPE,';') AS INTERVENTION_TYPE,
             GROUP_CONCAT(DISTINCT t_int.REGIMEN_TYPE,';') AS REGIMEN_TYPE
        --       intv.DRUG_ID
        FROM ABCXUNP1_ABBVIE_CORTELLIS_CLINICAL.TRIALS t
             INNER JOIN ABCXUNP1_ABBVIE_CORTELLIS_CLINICAL.TRIALS_INTERVENTIONS t_int ON (t.TRIAL_ID = t_int.TRIAL_ID)
             INNER JOIN ABCXUNP1_ABBVIE_CORTELLIS_CLINICAL.IDENTIFIERS ide ON (t.TRIAL_ID = ide.TRIAL_ID)
             INNER JOIN ABCXUNP1_ABBVIE_CORTELLIS_CLINICAL.INTERVENTIONS intv
                 ON (intv.INTERVENTION_NAME = t_int.INTERVENTION_NAME)
             INNER JOIN ABCXUNP1_WORLD3_WRITER.TRID_INVESTIGATIONAL_DRUG trid ON intv.DRUG_ID = CAST (trid.ID as STRING)
       WHERE (t_int.INTERVENTION_TYPE = 'InterventionPrimary')                        --    AND (intv.DRUG_ID = '15472')
                                                               AND (ide.IDENTIFIER_TYPE = 'NCT')
    --AND (t_int.REGIMEN_TYPE = 'single')
    --rofecoxib=15472  venetoclax=70895
    GROUP BY t.TRIAL_ID,
             trid.ID,
             trid.NAME,
             t.phase,
             t.TITLE_DISPLAY,
             t.TITLE_OFFICIAL,
             t.NUMBER_OF_SITES,
             t.PATIENT_COUNT_ENROLLMENT,
             t.PATIENT_COUNT_EVALUABLE,
             t.ENDPOINTS_ACHIEVED,
             t.DATE_START,
             t.DATE_END,
             t.DATE_END_TYPE,
             t.DATE_ENROLLMENT_END,
             t.PRIMARY_COMPLETION_DATE,
             t.OUTCOMES_AVAILABLE,
             t.RECRUITMENT_STATUS_NAME;
 

--CLIN_TRIALS_INDICATIONS_AGG_VW

CREATE VIEW ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_INDICATIONS_AGG_VW AS
SELECT t_ind.trial_id,
         GROUP_CONCAT(DISTINCT trid_ind.INDICATION,';') AS   INDICATION_NAMES
     FROM ABCXUNP1_ABBVIE_CORTELLIS_CLINICAL.TRIALS_INDICATIONS t_ind
          JOIN ABCXUNP1_WORLD3_WRITER.TRID_INDICATION trid_ind ON CAST (t_ind.INDICATION_ID AS STRING) = trid_ind.ID
 --where trial_id = 97344
 GROUP BY t_ind.trial_id;
 
 
--CLIN_TRIALS_COMPANIES_VW 

CREATE VIEW ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_COMPANIES_VW AS
SELECT tc.TRIAL_ID,
            GROUP_CONCAT(DISTINCT CASE tc.COMPANY_TYPE WHEN 'SPONSOR' THEN c.COMPANY_NAME ELSE NULL END,';')
                AS SPONSOR,
            GROUP_CONCAT(DISTINCT CASE tc.COMPANY_TYPE WHEN 'COLLABORATOR' THEN c.COMPANY_NAME ELSE NULL END,';')
                AS COLLABORATOR
       FROM ABCXUNP1_ABBVIE_CORTELLIS_CLINICAL.TRIALS_COMPANIES tc
            JOIN ABCXUNP1_ABBVIE_CORTELLIS_CLINICAL.COMPANIES c ON tc.COMPANY_ID = c.COMPANY_ID
   GROUP BY tc.TRIAL_ID;

--CLIN_TRIALS_ELIGIBILITY_VW

CREATE VIEW ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_ELIGIBILITY_VW AS
SELECT t.TRIAL_ID,
           TRIM (
               REGEXP_REPLACE (REGEXP_REPLACE (SUBSTR (t.CRITERIA_INCLUSION, 1, 400), '<[^>]*>', '~'),
                               '[\~]+',
                               ' '))    AS CRITERIA_INCLUSION,
           TRIM (
               REGEXP_REPLACE (REGEXP_REPLACE (SUBSTR (t.CRITERIA_EXCLUSION, 1, 400), '<[^>]*>', '~'),
                               '[\~]+',
                               ' '))    AS CRITERIA_EXCLUSION
      FROM ABCXUNP1_ABBVIE_CORTELLIS_CLINICAL.TRIALS t;


--CLIN_TRIALS_INTERV_DETAILS_VW

CREATE VIEW ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_INTERV_DETAILS_VW AS 
SELECT tr.trial_id,
             GROUP_CONCAT(DISTINCT tr.INTERVENTION_NAME,';') AS
                 INTERVENTION_NAME,
             CASE
                 WHEN LENGTH (REGEXP_REPLACE (tr.drug_id, '[0123456789]', '')) = 0 THEN CAST (tr.drug_id AS INT)
                 ELSE NULL
             END
                 AS DRUG_ID,
             tr.drug_id
                 AS DRUG_ID_TXT,
             GROUP_CONCAT(DISTINCT CONCAT_WS('',tr.INTERVENTION_NAME, '(', tr.ROUTE, '): ', tr.DOSE),';\r\n')
                 AS
                 DOSING_SUMMARY,
             CASE COUNT (DISTINCT REGEXP_EXTRACT (tr.DOSE,
                                                 '([^ ]+).([^ ]+)',
                                                 2))
                 WHEN 1
                 THEN
                        CONCAT_WS('',CAST (MIN (CAST (REGEXP_EXTRACT (tr.DOSE,
                                                           '([^ ]+).([^ ]+)',
                                                           1) AS INT)) AS STRING)
                     , '-'
                     , CAST (MAX (CAST (REGEXP_EXTRACT (tr.DOSE,
                                                           '([^ ]+).([^ ]+)',
                                                           1) AS INT)) AS STRING))
                 ELSE
                     NULL
             END
                 AS DOSE_RANGE,
             MIN (CAST (REGEXP_EXTRACT (tr.DOSE,
                                       '([^ ]+).([^ ]+)',
                                       1) AS INT))
                 MINIMUM_DOSE,
             MAX (CAST (REGEXP_EXTRACT (tr.DOSE,
                                       '([^ ]+).([^ ]+)',
                                       1) AS INT))
                 MAXIMUM_DOSE,
             GROUP_CONCAT(DISTINCT REGEXP_EXTRACT (tr.DOSE,
                                              '([^ ]+).([^ ]+)',
                                              2),'') AS
                 DOSE_UNIT,
             GROUP_CONCAT(DISTINCT tr.ROUTE,';')
                 AS ROUTES
        FROM ABCXUNP1_ABBVIE_CORTELLIS_CLINICAL.TREATMENTS tr 
    GROUP BY tr.TRIAL_ID, tr.DRUG_ID;
    
    
--CLIN_TRIALS_CANDIDATE_COLUMNS_VW    

CREATE VIEW ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_CANDIDATE_COLUMNS_VW AS
SELECT po.trial_id,
           REGEXP_REPLACE (
               REGEXP_REPLACE (REGEXP_REPLACE (SUBSTR (PO.REGIMENS, 1, 800), '<[^>]*>', '~'),
                               '\\[[~1234567890]*\\]',
                               ''),
               '[\~]+',
               '')    AS REGIMEN_SUMMARY,
           REGEXP_REPLACE (
               REGEXP_REPLACE (REGEXP_REPLACE (SUBSTR (PO.PROTOCOL_DESCRIPTION, 1, 800), '<[^>]*>', '~'),
                               '\\[[~1234567890]*\\]',
                               ''),
               '[\~]+',
               '')    AS PROTOCOL_DESCRIPTION,
           REGEXP_REPLACE (
               REGEXP_REPLACE (REGEXP_REPLACE (SUBSTR (PO.OUTCOMES, 1, 800), '<[^>]*>', '~'),
                               '\\[[~1234567890]*\\]',
                               ''),
               '[\~]+',
               '')    AS OUTCOMES_SUMMARY,
           REGEXP_REPLACE (
               REGEXP_REPLACE (REGEXP_REPLACE (SUBSTR (PO.AIMS_AND_SCOPE, 1, 800), '<[^>]*>', '~'),
                               '\\[[~1234567890]*\\]',
                               ''),
               '[\~]+',
               '')    AS AIMS_AND_SCOPE,
           REGEXP_REPLACE (
               REGEXP_REPLACE (REGEXP_REPLACE (SUBSTR (PO.ADVERSE_EVENTS, 1, 800), '<[^>]*>', '~'),
                               '\\[[~1234567890]*\\]',
                               ''),
               '[\~]+',
               '')    AS ADVERSE_EVENTS,
           REGEXP_REPLACE (
               REGEXP_REPLACE (REGEXP_REPLACE (SUBSTR (PO.SUSPENSION_REASON, 1, 800), '<[^>]*>', '~'),
                               '\\[[~1234567890]*\\]',
                               ''),
               '[\~]+',
               '')    AS SUSPENSION_REASON
      FROM ABCXUNP1_ABBVIE_CORTELLIS_CLINICAL.PROTOCOL_AND_OUTCOMES PO;
      
--CT_FULL_VIEW_VW

CREATE VIEW ABCXUNP1_ABV_ANALYZER_USER.CT_FULL_VIEW_VW AS
SELECT ct1.DATE_END,
           ct1.DATE_END_TYPE,
           ct1.DATE_ENROLLMENT_END,
           ct1.DATE_START,
           ct1.DRUG_ID,
           ct1.ENDPOINTS_ACHIEVED,
           ct1.IDENTIFIER_VALUE,
           ct1.NAME     AS DRUG_NAME,
           ct1.NUMBER_OF_SITES,
           ct1.PATIENT_COUNT_ENROLLMENT,
           ct1.PATIENT_COUNT_EVALUABLE,
           ct1.PHASE,
           ct1.PRIMARY_COMPLETION_DATE,
           ct1.TITLE_DISPLAY,
           ct1.TITLE_OFFICIAL,
           ct1.TRIAL_ID,
           ct1.REGIMEN_TYPE,
           ct1.INTERVENTION_TYPE,
           ct1.OUTCOMES_AVAILABLE,
           ct1.RECRUITMENT_STATUS_NAME,
           cte.CRITERIA_INCLUSION,
           cte.CRITERIA_EXCLUSION,
           ctia.INDICATION_NAMES,
           ctid.INTERVENTION_NAME,
           ctid.DOSE_RANGE,
           ctid.DOSE_UNIT,
           ctid.DOSING_SUMMARY,
           ctid.MAXIMUM_DOSE,
           ctid.MINIMUM_DOSE,
           ctid.ROUTES,
           ctcc.ADVERSE_EVENTS,
           ctcc.AIMS_AND_SCOPE,
           ctcc.OUTCOMES_SUMMARY,
           ctcc.PROTOCOL_DESCRIPTION,
           ctcc.REGIMEN_SUMMARY,
           ctcc.SUSPENSION_REASON,
           ctc.SPONSOR,
           ctc.COLLABORATOR
      FROM ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_VW  ct1
           LEFT JOIN ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_INTERV_DETAILS_VW ctid
               ON ct1.TRIAL_ID = ctid.TRIAL_ID AND ct1.DRUG_ID = ctid.DRUG_ID
           LEFT JOIN ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_INDICATIONS_AGG_VW ctia ON ct1.TRIAL_ID = ctia.TRIAL_ID
           LEFT JOIN ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_CANDIDATE_COLUMNS_VW ctcc ON ct1.TRIAL_ID = ctcc.TRIAL_ID
           LEFT JOIN ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_ELIGIBILITY_VW cte ON ct1.TRIAL_ID = cte.TRIAL_ID
           LEFT JOIN ABCXUNP1_ABV_ANALYZER_USER.CLIN_TRIALS_COMPANIES_VW ctc ON ct1.TRIAL_ID = ctc.TRIAL_ID;
           
   

