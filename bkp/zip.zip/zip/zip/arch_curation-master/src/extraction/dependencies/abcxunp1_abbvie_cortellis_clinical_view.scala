import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;
import com.github.music.of.the.ainur.quenya.QuenyaDSL

val almaren = Almaren("CORTELLIS_VIEWS")
var res = almaren.builder.sourceSql("""create or replace view dependency.v_abcxunp1_abbvie_cortellis_clinical as
SELECT 
    tr.INTERVENTION_NAME as intervention_name,
    tr.DOSE as dose,
    tr.ROUTE as route,
    i.INDICATION_NAME as indication_name,
    id.IDENTIFIER_VALUE as identifier_value,
    d.DRUG_NAME as drug_name,
    d.DRUG_ID as drug_id,
    tint.INTERVENTION_NAME as xtra_interventions,
    tint.INTERVENTION_TYPE as intervention_type,
    tint.regimen_type as regimen_type,
    t.trial_id as trial_id,
    t.title_display as title_display,
    t.outcomes_available as outcomes_available,
    t.endpoints_achieved as endpoints_achieved,
    t.phase as phase,
    t.recruitment_status_name as recruitment_status_name,
    t.number_of_sites as number_of_sites,
    t.patient_count_enrollment as patient_count_enrollment,
    t.date_start as date_start,
    t.date_end as date_end,
    t.primary_completion_date as primary_completion_date,
    t.criteria_inclusion as criteria_inclusion,
    t.criteria_exclusion as criteria_exclusion,
    outcomes.outcomes as outcomes,
	company_name as sponsor
FROM abcxunp1_ABBVIE_CORTELLIS_CLINICAL.TRIALS  t, abcxunp1_ABBVIE_CORTELLIS_clinical.protocol_and_outcomes outcomes
       JOIN abcxunp1_ABBVIE_CORTELLIS_CLINICAL.TRIALS_INDICATIONS ti ON t.TRIAL_ID = ti.TRIAL_ID
       JOIN abcxunp1_ABBVIE_CORTELLIS_CLINICAL.INDICATIONS i ON ti.INDICATION_ID = i.INDICATION_ID
       JOIN abcxunp1_ABBVIE_CORTELLIS_CLINICAL.TRIALS_INTERVENTIONS tint ON t.TRIAL_ID = tint.TRIAL_ID
       LEFT JOIN abcxunp1_ABBVIE_CORTELLIS_CLINICAL.TREATMENTS tr
       ON tint.INTERVENTION_NAME = tr.INTERVENTION_NAME AND tint.TRIAL_ID = tr.TRIAL_ID
       JOIN abcxunp1_ABBVIE_CORTELLIS_CLINICAL.DRUGS d ON tint.INTERVENTION_NAME = d.DRUG_NAME 
       JOIN abcxunp1_ABBVIE_CORTELLIS_CLINICAL.IDENTIFIERS id ON t.TRIAL_ID = id.TRIAL_ID
	   JOIN abcxunp1_ABBVIE_CORTELLIS_clinical.TRIALS_COMPANIES TC ON (T.TRIAL_ID = TC.TRIAL_ID)
       JOIN abcxunp1_ABBVIE_CORTELLIS_clinical.COMPANIES C ON (TC.COMPANY_ID = C.COMPANY_ID)
WHERE  tint.INTERVENTION_TYPE = 'InterventionPrimary'
AND (id.IDENTIFIER_TYPE = 'NCT') AND (COMPANY_TYPE = 'SPONSOR')
AND d.DRUG_ID > 0
AND t.TRIAL_ID = outcomes.TRIAL_ID
/*
AND d.DRUG_NAME = 'venetoclax'
*/
""").batch
