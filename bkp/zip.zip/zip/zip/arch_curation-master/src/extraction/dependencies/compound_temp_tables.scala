import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "preclinical"
val set_name = "t_abv_compounds"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
      select 
        fd3.inchi_key as inchi_key,
        fd3.identifier,
        fd3.source_inchi_key,
        fd3.drug_name,
        'BASE' as origin
      from aidxunp1_abv_fd2.fd_structure_source fd3
      where 
        fd3.inchi_key=fd3.source_inchi_key and 
        fd3.source='AbbVie'
""").batch
res.printSchema()
res.repartition(1).write.mode("OVERWRITE").partitionBy("origin").option("format", "parquet").option("path","s3a://arch-" + environment + "-datalake/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name).saveAsTable(db_name + "." + set_name)
	
val res2 = almaren.builder.sourceSql("""
      select 
        fd1.inchi_key,
        concat(split(fd1.identifier,'\\.')[0],'.0') as identifier,
        fd1.inchi_key as source_inchi_key,
        fd1.drug_name,
        'ROOT' as origin
      from aidxunp1_abv_fd2.fd_structure_source fd1
      left join preclinical.t_abv_compounds tac on
        fd1.inchi_key = tac.inchi_key
      where 
        fd1.identifier not like '%.0' and
        fd1.inchi_key<>fd1.source_inchi_key and 
        tac.inchi_key is null and
        fd1.source='AbbVie'
""").batch
res2.printSchema()
res2.repartition(1).write.mode("APPEND").partitionBy("origin").option("format", "parquet").option("path","s3a://arch-" + environment + "-datalake/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name).saveAsTable(db_name + "." + set_name)

val res3 = almaren.builder.sourceSql("""
      select 
        fd2.source_inchi_key as inchi_key,
        fd2.identifier,
        fd2.inchi_key as source_inchi_key,
        fd2.drug_name,
        'SALT' as origin
      from aidxunp1_abv_fd2.fd_structure_source fd2
      left join preclinical.t_abv_compounds tac on
        fd2.source_inchi_key=tac.inchi_key
      where 
        fd2.identifier not like '%.0' and
        fd2.inchi_key<>fd2.source_inchi_key and 
        tac.inchi_key is null and
        fd2.source='AbbVie'
""").batch
res3.printSchema()
res3.repartition(1).write.mode("APPEND").partitionBy("origin").option("format", "parquet").option("path","s3a://arch-" + environment + "-datalake/data/warehouse/" + data_store + "/" + db_name + ".db/" + set_name).saveAsTable(db_name + "." + set_name)
