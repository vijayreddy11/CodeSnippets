Add the code for all entities, relationships and triples in arch_curation/src/extraction
