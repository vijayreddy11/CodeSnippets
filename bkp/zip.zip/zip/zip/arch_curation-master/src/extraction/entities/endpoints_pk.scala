import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_endpoint_pk_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
with endpoint_pk as (
SELECT 
concat(RESULT_CATEGORY, '|', RESULT_TYPE) as ID,
":Endpoint:PK" as LABEL,
"InVivoPK" as PRIMARYSOURCE,
concat(RESULT_CATEGORY, '|', RESULT_TYPE) as PRIMARYIDENTIFIER,
RESULT_TYPE as PREFERRED_NAME,
array(SOURCE) as SOURCES,
array(concat(RESULT_CATEGORY, '|', RESULT_TYPE)) as IDENTIFIERS,
named_struct(
		"SOURCES",array("arch_normalized.pk_combined_view_norm"),
		"FILTERS","",
		"TIMESTAMP",unix_timestamp(),
		"VERSION","1.2.0"
	) as LINEAGE,
named_struct(
		"RESULT_CATEGORY", RESULT_CATEGORY,
		"RESULT_TYPE",RESULT_TYPE,
		"RESULT_UNIT",RESULT_UNIT
	) as METADATA
from arch_normalized.pk_combined_view_norm
)
SELECT 
LABEL,
ID,
PRIMARYSOURCE,
PRIMARYIDENTIFIER,
PREFERRED_NAME, 
SOURCES,
IDENTIFIERS,
LINEAGE,
METADATA
from (SELECT *,ROW_NUMBER() OVER(PARTITION BY ID ORDER BY ID) AS ROWNUM
from endpoint_pk) x
where ROWNUM=1
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
