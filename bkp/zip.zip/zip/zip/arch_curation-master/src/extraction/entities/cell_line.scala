import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_cellline_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
With cell_line_er_version as (
select  distinct concat(major,'.',minor) as  er_version ,'cell_line' as tmp_col
from academe.cell_line_version_v
)
select 
":Cell Line" as LABEL,
t1.ABBV_UID as ID,
t1.ABBV_TERM as PREFERRED_NAME,
t1.ABBV_TERM_SOURCE as PRIMARYSOURCE,
t1.ABBV_TERM as PRIMARYIDENTIFIER,
t1.ABBV_CODE as CVCL,
t1.ABBV_TERM as ABBVIE_CELL_LINE_NAME,
t1.ABBV_TERM_SOURCE as ABBVIE_CELL_LINE_NAME_SOURCE,
t1.CELLOSAURUS_TERM as CELL_LINE,  
t1.CELLOSAURUS_GENDER as GENDER,
t1.CELLOSAURUS_CATEGORY as CATEGORY,
t1.CELLOSAURUS_SPECIES as SPECIES,
t1.CELLOSAURUS_DISEASE as DISEASES,
t1.CELLOSAURUS_DISEASE_CODES as DISEASE_ACCS,
t1.CELLOSAURUS_SYNONYMS as SYNONYMS,
t1.CELLOSAURUS_XREFS as XREFS,
t1.CELLOSAURUS_PARENTS as PARENTS,
t1.CLO_CODE as CLO_ACC,
t1.CELL_TYPE,
concat(t1.ABBV_TERM,'_Cell Line') as TELLIC_ID, 
named_struct(
        "SOURCES",array(case when er_version is not null then concat("academe.cell_line_v",' ',er_version) else "academe.cell_line_v" end,"academe.cell_line_version_v"),
        "FILTERS",array(""),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.3.0"
           ) as LINEAGE
from 
(select *, 'cell_line' as tmp_col from academe.cell_line_v) t1
left outer join cell_line_er_version cell_line
on t1.tmp_col = cell_line.tmp_col
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
