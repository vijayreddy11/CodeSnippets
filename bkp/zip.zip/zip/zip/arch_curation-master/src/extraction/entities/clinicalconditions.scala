import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_clinicalcondition_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    ':Clinical Condition' as LABEL,
    t1.CLIN_INTERACTION as ID,
    t1.CLIN_INTERACTION as PREFERRED_NAME,
    t1.CLIN_INTERACTION,
    named_struct(
        "SOURCES",array("preclinical.t_scopiarx_ci_main_03062021"),
        "FILTERS","",
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.0"
    ) as LINEAGE
FROM (
    SELECT CLIN_INTERACTION from preclinical.t_scopiarx_ci_main_03062021
) t1
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
