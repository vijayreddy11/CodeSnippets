import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_ddi_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT 
    DISTINCT
    ':DDI' as LABEL,
    CASE 
        WHEN EMBL_DI > EMBL_DPS then concat(ABBVIE_DRUG2_UID, '|', ABBVIE_DRUG1_UID) 
        ELSE concat(ABBVIE_DRUG1_UID, '|', ABBVIE_DRUG2_UID)  
    END as ID,
    CASE 
        WHEN EMBL_DI > EMBL_DPS then concat(drug2_er_abbv_term, '|', drug1_er_abbv_term) 
        ELSE concat(drug1_er_abbv_term, '|', drug2_er_abbv_term)  
    END as PREFERRED_NAME,
    CASE 
        WHEN EMBL_DI > EMBL_DPS then concat(drug2_er_abbv_term, '|', drug1_er_abbv_term)
        ELSE concat(drug1_er_abbv_term, '|', drug2_er_abbv_term)  
    END as DDI,
    CASE 
        WHEN EMBL_DI > EMBL_DPS then concat(drug2_er_chembl_molecule_id, '|', drug1_er_chembl_molecule_id)
        ELSE concat(drug1_er_chembl_molecule_id, '|', drug2_er_chembl_molecule_id) 
    END as DDI_ID,
    named_struct(
        "SOURCES",array("scopiarx.di_main_db_norm"),
        "FILTERS","",
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.5"
    ) as LINEAGE
FROM arch_normalized.scopiarx_di_main_db_norm
where ABBVIE_DRUG1_UID is NOT NULL and ABBVIE_DRUG2_UID is NOT NULL
--and AI_DI rlike 'TINZAPARIN|HEPARIN|OMEGA-3-ACID ETHYL ESTERS' 
--and AI_DPS rlike 'TINZAPARIN|HEPARINOMEGA-3-ACID ETHYL ESTERS'
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
