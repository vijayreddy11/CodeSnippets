import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_adverseevent_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
select DISTINCT
  ':Patient Adverse Event' AS LABEL,
  aes.ABBV_UID as ID,
  aes.ABBV_TERM as PREFERRED_NAME,
  aes.ABBV_TERM_SOURCE as PRIMARYSOURCE,
  aes.ABBV_CODE as PRIMARYIDENTIFIER,
  aes.ABBV_TERM as AE,
  split(aes.MEDDRA_SOCS," \\| ") as MEDDRA_SOCS,
  named_struct(
    "SOURCES",array("academe.health_condition_v"),
    "FILTERS","",
    "TIMESTAMP",unix_timestamp(),
    "VERSION","1.2.0"
  ) as LINEAGE  
FROM (
select * from academe.health_condition_v 
-- As per ARCHO-2590 lynn mentioned to add filter to use meddra source values.
where abbv_uid is not null and abbv_uid not like '%|%' and abbv_term_source = 'meddra'
) aes
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
