import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_endpoint_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""with pcsdw_endpoint as ( 
SELECT DISTINCT CONCAT(':Endpoint:',t1.MEASUREMENT_AREA) as LABEL,
CONCAT(t1.MEASUREMENT_AREA,', ',t1.MEASUREMENT_NAME) as ID,
t1.MEASUREMENT_NAME as PREFERRED_NAME,
t1.MEASUREMENT_AREA,
t1.MEASUREMENT_NAME,
null as ASSAY,
null as EFFICACY_DESCRIPTION,
'PCSDW' as PRIMARYSOURCE,
CONCAT(t1.MEASUREMENT_AREA,', ',t1.MEASUREMENT_NAME) as PRIMARYIDENTIFIER,
--null as MEASUREMENT_TIME,
--null as MEASUREMENT_TIME_UNITS,
--t1.ISVISIBLE,
--t1.ABBREVIATION,
--t1.MEASUREMENT_UNIT,
--t1.MEASUREMENT_TYPE,
--cast(t1.MEASUREMENT_ID as integer) as MEASUREMENT_ID,
named_struct(
"SOURCES",array("ddmlcnp1_pcsdw.measurement"),
"FILTERS","",
"TIMESTAMP",unix_timestamp(),
"VERSION","1.0.0") as LINEAGE
FROM ddmlcnp1_pcsdw.measurement t1
WHERE t1.MEASUREMENT_AREA IN ('Chemistry Measurement','Hematology Measurement','Urinalysis Measurement','Organ Weights') 
and t1.ISVISIBLE='Y'
union
SELECT DISTINCT CONCAT(':Endpoint:','No Effect') as LABEL,
'No Effect, No Significant Effects' as  ID,
'No Significant Effects' as PREFERRED_NAME,
'No Effect' as MEASUREMENT_AREA,
'No Significant Effects' as MEASUREMENT_NAME,
null as ASSAY,
null as EFFICACY_DESCRIPTION,
'PCSDW' as PRIMARYSOURCE,
'No Effect, No Significant Effects' as PRIMARYIDENTIFIER,
named_struct(
"SOURCES",array("ddmlcnp1_pcsdw.measurement"),
"FILTERS","",
"TIMESTAMP",unix_timestamp(),
"VERSION","1.2.0") as LINEAGE
)
,cv_endpoint as (
SELECT DISTINCT CONCAT(':Endpoint:',t1.assay) as LABEL,
CONCAT(t1.assay,', ',t1.efficacy_description) as ID,
t1.efficacy_description as PREFERRED_NAME,
null as MEASUREMENT_AREA,
null as MEASUREMENT_NAME,
t1.ASSAY,
'CV SAFETY DATA' as PRIMARYSOURCE,
CONCAT(t1.assay,', ',t1.efficacy_description) as PRIMARYIDENTIFIER,
t1.EFFICACY_DESCRIPTION,
--t1.MEASUREMENT_TIME,
--t1.MEASUREMENT_TIME_UNITS,
--t1.MEASUREMENT_UNIT,
--t1.MEASUREMENT_TYPE,
--cast(t1.MEASUREMENT_ID as integer) as MEASUREMENT_ID,
named_struct(
"SOURCES",array("arch_normalized.ddmlcnp1_tdb_dm_invivo_full_seurat_norm"),
"FILTERS","",
"TIMESTAMP",unix_timestamp(),
"VERSION","1.2.0") as LINEAGE
from arch_normalized.ddmlcnp1_tdb_dm_invivo_full_seurat_norm t1
where 1=1 
and dose > 0
union
SELECT DISTINCT CONCAT(':Endpoint:',t1.assay) as LABEL,
CONCAT(t1.assay,', ','No Significant Effects') as ID,
'No Significant Effects' as PREFERRED_NAME,
null as MEASUREMENT_AREA,
null as MEASUREMENT_NAME,
t1.ASSAY,
'CV SAFETY DATA' as PRIMARYSOURCE,
CONCAT(t1.assay,', ','No Significant Effects') as PRIMARYIDENTIFIER ,
'No Significant Effects' as EFFICACY_DESCRIPTION,
--t1.MEASUREMENT_TIME,
--t1.MEASUREMENT_TIME_UNITS,
--t1.MEASUREMENT_UNIT,
--t1.MEASUREMENT_TYPE,
--cast(t1.MEASUREMENT_ID as integer) as MEASUREMENT_ID,
named_struct(
"SOURCES",array("arch_normalized.ddmlcnp1_tdb_dm_invivo_full_seurat_norm"),
"FILTERS","",
"TIMESTAMP",unix_timestamp(),
"VERSION","1.2.0") as LINEAGE
from arch_normalized.ddmlcnp1_tdb_dm_invivo_full_seurat_norm t1
where 1=1 
and dose > 0
)
select * from pcsdw_endpoint
union 
select * from cv_endpoint""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
