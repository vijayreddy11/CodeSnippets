import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_tissue_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
With tissue_er_version as (
select  distinct concat(major,'.',minor) as  er_version ,'tissue' as tmp_col
from academe.tissue_version_v
)
select 
":Tissue" as LABEL,
t1.ABBV_UID as ID,
t1.ABBV_TERM as PREFERRED_NAME,
t1.ABBV_TERM_SOURCE as PRIMARYSOURCE,
t1.ABBV_TERM as PRIMARYIDENTIFIER,
t1.TISSUE,
t1.CCLE_TERM as CCLE,
t1.GTEX_TERM as GTEX,
t1.TCGA_TERM as TCGA,
t1.MESH_CODE as MESH_ACC,
t1.MESH_TERM as MESH,
t1.NCIT_CODE as NCIT_ACC,
t1.NCIT_TERM as NCIT,
t1.ABBV_TERM as ABBVIE_NAME,
t1.ABBV_TERM_SOURCE as ABBVIENAME_SOURCE,
t1.BIOLOGICAL_SYSTEM,
t1.TISSUE_CATEGORY,
concat(t1.ABBV_TERM,'_Tissue') as TELLIC_ID, 
named_struct(
        "SOURCES",array(case when er_version is not null then concat("academe.tissue_v",' ',er_version) else "academe.tissue_v" end,"academe.tissue_version_v"),
        "FILTERS",array(""),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.3.0"
           ) as LINEAGE
from 
(select *,'tissue' as tmp_col from academe.tissue_v ) t1 left outer join tissue_er_version tissue
on t1.tmp_col = tissue.tmp_col
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
