import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_endpoint_cv_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""with cv_endpoint as (
SELECT DISTINCT CONCAT(':Endpoint:',t1.assay) as LABEL,
CONCAT(t1.assay,', ',t1.efficacy_description) as ID,
t1.efficacy_description as PREFERRED_NAME,
CAST(null as string) as MEASUREMENT_AREA,
CAST(null as string) as MEASUREMENT_NAME,
t1.ASSAY,
'CV SAFETY DATA' as PRIMARYSOURCE,
CONCAT(t1.assay,', ',t1.efficacy_description) as PRIMARYIDENTIFIER,
t1.EFFICACY_DESCRIPTION,
--t1.MEASUREMENT_TIME,
--t1.MEASUREMENT_TIME_UNITS,
--t1.MEASUREMENT_UNIT,
--t1.MEASUREMENT_TYPE,
--cast(t1.MEASUREMENT_ID as integer) as MEASUREMENT_ID,
named_struct(
"SOURCES",array("arch_normalized.ddmlcnp1_tdb_dm_invivo_full_seurat_norm"),
"FILTERS","",
"TIMESTAMP",unix_timestamp(),
"VERSION","1.2.0") as LINEAGE
from arch_normalized.ddmlcnp1_tdb_dm_invivo_full_seurat_norm t1
where 1=1 
and dose > 0
union
SELECT DISTINCT CONCAT(':Endpoint:',t1.assay) as LABEL,
CONCAT(t1.assay,', ','No Significant Effects') as ID,
'No Significant Effects' as PREFERRED_NAME,
CAST(null as string) as MEASUREMENT_AREA,
CAST(null as string) as MEASUREMENT_NAME,
t1.ASSAY,
'CV SAFETY DATA' as PRIMARYSOURCE,
CONCAT(t1.assay,', ','No Significant Effects') as PRIMARYIDENTIFIER ,
'No Significant Effects' as EFFICACY_DESCRIPTION,
--t1.MEASUREMENT_TIME,
--t1.MEASUREMENT_TIME_UNITS,
--t1.MEASUREMENT_UNIT,
--t1.MEASUREMENT_TYPE,
--cast(t1.MEASUREMENT_ID as integer) as MEASUREMENT_ID,
named_struct(
"SOURCES",array("arch_normalized.ddmlcnp1_tdb_dm_invivo_full_seurat_norm"),
"FILTERS","",
"TIMESTAMP",unix_timestamp(),
"VERSION","1.2.0") as LINEAGE
from arch_normalized.ddmlcnp1_tdb_dm_invivo_full_seurat_norm t1
where 1=1 
and dose > 0
)
select * from cv_endpoint""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
