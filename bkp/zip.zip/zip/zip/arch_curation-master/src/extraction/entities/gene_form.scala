import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_gene_form_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
WITH intermediate_gene_form_entities_tbl_1 as (
    SELECT 
	":GeneForm" as LABEL, 
    entity2 as ID, 
    "Biacore" as PRIMARYSOURCE,
    entity2 as PRIMARYIDENTIFIER,
    entity2 as PREFERRED_NAME,
    Source as SOURCES,
    array(entity2) as IDENTIFIERS,
    ROW_NUMBER() OVER(PARTITION BY entity2 ORDER BY entity1) AS ROWNUM 
    FROM arch_normalized.biacore_gpsc_norm
)
,intermediate_gene_form_entities_tbl_2 as(
	SELECT 
	":GeneForm" as LABEL, 
    protein as ID, 
    "Biacore" as PRIMARYSOURCE,
    protein as PRIMARYIDENTIFIER,
    protein as PREFERRED_NAME,
    Source as SOURCES,
    array(protein) as IDENTIFIERS,
    ROW_NUMBER() OVER(PARTITION BY protein ORDER BY anumber) AS ROWNUM 
    FROM arch_normalized.ddmlcnp1_tdb_dm_invitro_stats_all_norm
)
,gene_form_entities as(
SELECT 
    LABEL,
    ID,
    PRIMARYSOURCE,
    PRIMARYIDENTIFIER,
    PREFERRED_NAME, 
    SOURCES,
    IDENTIFIERS 
FROM intermediate_gene_form_entities_tbl_1
WHERE ROWNUM=1
union
SELECT 
    LABEL,
    ID,
    PRIMARYSOURCE,
    PRIMARYIDENTIFIER,
    PREFERRED_NAME, 
    SOURCES,
    IDENTIFIERS
FROM intermediate_gene_form_entities_tbl_2
WHERE ROWNUM=1
)
SELECT 
    LABEL,
    ID,
    PRIMARYSOURCE,
    PRIMARYIDENTIFIER,
    PREFERRED_NAME, 
    collect_set(SOURCES) as SOURCES,
    IDENTIFIERS,
	named_struct(
		"SOURCES",array("ddmlcnp1_ppilot_rad.biacore_gpsc","ddmlcnp1_tdb_dm.invitro_stats_all"),
		"FILTERS","",
		"TIMESTAMP",unix_timestamp(),
		"VERSION","1.2.0") 
	as LINEAGE
FROM gene_form_entities
where ID is not null
group by LABEL,ID,PRIMARYSOURCE,PRIMARYIDENTIFIER,PREFERRED_NAME,IDENTIFIERS""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
