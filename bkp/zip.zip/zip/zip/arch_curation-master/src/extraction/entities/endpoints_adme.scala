import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_endpoint_adme_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT 
DISTINCT
entity2 as ID
,':Endpoint:ADMETox' as LABEL
,adme_assay as PREFERRED_NAME
,ADME_ASSAY
,ADME_GROUP
,ADME_SUBGROUP
,'ADMETox' as PRIMARYSOURCE
,entity2 as PRIMARYIDENTIFIER
--,SOURCES
,named_struct(
        "SOURCES",array("ddmlcnp1_ppilot_rad.ddp_updated_adme,ark.t_compound_entities"),
        "FILTERS",array("data_group <> 'PK',col NOT LIKE '%WithNV%'"),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.2.0"
    ) as LINEAGE
from arch_normalized.ddp_updated_adme_norm
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
