import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_dci_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
with row_num as(
SELECT DISTINCT
    ':DCI' as LABEL,
    CONCAT(ai_drugs.IDENTIFIER,'|@|',dci.CLIN_INTERACTION) as ID,
    row_number() OVER (PARTITION BY CONCAT(ai_drugs.IDENTIFIER,'|@|',dci.CLIN_INTERACTION) ORDER BY CONCAT(ai_drugs.IDENTIFIER,'|@|',dci.CLIN_INTERACTION) DESC) as unique_id,
    CONCAT(dci.AI,'|@|',dci.CLIN_INTERACTION) as PREFERRED_NAME,
    CONCAT(dci.AI,'|@|',dci.CLIN_INTERACTION) as DCI,
    named_struct(
        "SOURCES",array("preclinical.t_scopiarx_ci_main_03062021","preclinical.r_scopia_chembl_ids"),
        "FILTERS","",
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.0"
    ) as LINEAGE
    FROM preclinical.t_scopiarx_ci_main_03062021 dci
LEFT JOIN preclinical.r_scopia_chembl_ids ai_drugs on dci.AI=ai_drugs.SCOPIA_NAME
WHERE ai_drugs.IDENTIFIER IS NOT NULL and dci.CLIN_INTERACTION is not null)
SELECT DISTINCT LABEL,ID,PREFERRED_NAME,DCI,LINEAGE 
FROM row_num 
WHERE unique_id =1
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
