import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren


val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_variant_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
select
LABEL,
ID,
PREFERRED_NAME,
collect_set(PRIMARYSOURCE) as PRIMARYSOURCE,
PRIMARYIDENTIFIER,
CHROMOSOME,
GENOMIC_POSITION_START,
GENOMIC_POSITION_END,
REFERENCE_ALLELE,
ALTERNATE_ALLELE,
JOINED_EXPLICIT_VAR_UIDS,
CHROMPOS_UID,
RSIDS,
CHROM_POS,
CYTO_LOCATION,
COMPUTED_CYTO_LOCATION,
collect_set(TELLIC_ID) as TELLIC_ID,
LINEAGE
from (
SELECT
":Variant" as LABEL,
t4.var_uid AS ID,
CONCAT('chr',t4.chromosome,':',split(t4.genomic_position_start,"\\|@\\|")[0],'-',cast(split(t4.genomic_position_start,"\\|@\\|")[0] as bigint)+length(t4.alt)) as PREFERRED_NAME,
case
      when t4.source='UKBB' then 'UKBB'
      when t4.source='FINNGEN' then 'FINNGEN'
      else null
end as PRIMARYSOURCE,
split(t4.joined_explicit_var_uids,'\\|@\\|')[0] as PRIMARYIDENTIFIER,
t4.chromosome,
split(t4.genomic_position_start,"\\|@\\|")[0] as GENOMIC_POSITION_START,
t4.GENOMIC_POSITION_END,
t4.ref as REFERENCE_ALLELE,
t4.alt as ALTERNATE_ALLELE,
split(t4.joined_explicit_var_uids,'\\|@\\|') as JOINED_EXPLICIT_VAR_UIDS,
t4.CHROMPOS_UID,
split(t4.rsids,'\\|@\\|') as RSIDS,
t4.CHROM_POS,
split(t4.cyto_location,'\\|@\\|') as CYTO_LOCATION,
t4.COMPUTED_CYTO_LOCATION,
coalesce(t5.concept_id,concat(t4.exp_rsid,'_','Variant')) as TELLIC_ID,
named_struct(
        "SOURCES",array("arch_normalized.genemap2_norm","arch_normalized.ukb_200k_exome_20200217_norm","arch_normalized.finngen_full_norm"),
        "FILTERS",array(""),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.1.0"
           ) as LINEAGE
from (
SELECT * from(
SELECT t1.*,t2.source from
academe.t_variants_lookup_v2_core_ukbb_finngen_omim_gwas_02202021 t1
LEFT OUTER JOIN
(
SELECT abbvie_variant_uid, 'OMIM' as source from arch_normalized.genemap2_norm where abbvie_variant_uid is not null
union
SELECT abbvie_variant_uid, 'UKBB' as source from arch_normalized.ukb_200k_exome_20200217_norm where abbvie_variant_uid is not null
union
SELECT abbvie_variant_uid, 'FINNGEN' as source from arch_normalized.finngen_full_norm where abbvie_variant_uid is not null
)t2
on t1.var_uid=t2.abbvie_variant_uid
where t2.abbvie_variant_uid is not null
)t3
lateral view outer explode(split(rsids,',|\\|@\\|')) expval as exp_rsid
)t4
LEFT OUTER JOIN
tellic_abbvie.tellic_graph_data_node_variant t5
on t4.exp_rsid = t5.entity_name
)var
group by LABEL,ID,PREFERRED_NAME,PRIMARYIDENTIFIER,chromosome,genomic_position_start,genomic_position_end,reference_allele,alternate_allele,joined_explicit_var_uids,chrompos_uid,rsids,chrom_pos,cyto_location,computed_cyto_location,LINEAGE
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
