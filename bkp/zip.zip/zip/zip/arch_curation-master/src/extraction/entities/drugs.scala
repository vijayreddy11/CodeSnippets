import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_drug_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
With drug_er_version as (
select  distinct concat(major,'.',minor) as  er_version ,'drug' as tmp_col
from academe.drug_concept_version_v
)
select distinct
LABEL,
ID,
MOLECULE_ID,
PREFERRED_NAME,
collect_set(CHEMBL_ID) as CHEMBL_ID,
MAX_PHASE,
concat_ws(',',collect_set(USAN_STEM_DEFINITION)) as USAN_STEM_DEFINITION,
ATC_CLASS,
collect_set(SYNONYMS) as SYNONYMS,
collect_set(NDCS) as NDCS,
PROPRIETARYNAME,
NUM_COMPONENTS,
COMPONENT_NAMES,
collect_set(moa) as MOA,
named_struct(
        "SOURCES",array(case when er_version is not null then concat("academe.drug_concept_v",' ',er_version) else "academe.drug_concept_v" end,"arch_normalized.r_moa_ids_norm","academe.drug_version_v"),
        "FILTERS","",
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.3.0"
) as LINEAGE
from (
        select distinct
                concat(':Drug') as LABEL,
                drugs.abbv_uid as ID,
                drugs.abbv_code as MOLECULE_ID,
                drugs.abbv_term as PREFERRED_NAME,
		drugs.chembl_id as CHEMBL_ID,
                cast(drugs.abbv_max_phase as integer) as MAX_PHASE,
                case
                when usan_stem_definition like '' then null
                else usan_stem_definition end as USAN_STEM_DEFINITION,
                --drugs.abbv_atc_class as ATC_CLASS,
		drugs.abbv_atc_term as ATC_CLASS,
                --split(regexp_replace(regexp_extract(get_json_object(abbv_details,'$.syns'),'^\\["(.*)"]$',1),'","','\\|'),'\\|') as SYNONYMS,
		trim(syn) as SYNONYMS,
                drugs.ndcs as NDCS,
                drugs.abbv_trade_names as PROPRIETARYNAME,
                cast(drugs.abbv_num_comp as int) as NUM_COMPONENTS,
                drugs.abbv_comp_names as COMPONENT_NAMES,
                moa.ensembl_hgnc_symbol as MOA,
                ver.ER_VERSION
        FROM
        (
        select *,'drug' as tmp_col from (
        select *,
	regexp_extract(get_json_object(chem, '$.chembl_id'),'^\\["(.*)"]$',1) as chembl_id,
        get_json_object(chem, '$.usan_stem_definition') as usan_stem_definition,
        regexp_replace(regexp_extract(get_json_object(ndc, '$.ndcs9'),'^\\["(.*)"]$',1),'"','') as ndcs9
        FROM (
		select *,ncit_syns as syns
		FROM academe.drug_concept_v 
		union
		select *,ndc_syns as syns
		FROM academe.drug_concept_v 
		union
		select *,abbvdrug_syns as syns
		FROM academe.drug_concept_v
		union
		select *,cortellis_syns as syns
		FROM academe.drug_concept_v 
		union
		select *,chembl_syns as syns
		FROM academe.drug_concept_v  
		)X
	LATERAL VIEW OUTER explode(chembl_details) lvxnd AS chem
	LATERAL VIEW OUTER explode(ndc_details) lvxnd AS ndc
	LATERAL VIEW OUTER explode(split(syns,'[\|]')) lvxnd AS syn
	--where abbv_uid = '000d1b2db7d8d9864cfed20fe641706f'
        )n LATERAL VIEW OUTER explode(split(ndcs9,',')) lvxnd AS ndcs
        ) drugs
        LEFT JOIN
        arch_normalized.r_moa_ids_norm moa
        ON drugs.abbv_uid=moa.abbv_drug_uid
        LEFT JOIN
        drug_er_version ver
        ON drugs.tmp_col = ver.tmp_col
        ) d
group by LABEL,ID,MOLECULE_ID,PREFERRED_NAME,MAX_PHASE,ATC_CLASS,PROPRIETARYNAME,NUM_COMPONENTS,COMPONENT_NAMES,ER_VERSION
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
