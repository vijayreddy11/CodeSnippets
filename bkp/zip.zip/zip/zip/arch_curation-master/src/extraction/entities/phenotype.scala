import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren


val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_phenotype_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
select 
":Phenotype" as LABEL,
t1.abbv_uid AS ID,
t1.abbv_term as PREFERRED_NAME,
t1.abbv_term_source as PRIMARYSOURCE,
t1.abbv_code as PRIMARYIDENTIFIER,
t1.EFO_TERM,
t1.EFO_CODE,
t1.ICD10_TERM,
t1.ICD10_CODE,
t1.ICD9_TERM,
t1.ICD9_CODE,
t1.ICD9_SYNS,
t1.TELLIC_TERM,
t1.TELLIC_CODE, 
coalesce(t1.tellic_code,concat(t1.abbv_term,'_','Phenotype')) as TELLIC_ID, 
named_struct(
        "SOURCES",array("arch_normalized.genemap2_norm","arch_normalized.ukb_200k_exome_20200217_norm","arch_normalized.finngen_full_norm","academe.health_condition_v"),
        "FILTERS",array(""),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.2.0"
           ) as LINEAGE 
from
(select * from academe.health_condition_v where abbv_uid is not null and  abbv_uid not like '%|%') t1
left outer join
(
select abbvie_phenotype_uid from arch_normalized.genemap2_norm where abbvie_phenotype_uid is not null
union
select abbvie_phenotype_uid from arch_normalized.ukb_200k_exome_20200217_norm where abbvie_phenotype_uid is not null
union
select abbvie_phenotype_uid from arch_normalized.finngen_full_norm where abbvie_phenotype_uid is not null
)t2
on t1.abbv_uid=t2.abbvie_phenotype_uid
where t2.abbvie_phenotype_uid is not null
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
