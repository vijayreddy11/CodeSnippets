import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_pkpairing_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
with pkpairing as (
SELECT 
concat(entity1, '|', entity2) as ID,
":PKPairing" as LABEL,
"InVivoPK" as PRIMARYSOURCE,
concat(entity1, '|', entity2) as PRIMARYIDENTIFIER,
concat(entity1, '|', entity2) as PREFERRED_NAME,
array(SOURCE) as SOURCES,
array(concat(entity1, '|', entity2)) as IDENTIFIERS,
named_struct(
		"SOURCES",array("arch_normalized.pk_combined_view_norm"),
		"FILTERS","",
		"TIMESTAMP",unix_timestamp(),
		"VERSION","1.2.0"
	) as LINEAGE
from arch_normalized.pk_combined_view_norm
)
SELECT 
LABEL,
ID,
PRIMARYSOURCE,
PRIMARYIDENTIFIER,
PREFERRED_NAME, 
SOURCES,
IDENTIFIERS,
LINEAGE 
from (SELECT *,ROW_NUMBER() OVER(PARTITION BY ID ORDER BY ID) AS ROWNUM
from pkpairing) x
where ROWNUM=1
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
