import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_pathway_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT 
    ':Pathway' as LABEL,
    t.abbv_uid as ID,
    t.abbv_term as PREFERRED_NAME,
    t.abbv_term_source as PRIMARYSOURCE,
    t.abbv_code as PRIMARYIDENTIFIER,
    named_struct(
    "SOURCES",array("academe.pathways_er_v2_17dec2021","arch_normalized.ingenuity_pathwaynodes_norm"),
    "FILTERS","",
    "TIMESTAMP",unix_timestamp(),
    "VERSION","1.5.0") as LINEAGE,
    named_struct(
    "IPA_CODE",t.IPA_CODE,
    "IPA_TERM",t.IPA_TERM,
    "IPA_CLASS",split(t.IPA_CLASSIFICATION,"|")
    ) as METADATA
from academe.pathways_er_v2_17dec2021 t
LEFT OUTER JOIN 
arch_normalized.ingenuity_pathwaynodes_norm norm
on t.abbv_uid = norm.pathway_uid
where norm.pathway_uid is not null
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
