import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
select  distinct
  ':Compound' as LABEL,
  compound_uid as ID,
  chembl_id AS CHEMBL_ID,
  case
    when ABBVIE_ID like 'A-%' then ABBVIE_ID
    when ABBVIE_ID like 'PR-%' then ABBVIE_ID
    when ABBVIE_ID like 'DC-%' then ABBVIE_ID
  else NULL
  end as ABBVIE_ID,
  c.inchi_key AS INCHI_KEY,
  root_inchi_key AS ROOT_INCHI_KEY,
  molecule_type AS MOLECULE_TYPE,
  case 
    when array_contains(c.other_sources,'ABBVIE') = 1 then 'AbbVie'
    when array_contains(c.other_sources,'CHEMBL') = 1 then 'ChEMBL'
    when array_contains(c.other_sources,'GOSTAR') = 1 then 'GOSTAR'
    when array_contains(c.other_sources,'WOMBAT') = 1 then 'Wombat'
    when array_contains(c.other_sources,'SOLVAY') = 1 then 'Solvay'
    when array_contains(c.other_sources,'INTEGRITY') = 1 then 'Integrity'
    when array_contains(c.other_sources,'DRUGMATRIX') = 1 then 'DrugMatrix'
    else c.other_sources[0]
  end as PRIMARYSOURCE,
  case 
    when array_contains(c.other_sources,'ABBVIE') = 1 then c.identifier_map["ABBVIE"][0]
    when array_contains(c.other_sources,'CHEMBL') = 1 then c.identifier_map["CHEMBL"][0]
    when array_contains(c.other_sources,'GOSTAR') = 1 then c.identifier_map["GOSTAR"][0]
    when array_contains(c.other_sources,'WOMBAT') = 1 then c.identifier_map["WOMBAT"][0]
    when array_contains(c.other_sources,'SOLVAY') = 1 then c.identifier_map["SOLVAY"][0]
    when array_contains(c.other_sources,'INTEGRITY') = 1 then c.identifier_map["INTEGRITY"][0]
    when array_contains(c.other_sources,'DRUGMATRIX') = 1 then c.identifier_map["DRUGMATRIX"][0]
    else c.other_identifiers[0]
  end as PRIMARYIDENTIFIER,
  case 
    when array_contains(c.other_sources,'ABBVIE') = 1 then c.identifier_map["ABBVIE"][0]
    when array_contains(c.other_sources,'CHEMBL') = 1 then c.identifier_map["CHEMBL"][0]
    when array_contains(c.other_sources,'GOSTAR') = 1 then c.identifier_map["INCHI_KEY"][0]
    when array_contains(c.other_sources,'WOMBAT') = 1 then c.identifier_map["INCHI_KEY"][0]
    when array_contains(c.other_sources,'SOLVAY') = 1 then c.identifier_map["INCHI_KEY"][0]
    when array_contains(c.other_sources,'INTEGRITY') = 1 then c.identifier_map["INCHI_KEY"][0]
    when array_contains(c.other_sources,'DRUGMATRIX') = 1 then c.identifier_map["INCHI_KEY"][0]
    else c.inchi_key
  end as PREFERRED_NAME,
  other_sources as SOURCES,
  other_identifiers as IDENTIFIERS,
  named_struct(
      "SOURCES",array("academe.compounds_v"),
      "FILTERS","",
      "TIMESTAMP",unix_timestamp(),
      "VERSION","1.3.0"
  ) as LINEAGE,  
  chem.concept_id as TELLIC_ID,
  c.batch as BATCH
from 
academe.compounds_v c
left outer join tellic_abbvie.tellic_graph_data_node_chem_subset chem  
on c.inchi_key=chem.inchi_key
""").batch

res.repartition(1).write.mode("OVERWRITE").option("format","parquet").partitionBy("BATCH").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
