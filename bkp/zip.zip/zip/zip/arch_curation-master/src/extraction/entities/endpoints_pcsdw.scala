import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_endpoint_pcsdw_entities"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""with pcsdw_endpoint as (
SELECT DISTINCT CONCAT(':Endpoint:',t1.MEASUREMENT_AREA) as LABEL,
CONCAT(t1.MEASUREMENT_AREA,', ',t1.MEASUREMENT_NAME) as ID,
t1.MEASUREMENT_NAME as PREFERRED_NAME,
t1.MEASUREMENT_AREA,
t1.MEASUREMENT_NAME,
CAST(null as string) as ASSAY,
CAST(null as string) as EFFICACY_DESCRIPTION,
'PCSDW' as PRIMARYSOURCE,
CONCAT(t1.MEASUREMENT_AREA,', ',t1.MEASUREMENT_NAME) as PRIMARYIDENTIFIER,
--null as MEASUREMENT_TIME,
--null as MEASUREMENT_TIME_UNITS,
--t1.ISVISIBLE,
--t1.ABBREVIATION,
--t1.MEASUREMENT_UNIT,
--t1.MEASUREMENT_TYPE,
--cast(t1.MEASUREMENT_ID as integer) as MEASUREMENT_ID,
named_struct(
"SOURCES",array("ddmlcnp1_pcsdw.measurement"),
"FILTERS","",
"TIMESTAMP",unix_timestamp(),
"VERSION","1.2.0") as LINEAGE
FROM ddmlcnp1_pcsdw.measurement t1
WHERE t1.MEASUREMENT_AREA IN ('Chemistry Measurement','Hematology Measurement','Urinalysis Measurement','Organ Weights','Body Weights','Food Consumption') 
and t1.ISVISIBLE='Y'
union
SELECT DISTINCT CONCAT(':Endpoint:','No Effect') as LABEL,
'No Significant Effects' as  ID,
'No Significant Effects' as PREFERRED_NAME,
'No Effect' as MEASUREMENT_AREA,
'No Significant Effects' as MEASUREMENT_NAME,
CAST(null as string) as ASSAY,
CAST(null as string) as EFFICACY_DESCRIPTION,
'PCSDW' as PRIMARYSOURCE,
'No Effect, No Significant Effects' as PRIMARYIDENTIFIER,
named_struct(
"SOURCES",array("ddmlcnp1_pcsdw.measurement"),
"FILTERS","",
"TIMESTAMP",unix_timestamp(),
"VERSION","1.2.0") as LINEAGE
)
select * from pcsdw_endpoint""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
