import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)


val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_endpoint_medmsd_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
with pcsdw_medmsd as(
    select * from dependency.v_pcsdw_medmsd
    union
    select * from dependency.v_pcsdw_noeffect_relationships
)
select distinct
	medmsd.ENTITY1,
	regexp_replace(medmsd.ENTITY1_TYPE,':','') as ENTITY1_TYPE,
	medmsd.ENTITY2, 
	regexp_replace(medmsd.ENTITY2_TYPE,':Endpoint:','') as ENTITY2_TYPE,
	medmsd.REL_TYPE, 
	medmsd.STRENGTH, 
	medmsd.RESULT, 
	medmsd.RESULT_TYPE, 
	medmsd.CONFIDENCE,
	medmsd.LINEAGE,
	named_struct(
		"ENTITY1_PROP",named_struct("INCHI_KEY",compound.INCHI_KEY,"ANUMBER",compound.ABBVIE_ID),
		"ENTITY2_PROP",named_struct("MEAS_AREA",endpoint.MEASUREMENT_AREA),
		"REL_PROP",medmsd.METADATA
	) as METADATA
from pcsdw_medmsd medmsd
left outer join ark.t_compound_entities compound
on medmsd.entity1=compound.id
left outer join
ark.t_endpoint_pcsdw_entities endpoint
on medmsd.entity2=endpoint.id
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
