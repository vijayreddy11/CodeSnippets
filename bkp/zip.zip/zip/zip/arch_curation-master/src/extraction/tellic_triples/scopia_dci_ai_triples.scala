import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_scopia_dci_ai_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    ai_drugs.IDENTIFIER as ENTITY1,
    "Drug" as ENTITY1_TYPE,
    CONCAT(ai_drugs.IDENTIFIER,'|@|',dci.CLIN_INTERACTION) as ENTITY2,
    "DCI" as ENTITY2_TYPE,
    "Is A Member Of" as REL_TYPE,
    1 as STRENGTH,
    1 as RESULT,
    "Membership" as RESULT_TYPE,
    1.0 as CONFIDENCE,
    named_struct(
        "RULESETS",array(),
        "SOURCES",array("preclinical.t_scopiarx_ci_main_03062021","preclinical.r_scopia_chembl_ids"),
        "FILTERS",array(),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.0"
    ) as LINEAGE,
    named_struct(
	"ENTITY1_PROP",named_struct("ACTIVE_INGREDIENT",dci.AI,"ID",drug_entities.ID,"MOA",drug_entities.MOA),
	"ENTITY2_PROP",named_struct("DCI",dci_entities.dci,
	"ACTIVE_INGREDIENT",dci.AI,
	"CLINICAL_INTERACTION",dci.CLIN_INTERACTION),
	"REL_PROP",named_struct(
        "DISPLAY_STRING",dci.DISPLAY_STRING,
        "SOURCE","Scopia")
    ) as METADATA
FROM preclinical.t_scopiarx_ci_main_03062021 dci
LEFT JOIN 
preclinical.r_scopia_chembl_ids ai_drugs 
on dci.AI=ai_drugs.SCOPIA_NAME
LEFT JOIN 
(
select distinct id,concat_ws('|',collect_set(dci)) AS dci
from 
(select * from ark.t_dci_entities order by dci desc)y group by id
) dci_entities 
on CONCAT(ai_drugs.IDENTIFIER,'|@|',dci.CLIN_INTERACTION) = dci_entities.id
LEFT JOIN 
ark.t_drug_entities drug_entities 
on ai_drugs.IDENTIFIER = drug_entities.id
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
