import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_fdb_compound_compound_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
select 
t1.entity1 as entity1
,regexp_replace(t1.entity1_type,':','') as entity1_type
,t1.entity2 as entity2
,regexp_replace(t1.entity2_type,':','') as entity2_type
,t1.rel_type
,t1.strength
,t1.result
,t1.result_type
,t1.confidence
,t1.lineage
,named_struct(
		  "ENTITY1_PROP",named_struct("INCHI_KEY",comps.INCHI_KEY),
          "ENTITY2_PROP",named_struct("INCHI_KEY",comps2.INCHI_KEY),
          "REL_PROP",t1.metadata
      ) as METADATA
,t1.tilesrc 
from
(select distinct a.*
from ark.t_compound_compound_relationships a
left join 
ark.t_drug_compound_relationships b
on a.entity1 = b.entity2
left join 
ark.t_drug_compound_relationships c
on a.entity2 = c.entity2
WHERE b.entity2 is not null OR c.entity2 is not null) t1
LEFT JOIN ark.t_compound_entities comps ON
    t1.ENTITY1 = comps.INCHI_KEY
LEFT JOIN ark.t_compound_entities comps2 
ON t1.ENTITY2 = comps2.INCHI_KEY
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
