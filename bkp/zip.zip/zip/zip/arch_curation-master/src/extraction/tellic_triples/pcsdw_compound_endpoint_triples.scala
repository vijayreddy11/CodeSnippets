import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_pcsdw_compound_endpoint_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
with pcsdw_rel as(SELECT 
  ENTITY1,
  ENTITY1_TYPE,
  ENTITY2,
  ENTITY2_TYPE,
  REL_TYPE,
  CONFIDENCE,
  STRENGTH,
  RESULT,
  RESULT_TYPE,
  LINEAGE,
  named_struct(
    "STUDY_ID",pcs.metadata.STUDY_ID,
    "STUDY",pcs.metadata.STUDY,
    "DURATION_DAYS",pcs.metadata.DURATION_DAYS,
    "STUDY_GROUP_ID",pcs.metadata.STUDY_GROUP_ID,
    "DAY_OF_PHASE",pcs.metadata.DAY_OF_PHASE,
    "PHASE",pcs.metadata.PHASE,
    "VEHICLE",pcs.metadata.VEHICLE,
    "SEX",pcs.metadata.SEX,
    "DOSE_GROUP",pcs.metadata.DOSE_GROUP,
    "CONDITION",pcs.metadata.CONDITION,
    "SPECIES",pcs.metadata.SPECIES,
    "DOSE",pcs.metadata.DOSE,
    "ROUTE",pcs.metadata.ROUTE,
    "UNITS",pcs.metadata.UNITS,
    "CHANGE",pcs.metadata.CHANGE,
    "FOLD_OVER_THRESHOLD",pcs.metadata.FOLD_OVER_THRESHOLD,
    "LINK",pcs.metadata.LINK,
    "MEDDRA_ID", ep.meddra_id,
    "MEDDRA_NAME", ep.meddra_name,
    "SOURCE","PCSDW"
  ) as METADATA
FROM dependency.v_pcsdw_result pcs
left outer join dependency.pcs_meddra_endpoints ep on  
 lower(pcs.rel_type) = lower(ep.effect) and
 pcs.entity2 = concat(ep.endpoint_type,', ', ep.endpoint)
 and ep.destination = 'PCS')
 
SELECT distinct  ENTITY1,
regexp_replace(pcsdw.ENTITY1_TYPE,':','') as ENTITY1_TYPE,
pcsdw.ENTITY2,
regexp_replace(pcsdw.ENTITY2_TYPE,':Endpoint:','') as ENTITY2_TYPE,
pcsdw.REL_TYPE,
pcsdw.CONFIDENCE,
pcsdw.STRENGTH,
pcsdw.RESULT,
pcsdw.RESULT_TYPE,
pcsdw.LINEAGE,
named_struct(
	"ENTITY1_PROP",named_struct("INCHI_KEY",compound.INCHI_KEY,"ANUMBER",compound.ABBVIE_ID),
    "ENTITY2_PROP",named_struct("MEAS_AREA",endpoint.MEASUREMENT_AREA),
    "REL_PROP",pcsdw.METADATA
  ) as METADATA
FROM pcsdw_rel pcsdw
left outer join ark.t_compound_entities compound
on pcsdw.entity1=compound.id
left outer join
ark.t_endpoint_pcsdw_entities endpoint
on pcsdw.entity2=endpoint.id
 """).batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
