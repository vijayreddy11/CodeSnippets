import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_scopia_drug_ci_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""

SELECT DISTINCT
    ai_drugs.IDENTIFIER as ENTITY1,
    "Drug" as ENTITY1_TYPE,
    dci.CLIN_INTERACTION as ENTITY2,
    "Clinical Condition" as ENTITY2_TYPE,
    CASE
        WHEN dci.DISPLAY_STRING LIKE '%increases%' THEN "Increases The Effect Of"
        WHEN dci.DISPLAY_STRING LIKE '%decreases%' THEN "Decreases The Effect Of"
        WHEN dci.DISPLAY_STRING LIKE '%interaction%' THEN "Has An Interaction With"
        ELSE NULL
    END as REL_TYPE,
    case
      WHEN dci.MAGNITUDE="Contra-Indicated" THEN 4
      WHEN dci.MAGNITUDE="Severe" THEN 3
      WHEN dci.MAGNITUDE="Moderate" THEN 2
    ELSE 1 END AS STRENGTH,
    dci.SCORE as RESULT,
    "ScopiaRX Score" as RESULT_TYPE,
    1.0 as CONFIDENCE,
    named_struct(
        "RULESETS",array("SCOPIA_DRUG_CLINICALCONDITION_STRENGTH","SCOPIA_DRUG_CLINICALCONDITION_REL_TYPE"),
        "SOURCES",array("preclinical.t_scopiarx_ci_main_03062021","preclinical.r_scopia_chembl_ids"),
        "FILTERS",array(),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.0"
    ) as LINEAGE,
    named_struct(
        
        "ENTITY1_PROP",named_struct("DRUG",dci.AI,"ID",drug.ID,"MOA",drug.MOA),
        "ENTITY2_PROP",named_struct("CLIN_INTERACTION",clinicalcondition.CLIN_INTERACTION),
	    "REL_PROP",named_struct("DISPLAY_STRING",dci.DISPLAY_STRING,
        "SEVERITY",dci.SEVERITY,
        "MAGNITUDE",dci.MAGNITUDE,
        "SOURCE","Scopia")
    ) as METADATA
FROM (
    SELECT AI,CLIN_INTERACTION,DISPLAY_STRING,SCORE,
    case
      WHEN instr(display_string,"(bw)")>0 THEN "Box Warning"
      WHEN instr(display_string,"(w)")>0 THEN "Warning"
      WHEN instr(display_string,"(contra)")>0 THEN "Contra-Indicated"
      WHEN instr(display_string,"(ca)")>0 THEN "Caution"
      WHEN instr(display_string,"(ns)")>0 THEN "Not Specified"
    ELSE "Not Specified" END AS SEVERITY,
    case
      WHEN instr(display_string,"(contra)")>0 THEN "Contra-Indicated"
      WHEN instr(display_string,"(ns)")>0 THEN "Not Specified"
      WHEN instr(display_string,"(min)")>0 THEN "Minor"
      WHEN instr(display_string,"(mod)")>0 THEN "Moderate"
      WHEN instr(display_string,"(sev)")>0 THEN "Severe"
    ELSE "Not Specified" END AS MAGNITUDE
    FROM preclinical.t_scopiarx_ci_main_03062021
) dci
LEFT JOIN preclinical.r_scopia_chembl_ids ai_drugs on dci.AI=ai_drugs.SCOPIA_NAME
LEFT JOIN ark.t_drug_entities drug  on  ai_drugs.IDENTIFIER= drug.id
LEFT JOIN (select distinct id,concat_ws('|',collect_set(CLIN_INTERACTION)) AS CLIN_INTERACTION
from (select * from ark.t_clinicalcondition_entities  order by CLIN_INTERACTION desc)y group by id) clinicalcondition 
on dci.CLIN_INTERACTION =clinicalcondition.id
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
