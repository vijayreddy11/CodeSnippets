import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_ukbb_variant_health_condition_triples"
val almaren = Almaren(set_name)

val res=almaren.builder.sourceSql("""
select distinct
ENTITY1,
ENTITY1_TYPE,
ENTITY1_CONCEPT_ID,
ENTITY2,
ENTITY2_TYPE,
regexp_replace(ENTITY2_CONCEPT_ID,'_Phenotype','_HealthCondition') as ENTITY2_CONCEPT_ID,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
LINEAGE,
METADATA
from (
select distinct
    case 
			when size(var.RSIDS)>1 then var.joined_explicit_var_uids[0]
			else concat_ws('|',var.RSIDS)
		END as ENTITY1,
		vp_rel.ENTITY1_TYPE,
		case
			when size(var.TELLIC_ID)>1 then var.ID
			else concat_ws('|',var.TELLIC_ID) 
		END as ENTITY1_CONCEPT_ID,
    phen.PREFERRED_NAME as ENTITY2,
    'Health Condition' as ENTITY2_TYPE,
    regexp_replace(phen.tellic_id,':','') as entity2_concept_id,
    vp_rel.REL_TYPE,
    vp_rel.STRENGTH,
    vp_rel.RESULT,
    vp_rel.RESULT_TYPE,
    vp_rel.CONFIDENCE,
    vp_rel.LINEAGE,
    vp_rel.METADATA
    from
    (select * from
        ark.t_variant_phenotype_relationships
        where metadata.source = 'UKBB') vp_rel
        left outer join
        ark.t_variant_entities var
        on vp_rel.entity1 = var.id
        left outer join
        ark.t_phenotype_entities phen
        on vp_rel.entity2 = phen.id
        where size(var.tellic_id)<>0
        )rel
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
