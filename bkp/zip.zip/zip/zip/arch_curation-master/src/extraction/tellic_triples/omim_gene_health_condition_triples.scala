import com.github.music.of.the.ainur.almaren.Almaren;
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit;

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_omim_gene_health_condition_triples"
val almaren = Almaren(set_name)

val df = almaren.builder.sourceSql("""
select distinct
ENTITY1,
ENTITY1_TYPE,
regexp_replace(ENTITY1_CONCEPT_ID,'_Phenotype','_HealthCondition') as ENTITY1_CONCEPT_ID,
ENTITY2,
ENTITY2_TYPE,
ENTITY2_CONCEPT_ID,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
LINEAGE,
METADATA
from (
select distinct
    phen.PREFERRED_NAME as ENTITY1,
    'Health Condition' as ENTITY1_TYPE,
    regexp_replace(phen.tellic_id,':','') as entity1_concept_id,
    gene.primaryidentifier as ENTITY2,
    gp_rel.ENTITY2_TYPE,
    gene.tellic_id as tellic2_id,
    gp_rel.REL_TYPE,
    gp_rel.STRENGTH,
    gp_rel.RESULT,
    gp_rel.RESULT_TYPE,
    gp_rel.CONFIDENCE,
    gp_rel.LINEAGE,
    gp_rel.METADATA
    from
	ark.t_gene_phenotype_relationships gp_rel
	left outer join
	ark.t_phenotype_entities phen
	on gp_rel.entity1 = phen.id
	left outer join
	ark.t_gene_entities gene
	on gp_rel.entity2 = gene.id
)rel
LATERAL VIEW explode(tellic2_id) expval AS entity2_concept_id
""").batch
df.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
