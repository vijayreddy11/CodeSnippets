import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_scopia_ddi_dps_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    ddi.IDENTIFIER as ENTITY1,
    "Drug" as ENTITY1_TYPE,
    ddi.DDI as ENTITY2,
    "DDI" as ENTITY2_TYPE,
    "Is A Member Of" as REL_TYPE,
    1 as STRENGTH,
    1 as RESULT,
    "Membership" as RESULT_TYPE,
    1.0 as CONFIDENCE,
    named_struct(
        "RULESETS",array(),
        "SOURCES",array("preclinical.t_scopiarx_di_main_03062021","preclinical.r_scopia_chembl_ids"),
        "FILTERS",array(),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.0"
    ) as LINEAGE,
    named_struct(
	"ENTITY1_PROP",named_struct("ACTIVE_INGREDIENT",ddi.AI_DPS,"ID",drug_entities.ID,"MOA",drug_entities.MOA),
	"ENTITY2_PROP",named_struct("DDI",ddi_entities.ddi),
	"REL_PROP",named_struct(
        "DISPLAY_STRING",ddi.DISPLAY_STRING,
        "SOURCE","Scopia")
    ) as METADATA
FROM (
    SELECT DISTINCT
        dps_drugs.IDENTIFIER,
        CONCAT(dps_drugs.IDENTIFIER,'|@|',di_drugs.IDENTIFIER) as DDI,
        dps_ddi.DISPLAY_STRING as DISPLAY_STRING,
		dps_ddi.AI_DPS as AI_DPS
    FROM preclinical.t_scopiarx_di_main_03062021 dps_ddi
        LEFT JOIN preclinical.r_scopia_chembl_ids di_drugs on dps_ddi.AI_DI=di_drugs.SCOPIA_NAME
        LEFT JOIN preclinical.r_scopia_chembl_ids dps_drugs on dps_ddi.AI_DPS=dps_drugs.SCOPIA_NAME
    WHERE di_drugs.NUM_COMPONENTS=1 and dps_drugs.NUM_COMPONENTS=1 and di_drugs.IDENTIFIER IS NOT NULL and dps_drugs.IDENTIFIER IS NOT NULL
    ) ddi
	LEFT JOIN 
(
select distinct id,concat_ws('|',collect_set(ddi)) AS ddi
from 
(select * from ark.t_ddi_entities order by ddi desc)y group by id
) ddi_entities 
on ddi.DDI = ddi_entities.id
LEFT JOIN 
ark.t_drug_entities drug_entities 
on ddi.IDENTIFIER = drug_entities.id
WHERE ddi.DDI is not null
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
