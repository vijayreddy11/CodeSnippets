import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_cpdb_gene_gene_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    t1.SOURCE as ENTITY1,
    "Gene" as ENTITY1_TYPE,
    t1.TARGET as ENTITY2,
    "Gene" as ENTITY2_TYPE,
    "Shares Pathway With" as REL_TYPE,
    1 as STRENGTH,
    t1.CONFIDENCE as RESULT,
    "Confidence" as RESULT_TYPE,
    t1.CONFIDENCE as CONFIDENCE,
    named_struct(
        "RULESETS",array("CPDB_GENE_GENE_STRENGTH"),
        "SOURCES",array("maprunp1_edges.consensuspathdb"),
        "FILTERS",array(),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.0"
    ) as LINEAGE,
    named_struct(
		"ENTITY1_PROP",named_struct("HGNC",gene.HGNC),
        "ENTITY2_PROP",named_struct("HGNC",gene2.HGNC),
        "REL_PROP",named_struct(
            "PMIDS",SPLIT(t1.PMIDS,';'),
            "SOURCE",t1.DATA_SOURCE
			)
    ) as METADATA
FROM maprunp1_edges.consensuspathdb t1
LEFT OUTER JOIN
ark.t_gene_entities gene
on t1.SOURCE=gene.ID
LEFT OUTER JOIN
ark.t_gene_entities gene2
on t1.TARGET=gene2.ID
WHERE t1.SOURCE<>t1.TARGET
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)

