import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.SparkSession

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_variant_variant_triples"

var res = spark.sql("""		
		with variant_variant as(
		SELECT distinct
			case 
				when size(a.RSIDS)>1 then a.joined_explicit_var_uids[0]
				else concat_ws('|',a.RSIDS)
			END as ENTITY1,
			a.LABEL as ENTITY1_TYPE,
			case
				when size(a.TELLIC_ID)>1 then a.ID
				else concat_ws('|',a.TELLIC_ID) 
			END as ENTITY1_CONCEPT_ID,
			case 
				when size(b.RSIDS)>1 then b.joined_explicit_var_uids[0]
				else concat_ws('|',b.RSIDS)
			END as ENTITY2,
			b.LABEL as ENTITY2_TYPE,
			case
				when size(b.TELLIC_ID)>1 then b.ID
				else concat_ws('|',b.TELLIC_ID) 
			END as ENTITY2_CONCEPT_ID,
			"IS_EQUIVALENT_TO" as REL_TYPE,
			1 as STRENGTH,
			cast(null as int) as RESULT,
			cast(null as string) as RESULT_TYPE,
			1 as CONFIDENCE,
			named_struct(
					"RULESETS",array(""),
					"SOURCES",array("ark.t_variant_entities_uc84"),
					"FILTERS",array(""),
					"TIMESTAMP",unix_timestamp(),
					"VERSION","1.1.0"
					   ) as LINEAGE
			FROM ark.t_variant_entities a
			JOIN ark.t_variant_entities b
			ON a.chromosome = b.chromosome
			AND a.chrom_pos = b.chrom_pos
			AND a.reference_allele = b.alternate_allele
			AND b.reference_allele = a.alternate_allele
			where size(a.tellic_id)<>0 and size(b.tellic_id)<>0
		)
		,variant_variant_partition as(
		select *,
		ROW_NUMBER() OVER(PARTITION BY v1.temp_uid ORDER BY v1.ENTITY1_CONCEPT_ID) AS ROWNUM 
		from(
		select 
		*,
		case 
		when t.entity1_concept_id < t.entity2_concept_id then concat(t.entity1_concept_id,'_',t.entity2_concept_id)
		else concat(t.entity2_concept_id,'_',t.entity1_concept_id) end as temp_uid
		from variant_variant t
		)v1
		)
		select distinct
		ENTITY1,
		ENTITY1_TYPE,
		ENTITY1_CONCEPT_ID,
		ENTITY2,
		ENTITY2_TYPE,
		ENTITY2_CONCEPT_ID,
		REL_TYPE,
		STRENGTH,
		RESULT,
		RESULT_TYPE,
		CONFIDENCE,
		LINEAGE
		from variant_variant_partition vvp
		where ROWNUM=1
	""")
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
