import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)


val data_store = "integrated"
val db_name = "ark"
val set_name = "t_drug_gene_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    t1.PARENT_ID as ENTITY1,
    'Drug' as ENTITY1_TYPE,
    t1.TARGET as ENTITY2,
    'Gene' as ENTITY2_TYPE,
    'Has MOA' as REL_TYPE,
    4 as STRENGTH,
    1 as RESULT,
    'Activity' as RESULT_TYPE,
    1.0 as CONFIDENCE,
    named_struct(
        "RULESETS",array(""),
        "SOURCES",array("preclinical.r_pikm_moa_chembl_ids"),
        "FILTERS",array(""),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.0"
    ) as LINEAGE,
    named_struct(
		"ENTITY1_PROP",named_struct("ID",drug.ID,"MOA",drug.MOA),
        "ENTITY2_PROP",named_struct("HGNC",gene.HGNC),
        "REL_PROP",named_struct(
      "MODALITY","Activity",
      "SOURCE","PIKM MOA")
    ) as METADATA
FROM preclinical.r_pikm_moa_chembl_ids t1
LEFT JOIN ark.t_drug_entities drug 
on t1.PARENT_ID=drug.id
LEFT OUTER JOIN
ark.t_gene_entities gene
on t1.TARGET=gene.ID
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
