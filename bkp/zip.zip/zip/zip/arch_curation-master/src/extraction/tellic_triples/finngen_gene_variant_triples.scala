import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_finngen_gene_variant_triples"
val almaren = Almaren(set_name)

val res=almaren.builder.sourceSql("""
select distinct
ENTITY1,
ENTITY1_TYPE,
ENTITY1_CONCEPT_ID,
ENTITY2,
ENTITY2_TYPE,
ENTITY2_CONCEPT_ID,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
LINEAGE,
METADATA
from (
select distinct
    case 
	when size(var.RSIDS)>1 then var.joined_explicit_var_uids[0]
	else concat_ws('|',var.RSIDS)
    END as ENTITY1,
    gv_rel.ENTITY1_TYPE,
    case
	when size(var.TELLIC_ID)>1 then var.ID
	else concat_ws('|',var.TELLIC_ID) 
    END as ENTITY1_CONCEPT_ID,
    gene.PRIMARYIDENTIFIER as ENTITY2,
    gv_rel.ENTITY2_TYPE,
    gene.tellic_id as tellic2_id,
    gv_rel.REL_TYPE,
    gv_rel.STRENGTH,
    gv_rel.RESULT,
    gv_rel.RESULT_TYPE,
    gv_rel.CONFIDENCE,
    gv_rel.lineage,
    gv_rel.METADATA
    from
    (select * from 
	ark.t_gene_variant_relationships where metadata.source = 'FINNGEN'
    ) gv_rel
    left outer join 
    (select * from ark.t_variant_entities) var
    on gv_rel.entity1 = var.id 
    left outer join
    ark.t_gene_entities gene
    on gv_rel.entity2 = gene.id
    where size(var.tellic_id)<>0
)rel
LATERAL VIEW explode(tellic2_id) expval AS entity2_concept_id
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
