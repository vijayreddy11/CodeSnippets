import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_fdb_drug_compound_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
select DISTINCT
    rels.ENTITY1 as ENTITY1,
    "Drug" as ENTITY1_TYPE,
    rels.ENTITY2 as ENTITY2,
    "Compound" as ENTITY2_TYPE,
    "Contains" as REL_TYPE,
    1 as STRENGTH,
    1 as CONFIDENCE,
    1 as RESULT,
    "Membership" as RESULT_TYPE,
    named_struct(
        "RULESETS",array(),
        "SOURCES",array("preclinical.r_drug_metadata","aidxunp1_abv_federated_data.fd_structure_source"),
        "FILTERS",array(),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.0"
    ) as LINEAGE,
    named_struct(
    "ENTITY1_PROP",named_struct("ID",t1.ID,"NAME",t1.NAME,"NDC",sort_array(t1.NDCS),"NUM_COMP",t1.NUM_COMP,"FDB",t1.NAME,"MOA",t1.MOA),
	"ENTITY2_PROP",named_struct("INCHI_KEY",t2.INCHI_KEY,"SOURCES",rels.SOURCES,"IDENTIFIERS",t2.IDENTIFIERS),
	"REL_PROP",named_struct("SOURCE",rels.sources)
    ) as METADATA
from (
    select distinct
        drugs.id as ENTITY1,
        comps.id as ENTITY2,
        collect_set(comps.primarysource) as sources
    from ark.t_drug_entities drugs
    inner join ark.t_compound_entities comps ON 
      drugs.id = comps.chembl_id
    where comps.chembl_id is not null
    group by drugs.id,comps.id
) rels
LEFT JOIN ark.t_drug_entities t1 
on rels.ENTITY1=t1.id
left join ark.t_compound_entities t2
on rels.ENTITY2=t2.id
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
