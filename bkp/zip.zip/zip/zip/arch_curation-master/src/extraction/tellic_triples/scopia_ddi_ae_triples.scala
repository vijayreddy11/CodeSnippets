import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_scopia_ddi_ae_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    CONCAT(dps_drugs.IDENTIFIER,'|@|',di_drugs.IDENTIFIER) as ENTITY1,
    "DDI" as ENTITY1_TYPE,
    CASE
        WHEN aes.MEDRA_ID IS NOT NULL then aes.MEDRA_ID
    ELSE NULL END AS ENTITY2,
    "Patient Adverse Event" as ENTITY2_TYPE,
    "Has Modulated Side Effect" as REL_TYPE,
    case
      WHEN ddi.MAGNITUDE="Contra-Indicated" THEN 4
      WHEN ddi.MAGNITUDE="Severe" THEN 3
      WHEN ddi.MAGNITUDE="Moderate" THEN 2
    ELSE 1 END AS STRENGTH,
    nvl(cast(ddi.SCORE as integer),0) as RESULT,
    "ScopiaRX Score" as RESULT_TYPE,
    1.0 as CONFIDENCE,
    named_struct(
        "RULESETS",array("SCOPIA_DDI_ADVERSEEVENT_STRENGTH"),
        "SOURCES",array("preclinical.t_scopiarx_di_main_03062021","preclinical.r_adverseevents","preclinical.r_scopia_chembl_ids"),
        "FILTERS",array(),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.3"
    ) as LINEAGE,
    named_struct(
	    "ENTITY1_PROP",named_struct("DDI",ddi_entities.DDI),
        "ENTITY2_PROP",named_struct("ADVERSE_EVENT",ae_entities.AE),
	    "REL_PROP",named_struct("DISPLAY_STRING",ddi.DISPLAY_STRING,
        "SEVERITY",ddi.SEVERITY,
        "MAGNITUDE",ddi.MAGNITUDE,
        "SOURCE","Scopia")
    ) as METADATA
FROM (
    SELECT AI_DPS,AI_DI,AE,DISPLAY_STRING,SCORE,
    case
      WHEN instr(display_string,"(bw)")>0 THEN "Box Warning"
      WHEN instr(display_string,"(w)")>0 THEN "Warning"
      WHEN instr(display_string,"(contra)")>0 THEN "Contra-Indicated"
      WHEN instr(display_string,"(ca)")>0 THEN "Caution"
      WHEN instr(display_string,"(ns)")>0 THEN "Not Specified"
    ELSE "Not Specified" END AS SEVERITY,
    case
      WHEN instr(display_string,"(contra)")>0 THEN "Contra-Indicated"
      WHEN instr(display_string,"(ns)")>0 THEN "Not Specified"
      WHEN instr(display_string,"(min)")>0 THEN "Minor"
      WHEN instr(display_string,"(mod)")>0 THEN "Moderate"
      WHEN instr(display_string,"(sev)")>0 THEN "Severe"
    ELSE "Not Specified" END AS MAGNITUDE
    FROM preclinical.t_scopiarx_di_main_03062021
    WHERE AI_DPS<>AI_DI
) ddi
LEFT JOIN preclinical.r_adverseevents aes ON
    ddi.AE=aes.SCOPIA_NAME
LEFT JOIN preclinical.r_scopia_chembl_ids di_drugs on ddi.AI_DI=di_drugs.SCOPIA_NAME
LEFT JOIN preclinical.r_scopia_chembl_ids dps_drugs on ddi.AI_DPS=dps_drugs.SCOPIA_NAME
LEFT JOIN (select distinct id,concat_ws('|',collect_set(ddi)) AS ddi
from (select * from ark.t_ddi_entities order by ddi desc)y group by id) ddi_entities 
on CONCAT(dps_drugs.IDENTIFIER,'|@|',di_drugs.IDENTIFIER)=ddi_entities.id
LEFT JOIN (select distinct id,concat_ws('|',collect_set(ae)) AS ae 
from (select * from ark.t_adverseevent_entities order by ae desc)y group by id) ae_entities 
on aes.MEDRA_ID=ae_entities.id
WHERE di_drugs.NUM_COMPONENTS=1 and dps_drugs.NUM_COMPONENTS=1 and di_drugs.IDENTIFIER IS NOT NULL and dps_drugs.IDENTIFIER IS NOT NULL AND ddi.AI_DPS<>'noae' AND ddi.AI_DI<>'noae'
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
