import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_cv_endpoint_medmsd_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
with cv_endpoint_medmsd as(
	select * from dependency.v_cv_medmsd_relationships
	union
	select * from dependency.v_cv_noeffect_relationships
)
select DISTINCT 
cv_medmsd.ENTITY1
,regexp_replace(cv_medmsd.ENTITY1_TYPE,':','') as ENTITY1_TYPE
,cv_medmsd.ENTITY2
,regexp_replace(cv_medmsd.ENTITY2_TYPE,':Endpoint:','') as ENTITY2_TYPE
,cv_medmsd.REL_TYPE
,cv_medmsd.STRENGTH
,cv_medmsd.RESULT
,cv_medmsd.RESULT_TYPE
,cv_medmsd.CONFIDENCE
,cv_medmsd.LINEAGE,
named_struct(
"ENTITY1_PROP",named_struct(
	"CHEMBL_ID",compound.CHEMBL_ID,
	"DRUG_NAME",compound.DRUG_NAME,
	"INCHI_KEY",compound.INCHI_KEY,
	"ANUMBER",compound.ABBVIE_ID,
	"MOLECULE_TYPE",compound.MOLECULE_TYPE,
	"PRIMARYIDENTIFIER",compound.PRIMARYIDENTIFIER),
"ENTITY2_PROP",named_struct(
	"MEAS_AREA",endpoint.MEASUREMENT_AREA,
	"MEAS_NAME",endpoint.MEASUREMENT_NAME,
	"ASSAY",endpoint.ASSAY),
"REL_PROP",cv_medmsd.METADATA
) as METADATA
from  cv_endpoint_medmsd cv_medmsd
left outer join ark.t_compound_entities compound
on cv_medmsd.entity1=compound.id
left outer join
ark.t_endpoint_entities endpoint
on cv_medmsd.entity2=endpoint.id
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
