import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_tdb_compound_cell_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
  t5.ENTITY1 as ENTITY1,
  t5.ENTITY1_TYPE as ENTITY1_TYPE,
  t5.ENTITY2 as ENTITY2,
  t5.ENTITY2_TYPE as ENTITY2_TYPE,
  t5.REL_TYPE as REL_TYPE,
  t5.STRENGTH as STRENGTH,
  t5.RESULT as RESULT,
  t5.RESULT_TYPE as RESULT_TYPE,
  t5.CONFIDENCE as CONFIDENCE,
  named_struct(
    "RULESETS",array("TDB_MODALITY_RULE","TDB_STRENGTH_RULE","TDB_CONFIDENCE_RULE"),"SOURCES",array("ddmlcnp1_tdb_dm.invitro_base_all_dlr_2,aidxunp1_abv_federated_data.federated_data_mv"),"FILTERS",array("result is not null,anumber is not null,cell_line is not null,result_type in ('IC50','IC20','EC50','Ki','Kic','Kd') OR result_type like 'pIC%' OR result_type like 'pEC%' OR result_type like 'pK%'),RANK 1 OVER (CONFIDENCE DESC,STRENGTH DESC)"),"TIMESTAMP",unix_timestamp(),"VERSION","0.1.1") as LINEAGE,
  t5.METADATA as METADATA
FROM (
  SELECT 
    t4.ENTITY1,
    t4.ENTITY1_TYPE,
    t4.ENTITY2,
    t4.ENTITY2_TYPE,
    t4.REL_TYPE,
    t4.STRENGTH,
    t4.RESULT,
    t4.RESULT_TYPE,
    t4.CONFIDENCE,
    t4.METADATA,
    rank() over ( partition by t4.ENTITY1,t4.ENTITY2,t4.REL_TYPE ORDER BY t4.CONFIDENCE DESC,t4.STRENGTH DESC,t4.RESULT DESC) as RANK
  FROM (
      SELECT 
          t3.INCHIKEY as ENTITY1,
          "Compound" as ENTITY1_TYPE,
          t3.CELL_LINE as ENTITY2,
          "Cell Line" as ENTITY2_TYPE,
          CONCAT('Has ',t3.MODALITY,' Against') as REL_TYPE,
          CASE 
              WHEN t3.RESULT_QUALIFIER='<' THEN 0
              WHEN t3.RESULT_QUALIFIER='=' THEN
                  CASE
                      WHEN t3.ACTIVITY_VAL_LOG < 4 THEN 0
                      WHEN t3.ACTIVITY_VAL_LOG >=4 AND t3.ACTIVITY_VAL_LOG<6 THEN 1
                      WHEN t3.ACTIVITY_VAL_LOG >=6 AND t3.ACTIVITY_VAL_LOG<7 THEN 2
                      WHEN t3.ACTIVITY_VAL_LOG >=7 AND t3.ACTIVITY_VAL_LOG<8 THEN 3 
                  ELSE 4 END 
              WHEN t3.RESULT_QUALIFIER='>' THEN
                  CASE
                      WHEN t3.ACTIVITY_VAL_LOG < 4 THEN 0
                      WHEN t3.ACTIVITY_VAL_LOG >=4 AND t3.ACTIVITY_VAL_LOG<6 THEN 1
                      WHEN t3.ACTIVITY_VAL_LOG >=6 AND t3.ACTIVITY_VAL_LOG<7 THEN 2
                      WHEN t3.ACTIVITY_VAL_LOG >=7 AND t3.ACTIVITY_VAL_LOG<8 THEN 3 
                  ELSE 4 END
          ELSE 0 END as STRENGTH,        
          t3.ACTIVITY_VAL_LOG as RESULT,
          "Log Activity" as RESULT_TYPE,
          CASE
              WHEN t3.SPECIES='Human' THEN
                  CASE
                      WHEN t3.ASSAY_SOURCE IN ('TDB','PIKM MOA') THEN 1.0
                      WHEN t3.ASSAY_SOURCE='HTS' THEN 0.95
                      WHEN t3.ASSAY_SOURCE='ChEMBL' THEN 0.94
                      WHEN t3.ASSAY_SOURCE='GOSTAR' THEN 0.93
                      WHEN t3.ASSAY_SOURCE='WOMBAT' THEN 0.92
                  ELSE 0.90 END        
              ELSE 
                  CASE
                      WHEN t3.ASSAY_SOURCE IN ('TDB','PIKM MOA') THEN 1.0*0.75
                      WHEN t3.ASSAY_SOURCE='HTS' THEN 0.95*0.75
                      WHEN t3.ASSAY_SOURCE='ChEMBL' THEN 0.94*0.75
                      WHEN t3.ASSAY_SOURCE='GOSTAR' THEN 0.93*0.75
                      WHEN t3.ASSAY_SOURCE='WOMBAT' THEN 0.92*0.75
                  ELSE 0.90*0.75 END                
              END as CONFIDENCE,
          named_struct("ENTITY1_PROP",named_struct("INCHI_KEY",t3.INCHIKEY,"ANUMBER",t3.ANUMBER),"ENTITY2_PROP",named_struct("CELL_LINE",t3.CELL_LINE),"REL_PROP",named_struct("CONDITION",t3.SEURAT_ASSAY,"ASSAY_SOURCE",t3.ASSAY_SOURCE,"RESULT_QUALIFIER",t3.RESULT_QUALIFIER,"UNITS",t3.UNITS,"RESULT",t3.RESULT,"BIOLOGICAL_ENTITY",t3.BIOLOGICAL_ENTITY,"MODALITY",t3.MODALITY,"SPECIES",t3.SPECIES,"SOURCE","TDB")) as METADATA
    FROM (
      select 
        t2.inchikey as INCHIKEY, 
        t1.cell_line as CELL_LINE, 
        t1.anumber as ANUMBER, 
        t1.species as SPECIES, 
        t1.result as RESULT,
        CASE
            WHEN t1.RESULT_TYPE LIKE 'pIC%' THEN CONCAT('Converted_',t1.RESULT_TYPE)
            WHEN t1.RESULT_TYPE LIKE 'pEC%' THEN CONCAT('Converted_',t1.RESULT_TYPE)
            WHEN t1.RESULT_TYPE LIKE 'pK%' THEN CONCAT('Converted_',t1.RESULT_TYPE)
        ELSE t1.RESULT_TYPE END as RESULT_TYPE,
        t1.units as UNITS,
        t1.biological_entity as BIOLOGICAL_ENTITY,
        t1.SOURCE as ASSAY_SOURCE,
        CASE
            WHEN t1.RESULT_TYPE LIKE 'pIC%' AND t1.QUALIFIER="<" THEN ">"
            WHEN t1.RESULT_TYPE LIKE 'pEC%' AND t1.QUALIFIER="<" THEN ">"
            WHEN t1.RESULT_TYPE LIKE 'pK%' AND t1.QUALIFIER="<" THEN ">"
            WHEN t1.RESULT_TYPE LIKE 'pIC%' AND t1.QUALIFIER<>"<" THEN "="
            WHEN t1.RESULT_TYPE LIKE 'pEC%' AND t1.QUALIFIER<>"<" THEN "="
            WHEN t1.RESULT_TYPE LIKE 'pK%' AND t1.QUALIFIER<>"<" THEN "="
            WHEN t1.QUALIFIER is NULL then "="
        ELSE t1.QUALIFIER END as RESULT_QUALIFIER,
        t1.SEURAT_ASSAY as SEURAT_ASSAY,
        CASE
            WHEN instr(t1.SEURAT_ASSAY,' Antag') > 0 OR instr(t1.SEURAT_ASSAY,'-Antag') > 0 OR instr(t1.SEURAT_ASSAY,'_Antag') > 0 THEN 'Antagonism'
            WHEN instr(t1.SEURAT_ASSAY,' Ag') > 0 OR instr(t1.SEURAT_ASSAY,'-Ag') > 0 OR instr(t1.SEURAT_ASSAY,'_Ag') > 0 THEN 'Antagonism'
            WHEN instr(t1.SEURAT_ASSAY,' Mod') > 0 OR instr(t1.SEURAT_ASSAY,'-Mod') > 0 OR instr(t1.SEURAT_ASSAY,'_Mod') > 0 THEN 'Modulation'
            WHEN instr(t1.SEURAT_ASSAY,' Pot') > 0 OR instr(t1.SEURAT_ASSAY,'-Pot') > 0 OR instr(t1.SEURAT_ASSAY,'_Pot') > 0 THEN 'Modulation'
            WHEN instr(t1.SEURAT_ASSAY,' Induction') > 0 OR instr(t1.SEURAT_ASSAY,'-Induction') > 0 OR instr(t1.SEURAT_ASSAY,'Induction') > 0 THEN 'Induction/Activation'
            WHEN instr(t1.SEURAT_ASSAY,' Activation') > 0 OR instr(t1.SEURAT_ASSAY,'-Activation') > 0 OR instr(t1.SEURAT_ASSAY,'Activation') > 0 THEN 'Induction/Activation'
        ELSE 'Activity' END as MODALITY,
        CASE
            WHEN t1.RESULT_TYPE LIKE 'pIC%' THEN t1.RESULT
            WHEN t1.RESULT_TYPE LIKE 'pEC%' THEN t1.RESULT
            WHEN t1.RESULT_TYPE LIKE 'pK%' THEN t1.RESULT
        ELSE 6-LOG10(t1.RESULT) END as ACTIVITY_VAL_LOG
      from (
        SELECT * 
        from ddmlcnp1_tdb_dm.invitro_base_all_dlr_2 
        where 
          result is not null and
          anumber is not null and 
          cell_line is not null and
          (result_type in ('IC50','IC20','EC50','Ki','Kic','Kd') OR
          result_type like 'pIC%' or
          result_type like 'pEC%' OR
          result_type like 'pK%')
        ) t1
      join aidxunp1_abv_federated_data.federated_data_mv t2 on t1.anumber=t2.anumber
    ) t3
  ) t4
) t5
WHERE t5.RANK=1
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
