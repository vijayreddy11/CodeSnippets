import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_pkpairing_measured_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT 
ENTITY1,
split(ENTITY1_TYPE,":")[1] as ENTITY1_TYPE,
ENTITY2,
split(ENTITY2_TYPE,":")[1] as ENTITY2_TYPE,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
t1.LINEAGE,
named_struct(
	"ENTITY1_PROP",
		named_struct("CHEMBL_ID",compound.CHEMBL_ID,
					"DRUG_NAME",compound.DRUG_NAME,
					"INCHI_KEY",compound.INCHI_KEY,
					"ANUMBER",compound.ABBVIE_ID,
					"MOLECULE_TYPE",compound.MOLECULE_TYPE,
					"PRIMARYIDENTIFIER",compound.PRIMARYIDENTIFIER),
	"ENTITY2_PROP",
		named_struct("PRIMARYIDENTIFIER",pkpairing.PRIMARYIDENTIFIER),
	"REL_PROP",t1.metadata
) as METADATA
 FROM ark.t_compound_pkpairing_measured_relationships t1
 left outer join ark.t_compound_entities compound 
 ON t1.ENTITY1 = compound.ID
 left outer join ark.t_pkpairing_entities pkpairing
 ON t1.ENTITY2 = pkpairing.ID
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
