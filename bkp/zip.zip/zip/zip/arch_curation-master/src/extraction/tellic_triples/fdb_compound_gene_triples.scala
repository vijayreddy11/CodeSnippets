import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_fdb_compound_gene_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT distinct
    t10.ENTITY1 as ENTITY1,
    t10.ENTITY1_TYPE as ENTITY1_TYPE,
    t10.ENTITY2 as ENTITY2,
    t10.ENTITY2_TYPE as ENTITY2_TYPE,
    t10.REL_TYPE as REL_TYPE,
    t10.STRENGTH as STRENGTH,
    t10.RESULT as RESULT,
    t10.RESULT_TYPE as RESULT_TYPE,
    t10.CONFIDENCE as CONFIDENCE,
    named_struct(
        "RULESETS",array("FDB_COMPOUND_GENE_CONFIDENCE","FDB_COMPOUND_GENE_REL_TYPE","FDB_COMPOUND_GENE_STRENGTH"),
        "SOURCES",array("aidxunp1_abv_federated_data.federated_data_mv","preclinical.r_drug_metadata","preclinical.r_drug_compound"),
        "FILTERS",array(""),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.3"
    ) as LINEAGE,
  t10.METADATA as METADATA,
  t10.REL_RANK as REL_RANK
FROM (
    select
      t9.ENTITY1 as ENTITY1,
      'Compound' as ENTITY1_TYPE,
      t9.entity1 as DRUG_NAME,
      t9.entity1_id as ENTITY1_ID,
      t9.ENTITY2,
      t9.ENTITY2_TYPE,
      t9.rel_type,
      -- remove conditional, will end up s4/c1/moa/null for moa without inhibition
      t9.strength as strength,
      cast(t9.result as float) as result,
      t9.result_type,  
      -- remove conditional, will end up s4/c1/moa/null for moa without inhibition
      t9.confidence as confidence,
        named_struct(
		  "ENTITY1_PROP",named_struct("INCHI_KEY",compound.INCHI_KEY,"PRIMARYIDENTIFIER",compound.PRIMARYIDENTIFIER),
          "ENTITY2_PROP",named_struct("HGNC",gene.HGNC),
          "REL_PROP",named_struct(
          "MODALITY",t9.modality,
          "SPECIES",t9.species,
          "NUM_MEASUREMENTS",t9.num_result,
          "RESULT_WEIGHTAVG",cast(t9.result_weightavg as double),
          "RESULT_UNCERTAINTY",cast(t9.result_uncertainty as double),
          "ZSCORE",cast(t9.zscore as double),
          "AUC",cast(t9.auc as double),
          "ASSAYCONFIDENCE",cast(t9.assayconfidence as double),
          "COMMENT",t9.comment,
          "CONDITION",t9.condition,
          "SOURCEMODALITY",t9.sourcemodality,
          "SOURCE",case when moa.ismoa is null then t9.source else concat(t9.source,'/PIKM MOA') end,
          "SOURCE_ID",t9.source_id,
          "ACTIVITYQUAL",t9.activityqual,
          "RESULTQUAL",t9.result_qualifier,
          "REPORTED_MOA",case when moa.ismoa is null then 'NO' else 'YES' end,
          "PARENT_DRUG_ID",t9.parent_id,
          "PARENT_DRUG_NAME",t9.parent_name)
        ) as metadata,
      rank() over ( partition by t9.entity1,t9.entity2,t9.rel_type order by t9.confidence desc,t9.absdiff asc,t9.strength desc,t9.result desc,t9.rownum) as rel_rank,
      moa.ismoa as pikm_moa
    from (
        select
          t8.entity1,
          t8.entity1_type,
          t8.entity1_id,
          t8.rel_type,
          t8.entity2,
          t8.entity2_type,
          t8.assaystrength as strength,
          t8.result,
          t8.result_type,
          t8.modality,
          t8.species,
          case
            when t8.assaystrength>0 and t8.weightavg>5 or t8.assaystrength=0 and t8.weightavg<5.5 then least(0.5 + 0.0167*pow(t8.zscore,3) - 0.1593*power(zscore,2) + 0.4969*zscore - 0.0114,1.0)*t8.assayconfidence
            else (1 - (0.5 + 0.0167*pow(t8.zscore,3) - 0.1593*power(zscore,2) + 0.4969*zscore - 0.0114))*t8.assayconfidence
          end as confidence,
          t8.num_result,
          t8.weightavg as result_weightavg,
          t8.result_uncertainty,
          t8.zscore,
          case
            when t8.assaystrength>0 and t8.weightavg>5 or t8.assaystrength=0 and t8.weightavg<5.5 then least(0.5 + 0.0167*pow(t8.zscore,3) - 0.1593*power(zscore,2) + 0.4969*zscore - 0.0114,1.0)
            else 1 - (0.5 + 0.0167*pow(t8.zscore,3) - 0.1593*power(zscore,2) + 0.4969*zscore - 0.0114)
          end as auc,
          t8.assayconfidence,
          t8.comment,
          t8.condition,
          t8.activityqual,
          t8.result_qualifier,
          t8.sourcemodality,
          t8.source,
          t8.source_id,
          t8.inchi_key,
          t8.parent_name,
          t8.parent_id,
          t8.num_components,
          t8.activityvalum,
          t8.resultsum,
          t8.weightsum,
          t8.weightavg,
          t8.absdiff,
          t8.mean_result,
          t8.stddev_result,
          case
            when t8.assaystrength>0 and t8.weightavg>5 or t8.assaystrength=0 and t8.weightavg<5.5 then least(0.5 + 0.0167*pow(t8.zscore,3) - 0.1593*power(zscore,2) + 0.4969*zscore - 0.0114,1.0)*t8.assayconfidence
            else (1 - (0.5 + 0.0167*pow(t8.zscore,3) - 0.1593*power(zscore,2) + 0.4969*zscore - 0.0114))*t8.assayconfidence
          end as edgeconfidence,
          t8.assaystrength as edgestrength,
          row_number() over ( partition by t8.entity1,t8.entity2,t8.rel_type order by t8.assayconfidence desc,t8.absdiff asc,t8.assaystrength desc,t8.result desc) as rownum
        from (
            select
                t7.entity1,
                t7.entity1_type,
                t7.entity1_id,
                t7.rel_type,
                t7.entity2,
                t7.entity2_type,
                t7.assaystrength,
                t7.result,
                t7.result_type,  
                t7.modality,
                t7.species,
                t7.resultsum/t7.weightsum as weightavg,
                case
                    when t7.stddev_result<=0.5 then
                        case
                          when t7.assaystrength>0 and t7.resultsum/t7.weightsum>5 then (t7.resultsum/t7.weightsum-5)/0.5
                          when t7.assaystrength=0 and t7.resultsum/t7.weightsum<5.5 then (5.5-t7.resultsum/t7.weightsum)/0.5
                          when t7.assaystrength=0 and t7.resultsum/t7.weightsum>=5.5 then (t7.resultsum/t7.weightsum-5)/0.5
                          else abs((t7.resultsum/t7.weightsum-5)/0.5)
                        end
                    when t7.stddev_result>0.5 then
                        case
                          when t7.assaystrength>0 and t7.resultsum/t7.weightsum>5 then (t7.resultsum/t7.weightsum-5)/t7.stddev_result
                          when t7.assaystrength=0 and t7.resultsum/t7.weightsum<5.5 then (5.5-t7.resultsum/t7.weightsum)/t7.stddev_result
                          when t7.assaystrength=0 and t7.resultsum/t7.weightsum>=5.5 then (t7.resultsum/t7.weightsum-5)/t7.stddev_result
                          else abs((t7.resultsum/t7.weightsum-5)/t7.stddev_result)
                        end
                end as zscore,
                t7.assayconfidence,
                t7.comment,
                t7.condition,
                t7.sourcemodality,
                t7.source,
                t7.source_id,
                t7.inchi_key,
                t7.parent_name,
                t7.parent_id,
                t7.num_components,
                t7.activityqual,
                t7.result_qualifier,
                t7.activityvalum,
                t7.resultsum,
                t7.weightsum,
                abs(t7.result-(t7.resultsum/t7.weightsum)) as absdiff,
                t7.mean_result,
                t7.num_result,
                t7.stddev_result,
                case
                    when t7.stddev_result<0.5 then 0.5
                    else t7.stddev_result
                end as result_uncertainty
            from (
                select 
                    t6.entity1,
                    t6.entity1_type,
                    t6.entity1_id,
                    concat('Has ',t6.modality,' Against') as rel_type,
                    t6.entity2,
                    t6.entity2_type,
                    t6.assaystrength,
                    t6.result,
                    t6.result_type,
                    t6.modality,
                    t6.species,
                    sum(t6.result*t6.assayconfidence) over ( partition by t6.entity1, t6.entity2, t6.modality) as resultsum,
                    sum(t6.assayconfidence) over ( partition by t6.entity1, t6.entity2, t6.modality) as weightsum,
                    stddev_pop(t6.result) over ( partition by t6.entity1, t6.entity2, t6.modality) as stddev_result,
                    t6.assayconfidence,
                    case
                        when t6.modality='%Inhibition' THEN concat('%Inhibition = ',t6.activityval,'; Modality: ',t6.modality,'; Species: ',t6.species,'; Source: ',t6.assaysource,'; Source ID: ',t6.source_id)
                        else concat(t6.activitytype,' ',t6.result_qualifier,' ',t6.activityvalum,' uM; Modality: ',t6.modality,'; Species: ',t6.species,'; Source: ',t6.assaysource,'; Source ID: ',t6.source_id) 
                    end as comment,
                    t6.condition,
                    t6.sourcemodality,
                    t6.assaysource as source,
                    t6.source_id,
                    t6.inchi_key,
                    t6.num_components,
                    t6.parent_id,
                    t6.parent_name,
                    t6.activityvalum,
                    avg(t6.result) over ( partition by t6.entity1, t6.entity2, t6.modality) as mean_result,
                    count(t6.result) over ( partition by t6.entity1, t6.entity2, t6.modality) as num_result,
                    
                    t6.id,
                    t6.hugogenesymbol,
                    t6.activityval,
                    t6.assaysource,
                    t6.assaydescription,
                    t6.primaryidentifier,
                    t6.anumber,
                    t6.activityqual,
                    t6.activitytype,
                    t6.activity_val_log,
                    t6.result_qualifier
                from (
                      SELECT 
                        t4.INCHIKEY as ENTITY1,
                        'Compound' as ENTITY1_TYPE,
                        t4.INCHIKEY as ENTITY1_ID,
                        t1.parent_id,
                        upper(t3.parent_name) as parent_name,
                        t4.hugogenesymbol as ENTITY2,
                        'Gene' as ENTITY2_TYPE,
                        case
                            when t4.activityqual is not null and t4.activityqual='>' and 6-log10(t4.activityvalum)<6.0 then 0
                            --same logic as result_qualifier as below
                            when t4.activityqual is not null and t4.activityqual='>' and 6-log10(t4.activityvalum)>=6.0 then NULL
                            when (t4.activityqual is null or t4.activityqual<>'>') and 6-log10(t4.activityvalum)<5.0 then 0
                            when (t4.activityqual is null or t4.activityqual<>'>') and 6-log10(t4.activityvalum)>=5.0 and 6-log10(t4.activityvalum)<6.0 then 1
                            when (t4.activityqual is null or t4.activityqual<>'>') and 6-log10(t4.activityvalum)>=6.0 and 6-log10(t4.activityvalum)<7.0 then 2
                            when (t4.activityqual is null or t4.activityqual<>'>') and 6-log10(t4.activityvalum)>=7.0 and 6-log10(t4.activityvalum)<8.0 then 3
                            when (t4.activityqual is null or t4.activityqual<>'>') and 6-log10(t4.activityvalum)>=8.0 then 4
                            -- nothing should hit this
                            else NULL
                        end as assaystrength,  
                        case
                            when t4.activityqual is not null and t4.activityqual='>' and 6-log10(t4.activityvalum)<6.0 then 6-log10(t4.activityvalum)
                            when t4.activityqual is not null and t4.activityqual='>' and 6-log10(t4.activityvalum)>=6.0 then null
                            when 6-log10(t4.activityvalum)>=12.0 then 12.0
                            else 6-log10(t4.activityvalum)
                        end as result,
                        case
                            when t4.activityqual is not null and t4.activityqual='>' and 6-log10(t4.activityvalum)<6.0 then 'Log Activity'
                            when t4.activityqual is not null and t4.activityqual='>' and 6-log10(t4.activityvalum)>=6.0 then null
                            else 'Log Activity'
                        end as result_type,
                        case
                            when t4.modality in ('Antagonism','Agonism','Modulation') then t4.modality
                            when t4.modality in ('Induction','Activation') then 'Induction/Activation'
                            else 'Activity'
                        end as modality,
                        t4.species,
                        t4.modality_confidence_multiplier*assaysource_confidence.multiplier*species_confidence.multiplier as assayconfidence,
                        t4.modality_confidence_multiplier,
                        assaysource_confidence.multiplier as assaysource_confidence_multiplier,
                        species_confidence.multiplier as species_confidence_multiplier,
                        t4.source_id,
                        t4.assaydescription as condition,
                        t4.modality as sourcemodality,
                        t4.assaysource,
                        t2.inchi_key as drug_inchi_key,
                        t4.inchikey as inchi_key,
                        t1.num_comp as num_components,
                        
                        t4.hugogenesymbol,
                        t4.activityval,
                        t4.assaydescription,
                        t1.id,
                        row_number() over ( partition by t4.inchikey,t4.hugogenesymbol,t4.activityval,t4.modality,t4.assaysource,t4.species,t4.assaydescription order by t4.modality_confidence_multiplier*assaysource_confidence.multiplier*species_confidence.multiplier desc) as rec_rank,
                        t4.primaryidentifier,
                        t4.anumber,
                        t4.activityqual,
                        t4.activityvalum,
                        t4.activitytype,
                        6-log10(t4.activityvalum) as activity_val_log,
                        case
                            when t4.activityqual is not null and t4.activityqual='>' and 6-log10(t4.activityvalum)<6.0 then '<'
                            --Changed to NULL for when log result>=6.0, don't know how to handle so discard
                            when t4.activityqual is not null and t4.activityqual='>' and 6-log10(t4.activityvalum)>=6.0 then NULL
                            when t4.activityqual<>'>' and 6-log10(t4.activityvalum)>=12.0 then '>'
                            else '='
                        end as result_qualifier
                    FROM (
                            select distinct
                                PRIMARYIDENTIFIER,
                                PRIMARYIDENTIFIER AS SOURCE_ID,
                                ANUMBER,
                                HUGOGENESYMBOL,
                                case
                                    when activityvalum > 100 then '>'
                                    when (activityvalum is null or activityvalum<=0) and activityval>50 then '='
                                    when (activityvalum is null or activityvalum<=0) and activityval<=50 then '>'
                                    else activityqual
                                end as activityqual,
                                ACTIVITYTYPE,
                                ACTIVITYVAL,
                                case
                                    when activityvalum > 100 then 100
                                    when (activityvalum is null or activityvalum<=0) and activityval>90 then 1
                                    when (activityvalum is null or activityvalum<=0) and activityval>75 then 3
                                    when (activityvalum is null or activityvalum<=0) and activityval>50 then 10
                                    when (activityvalum is null or activityvalum<=0) and activityval<=50 then 10
                                    else activityvalum
                                end as activityvalum,
                                case
                                    when activityvalum is null or activityvalum<=0 then '%Inhibition'
                                    else MODALITY
                                end as MODALITY,
                                case
                                    when activityvalum is null or activityvalum<=0 then 0.9
                                    else 1.0
                                end as modality_confidence_multiplier,
                                MODALITY as SOURCEMODALITY,
                                ASSAYSOURCE,
                                SPECIES,
                                ASSAYDESCRIPTION,
                                INCHIKEY
                            from aidxunp1_abv_federated_data.federated_data_mv
                    ) t4
                    LEFT JOIN (
                        select distinct
                            assaysource,
                            case
                                when assaysource in ('TDB','PIKM MOA') then 1.0
                                when assaysource='HTS' then 0.99
                                when assaysource='ChEMBL' then 0.98
                                when assaysource='GOSTAR' then 0.97
                                when assaysource='WOMBAT' then 0.96
                                when assaysource='DrugMatrix' then 0.95
                                else 0.95        
                            end as multiplier
                        from aidxunp1_abv_federated_data.federated_data_mv
                    ) assaysource_confidence on t4.assaysource=assaysource_confidence.assaysource
                    LEFT JOIN (
                        select distinct
                            species,
                            case
                                when species='Human' then 1.0
                                else 0.75
                            end as multiplier
                        from aidxunp1_abv_federated_data.federated_data_mv
                    ) species_confidence on t4.species=species_confidence.species
                    LEFT JOIN preclinical.r_drug_compound t2 ON t4.inchikey=t2.inchi_key
                    LEFT JOIN (
                        select
                            parent_id,
                            id,
                            molecule_id,
                            molecule_type,
                            molecule_name,
                            max_phase,
                            num_comp,
                            identifier
                        from preclinical.r_drug_metadata
                    ) t1 ON t2.id=t1.id
                    LEFT JOIN (
                        SELECT DISTINCT 
                        parent_id,
                        molecule_name as parent_name
                        FROM preclinical.r_drug_metadata
                        WHERE molecule_id=parent_id
                    ) t3 ON t1.parent_id=t3.parent_id
                ) t6
                where 
                    --t6.rec_rank=1 and 
                    cast(t6.result as double) is not null and 
                    t6.result>0
            ) t7 
            order by 
                t7.entity1,
                t7.entity2,
                t7.modality,
                t7.result desc
        ) t8
    ) t9
    LEFT JOIN (
        SELECT DISTINCT
            t1.parent_id as ENTITY1_ID,
            t1.target as ENTITY2,
            'YES' as ismoa
        FROM preclinical.r_pikm_moa_chembl_ids t1
    ) moa ON
      t9.PARENT_ID=moa.ENTITY1_ID AND t9.ENTITY2=moa.ENTITY2
  LEFT JOIN ark.t_compound_entities compound ON t9.ENTITY1=compound.ID
  LEFT JOIN ark.t_gene_entities gene ON t9.ENTITY2=gene.id
) t10
WHERE 
  t10.rel_rank=1 
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
