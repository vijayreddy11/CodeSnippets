

import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_scopia_rare_ae_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    t5.ENTITY1,
    "Drug" as ENTITY1_TYPE,
    t5.ENTITY2,
    "Patient Adverse Event" as ENTITY2_TYPE,
    "Has Side Effect" as REL_TYPE,
    t5.STRENGTH,
    t5.RESULT,
    t5.RESULT_TYPE,
    t5.CONFIDENCE,
    named_struct(
        "RULESETS",array("SCOPIA_DRUG_AE_STRENGTH_RULE","SCOPIA_DRUG_AE_CONFIDENCE_RULE","SCOPIA_DRUG_AE_FREQUENCY_RULE","SCOPIA_DRUG_AE_SEVERITY_RULE"),
        "SOURCES",array("preclinical.t_scopiarx_ae_rare_03062021","preclinical.r_scopia_chembl_ids","preclinical.r_adverseevents"),
        "FILTERS",array(),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.2"
    ) as LINEAGE,
    named_struct(
        "ENTITY1_PROP",named_struct("ACTIVE_INGREDIENT",t5.AI,"ID",drug.ID),
        "ENTITY2_PROP",named_struct("ADVERSE_EVENT",ae_entities.AE),
	    "REL_PROP",named_struct("COMMENT",t5.COMMENT,
        "REPORTS",cast(t5.NUM_REPORTS as integer),
        "AES",cast(t5.NUM_AE_REPORTS as integer),
        "SEVERITY",t5.SEVERITY,
        "FREQUENCY",t5.FREQUENCY,
        "SOURCE","Scopia")
    ) as METADATA
FROM (
SELECT
  t3.ENTITY1_ID as ENTITY1,
  t4.ENTITY2_ID as ENTITY2,
  t2.NUM_AE_REPORTS,
  t2.Entity1 as AI,
  t2.NUM_REPORTS,
  CASE
    WHEN array_contains(split(t2.codes,' '),'vc') THEN 3
    WHEN array_contains(split(t2.codes,' '),'c') THEN 2
    ELSE CASE
      WHEN CAST(t2.num_ae_reports as DOUBLE) IS NOT NULL AND 100*t2.num_ae_reports/t2.num_reports>=10 THEN 3
      WHEN CAST(t2.num_ae_reports as DOUBLE) IS NOT NULL AND 100*t2.num_ae_reports/t2.num_reports>=1 AND 100*t2.num_ae_reports/t2.num_reports<10 THEN 2
      WHEN CAST(t2.num_ae_reports as DOUBLE) IS NOT NULL AND 100*t2.num_ae_reports/t2.num_reports>=0.1 AND 100*t2.num_ae_reports/t2.num_reports<1 THEN 1
      WHEN CAST(t2.num_ae_reports as DOUBLE) IS NOT NULL AND 100*t2.num_ae_reports/t2.num_reports<0.1 THEN 0
      ELSE 1 
    END
  END AS STRENGTH,
  CASE
    WHEN array_contains(split(t2.codes,' '),'vc') THEN 1.0
    WHEN array_contains(split(t2.codes,' '),'c') THEN 1.0
    ELSE CASE
      WHEN CAST(t2.num_ae_reports as DOUBLE) IS NOT NULL AND CAST(t2.num_reports as DOUBLE) IS NOT NULL THEN LEAST(0.9,0.5 * SQRT(POW(LOG10(t2.num_ae_reports) / LOG10(10),2) + POW(LOG10(t2.num_reports) / LOG10(10000),2)))
      ELSE 0.0 
    END
  END AS CONFIDENCE,
  CASE
    WHEN array_contains(split(t2.codes,' '),'vc') THEN 'Very Common'
    WHEN array_contains(split(t2.codes,' '),'c') THEN 'Common'
    ELSE 'Post-Market Reports'
  END AS FREQUENCY,
  CASE
    WHEN array_contains(split(t2.codes,' '),'bw') THEN 'Box Warning'
    WHEN array_contains(split(t2.codes,' '),'w') THEN 'Warning'
    WHEN array_contains(split(t2.codes,' '),'ca') THEN 'Caution'
    ELSE 'Not Specified'
  END AS SEVERITY,
  100*t2.num_ae_reports/t2.num_reports AS RESULT,
  'Reporting Frequency (%)' AS RESULT_TYPE,
  concat('Code =',t2.codes,'; Scopia Score =',t2.scopia_strength,'; Reports := ',t2.num_reports,'; AEs =',t2.num_ae_reports) AS COMMENT
FROM (
  SELECT
  	rare.ai as Entity1,
  	rare.ae as Entity2,
  	rare.score as Scopia_Strength,
  	concat(nvl(main.codes,''),' ',nvl(rare.code,'')) as codes,
  	case
  	    when rare.total_after_market_reports_for_drug is not null then rare.total_after_market_reports_for_drug
  	    when rare.total_after_market_reports_for_drug is null and main.total_after_market_reports_for_drug is not null then main.total_after_market_reports_for_drug
  	    else 0
  	end as Num_Reports,
  	case
  	    when rare.total_reports_for_drug_and_adverse_event is not null then rare.total_reports_for_drug_and_adverse_event
  	    when rare.total_reports_for_drug_and_adverse_event is null and main.total_reports_for_drug_and_adverse_event is not null then main.total_reports_for_drug_and_adverse_event
  	    else 0
  	end as Num_AE_Reports
  FROM preclinical.t_scopiarx_ae_rare_03062021 rare
  FULL OUTER JOIN preclinical.t_scopiarx_ae_main_03062021 main
    on rare.ai=main.ai and rare.ae=main.ae
 ) t2
JOIN (
  select 
    scopia_name as ENTITY1,
    identifier as ENTITY1_ID,
    num_components
  from preclinical.r_scopia_chembl_ids
  WHERE 
    scopia_name IS NOT NULL AND
    scopia_name > ''
) t3 ON t2.ENTITY1=t3.ENTITY1
JOIN (
  SELECT 
  	scopia_name as ENTITY2,
  	medra_id as ENTITY2_ID,
  	medra_source as ENTITY2_ID_Source
  FROM preclinical.r_adverseevents
) t4 ON t2.ENTITY2=t4.ENTITY2
WHERE 
  CAST(t2.num_ae_reports AS DOUBLE) IS NOT NULL AND
  t3.ENTITY1_ID IS NOT NULL AND t3.ENTITY1_ID>'' AND
  t4.ENTITY2_ID IS NOT NULL AND t4.ENTITY2_ID>'' AND
  t2.ENTITY2<>'noae'
) t5
LEFT JOIN ark.t_drug_entities drug  on  t5.ENTITY1= drug.id
LEFT JOIN (select distinct id,concat_ws('|',collect_set(ae)) AS ae 
from (select * from ark.t_adverseevent_entities order by ae desc)y group by id) ae_entities 
on t5.ENTITY2=ae_entities.id
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
