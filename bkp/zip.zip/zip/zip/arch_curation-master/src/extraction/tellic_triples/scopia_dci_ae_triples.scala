import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_scopia_dci_ae_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    CONCAT(ai_drugs.IDENTIFIER,'|@|',dci.CLIN_INTERACTION) as ENTITY1,
    "DCI" as ENTITY1_TYPE,
    aes.MEDRA_ID as ENTITY2,
    "Patient Adverse Event" as ENTITY2_TYPE,
    "Has Modulated Side Effect" as REL_TYPE,
    CASE
        WHEN dci.MAGNITUDE="Contra-Indicated" THEN 4
        WHEN dci.MAGNITUDE="Severe" THEN 3
        WHEN dci.MAGNITUDE="Moderate" THEN 2
    ELSE 1 END AS STRENGTH,
    dci.SCORE as RESULT,
    "ScopiaRX Score" as RESULT_TYPE,
    1.0 as CONFIDENCE,
    named_struct(
        "RULESETS",array("SCOPIA_DCI_ADVERSEEVENT_STRENGTH"),
        "SOURCES",array("preclinical.t_scopiarx_ci_main_03062021","preclinical.r_scopia_chembl_ids","preclinical.r_adverseevents"),
        "FILTERS",array(),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.3"
    ) as LINEAGE,
    named_struct(
		"ENTITY1_PROP",named_struct("DCI",dci_entities.DCI),
		"ENTITY2_PROP",named_struct("ADVERSE_EVENT",ae_entities.AE),
        "REL_PROP",named_struct("DISPLAY_STRING",dci.DISPLAY_STRING,"SEVERITY",dci.SEVERITY,"MAGNITUDE",dci.MAGNITUDE,"SOURCE","Scopia")	
		 ) as METADATA
FROM (
    SELECT AI,CLIN_INTERACTION,AE,DISPLAY_STRING,SCORE,
    case
      WHEN instr(display_string,"(bw)")>0 THEN "Box Warning"
      WHEN instr(display_string,"(w)")>0 THEN "Warning"
      WHEN instr(display_string,"(contra)")>0 THEN "Contra-Indicated"
      WHEN instr(display_string,"(ca)")>0 THEN "Caution"
      WHEN instr(display_string,"(ns)")>0 THEN "Not Specified"
    ELSE "Not Specified" END AS SEVERITY,
    case
      WHEN instr(display_string,"(contra)")>0 THEN "Contra-Indicated"
      WHEN instr(display_string,"(ns)")>0 THEN "Not Specified"
      WHEN instr(display_string,"(min)")>0 THEN "Minor"
      WHEN instr(display_string,"(mod)")>0 THEN "Moderate"
      WHEN instr(display_string,"(sev)")>0 THEN "Severe"
    ELSE "Not Specified" END AS MAGNITUDE
    FROM preclinical.t_scopiarx_ci_main_03062021
) dci
LEFT JOIN preclinical.r_adverseevents aes ON
    dci.AE=aes.SCOPIA_NAME
LEFT JOIN preclinical.r_scopia_chembl_ids ai_drugs on dci.AI=ai_drugs.SCOPIA_NAME
LEFT JOIN 
(select distinct id,concat_ws('|',collect_set(dci)) AS dci
from 
(select * from ark.t_dci_entities order by dci desc)y group by id) dci_entities 
on CONCAT(ai_drugs.IDENTIFIER,'|@|',dci.CLIN_INTERACTION) = dci_entities.id
LEFT JOIN 
(select distinct id,concat_ws('|',collect_set(ae)) AS ae 
from 
(select * from ark.t_adverseevent_entities order by ae desc)y group by id) ae_entities 
on aes.MEDRA_ID = ae_entities.id
""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
