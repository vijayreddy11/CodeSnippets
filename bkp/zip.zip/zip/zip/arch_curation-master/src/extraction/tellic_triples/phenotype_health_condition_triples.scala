import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_phenotype_health_condition_triples"
val almaren = Almaren(set_name)

val res=almaren.builder.sourceSql("""with variant_phenotype_triples as(
select distinct
ENTITY1,
ENTITY1_TYPE,
ENTITY1_CONCEPT_ID,
ENTITY2,
ENTITY2_TYPE,
ENTITY2_CONCEPT_ID,
pheno_tellic_id,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
LINEAGE,
METADATA
from (
select distinct
    case 
        when size(var.RSIDS)>1 then var.joined_explicit_var_uids[0]
        else concat_ws('|',var.RSIDS)
    END as ENTITY1,
	vp_rel.ENTITY1_TYPE,
    case
        when size(var.TELLIC_ID)>1 then var.ID
        else concat_ws('|',var.TELLIC_ID) 
    END as ENTITY1_CONCEPT_ID,
    phen.PREFERRED_NAME as ENTITY2,
    vp_rel.ENTITY2_TYPE,
    CASE WHEN phen.tellic_id LIKE "EFO%" or phen.tellic_id  like "%_Phenotype" THEN phen.tellic_id
    ELSE CONCAT("EFO", phen.tellic_id)
    END as entity2_concept_id ,  
    phen.tellic_id as pheno_tellic_id,
    vp_rel.REL_TYPE,
    vp_rel.STRENGTH,
    vp_rel.RESULT,
    vp_rel.RESULT_TYPE,
    vp_rel.CONFIDENCE,
    vp_rel.lineage,
    vp_rel.METADATA
    from
    (select * from
        ark.t_variant_phenotype_relationships
        ) vp_rel
        left outer join
        ark.t_variant_entities var
        on vp_rel.entity1 = var.id
        left outer join
        ark.t_phenotype_entities phen
        on vp_rel.entity2 = phen.id
        where size(var.tellic_id)<>0
     )rel
),
variant_phenotype_triples_mesh_efo_mapping as (
    select distinct
    fvp.ENTITY1,
    fvp.ENTITY1_TYPE,
    fvp.ENTITY1_CONCEPT_ID,
    fvp.ENTITY2,
    fvp.ENTITY2_TYPE,
    COALESCE(b.end_node, fvp.ENTITY2_CONCEPT_ID) as ENTITY2_CONCEPT_ID,
    fvp.pheno_tellic_id,
    fvp.REL_TYPE,
    fvp.STRENGTH,
    fvp.RESULT,
    fvp.RESULT_TYPE,
    fvp.CONFIDENCE,
    fvp.LINEAGE,
    fvp.METADATA
    from 
    variant_phenotype_triples fvp
    LEFT JOIN tellic_abbvie.efo_mesh_remapping b
    ON fvp.ENTITY2_CONCEPT_ID = b.start_node
)
select distinct
triples.ENTITY2 as ENTITY1,
triples.ENTITY2_TYPE as ENTITY1_TYPE,
replace(triples.pheno_tellic_id,':','') AS ENTITY1_CONCEPT_ID,
coalesce(he.entity_2_name,triples.entity2) as ENTITY2,
'Health Condition' as ENTITY2_TYPE,
coalesce(he.end_node,replace(er.tellic_code,':',''),concat(triples.entity2,'_HealthCondition')) as ENTITY2_CONCEPT_ID,
'IS_MEMBER' AS REL_TYPE,
triples.STRENGTH,
triples.RESULT,
triples.RESULT_TYPE,
triples.CONFIDENCE,
triples.LINEAGE,
triples.METADATA
from 
variant_phenotype_triples_mesh_efo_mapping triples
left outer join 
tellic_abbvie.tellic_graph_data_solr_relationships_is_member_health_event he
on triples.entity2_concept_id=he.start_node
left outer join
academe.health_condition_disease_v6_0_08dec2021 er
on triples.ENTITY2=er.abbv_term
where he.start_node is null 
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
