import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_compound_compound_metabolite_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT 
ENTITY1,
split(ENTITY1_TYPE,":")[1] as ENTITY1_TYPE,
ENTITY2,
split(ENTITY2_TYPE,":")[1] as ENTITY2_TYPE,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
t1.LINEAGE,
named_struct(
	"ENTITY1_PROP",
		named_struct("CHEMBL_ID",comp.CHEMBL_ID,
					"DRUG_NAME",comp.DRUG_NAME,
					"INCHI_KEY",comp.INCHI_KEY,
					"ANUMBER",comp.ABBVIE_ID,
					"MOLECULE_TYPE",comp.MOLECULE_TYPE,
					"PRIMARYIDENTIFIER",comp.PRIMARYIDENTIFIER),
	"ENTITY2_PROP",
		named_struct("CHEMBL_ID",comp2.CHEMBL_ID,
					"DRUG_NAME",comp2.DRUG_NAME,
					"INCHI_KEY",comp2.INCHI_KEY,
					"ANUMBER",comp2.ABBVIE_ID,
					"MOLECULE_TYPE",comp2.MOLECULE_TYPE,
					"PRIMARYIDENTIFIER",comp2.PRIMARYIDENTIFIER),
	"REL_PROP",t1.metadata
) as METADATA
from ark.t_compound_compound_metabolite_relationships t1
left outer join ark.t_compound_entities comp
ON t1.ENTITY1 = comp.ID
left outer join ark.t_compound_entities comp2
ON t1.ENTITY2 = comp2.ID
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
