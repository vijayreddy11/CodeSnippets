import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_gene_cell_line_triples"
val almaren = Almaren(set_name)

val res=almaren.builder.sourceSql("""
SELECT DISTINCT 
ENTITY1,
ENTITY1_TYPE,
ENTITY1_CONCEPT_ID_GENE AS ENTITY1_CONCEPT_ID,
ENTITY2,
ENTITY2_TYPE,
ENTITY1_CONCEPT_ID_CELL_LINE AS ENTITY2_CONCEPT_ID,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
LINEAGE,
METADATA
FROM (
SELECT DISTINCT gene.HGNC as ENTITY1,
	t1.ENTITY1_TYPE,
	gene.TELLIC_ID AS ENTITY1_CONCEPT_ID,
    cell_line.PREFERRED_NAME as ENTITY2,
	t1.ENTITY2_TYPE,
	cell_line.TELLIC_ID AS ENTITY2_CONCEPT_ID,
	t1.REL_TYPE,
	t1.STRENGTH,
	t1.RESULT,
	t1.RESULT_TYPE,
	t1.CONFIDENCE,
	t1.LINEAGE,
	named_struct(
	"REL_PROP",t1.metadata.rel_prop
) as METADATA
FROM ark.t_gene_cell_line_relationships t1
LEFT JOIN ark.t_gene_entities  gene 
on t1.ENTITY1=gene.ID
LEFT OUTER JOIN
ark.t_cellline_entities cell_line
on t1.ENTITY2=cell_line.ID)X
LATERAL VIEW explode(X.ENTITY1_CONCEPT_ID) expval AS ENTITY1_CONCEPT_ID_GENE
LATERAL VIEW explode(SPLIT(X.ENTITY2_CONCEPT_ID,'\\|')) expval AS ENTITY1_CONCEPT_ID_CELL_LINE
WHERE  ENTITY1 is not null and ENTITY2 is not null""").batch

res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/development/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
