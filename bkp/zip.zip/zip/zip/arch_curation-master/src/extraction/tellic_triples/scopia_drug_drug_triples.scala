import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_scopia_drug_drug_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT DISTINCT
    t1.ENTITY1_ID as ENTITY1,
    "Drug" as ENTITY1_TYPE,
    t1.ENTITY2_ID as ENTITY2,
    "Drug" as ENTITY2_TYPE,
    t1.REL_TYPE,
    t1.STRENGTH,
    t1.CONFIDENCE,
    t1.SCOPIA_STRENGTH AS RESULT,
    'ScopiaRX Score' AS RESULT_TYPE,
    named_struct(
        "RULESETS",array("SCOPIA_DRUG_DRUG_STRENGTH","SCOPIA_DRUG_DRUG_REL_TYPE"),
        "SOURCES",array("preclinical.t_scopiarx_di_main","preclinical.t_drug_reference"),
        "FILTERS",array(),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.0"
    ) as LINEAGE,
    named_struct(
        "ENTITY1_PROP",named_struct("DRUG",t1.ENTITY2,"ID",drug1.ID,"MOA",drug1.MOA),
        "ENTITY2_PROP",named_struct("DRUG",t1.ENTITY1,"ID",drug2.ID,"MOA",drug2.MOA),
	    "REL_PROP",named_struct("SCOPIA_STRENGTH",t1.SCOPIA_STRENGTH,
        "CODES",t1.CODES,
        "SEVERITY",t1.SEVERITY,
        "MAGNITUDE",t1.MAGNITUDE,
        "SOURCE",t1.SOURCE,
        "COMMENT",t1.COMMENT)) as METADATA
FROM (
    SELECT
    	ai_di as ENTITY1,
      drug1.ENTITY1_ID,
    	ai_dps as ENTITY2,
    	'Drug' as ENTITY2_TYPE,
    	drug2.ENTITY2_ID,
    	ae as AE,
    	score as Scopia_Strength,
    	display_string as codes,
    	'ScopiaRx - DI' as SOURCE,
    	display_string as COMMENT,
    	1.0 as CONFIDENCE,
    	CASE
    	  WHEN array_contains(split(display_string,' '),'(bw)') THEN 'Box Warning'
    	  WHEN array_contains(split(display_string,' '),'(w)') THEN 'Warning'
    	  WHEN array_contains(split(display_string,' '),'(ca)') THEN 'Caution'
    	  WHEN array_contains(split(display_string,' '),'(contra)') THEN 'Contra-indicated'
    	  ELSE 'Not Specified'
    	END AS SEVERITY,
    	CASE
    	  WHEN array_contains(split(display_string,' '),'(min)') THEN 'Minor'
    	  WHEN array_contains(split(display_string,' '),'(mod)') THEN 'Moderate'
    	  WHEN array_contains(split(display_string,' '),'(sev)') THEN 'Severe'
    	  ELSE 'Not Specified'
    	END AS MAGNITUDE,
    	CASE
    	  WHEN array_contains(split(display_string,' '),'(contra)') THEN 4
    	  WHEN array_contains(split(display_string,' '),'(sev)') THEN 3
    	  WHEN array_contains(split(display_string,' '),'(mod)') THEN 2
    	  ELSE 1
    	END AS STRENGTH,
    	CASE
    		  WHEN locate('increases the effect of',display_string)>0 THEN "Increases The Effect Of"
    		  WHEN locate('decreases the effect of',display_string)>0 THEN "Decreases The Effect Of"
    		  WHEN locate('interaction',display_string)>0 THEN "Has An Interaction With"
        ELSE NULL
      END AS REL_TYPE
     FROM preclinical.t_scopiarx_di_main_03062021 aes
    LEFT JOIN (
      select 
        scopia_name as ENTITY1,
        identifier as ENTITY1_ID,
        num_components
      from preclinical.r_scopia_chembl_ids
      WHERE 
        scopia_name IS NOT NULL AND
        scopia_name > ''
    ) drug1 on aes.ai_di=drug1.ENTITY1
    LEFT JOIN (
      select 
        scopia_name as ENTITY2,
        identifier as ENTITY2_ID,
        num_components
      from preclinical.r_scopia_chembl_ids
      WHERE 
        scopia_name IS NOT NULL AND
        scopia_name > ''
    ) drug2 on aes.ai_dps=drug2.ENTITY2
    WHERE 
      ai_di is not null and ai_dps is not null and ai_di<>ai_dps and ai_di>'' and ai_dps>'' and
      drug1.ENTITY1_ID is not null and drug1.ENTITY1_ID>'' and
      drug2.ENTITY2_ID is not null and drug2.ENTITY2_ID>''
) t1
LEFT JOIN ark.t_drug_entities drug1  on  t1.ENTITY1_ID= drug1.id
LEFT JOIN ark.t_drug_entities drug2  on  t1.ENTITY2_ID= drug2.id
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
