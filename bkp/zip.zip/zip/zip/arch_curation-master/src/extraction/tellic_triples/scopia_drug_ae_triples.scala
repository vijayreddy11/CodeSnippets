## Based on v1.0.0 release we including this scopia_rare_ae triple also in this triple.
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")

val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_scopia_drug_ae_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
with NORM as (
SELECT 
    regexp_replace(aedb.embl_code,"&","|") as ENTITY1_ID,
    ":Drug" as ENTITY1_TYPE,
    aedb.ai as ENTITY1,
    concat("MDR",split(cast(aedb.meddra_code as string),'\\.')[0]) as ENTITY2_ID,
    aedb.ae as ENTITY2,
    ":Patient Adverse Event" as ENTITY2_TYPE,
    aedb.SCORE as SCORE,
    aedb.CODES as CODES,
    cast(aedb.total_after_market_reports_for_drug as integer) as NUM_REPORTS,
    cast(aedb.total_reports_for_drug_and_adverse_event as integer) as NUM_AE_REPORTS,
    cast(replace(aedb.aftermarket_reporting_freq,'%','') as double) as RESULT,
    aedb.grade_3_percent as GRADE_3_PERCENT,
    aedb.grade_4_percent as GRADE_4_PERCENT,
    aedb.grade_3or4_percent as GRADE_3OR4_PERCENT,
    LENGTH(regexp_replace(aedb.ai,'[^;]',''))+1 as NUM_COMPONENTS,
    LENGTH(regexp_replace(aedb.ai,'[^&]',''))+1 as NUM_IDS,
    -1 as STRENGTH,
    'N' as ONLABEL,
    aedb.ai
FROM ARCH_NORMALIZED.SCOPIARX_2020Q4_V4_AE_MAIN_DB_NORM aedb
where 1=1
)
,STRENGTH_RULE_1 as (
select 
    ENTITY1_ID,
    ENTITY1_TYPE,
    ENTITY1,
    ENTITY2_ID,
    ENTITY2,
    ENTITY2_TYPE,
    SCORE,
    CODES,
    GRADE_3_PERCENT,
    GRADE_4_PERCENT,
    GRADE_3OR4_PERCENT,
    NUM_REPORTS,
    NUM_AE_REPORTS,
    NUM_COMPONENTS,
    NUM_IDS,
    RESULT,
    AI,
    case 
        when STRENGTH < 0 and  array_contains(split(CODES," "),'vc') THEN 'Y'
        when STRENGTH < 0 and  array_contains(split(CODES," "),'c') THEN 'Y'
        when array_contains(split(CODES," "),'bw') THEN 'Y'
        when array_contains(split(CODES," "),'w') THEN 'Y'
        when array_contains(split(CODES," "),'ca') THEN 'Y'
        else ONLABEL
    end as ONLABEL,
    /* Assign Frequency and Severity from label */
    case 
        when array_contains(split(CODES," "),'bw') THEN 'Box Warning'
        when array_contains(split(CODES," "),'w') THEN 'Warning'
        when array_contains(split(CODES," "),'ca') THEN 'Caution'
        else "Not Specified"
    end as SEVERITY,
    /* Assign Frequency and Severity from label */
    case
        when STRENGTH < 0 and  array_contains(split(CODES," "),'vc') THEN 'Very Common'
        when STRENGTH < 0 and  array_contains(split(CODES," "),'c') THEN 'Common'
    end as FREQUENCY,
    concat("Code =",".",CODES) as COMMENT,
    case 
        when STRENGTH < 0 and  array_contains(split(CODES," "),'vc') THEN 3
        when STRENGTH < 0 and  array_contains(split(CODES," "),'c') THEN 2
        else STRENGTH
    end as STRENGTH
from NORM n
)
,STRENGTH_RULE_2 as(
Select 
    ENTITY1_ID,
    ENTITY1_TYPE,
    ENTITY1,
    ENTITY2_ID,
    ENTITY2,
    ENTITY2_TYPE,
    SCORE,
    CODES,
    GRADE_3_PERCENT,
    GRADE_4_PERCENT,
    GRADE_3OR4_PERCENT,
    NUM_REPORTS,
    NUM_AE_REPORTS,
    NUM_COMPONENTS,
    NUM_IDS,
    ONLABEL,
    RESULT,
    AI,
    SEVERITY,
    COMMENT,
    /* Warning with no frequency on label - default strength to 1 */
    case
        when STRENGTH < 0 and ONLABEL = 'Y' THEN "not specified in label"
        else FREQUENCY
    end as FREQUENCY,
    /* Warning with no frequency on label - default strength to 1 */
    case
        when STRENGTH < 0 and ONLABEL = 'Y' THEN 1
        else STRENGTH
    end as STRENGTH
from STRENGTH_RULE_1 sr1
)
,RESULT_RULE_1 as (
select 
    ENTITY1_ID,
    ENTITY1_TYPE,
    ENTITY1,
    ENTITY2_ID,
    ENTITY2,
    ENTITY2_TYPE,
    SCORE,
    CODES,
    GRADE_3_PERCENT,
    GRADE_4_PERCENT,
    GRADE_3OR4_PERCENT,
    NUM_REPORTS,
    NUM_AE_REPORTS,
    NUM_COMPONENTS,
    NUM_IDS,
    STRENGTH,
    AI,
    ONLABEL,
    SEVERITY,
    FREQUENCY,
    COMMENT,
    /* Calc Result if P4 available */
    CASE 
        WHEN NUM_REPORTS is not null and cast(NUM_REPORTS as double) is not null THEN 100*NUM_AE_REPORTS/NUM_REPORTS 
        else RESULT 
    end as RESULT,
    CASE 
        WHEN NUM_REPORTS is not null and cast(NUM_REPORTS as double) is not null THEN  "Reporting Frequency (%)" 
    end as RESULT_TYPE
from STRENGTH_RULE_2 sr2
)
,RESULT_RULE_2 as (
select 
    ENTITY1_ID,
    ENTITY1_TYPE,
    ENTITY1,
    ENTITY2_ID,
    ENTITY2,
    ENTITY2_TYPE,
    SCORE,
    CODES,
    GRADE_3_PERCENT,
    GRADE_4_PERCENT,
    GRADE_3OR4_PERCENT,
    NUM_REPORTS,
    NUM_AE_REPORTS,
    NUM_COMPONENTS,
    NUM_IDS,
    ONLABEL,
    SEVERITY,
    RESULT_TYPE,
    COMMENT,
    RESULT,
    AI,
    case 
        when RESULT is not null and STRENGTH < 0 then "post-market reports"
        else FREQUENCY
    end as FREQUENCY,
    /* Assign strength from result for all non-label P4 reports */
    case 
        when RESULT is not null and STRENGTH < 0 THEN    
    ( case 
    when RESULT >= 10 Then 3 
    when RESULT >= 1 Then 2
    when RESULT >= 0.1 THEN 1
    else 0
      end
    )
        else STRENGTH
    end as STRENGTH
from RESULT_RULE_1 rr1
)
,CONFIDENCE_RULE as (
select 
    ENTITY1_ID,
    ENTITY1_TYPE,
    ENTITY1,
    ENTITY2_ID,
    ENTITY2,
    ENTITY2_TYPE,
    SCORE,
    CODES,
    GRADE_3_PERCENT,
    GRADE_4_PERCENT,
    GRADE_3OR4_PERCENT,
    NUM_REPORTS,
    NUM_AE_REPORTS,
    NUM_COMPONENTS,
    NUM_IDS,
    ONLABEL,
    RESULT,
    AI,
    SEVERITY,
    FREQUENCY,
    COMMENT,
    STRENGTH,
    RESULT_TYPE,
    case 
        when ONLABEL = 'Y' then 1.0
        when (RESULT is not null and cast(RESULT as double) is not null) then 
          case 
          when 0.5 * Sqrt(Power(Log10(NUM_AE_REPORTS) / Log10(10),2) + Power(Log10(NUM_REPORTS) / Log10(10000),2))<=0.9 then 0.5 * Sqrt(Power(Log10(NUM_AE_REPORTS) / Log10(10),2) + Power(Log10(NUM_REPORTS) / Log10(10000),2))
          else 0.9
          end
    end as CONFIDENCE
FROM RESULT_RULE_2
where NUM_COMPONENTS = NUM_IDS
)
,ENTITY1_ID_FILTER as (
select *
from CONFIDENCE_RULE c
where 1=1
and ((ENTITY1_ID is not null and length(ENTITY1_ID) > 0) and (ENTITY2_ID is not null and length(ENTITY2_ID) > 0))
and strength>=0
)
,PROPERTY_LIST as (
select 
ENTITY1,
ENTITY1_ID,
ENTITY1_TYPE,
ENTITY2,
ENTITY2_ID,
ENTITY2_TYPE,
STRENGTH,
CONFIDENCE,
FREQUENCY,
SEVERITY,
COMMENT,
RESULT,
AI,
RESULT_TYPE,
NUM_AE_REPORTS,
NUM_REPORTS,
ONLABEL,
NUM_COMPONENTS,
GRADE_3_PERCENT,
GRADE_4_PERCENT,
GRADE_3OR4_PERCENT
from ENTITY1_ID_FILTER
)
, ENTITY2_ADVERSEEVENT as (
SELECT ENTITY2_ID from PRECLINICAL.R_ADVERSEEVENT_EXCLUSIONS
)
, JOINER as (
select pl.* 
from PROPERTY_LIST pl left outer join ENTITY2_ADVERSEEVENT ea
on pl.ENTITY2_ID = ea.ENTITY2_ID
where ea.ENTITY2_ID is null
)
, ENTITY2_FILTER as (
select * from JOINER
where ENTITY2 != 'noae'
)
,DRUG_ADVERSEEVENT as (
select 
ENTITY1_ID as ENTITY1,
ENTITY1_TYPE,
ENTITY2_ID as ENTITY2,
ENTITY2_TYPE,
'Has Side Effect' as REL_TYPE,
STRENGTH,
RESULT,
AI,
RESULT_TYPE,
CONFIDENCE,
named_struct(
      "RULESETS",array(""),
      "SOURCES",array("scopiarx_2020q4_v4", "preclinical.t_adverseevent_exclusions"),
      "FILTERS",array("strength>0"),
      "TIMESTAMP",unix_timestamp(),
      "VERSION","1.3.0"
) as LINEAGE,
named_struct(
"COMMENT",COMMENT,
"SOURCE","Scopia",
"ONLABEL",ONLABEL,
"GRADE_3_PERCENT",GRADE_3_PERCENT,
"GRADE_4_PERCENT",GRADE_4_PERCENT,
"GRADE_3OR4_PERCENT",GRADE_3OR4_PERCENT,
"REPORTS",NUM_REPORTS,
"AES",NUM_AE_REPORTS,
"SEVERITY",SEVERITY,
"FREQUENCY",FREQUENCY
) as METADATA
from ENTITY2_FILTER
)
,DRUG_AE as (
select 
ENTITY1,
ENTITY1_TYPE,
ENTITY2,
ENTITY2_TYPE,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
AI,
CONFIDENCE,
LINEAGE,
METADATA
from 
(
  select *,row_number() over(partition by ENTITY1,ENTITY2 order by ENTITY1) as ROWNUM from DRUG_ADVERSEEVENT
) a
where ROWNUM = 1
)
select 
ENTITY1,
ENTITY1_TYPE,
ENTITY2,
ENTITY2_TYPE,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
DRUG_AE.LINEAGE,
named_struct(
	"ENTITY1_PROP",named_struct("ACTIVE_INGREDIENT",AI,"ID",drug.ID,"MOA",drug.MOA),
  "ENTITY2_PROP",named_struct("ADVERSE_EVENT",ae_entities.AE),
	"REL_PROP",named_struct(
		"COMMENT",METADATA.COMMENT,
		"SOURCE","Scopia",
		"ONLABEL",METADATA.ONLABEL,
		"GRADE_3_PERCENT",METADATA.GRADE_3_PERCENT,
		"GRADE_4_PERCENT",METADATA.GRADE_4_PERCENT,
		"GRADE_3OR4_PERCENT",METADATA.GRADE_3OR4_PERCENT,
		"REPORTS",METADATA.REPORTS,
		"AES",METADATA.AES,
		"SEVERITY",METADATA.SEVERITY,
		"FREQUENCY",METADATA.FREQUENCY
		)
) as METADATA
from DRUG_AE
LEFT JOIN ark.t_drug_entities drug 
on  DRUG_AE.ENTITY1= drug.id
LEFT JOIN 
(select distinct id,concat_ws('|',collect_set(ae)) AS ae 
from 
(select * from ark.t_adverseevent_entities order by ae desc)y group by id) as ae_entities 
on DRUG_AE.ENTITY2=ae_entities.id
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
