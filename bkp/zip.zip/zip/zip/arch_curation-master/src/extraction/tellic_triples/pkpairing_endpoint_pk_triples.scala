import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.Almaren

val args = sc.getConf.get("spark.driver.args").split("\\s+")
val environment = args(0)
val data_store = "integrated"
val db_name = "ark"
val set_name = "t_pkpairing_endpoint_pk_triples"
val almaren = Almaren(set_name)

val res = almaren.builder.sourceSql("""
SELECT 
ENTITY1,
split(ENTITY1_TYPE,":")[1] as ENTITY1_TYPE,
ENTITY2,
split(ENTITY2_TYPE,":")[2] as ENTITY2_TYPE,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
t1.LINEAGE,
named_struct(
	"ENTITY1_PROP",
		named_struct("PRIMARYIDENTIFIER",pkpairing.PRIMARYIDENTIFIER),
	"ENTITY2_PROP",
		named_struct("PRIMARYIDENTIFIER",pk.PRIMARYIDENTIFIER),
	"REL_PROP",t1.metadata
) as METADATA
from ark.t_pkpairing_endpoint_pk_relationships t1
left outer join ark.t_pkpairing_entities pkpairing
ON t1.ENTITY1 = pkpairing.ID
left outer join ark.t_endpoint_pk_entities pk
ON t1.ENTITY2 = pk.ID 
""").batch
res.write.mode("OVERWRITE").option("format", "parquet").option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
