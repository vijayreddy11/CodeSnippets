import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;

public class SparkTemplate {
    public static void main(String[] args) {
        String environment = "dev" ;
        String db_name = "genomics_dev" ;
        String table_name = "table_name" ;
        String sql = "" ;

        Integer no_of_cores = 5 ;
        Integer no_of_executors = 5 ;
        Integer executor_memory = 15 ;
        Integer driver_memory = 10 ;
        Boolean dynamicAllocation = false ;
        STGroup stGroup = new STGroupFile("C:\\Users\\gudurvk\\Workarea\\DecryptRSA\\PGActivity\\src\\main\\resources\\spark.stg", '$', '$');
        String sparkcode = stGroup.getInstanceOf("sparkshell")
                .add("environment",environment)
                .add("db_name", db_name)
                .add("table_name", table_name)
                .add("sql", sql)
                .add("no_of_cores",no_of_cores)
                .add("no_of_executors", no_of_executors)
                .add("executor_memory", executor_memory)
                .add("driver_memory", driver_memory)
                .add("dynamicAllocation", dynamicAllocation)
                .render();
        System.out.println("\n" + sparkcode);
    }
}
