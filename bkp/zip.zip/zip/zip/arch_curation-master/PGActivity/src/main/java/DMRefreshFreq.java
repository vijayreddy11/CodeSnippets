import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;

import java.util.Scanner;

public class DMRefreshFreq extends PgAdmin {

    public static void main(String[] args) throws Exception {
        /////////////////////////////////////////////////////////////////////////////////////////////

        String data_movement_ids = "1240";

        ////////////////////////////////////////////////////////////////////////////////////////////
        DMRefreshFreq dmRefreshFreq = new DMRefreshFreq();
        dmRefreshFreq.init(data_movement_ids);
    }

    private void init(String data_movement_ids) throws Exception {

        STGroup stGroup = new STGroupFile("C:\\Users\\gudurvk\\Workarea\\test\\PGActivity\\src\\main\\resources\\queries.stg", '$', '$');
        String updateDM = stGroup.getInstanceOf("updateDM")
                .add("data_movement_ids", data_movement_ids)
                .add("refreshfreq", getRefreshFreq(2))
                .render();

        System.out.println("===============================================================================");
        System.out.println("Your Query: \n" + updateDM);
        System.out.println("===============================================================================");
        initDB();
        String viewDMName = stGroup.getInstanceOf("getDMName")
                .add("data_movement_ids", data_movement_ids)
                .render();
        System.out.println(utils.executeQuery(conn, viewDMName));
        System.out.println("===============================================================================");
        System.out.println("Should I go ahead : Y or N");
        Scanner sc = new Scanner(System.in);
        String bool = sc.nextLine();
        if (bool.equalsIgnoreCase("N")) {
            System.out.println("Process Aborted");
            System.exit(1);
        }
        System.out.println("The process is scheduled :---");

        utils.executeUpdateQuery(conn, updateDM);

        String viewDM = stGroup.getInstanceOf("viewDM2")
                .add("data_movement_ids", data_movement_ids)
                .render();

        System.out.println(utils.executeQuery(conn, viewDM));
        if (conn != null)
            conn.close();
    }
}
