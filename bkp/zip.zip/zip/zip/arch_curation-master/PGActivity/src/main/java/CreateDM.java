import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;
import utility.JSONUtils;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CreateDM extends PgAdmin {

    ////////////////////////////////////////////////////////////////////////////////////////////////

    private String data_movement_name = "";
    private String environment = "dev";
    private String file_path = "arch_curation/src/normalization/gtex_b38_geneannotation_norm.py";
    private String directory_path = "arch_curation";
    private String git_url = "git@pig.abbvienet.com:arch/arch_curation.git";

    ////////////////////////////////////////////////////////////////////////////////////////////////

    public static void main(String[] args) throws Exception {
        CreateDM createDM = new CreateDM();

        createDM.init();
        //createDM.writeToJson();
    }

    private void init() throws Exception {

        STGroup stGroup = new STGroupFile("C:\\Users\\gudurvk\\Workarea\\test\\PGActivity\\src\\main\\resources\\queries.stg", '$', '$');
        String createDM = stGroup.getInstanceOf("createDM")
                .add("data_movement_name", data_movement_name)
                .add("env", environment)
                .add("directory_path", directory_path)
                .add("file_path", file_path)
                .add("git_url", git_url)
                .add("refreshfreq", getRefreshFreq(10))
                .render();
        System.out.println("=================================================================================================================================");
        System.out.println("Your Query: \n" + createDM);
        System.out.println("=================================================================================================================================");
    }

    public void writeToJson() {
        Map jsonObject = new HashMap();
        jsonObject.put("data_movement_name", data_movement_name);
        jsonObject.put("file_path", file_path);
        jsonObject.put("directory_path", directory_path);
        jsonObject.put("git_url", git_url);
        try {
            FileWriter file = new FileWriter("C:\\Users\\gudurvk\\Workarea\\SparkTemplate\\PGActivity\\src\\main\\resources\\dm_config.json");
            file.write(JSONUtils.map2JsonString(jsonObject));
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
