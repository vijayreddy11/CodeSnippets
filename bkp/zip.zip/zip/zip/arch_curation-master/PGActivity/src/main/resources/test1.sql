table_name	column_name	applied_anon_func	applied_reason
clinical_trials_harmonized.ae	accessts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	actevent	Keep	NULL
clinical_trials_harmonized.ae	ae1acdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	ae1acdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	ae1acdtp	Keep	NULL
clinical_trials_harmonized.ae	ae2acdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	ae2acdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	ae2acdtp	Keep	NULL
clinical_trials_harmonized.ae	ae3acdtc	Keep	NULL
clinical_trials_harmonized.ae	ae3acdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	ae3acdtp	Keep	NULL
clinical_trials_harmonized.ae	aeac1dte	Keep	NULL
clinical_trials_harmonized.ae	aeac2dte	Keep	NULL
clinical_trials_harmonized.ae	aeac3dte	Keep	NULL
clinical_trials_harmonized.ae	aeacdd1	Keep	NULL
clinical_trials_harmonized.ae	aeacdd2	Keep	NULL
clinical_trials_harmonized.ae	aeacdd3	Keep	NULL
clinical_trials_harmonized.ae	aeacdd4	Keep	NULL
clinical_trials_harmonized.ae	aeacdp	Keep	NULL
clinical_trials_harmonized.ae	aeacdr1	Keep	NULL
clinical_trials_harmonized.ae	aeacdr2	Keep	NULL
clinical_trials_harmonized.ae	aeacdr3	Keep	NULL
clinical_trials_harmonized.ae	aeacdr4	Keep	NULL
clinical_trials_harmonized.ae	aeacdr	Keep	NULL
clinical_trials_harmonized.ae	aeacea	Keep	NULL
clinical_trials_harmonized.ae	aeacer	Keep	NULL
clinical_trials_harmonized.ae	aeacid1	Keep	NULL
clinical_trials_harmonized.ae	aeacid2	Keep	NULL
clinical_trials_harmonized.ae	aeacid3	Keep	NULL
clinical_trials_harmonized.ae	aeacid4	Keep	NULL
clinical_trials_harmonized.ae	aeacid	Keep	NULL
clinical_trials_harmonized.ae	aeacmd	Keep	NULL
clinical_trials_harmonized.ae	aeacn1	Keep	NULL
clinical_trials_harmonized.ae	aeacn4	Keep	NULL
clinical_trials_harmonized.ae	aeacn5	Keep	NULL
clinical_trials_harmonized.ae	aeacn6	Keep	NULL
clinical_trials_harmonized.ae	aeacnabt	Keep	NULL
clinical_trials_harmonized.ae	aeacnccm	Keep	NULL
clinical_trials_harmonized.ae	aeacncs	Keep	NULL
clinical_trials_harmonized.ae	aeacnd1	Keep	NULL
clinical_trials_harmonized.ae	aeacnd2	Keep	NULL
clinical_trials_harmonized.ae	aeacnd3	Keep	NULL
clinical_trials_harmonized.ae	aeacnd4	Keep	NULL
clinical_trials_harmonized.ae	aeacnd5	Keep	NULL
clinical_trials_harmonized.ae	aeacndcm	Keep	NULL
clinical_trials_harmonized.ae	aeacndd1	Keep	NULL
clinical_trials_harmonized.ae	aeacndd2	Keep	NULL
clinical_trials_harmonized.ae	aeacndd3	Keep	NULL
clinical_trials_harmonized.ae	aeacndd4	Keep	NULL
clinical_trials_harmonized.ae	aeacndd	Keep	NULL
clinical_trials_harmonized.ae	aeacndm	Keep	NULL
clinical_trials_harmonized.ae	aeacndn1	Keep	NULL
clinical_trials_harmonized.ae	aeacndn2	Keep	NULL
clinical_trials_harmonized.ae	aeacndn3	Keep	NULL
clinical_trials_harmonized.ae	aeacndn4	Keep	NULL
clinical_trials_harmonized.ae	aeacndnp	Keep	NULL
clinical_trials_harmonized.ae	aeacndp1	Keep	NULL
clinical_trials_harmonized.ae	aeacndp2	Keep	NULL
clinical_trials_harmonized.ae	aeacndp	Keep	NULL
clinical_trials_harmonized.ae	aeacndr1	Keep	NULL
clinical_trials_harmonized.ae	aeacndr2	Keep	NULL
clinical_trials_harmonized.ae	aeacndr3	Keep	NULL
clinical_trials_harmonized.ae	aeacndr4	Keep	NULL
clinical_trials_harmonized.ae	aeacndr5	Keep	NULL
clinical_trials_harmonized.ae	aeacndr	Keep	NULL
clinical_trials_harmonized.ae	aeacnds	Keep	NULL
clinical_trials_harmonized.ae	aeacnd	Keep	NULL
clinical_trials_harmonized.ae	aeacner	Keep	NULL
clinical_trials_harmonized.ae	aeacnha	Keep	NULL
clinical_trials_harmonized.ae	aeacnid1	Keep	NULL
clinical_trials_harmonized.ae	aeacnid2	Keep	NULL
clinical_trials_harmonized.ae	aeacnid3	Keep	NULL
clinical_trials_harmonized.ae	aeacnid4	Keep	NULL
clinical_trials_harmonized.ae	aeacnid5	Keep	NULL
clinical_trials_harmonized.ae	aeacnid	Keep	NULL
clinical_trials_harmonized.ae	aeacnlom	Keep	NULL
clinical_trials_harmonized.ae	aeacnmd1	Keep	NULL
clinical_trials_harmonized.ae	aeacnmd2	Keep	NULL
clinical_trials_harmonized.ae	aeacnmd3	Keep	NULL
clinical_trials_harmonized.ae	aeacnmd	Keep	NULL
clinical_trials_harmonized.ae	aeacnmr	Keep	NULL
clinical_trials_harmonized.ae	aeacnm	Keep	NULL
clinical_trials_harmonized.ae	aeacnmt	Keep	NULL
clinical_trials_harmonized.ae	aeacnnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeacnn	Keep	NULL
clinical_trials_harmonized.ae	aeacno2	Keep	NULL
clinical_trials_harmonized.ae	aeacnosp	Keep	NULL
clinical_trials_harmonized.ae	aeacno	Keep	NULL
clinical_trials_harmonized.ae	aeacnot1	Keep	NULL
clinical_trials_harmonized.ae	aeacnot2	Keep	NULL
clinical_trials_harmonized.ae	aeacnot3	Keep	NULL
clinical_trials_harmonized.ae	aeacnoth	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeacnrp1	Keep	NULL
clinical_trials_harmonized.ae	aeacnrp2	Keep	NULL
clinical_trials_harmonized.ae	aeacnrp3	Keep	NULL
clinical_trials_harmonized.ae	aeacnrp4	Keep	NULL
clinical_trials_harmonized.ae	aeacnrp	Keep	NULL
clinical_trials_harmonized.ae	aeacn	Keep	NULL
clinical_trials_harmonized.ae	aeacntmz	Keep	NULL
clinical_trials_harmonized.ae	aeacr	Keep	NULL
clinical_trials_harmonized.ae	aeacrv	Keep	NULL
clinical_trials_harmonized.ae	aeacsp	Keep	NULL
clinical_trials_harmonized.ae	aeacst	Keep	NULL
clinical_trials_harmonized.ae	aeaddr1	Keep	NULL
clinical_trials_harmonized.ae	aeaddr2	Keep	NULL
clinical_trials_harmonized.ae	aeaddr3	Keep	NULL
clinical_trials_harmonized.ae	aeaddr4	Keep	NULL
clinical_trials_harmonized.ae	aeaddr5	Keep	NULL
clinical_trials_harmonized.ae	aeaddr	Keep	NULL
clinical_trials_harmonized.ae	aeadel1	Keep	NULL
clinical_trials_harmonized.ae	aeadel2	Keep	NULL
clinical_trials_harmonized.ae	aeadel3	Keep	NULL
clinical_trials_harmonized.ae	aeadel4	Keep	NULL
clinical_trials_harmonized.ae	aeadel5	Keep	NULL
clinical_trials_harmonized.ae	aeadel	Keep	NULL
clinical_trials_harmonized.ae	aeadev	Keep	NULL
clinical_trials_harmonized.ae	aeadit1	Keep	NULL
clinical_trials_harmonized.ae	aeadit2	Keep	NULL
clinical_trials_harmonized.ae	aeadit3	Keep	NULL
clinical_trials_harmonized.ae	aeadit4	Keep	NULL
clinical_trials_harmonized.ae	aeadit5	Keep	NULL
clinical_trials_harmonized.ae	aeadit	Keep	NULL
clinical_trials_harmonized.ae	aeadjcl1	Keep	NULL
clinical_trials_harmonized.ae	aeadjcl2	Keep	NULL
clinical_trials_harmonized.ae	aeadjcl3	Keep	NULL
clinical_trials_harmonized.ae	aeadjdtc	Keep	NULL
clinical_trials_harmonized.ae	aeadjdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeadjdtp	Keep	NULL
clinical_trials_harmonized.ae	aeadjdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeadjedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeadjot2	Keep	NULL
clinical_trials_harmonized.ae	aeadjsp2	Keep	NULL
clinical_trials_harmonized.ae	aeadjsp3	Keep	NULL
clinical_trials_harmonized.ae	aeadnr1	Keep	NULL
clinical_trials_harmonized.ae	aeadnr2	Keep	NULL
clinical_trials_harmonized.ae	aeadnr3	Keep	NULL
clinical_trials_harmonized.ae	aeadnr4	Keep	NULL
clinical_trials_harmonized.ae	aeadnrp1	Keep	NULL
clinical_trials_harmonized.ae	aeadnrp2	Keep	NULL
clinical_trials_harmonized.ae	aeadnrp3	Keep	NULL
clinical_trials_harmonized.ae	aeadnrp4	Keep	NULL
clinical_trials_harmonized.ae	aeadnrp5	Keep	NULL
clinical_trials_harmonized.ae	aeadnrp	Keep	NULL
clinical_trials_harmonized.ae	aeadpr	Keep	NULL
clinical_trials_harmonized.ae	aeadrp1	Keep	NULL
clinical_trials_harmonized.ae	aeadrp2	Keep	NULL
clinical_trials_harmonized.ae	aeadrp3	Keep	NULL
clinical_trials_harmonized.ae	aeadrp4	Keep	NULL
clinical_trials_harmonized.ae	aeadrp5	Keep	NULL
clinical_trials_harmonized.ae	aeadrp	Keep	NULL
clinical_trials_harmonized.ae	aeadr	Keep	NULL
clinical_trials_harmonized.ae	aeadsnp	Keep	NULL
clinical_trials_harmonized.ae	aeadsrp	Keep	NULL
clinical_trials_harmonized.ae	aeaeno	Keep	NULL
clinical_trials_harmonized.ae	aeaerno	Keep	NULL
clinical_trials_harmonized.ae	aeage	Age	Use Age for age column
clinical_trials_harmonized.ae	aeanemfl	Keep	NULL
clinical_trials_harmonized.ae	aeant	Keep	NULL
clinical_trials_harmonized.ae	aeaoer	Keep	NULL
clinical_trials_harmonized.ae	aeare1cd	Keep	NULL
clinical_trials_harmonized.ae	aeare2cd	Keep	NULL
clinical_trials_harmonized.ae	aeare3cd	Keep	NULL
clinical_trials_harmonized.ae	aeare4cd	Keep	NULL
clinical_trials_harmonized.ae	aearecd2	Keep	NULL
clinical_trials_harmonized.ae	aearec	Keep	NULL
clinical_trials_harmonized.ae	aearel1	Keep	NULL
clinical_trials_harmonized.ae	aearel2	Keep	NULL
clinical_trials_harmonized.ae	aearel3	Keep	NULL
clinical_trials_harmonized.ae	aearel4	Keep	NULL
clinical_trials_harmonized.ae	aearelcd	Keep	NULL
clinical_trials_harmonized.ae	aeareln	Keep	NULL
clinical_trials_harmonized.ae	aearel	Keep	NULL
clinical_trials_harmonized.ae	aeareon	Keep	NULL
clinical_trials_harmonized.ae	aeareo	Keep	NULL
clinical_trials_harmonized.ae	aeasexn	Keep	NULL
clinical_trials_harmonized.ae	aeasex	Keep	NULL
clinical_trials_harmonized.ae	aeasnrp	Keep	NULL
clinical_trials_harmonized.ae	aeasrp	Keep	NULL
clinical_trials_harmonized.ae	aebdsycd	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aebodsys	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aebore	Keep	NULL
clinical_trials_harmonized.ae	aecardia	Keep	NULL
clinical_trials_harmonized.ae	aecatcd	Keep	NULL
clinical_trials_harmonized.ae	aecat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aecdth	Keep	NULL
clinical_trials_harmonized.ae	aececoad	Keep	NULL
clinical_trials_harmonized.ae	aecejtub	Keep	NULL
clinical_trials_harmonized.ae	aecelcig	Keep	NULL
clinical_trials_harmonized.ae	aecenjtu	Keep	NULL
clinical_trials_harmonized.ae	aecepegt	Keep	NULL
clinical_trials_harmonized.ae	aecepump	Keep	NULL
clinical_trials_harmonized.ae	aecestom	Keep	NULL
clinical_trials_harmonized.ae	aecetppr	Keep	NULL
clinical_trials_harmonized.ae	aechron	Keep	NULL
clinical_trials_harmonized.ae	aecns	Keep	NULL
clinical_trials_harmonized.ae	aecoadsp	Keep	NULL
clinical_trials_harmonized.ae	aecoalc	Keep	NULL
clinical_trials_harmonized.ae	aecoalrh	Keep	NULL
clinical_trials_harmonized.ae	aecoalrs	Keep	NULL
clinical_trials_harmonized.ae	aecocdrh	Keep	NULL
clinical_trials_harmonized.ae	aecocdrs	Keep	NULL
clinical_trials_harmonized.ae	aecomcdr	Keep	NULL
clinical_trials_harmonized.ae	aecontrt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aecoucrh	Keep	NULL
clinical_trials_harmonized.ae	aecoucrs	Keep	NULL
clinical_trials_harmonized.ae	aecva	Keep	NULL
clinical_trials_harmonized.ae	aecvatia	Keep	NULL
clinical_trials_harmonized.ae	aecvhosp	Keep	NULL
clinical_trials_harmonized.ae	aedecod	Keep	Detected Entity "clinical_aedecod"
clinical_trials_harmonized.ae	aedfas01	Keep	NULL
clinical_trials_harmonized.ae	aedfas02	Keep	NULL
clinical_trials_harmonized.ae	aedfas03	Keep	NULL
clinical_trials_harmonized.ae	aediag	Keep	NULL
clinical_trials_harmonized.ae	aedict	Keep	NULL
clinical_trials_harmonized.ae	aedictv	Keep	NULL
clinical_trials_harmonized.ae	aedltn	Keep	NULL
clinical_trials_harmonized.ae	aedlt	Keep	NULL
clinical_trials_harmonized.ae	aedrel	Keep	NULL
clinical_trials_harmonized.ae	aedsprg	Keep	NULL
clinical_trials_harmonized.ae	aedsrel	Keep	NULL
clinical_trials_harmonized.ae	aedt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aedtmp	Keep	NULL
clinical_trials_harmonized.ae	aedtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aedtp	Keep	NULL
clinical_trials_harmonized.ae	aedurc	Keep	NULL
clinical_trials_harmonized.ae	aedur	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aedxcnf1	Keep	NULL
clinical_trials_harmonized.ae	aedxcnf2	Keep	NULL
clinical_trials_harmonized.ae	aedxcnf8	Keep	NULL
clinical_trials_harmonized.ae	aedxcnf9	Keep	NULL
clinical_trials_harmonized.ae	aedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeedtce	Keep	NULL
clinical_trials_harmonized.ae	aeedtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeedt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeedtp	Keep	NULL
clinical_trials_harmonized.ae	aeedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeeedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeendtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeendt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeendte	Keep	NULL
clinical_trials_harmonized.ae	aeendtmp	Keep	NULL
clinical_trials_harmonized.ae	aeendtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeendtp	Keep	NULL
clinical_trials_harmonized.ae	aeendy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeened	Keep	NULL
clinical_trials_harmonized.ae	aeenedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeenrtpt	Keep	NULL
clinical_trials_harmonized.ae	aeentmc	Keep	NULL
clinical_trials_harmonized.ae	aeentme	Keep	NULL
clinical_trials_harmonized.ae	aeentmp	Keep	NULL
clinical_trials_harmonized.ae	aeentm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeentpt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeepochd	Keep	NULL
clinical_trials_harmonized.ae	aeepoch	Keep	NULL
clinical_trials_harmonized.ae	aeetiol	Keep	NULL
clinical_trials_harmonized.ae	aeetmp	Keep	NULL
clinical_trials_harmonized.ae	aeeval	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aefuout1	Keep	NULL
clinical_trials_harmonized.ae	aefuout2	Keep	NULL
clinical_trials_harmonized.ae	aegiperf	Keep	NULL
clinical_trials_harmonized.ae	aegodt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aegrpid	Keep	NULL
clinical_trials_harmonized.ae	aehep	Keep	NULL
clinical_trials_harmonized.ae	aehgcd	Keep	NULL
clinical_trials_harmonized.ae	aehgtcd	Keep	NULL
clinical_trials_harmonized.ae	aehgt	Keep	NULL
clinical_trials_harmonized.ae	aehivcd	Keep	NULL
clinical_trials_harmonized.ae	aehiv	Keep	NULL
clinical_trials_harmonized.ae	aehlcd	Keep	NULL
clinical_trials_harmonized.ae	aehlgtcd	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aehlgt	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aehltcd	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aehlt	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aehyp	Keep	NULL
clinical_trials_harmonized.ae	aehypsty	Keep	NULL
clinical_trials_harmonized.ae	aeiakild	Keep	NULL
clinical_trials_harmonized.ae	aeiakind	Keep	NULL
clinical_trials_harmonized.ae	aeianemi	Keep	NULL
clinical_trials_harmonized.ae	aeiangi	Keep	NULL
clinical_trials_harmonized.ae	aeicancr	Keep	NULL
clinical_trials_harmonized.ae	aeicatcd	Keep	NULL
clinical_trials_harmonized.ae	aeicat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeicdeth	Keep	NULL
clinical_trials_harmonized.ae	aeichflr	Keep	NULL
clinical_trials_harmonized.ae	aeicorev	Keep	NULL
clinical_trials_harmonized.ae	aeideath	Keep	NULL
clinical_trials_harmonized.ae	aeielvat	Keep	NULL
clinical_trials_harmonized.ae	aeifmyif	Keep	NULL
clinical_trials_harmonized.ae	aeifstrk	Keep	NULL
clinical_trials_harmonized.ae	aeihmrep	Keep	NULL
clinical_trials_harmonized.ae	aeihosp	Keep	NULL
clinical_trials_harmonized.ae	aeihypem	Keep	NULL
clinical_trials_harmonized.ae	aeimusm	Keep	NULL
clinical_trials_harmonized.ae	aeincomp	Keep	NULL
clinical_trials_harmonized.ae	aeinfr	Keep	NULL
clinical_trials_harmonized.ae	aeinmyif	Keep	NULL
clinical_trials_harmonized.ae	aeinoa	Keep	NULL
clinical_trials_harmonized.ae	aeinstrk	Keep	NULL
clinical_trials_harmonized.ae	aeipere	Keep	NULL
clinical_trials_harmonized.ae	aeirinj	Keep	NULL
clinical_trials_harmonized.ae	aeitiata	Keep	NULL
clinical_trials_harmonized.ae	aeiwckd	Keep	NULL
clinical_trials_harmonized.ae	aelltcd	Keep	Detected Entity "clinical_aelltcd"
clinical_trials_harmonized.ae	aellt	Keep	Detected Entity "clinical_aellt"
clinical_trials_harmonized.ae	aeloc	Keep	NULL
clinical_trials_harmonized.ae	aemalg	Keep	NULL
clinical_trials_harmonized.ae	aemali	Keep	NULL
clinical_trials_harmonized.ae	aemint	Keep	NULL
clinical_trials_harmonized.ae	aemod1	Keep	NULL
clinical_trials_harmonized.ae	aemodify	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aemre1cd	Keep	NULL
clinical_trials_harmonized.ae	aemre2cd	Keep	NULL
clinical_trials_harmonized.ae	aemrel1	Keep	NULL
clinical_trials_harmonized.ae	aemrel2	Keep	NULL
clinical_trials_harmonized.ae	aemrelcd	Keep	NULL
clinical_trials_harmonized.ae	aemrel	Keep	NULL
clinical_trials_harmonized.ae	aemspc	Keep	NULL
clinical_trials_harmonized.ae	aencitcd	Keep	NULL
clinical_trials_harmonized.ae	aencitl	Keep	NULL
clinical_trials_harmonized.ae	aencitn	Keep	NULL
clinical_trials_harmonized.ae	aencit	Keep	NULL
clinical_trials_harmonized.ae	aendn	Keep	NULL
clinical_trials_harmonized.ae	aendtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeneuro	Keep	NULL
clinical_trials_harmonized.ae	aenew	Keep	NULL
clinical_trials_harmonized.ae	aeno	Keep	NULL
clinical_trials_harmonized.ae	aenoncar	Keep	NULL
clinical_trials_harmonized.ae	aentdtc	Keep	NULL
clinical_trials_harmonized.ae	aentdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aentdte	Keep	NULL
clinical_trials_harmonized.ae	aentdtp	Keep	NULL
clinical_trials_harmonized.ae	aeoacmd	Keep	NULL
clinical_trials_harmonized.ae	aeoacmp	Keep	NULL
clinical_trials_harmonized.ae	aeoacnds	Keep	NULL
clinical_trials_harmonized.ae	aeoacnmt	Keep	NULL
clinical_trials_harmonized.ae	aeoacnn	Keep	NULL
clinical_trials_harmonized.ae	aeoacosp	Keep	NULL
clinical_trials_harmonized.ae	aeoaco	Keep	NULL
clinical_trials_harmonized.ae	aeoacpp	Keep	NULL
clinical_trials_harmonized.ae	aeoacscn	Keep	NULL
clinical_trials_harmonized.ae	aeoacscr	Keep	NULL
clinical_trials_harmonized.ae	aeoadpr	Keep	NULL
clinical_trials_harmonized.ae	aeoadsnp	Keep	NULL
clinical_trials_harmonized.ae	aeoadsrp	Keep	NULL
clinical_trials_harmonized.ae	aeoads	Keep	NULL
clinical_trials_harmonized.ae	aeoage	Age	Use Age for age column
clinical_trials_harmonized.ae	aeoaoer	Keep	NULL
clinical_trials_harmonized.ae	aeoaotsp	Keep	NULL
clinical_trials_harmonized.ae	aeoaot	Keep	NULL
clinical_trials_harmonized.ae	aeocnmt	Keep	NULL
clinical_trials_harmonized.ae	aeodtce	Keep	NULL
clinical_trials_harmonized.ae	aeodtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeodt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeodtp	Keep	NULL
clinical_trials_harmonized.ae	aeody	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeoedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeoeose	Keep	NULL
clinical_trials_harmonized.ae	aeofint	Keep	NULL
clinical_trials_harmonized.ae	aeongdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeongdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aeongdte	Keep	NULL
clinical_trials_harmonized.ae	aeongdtp	Keep	NULL
clinical_trials_harmonized.ae	aeongdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeongedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeongo	Keep	NULL
clinical_trials_harmonized.ae	aeored	Keep	NULL
clinical_trials_harmonized.ae	aeoutcd	Keep	NULL
clinical_trials_harmonized.ae	aeoutc	Keep	NULL
clinical_trials_harmonized.ae	aeout	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aepattcd	Keep	NULL
clinical_trials_harmonized.ae	aepatt	Keep	NULL
clinical_trials_harmonized.ae	aepattl	Keep	NULL
clinical_trials_harmonized.ae	aepattn	Keep	NULL
clinical_trials_harmonized.ae	aepcrs01	Keep	NULL
clinical_trials_harmonized.ae	aepcrs02	Keep	NULL
clinical_trials_harmonized.ae	aepcrs03	Keep	NULL
clinical_trials_harmonized.ae	aepcrs04	Keep	NULL
clinical_trials_harmonized.ae	aepcrs05	Keep	NULL
clinical_trials_harmonized.ae	aepc	Keep	NULL
clinical_trials_harmonized.ae	aepdocn	Keep	NULL
clinical_trials_harmonized.ae	aepdoc	Keep	NULL
clinical_trials_harmonized.ae	aepdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aepecd	Keep	NULL
clinical_trials_harmonized.ae	aepoch	Keep	NULL
clinical_trials_harmonized.ae	aepostpr	Keep	NULL
clinical_trials_harmonized.ae	aepqc	Keep	NULL
clinical_trials_harmonized.ae	aeprefid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ae	aeprel	Keep	NULL
clinical_trials_harmonized.ae	aepsrn	Keep	NULL
clinical_trials_harmonized.ae	aeptcd	Keep	NULL
clinical_trials_harmonized.ae	aeptcq	Keep	NULL
clinical_trials_harmonized.ae	aeptc	Keep	NULL
clinical_trials_harmonized.ae	aeptq	Keep	NULL
clinical_trials_harmonized.ae	aept	Keep	NULL
clinical_trials_harmonized.ae	aeq	Keep	NULL
clinical_trials_harmonized.ae	aerdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aerdvc	Keep	NULL
clinical_trials_harmonized.ae	aere1cd0	Keep	NULL
clinical_trials_harmonized.ae	aerefid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ae	aerel10	Keep	NULL
clinical_trials_harmonized.ae	aerel1cd	Keep	NULL
clinical_trials_harmonized.ae	aerel1	Keep	NULL
clinical_trials_harmonized.ae	aerel1n	Keep	NULL
clinical_trials_harmonized.ae	aerel2cd	Keep	NULL
clinical_trials_harmonized.ae	aerel2	Keep	NULL
clinical_trials_harmonized.ae	aerel2n	Keep	NULL
clinical_trials_harmonized.ae	aerel3cd	Keep	NULL
clinical_trials_harmonized.ae	aerel3	Keep	NULL
clinical_trials_harmonized.ae	aerel3n	Keep	NULL
clinical_trials_harmonized.ae	aerel4cd	Keep	NULL
clinical_trials_harmonized.ae	aerel4	Keep	NULL
clinical_trials_harmonized.ae	aerel5cd	Keep	NULL
clinical_trials_harmonized.ae	aerel5	Keep	NULL
clinical_trials_harmonized.ae	aerel6cd	Keep	NULL
clinical_trials_harmonized.ae	aerel6	Keep	NULL
clinical_trials_harmonized.ae	aerel7cd	Keep	NULL
clinical_trials_harmonized.ae	aerel7	Keep	NULL
clinical_trials_harmonized.ae	aerel8cd	Keep	NULL
clinical_trials_harmonized.ae	aerel8	Keep	NULL
clinical_trials_harmonized.ae	aerel9cd	Keep	NULL
clinical_trials_harmonized.ae	aerel9	Keep	NULL
clinical_trials_harmonized.ae	aerelabt	Keep	NULL
clinical_trials_harmonized.ae	aerelcd1	Keep	NULL
clinical_trials_harmonized.ae	aerelcd2	Keep	NULL
clinical_trials_harmonized.ae	aerelcd3	Keep	NULL
clinical_trials_harmonized.ae	aerelcd4	Keep	NULL
clinical_trials_harmonized.ae	aerelcd5	Keep	NULL
clinical_trials_harmonized.ae	aerelcd6	Keep	NULL
clinical_trials_harmonized.ae	aerelcd7	Keep	NULL
clinical_trials_harmonized.ae	aerelcd8	Keep	NULL
clinical_trials_harmonized.ae	aerelcd	Keep	NULL
clinical_trials_harmonized.ae	aereldis	Keep	NULL
clinical_trials_harmonized.ae	aerelep	Keep	NULL
clinical_trials_harmonized.ae	aerell1	Keep	NULL
clinical_trials_harmonized.ae	aerell2	Keep	NULL
clinical_trials_harmonized.ae	aerellom	Keep	NULL
clinical_trials_harmonized.ae	aerells	Keep	NULL
clinical_trials_harmonized.ae	aerell	Keep	NULL
clinical_trials_harmonized.ae	aereln1	Keep	NULL
clinical_trials_harmonized.ae	aereln2	Keep	NULL
clinical_trials_harmonized.ae	aereln3	Keep	NULL
clinical_trials_harmonized.ae	aereln4	Keep	NULL
clinical_trials_harmonized.ae	aereln	Keep	NULL
clinical_trials_harmonized.ae	aerelns1	Keep	NULL
clinical_trials_harmonized.ae	aerelns2	Keep	NULL
clinical_trials_harmonized.ae	aerelns3	Keep	NULL
clinical_trials_harmonized.ae	aerelns4	Keep	NULL
clinical_trials_harmonized.ae	aerelns5	Keep	NULL
clinical_trials_harmonized.ae	aerelns6	Keep	NULL
clinical_trials_harmonized.ae	aerelns7	Keep	NULL
clinical_trials_harmonized.ae	aerelns8	Keep	NULL
clinical_trials_harmonized.ae	aerelns9	Keep	NULL
clinical_trials_harmonized.ae	aerelnsc	Keep	NULL
clinical_trials_harmonized.ae	aerelns	Keep	NULL
clinical_trials_harmonized.ae	aerelnst	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aerelo1	Keep	NULL
clinical_trials_harmonized.ae	aerelo2	Keep	NULL
clinical_trials_harmonized.ae	aerelo3	Keep	NULL
clinical_trials_harmonized.ae	aerelo4	Keep	NULL
clinical_trials_harmonized.ae	aerelo	Keep	NULL
clinical_trials_harmonized.ae	aerelpsp	Keep	NULL
clinical_trials_harmonized.ae	aerelp	Keep	NULL
clinical_trials_harmonized.ae	aerelscl	Keep	NULL
clinical_trials_harmonized.ae	aerel	Keep	NULL
clinical_trials_harmonized.ae	aereltls	Keep	NULL
clinical_trials_harmonized.ae	aereltmz	Keep	NULL
clinical_trials_harmonized.ae	aerens10	Keep	NULL
clinical_trials_harmonized.ae	aerlcd10	Keep	NULL
clinical_trials_harmonized.ae	aerlcd9	Keep	NULL
clinical_trials_harmonized.ae	aernjt	Keep	NULL
clinical_trials_harmonized.ae	aersd	Keep	NULL
clinical_trials_harmonized.ae	aersv	Keep	NULL
clinical_trials_harmonized.ae	aertyp	Keep	NULL
clinical_trials_harmonized.ae	aescat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aescong	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aescon	Keep	NULL
clinical_trials_harmonized.ae	aesctcq	Keep	NULL
clinical_trials_harmonized.ae	aesctc	Keep	NULL
clinical_trials_harmonized.ae	aesctq	Keep	NULL
clinical_trials_harmonized.ae	aesct	Keep	NULL
clinical_trials_harmonized.ae	aesdisab	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aesdis	Keep	NULL
clinical_trials_harmonized.ae	aesdth	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeseab	Keep	NULL
clinical_trials_harmonized.ae	aesecdd	Keep	NULL
clinical_trials_harmonized.ae	aesecd	Keep	NULL
clinical_trials_harmonized.ae	aesecdx	Keep	NULL
clinical_trials_harmonized.ae	aeseqd	Keep	NULL
clinical_trials_harmonized.ae	aeseq	Keep	NULL
clinical_trials_harmonized.ae	aeser	Keep	NULL
clinical_trials_harmonized.ae	aeserl	Keep	NULL
clinical_trials_harmonized.ae	aesern	Keep	NULL
clinical_trials_harmonized.ae	aesevcd	Keep	NULL
clinical_trials_harmonized.ae	aesevl	Keep	NULL
clinical_trials_harmonized.ae	aesevn	Keep	NULL
clinical_trials_harmonized.ae	aesev	Keep	NULL
clinical_trials_harmonized.ae	aeshosp	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeshos	Keep	NULL
clinical_trials_harmonized.ae	aesimp	Keep	NULL
clinical_trials_harmonized.ae	aesins	Keep	NULL
clinical_trials_harmonized.ae	aesint1	Keep	NULL
clinical_trials_harmonized.ae	aesint2	Keep	NULL
clinical_trials_harmonized.ae	aesint3	Keep	NULL
clinical_trials_harmonized.ae	aesint4	Keep	NULL
clinical_trials_harmonized.ae	aesint5	Keep	NULL
clinical_trials_harmonized.ae	aesint6	Keep	NULL
clinical_trials_harmonized.ae	aesint7	Keep	NULL
clinical_trials_harmonized.ae	aesintfr	Keep	NULL
clinical_trials_harmonized.ae	aesintnp	Keep	NULL
clinical_trials_harmonized.ae	aesintrh	Keep	NULL
clinical_trials_harmonized.ae	aesint	Keep	NULL
clinical_trials_harmonized.ae	aesleep	Keep	NULL
clinical_trials_harmonized.ae	aeslife	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeslif	Keep	NULL
clinical_trials_harmonized.ae	aesmie	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aesmsab	Keep	NULL
clinical_trials_harmonized.ae	aesmsin	Keep	NULL
clinical_trials_harmonized.ae	aesmsi	Keep	NULL
clinical_trials_harmonized.ae	aesoccd	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aesoc	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aesphosp	Keep	NULL
clinical_trials_harmonized.ae	aespho	Keep	NULL
clinical_trials_harmonized.ae	aespid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ae	aesren	Keep	NULL
clinical_trials_harmonized.ae	aesre	Keep	NULL
clinical_trials_harmonized.ae	aesrn	Keep	NULL
clinical_trials_harmonized.ae	aessab	Keep	NULL
clinical_trials_harmonized.ae	aessvr	Keep	NULL
clinical_trials_harmonized.ae	aest72hr	Keep	NULL
clinical_trials_harmonized.ae	aestdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aestdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aestdte	Keep	NULL
clinical_trials_harmonized.ae	aestdti	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aestdtmp	Keep	NULL
clinical_trials_harmonized.ae	aestdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aestdtp	Keep	NULL
clinical_trials_harmonized.ae	aestdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aested	Keep	NULL
clinical_trials_harmonized.ae	aestedy2	Keep	NULL
clinical_trials_harmonized.ae	aestedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aestpd	Keep	NULL
clinical_trials_harmonized.ae	aestpdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aestpdyx	Keep	NULL
clinical_trials_harmonized.ae	ae	Keep	NULL
clinical_trials_harmonized.ae	aesttmc	Keep	NULL
clinical_trials_harmonized.ae	aesttme	Keep	NULL
clinical_trials_harmonized.ae	aesttmp	Keep	NULL
clinical_trials_harmonized.ae	aesttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aestt	Keep	NULL
clinical_trials_harmonized.ae	aesympsp	Keep	NULL
clinical_trials_harmonized.ae	aetdmp	Keep	NULL
clinical_trials_harmonized.ae	aetdm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aetdtce	Keep	NULL
clinical_trials_harmonized.ae	aetdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aetdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	aetdtp	Keep	NULL
clinical_trials_harmonized.ae	aetdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aetedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeterm10	Keep	NULL
clinical_trials_harmonized.ae	aeterm1	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeterm2	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeterm3	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeterm4	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeterm5	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeterm6	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeterm7	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeterm8	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aeterm9	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aetermo	Keep	NULL
clinical_trials_harmonized.ae	aeterm	Redact	user hardcoded rule
clinical_trials_harmonized.ae	aetmcn	Keep	NULL
clinical_trials_harmonized.ae	aetmc	Keep	NULL
clinical_trials_harmonized.ae	aetoxgr	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	aetoxs	Keep	NULL
clinical_trials_harmonized.ae	aetox	Keep	NULL
clinical_trials_harmonized.ae	aettmp	Keep	NULL
clinical_trials_harmonized.ae	aetucol	Keep	NULL
clinical_trials_harmonized.ae	aetzss01	Keep	NULL
clinical_trials_harmonized.ae	aetzss02	Keep	NULL
clinical_trials_harmonized.ae	aeuvev	Keep	NULL
clinical_trials_harmonized.ae	aevae	Keep	NULL
clinical_trials_harmonized.ae	aewdsl	Keep	NULL
clinical_trials_harmonized.ae	aewdsn	Keep	NULL
clinical_trials_harmonized.ae	aewds	Keep	NULL
clinical_trials_harmonized.ae	agec	Age	Use Age for age column
clinical_trials_harmonized.ae	arisae	Keep	NULL
clinical_trials_harmonized.ae	blstatcd	Keep	NULL
clinical_trials_harmonized.ae	blstat	Keep	NULL
clinical_trials_harmonized.ae	brtdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	brthdtc	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	brthdt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	brthdte	Keep	NULL
clinical_trials_harmonized.ae	brthdtp	Keep	NULL
clinical_trials_harmonized.ae	comploph	Keep	NULL
clinical_trials_harmonized.ae	complosp	Keep	NULL
clinical_trials_harmonized.ae	conan	Keep	NULL
clinical_trials_harmonized.ae	country	Keep	NULL
clinical_trials_harmonized.ae	cpevent	Keep	NULL
clinical_trials_harmonized.ae	dcmdate	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	dcmdd	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	dcmname	Keep	NULL
clinical_trials_harmonized.ae	dcmsubnm	Keep	NULL
clinical_trials_harmonized.ae	dcmtime	Keep	NULL
clinical_trials_harmonized.ae	death	Keep	NULL
clinical_trials_harmonized.ae	disab	Keep	NULL
clinical_trials_harmonized.ae	disc	Keep	NULL
clinical_trials_harmonized.ae	docnum	Keep	NULL
clinical_trials_harmonized.ae	domain	Keep	NULL
clinical_trials_harmonized.ae	dtarisae	Keep	NULL
clinical_trials_harmonized.ae	durcq	Keep	NULL
clinical_trials_harmonized.ae	durc	Keep	NULL
clinical_trials_harmonized.ae	eab	Keep	NULL
clinical_trials_harmonized.ae	edcix	Keep	NULL
clinical_trials_harmonized.ae	epoch	Keep	NULL
clinical_trials_harmonized.ae	etiolq	Keep	NULL
clinical_trials_harmonized.ae	etiol	Keep	NULL
clinical_trials_harmonized.ae	eyerl	Keep	NULL
clinical_trials_harmonized.ae	gnpage	Age	Use Age for age column
clinical_trials_harmonized.ae	hosptlq	Keep	NULL
clinical_trials_harmonized.ae	hosptl	Keep	NULL
clinical_trials_harmonized.ae	idvar	Keep	NULL
clinical_trials_harmonized.ae	idvarval	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ae	invid	Redact	Detected Entity with tag PII "clinical_invid"
clinical_trials_harmonized.ae	invind	Keep	NULL
clinical_trials_harmonized.ae	invnam	Redact	Detected Facet with tag PII "clinical_invnam"
clinical_trials_harmonized.ae	invno	Keep	NULL
clinical_trials_harmonized.ae	invsite	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ae	invsno	Keep	NULL
clinical_trials_harmonized.ae	invstn	Keep	NULL
clinical_trials_harmonized.ae	inv	Keep	NULL
clinical_trials_harmonized.ae	labatype	Keep	NULL
clinical_trials_harmonized.ae	lab_id	Keep	NULL
clinical_trials_harmonized.ae	labsn	Keep	NULL
clinical_trials_harmonized.ae	lab	Keep	NULL
clinical_trials_harmonized.ae	life	Keep	NULL
clinical_trials_harmonized.ae	lockflag	Keep	NULL
clinical_trials_harmonized.ae	logints	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	lstchgts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	msab	Keep	NULL
clinical_trials_harmonized.ae	msint	Keep	NULL
clinical_trials_harmonized.ae	noact	Keep	NULL
clinical_trials_harmonized.ae	ocuexam	Keep	NULL
clinical_trials_harmonized.ae	ongodd	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	ongodt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	othact	Keep	NULL
clinical_trials_harmonized.ae	othmed	Keep	NULL
clinical_trials_harmonized.ae	permd	Keep	NULL
clinical_trials_harmonized.ae	phosp	Keep	NULL
clinical_trials_harmonized.ae	pt	Keep	NULL
clinical_trials_harmonized.ae	qeval	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	qlabel	Keep	NULL
clinical_trials_harmonized.ae	qnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	qorig	Keep	NULL
clinical_trials_harmonized.ae	qualifyq	Keep	NULL
clinical_trials_harmonized.ae	qualifyv	Keep	NULL
clinical_trials_harmonized.ae	qval	Keep	NULL
clinical_trials_harmonized.ae	rdomain	Keep	NULL
clinical_trials_harmonized.ae	relabt	Keep	NULL
clinical_trials_harmonized.ae	rellom	Keep	NULL
clinical_trials_harmonized.ae	relnst	Keep	NULL
clinical_trials_harmonized.ae	relshpq	Keep	NULL
clinical_trials_harmonized.ae	relshp	Keep	NULL
clinical_trials_harmonized.ae	reltest2	Keep	NULL
clinical_trials_harmonized.ae	reltest	Keep	NULL
clinical_trials_harmonized.ae	reltmz	Keep	NULL
clinical_trials_harmonized.ae	repeatsn	Keep	NULL
clinical_trials_harmonized.ae	ri	Keep	NULL
clinical_trials_harmonized.ae	rowid	Keep	NULL
clinical_trials_harmonized.ae	saeq	Keep	NULL
clinical_trials_harmonized.ae	sae	Keep	NULL
clinical_trials_harmonized.ae	satest	Keep	NULL
clinical_trials_harmonized.ae	seqno	Keep	NULL
clinical_trials_harmonized.ae	sevrtqy	Keep	NULL
clinical_trials_harmonized.ae	sevrtqyt	Keep	NULL
clinical_trials_harmonized.ae	sevrtyq	Keep	NULL
clinical_trials_harmonized.ae	sevrty	Keep	NULL
clinical_trials_harmonized.ae	sex	Keep	NULL
clinical_trials_harmonized.ae	smdactq	Keep	NULL
clinical_trials_harmonized.ae	smdact	Keep	NULL
clinical_trials_harmonized.ae	soc	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	spec1	Keep	NULL
clinical_trials_harmonized.ae	spec2	Keep	NULL
clinical_trials_harmonized.ae	spec3	Keep	NULL
clinical_trials_harmonized.ae	specq1	Keep	NULL
clinical_trials_harmonized.ae	specq2	Keep	NULL
clinical_trials_harmonized.ae	stopdd	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	stopdtq	Keep	NULL
clinical_trials_harmonized.ae	stopdt	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.ae	stpdtae	Keep	NULL
clinical_trials_harmonized.ae	strtdd	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	strtdtq	Keep	NULL
clinical_trials_harmonized.ae	strtdt	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.ae	strttmae	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	strttmq	Keep	NULL
clinical_trials_harmonized.ae	strttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ae	studyid	Keep	Detected Entity "clinical_studyid"
clinical_trials_harmonized.ae	study	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ae	subeve	Keep	NULL
clinical_trials_harmonized.ae	subid	Keep	NULL
clinical_trials_harmonized.ae	subjid	FPENumeric	Detected Entity with tag PII "clinical_subjid"
clinical_trials_harmonized.ae	subsetsn	Keep	NULL
clinical_trials_harmonized.ae	timec	Keep	NULL
clinical_trials_harmonized.ae	txcom1ae	Keep	NULL
clinical_trials_harmonized.ae	txcom2ae	Keep	NULL
clinical_trials_harmonized.ae	txcom3ae	Keep	NULL
clinical_trials_harmonized.ae	usubjid	FPEAlphaNumeric	Detected Entity with tag PII "clinical_usubjid"
clinical_trials_harmonized.ae	varisae	Keep	NULL
clinical_trials_harmonized.ae	visit	Keep	NULL
clinical_trials_harmonized.ae	visitnum	Keep	NULL
clinical_trials_harmonized.ae	source_dataset	Keep	NULL
clinical_trials_harmonized.cm	accessts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	actevent	Keep	NULL
clinical_trials_harmonized.cm	aerefid1	Keep	NULL
clinical_trials_harmonized.cm	aerefid2	Keep	NULL
clinical_trials_harmonized.cm	aerefid3	Keep	NULL
clinical_trials_harmonized.cm	aerefid4	Keep	NULL
clinical_trials_harmonized.cm	aerefid5	Keep	NULL
clinical_trials_harmonized.cm	aerefid6	Keep	NULL
clinical_trials_harmonized.cm	aesrn	Keep	NULL
clinical_trials_harmonized.cm	cmacagnt	Keep	NULL
clinical_trials_harmonized.cm	cmaccd	Keep	NULL
clinical_trials_harmonized.cm	cmaesrn1	Keep	NULL
clinical_trials_harmonized.cm	cmaesrn2	Keep	NULL
clinical_trials_harmonized.cm	cmaesrn3	Keep	NULL
clinical_trials_harmonized.cm	cmaesrn4	Keep	NULL
clinical_trials_harmonized.cm	cmaesrn5	Keep	NULL
clinical_trials_harmonized.cm	cmaesrn	Keep	NULL
clinical_trials_harmonized.cm	cmae	Keep	NULL
clinical_trials_harmonized.cm	cmam	Keep	NULL
clinical_trials_harmonized.cm	cmange	Keep	NULL
clinical_trials_harmonized.cm	cmcatcd	Keep	NULL
clinical_trials_harmonized.cm	cmcatl	Keep	NULL
clinical_trials_harmonized.cm	cmcatn	Keep	NULL
clinical_trials_harmonized.cm	cmcat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmccd1	Keep	NULL
clinical_trials_harmonized.cm	cmccd2	Keep	NULL
clinical_trials_harmonized.cm	cmccd3	Keep	NULL
clinical_trials_harmonized.cm	cmccd4	Keep	NULL
clinical_trials_harmonized.cm	cmcd1	Keep	NULL
clinical_trials_harmonized.cm	cmcd2	Keep	NULL
clinical_trials_harmonized.cm	cmcdcd1	Keep	NULL
clinical_trials_harmonized.cm	cmcdcd2	Keep	NULL
clinical_trials_harmonized.cm	cmcdcd	Keep	NULL
clinical_trials_harmonized.cm	cmcdl1	Keep	NULL
clinical_trials_harmonized.cm	cmcdl2	Keep	NULL
clinical_trials_harmonized.cm	cmcdl	Keep	NULL
clinical_trials_harmonized.cm	cmcdsp	Keep	NULL
clinical_trials_harmonized.cm	cmcd	Keep	NULL
clinical_trials_harmonized.cm	cmclas1	Keep	NULL
clinical_trials_harmonized.cm	cmclas2	Keep	NULL
clinical_trials_harmonized.cm	cmclas3	Keep	NULL
clinical_trials_harmonized.cm	cmclas4	Keep	NULL
clinical_trials_harmonized.cm	cmclascd	Keep	NULL
clinical_trials_harmonized.cm	cmclas	Keep	NULL
clinical_trials_harmonized.cm	cmcls1cd	Keep	NULL
clinical_trials_harmonized.cm	cmcls1	Keep	NULL
clinical_trials_harmonized.cm	cmcls2cd	Keep	NULL
clinical_trials_harmonized.cm	cmcls2	Keep	NULL
clinical_trials_harmonized.cm	cmcls3cd	Keep	NULL
clinical_trials_harmonized.cm	cmcls3	Keep	NULL
clinical_trials_harmonized.cm	cmcls4cd	Keep	NULL
clinical_trials_harmonized.cm	cmcls4	Keep	NULL
clinical_trials_harmonized.cm	cmclscd1	Keep	NULL
clinical_trials_harmonized.cm	cmclscd2	Keep	NULL
clinical_trials_harmonized.cm	cmclscd3	Keep	NULL
clinical_trials_harmonized.cm	cmclscd4	Keep	NULL
clinical_trials_harmonized.cm	cmcoabio	Keep	NULL
clinical_trials_harmonized.cm	cmcoab	Keep	NULL
clinical_trials_harmonized.cm	cmcoacet	Keep	NULL
clinical_trials_harmonized.cm	cmcoaiad	Keep	NULL
clinical_trials_harmonized.cm	cmcoania	Keep	NULL
clinical_trials_harmonized.cm	cmcoan	Keep	NULL
clinical_trials_harmonized.cm	cmcoasal	Keep	NULL
clinical_trials_harmonized.cm	cmcoasdr	Keep	NULL
clinical_trials_harmonized.cm	cmcoas	Keep	NULL
clinical_trials_harmonized.cm	cmcoatnf	Keep	NULL
clinical_trials_harmonized.cm	cmcoat	Keep	NULL
clinical_trials_harmonized.cm	cmcoba	Keep	NULL
clinical_trials_harmonized.cm	cmcobd	Keep	NULL
clinical_trials_harmonized.cm	cmcobidm	Keep	NULL
clinical_trials_harmonized.cm	cmcobio	Keep	NULL
clinical_trials_harmonized.cm	cmcocdfl	Keep	NULL
clinical_trials_harmonized.cm	cmcocdra	Keep	NULL
clinical_trials_harmonized.cm	cmcocdrl	Keep	NULL
clinical_trials_harmonized.cm	cmcocort	Keep	NULL
clinical_trials_harmonized.cm	cmcoco	Keep	NULL
clinical_trials_harmonized.cm	cmcocp	Keep	NULL
clinical_trials_harmonized.cm	cmcocsdm	Keep	NULL
clinical_trials_harmonized.cm	cmcocypi	Keep	NULL
clinical_trials_harmonized.cm	cmcocy	Keep	NULL
clinical_trials_harmonized.cm	cmcodm	Keep	NULL
clinical_trials_harmonized.cm	cmcoet	Keep	NULL
clinical_trials_harmonized.cm	cmcohyal	Keep	NULL
clinical_trials_harmonized.cm	cmcoibda	Keep	NULL
clinical_trials_harmonized.cm	cmcoimsp	Keep	NULL
clinical_trials_harmonized.cm	cmcoim	Keep	NULL
clinical_trials_harmonized.cm	cmcois	Keep	NULL
clinical_trials_harmonized.cm	cmcomp	Keep	NULL
clinical_trials_harmonized.cm	cmcomt	Keep	NULL
clinical_trials_harmonized.cm	cmconarc	Keep	NULL
clinical_trials_harmonized.cm	cmconc	Keep	NULL
clinical_trials_harmonized.cm	cmcondb	Keep	NULL
clinical_trials_harmonized.cm	cmconep	Keep	NULL
clinical_trials_harmonized.cm	cmconsai	Keep	NULL
clinical_trials_harmonized.cm	cmcons	Keep	NULL
clinical_trials_harmonized.cm	cmcontnf	Keep	NULL
clinical_trials_harmonized.cm	cmconutr	Keep	NULL
clinical_trials_harmonized.cm	cmcopa	Keep	NULL
clinical_trials_harmonized.cm	cmcort	Keep	NULL
clinical_trials_harmonized.cm	cmcosc	Keep	NULL
clinical_trials_harmonized.cm	cmcosd	Keep	NULL
clinical_trials_harmonized.cm	cmcoss	Keep	NULL
clinical_trials_harmonized.cm	cmcosydm	Keep	NULL
clinical_trials_harmonized.cm	cmcosysn	Keep	NULL
clinical_trials_harmonized.cm	cmcota	Keep	NULL
clinical_trials_harmonized.cm	cmcotopn	Keep	NULL
clinical_trials_harmonized.cm	cmcotsdm	Keep	NULL
clinical_trials_harmonized.cm	cmcoucfl	Keep	NULL
clinical_trials_harmonized.cm	cmcovd	Keep	NULL
clinical_trials_harmonized.cm	cmcrohn	Keep	NULL
clinical_trials_harmonized.cm	cmcycr	Keep	NULL
clinical_trials_harmonized.cm	cmdecocd	Keep	NULL
clinical_trials_harmonized.cm	cmdecod	Keep	NULL
clinical_trials_harmonized.cm	cmdictl	Keep	NULL
clinical_trials_harmonized.cm	cmdictn	Keep	NULL
clinical_trials_harmonized.cm	cmdict	Keep	NULL
clinical_trials_harmonized.cm	cmdictv	Keep	NULL
clinical_trials_harmonized.cm	cmdicv	Keep	NULL
clinical_trials_harmonized.cm	cmdidtc	Keep	NULL
clinical_trials_harmonized.cm	cmdidt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmdidtp	Keep	NULL
clinical_trials_harmonized.cm	cmdisp	Keep	NULL
clinical_trials_harmonized.cm	cmdmarb	Keep	NULL
clinical_trials_harmonized.cm	cmdmard	Keep	NULL
clinical_trials_harmonized.cm	cmdmars	Keep	NULL
clinical_trials_harmonized.cm	cmdncd	Keep	NULL
clinical_trials_harmonized.cm	cmdosc1	Keep	NULL
clinical_trials_harmonized.cm	cmdosc2	Keep	NULL
clinical_trials_harmonized.cm	cmdosc	Keep	NULL
clinical_trials_harmonized.cm	cmdose	Keep	NULL
clinical_trials_harmonized.cm	cmdosee	Keep	NULL
clinical_trials_harmonized.cm	cmdosest	Keep	NULL
clinical_trials_harmonized.cm	cmdosfq	Keep	NULL
clinical_trials_harmonized.cm	cmdosfrm	Keep	NULL
clinical_trials_harmonized.cm	cmdosfrq	Keep	NULL
clinical_trials_harmonized.cm	cmdosf	Keep	NULL
clinical_trials_harmonized.cm	cmdostot	Keep	NULL
clinical_trials_harmonized.cm	cmdostxt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmdosu1	Keep	NULL
clinical_trials_harmonized.cm	cmdosu2	Keep	NULL
clinical_trials_harmonized.cm	cmdosusp	Keep	NULL
clinical_trials_harmonized.cm	cmdosu	Keep	NULL
clinical_trials_harmonized.cm	cmdoth	Keep	NULL
clinical_trials_harmonized.cm	cmdrug1	Keep	NULL
clinical_trials_harmonized.cm	cmdrug2	Keep	NULL
clinical_trials_harmonized.cm	cmdrug3	Keep	NULL
clinical_trials_harmonized.cm	cmdrug4	Keep	NULL
clinical_trials_harmonized.cm	cmdrug5	Keep	NULL
clinical_trials_harmonized.cm	cmdrug6	Keep	NULL
clinical_trials_harmonized.cm	cmdrug7	Keep	NULL
clinical_trials_harmonized.cm	cmdrugcd	Keep	NULL
clinical_trials_harmonized.cm	cmdrugd	Keep	NULL
clinical_trials_harmonized.cm	cmdrug	Keep	NULL
clinical_trials_harmonized.cm	cmdsp	Keep	NULL
clinical_trials_harmonized.cm	cmdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmdtp	Keep	NULL
clinical_trials_harmonized.cm	cmdur	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmduru	Keep	NULL
clinical_trials_harmonized.cm	cmdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmedmp	Keep	NULL
clinical_trials_harmonized.cm	cmedm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmedtce	Keep	NULL
clinical_trials_harmonized.cm	cmedtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmedt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmedtp	Keep	NULL
clinical_trials_harmonized.cm	cmedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmeedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmendtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.cm	cmendt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmendte	Keep	NULL
clinical_trials_harmonized.cm	cmendtmp	Keep	NULL
clinical_trials_harmonized.cm	cmendtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmendtp	Keep	NULL
clinical_trials_harmonized.cm	cmendy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmened	Keep	NULL
clinical_trials_harmonized.cm	cmenedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmenrtpt	Keep	NULL
clinical_trials_harmonized.cm	cmentmc	Keep	NULL
clinical_trials_harmonized.cm	cmentme	Keep	NULL
clinical_trials_harmonized.cm	cmentmp	Keep	NULL
clinical_trials_harmonized.cm	cmentm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmentpt	Keep	NULL
clinical_trials_harmonized.cm	cmepofl	Keep	NULL
clinical_trials_harmonized.cm	cmfama	Keep	NULL
clinical_trials_harmonized.cm	cmfqcd	Keep	NULL
clinical_trials_harmonized.cm	cmfqe	Keep	NULL
clinical_trials_harmonized.cm	cmfql	Keep	NULL
clinical_trials_harmonized.cm	cmfqn	Keep	NULL
clinical_trials_harmonized.cm	cmfqsp	Keep	NULL
clinical_trials_harmonized.cm	cmfq	Keep	NULL
clinical_trials_harmonized.cm	cmfract	Keep	NULL
clinical_trials_harmonized.cm	cmfrqsp	Keep	NULL
clinical_trials_harmonized.cm	cmfsyco	Keep	NULL
clinical_trials_harmonized.cm	cmgecd	Keep	NULL
clinical_trials_harmonized.cm	cmgen1	Keep	NULL
clinical_trials_harmonized.cm	cmgen2	Keep	NULL
clinical_trials_harmonized.cm	cmgen3	Keep	NULL
clinical_trials_harmonized.cm	cmgen4	Keep	NULL
clinical_trials_harmonized.cm	cmgen5	Keep	NULL
clinical_trials_harmonized.cm	cmgen6	Keep	NULL
clinical_trials_harmonized.cm	cmgen7	Keep	NULL
clinical_trials_harmonized.cm	cmgencd	Keep	NULL
clinical_trials_harmonized.cm	cmgend	Keep	NULL
clinical_trials_harmonized.cm	cmgen	Keep	NULL
clinical_trials_harmonized.cm	cmgrpid	Keep	NULL
clinical_trials_harmonized.cm	cmiendo	Keep	NULL
clinical_trials_harmonized.cm	cmihs	Keep	NULL
clinical_trials_harmonized.cm	cmimuno	Keep	NULL
clinical_trials_harmonized.cm	cmindcls	Keep	NULL
clinical_trials_harmonized.cm	cmindcsp	Keep	NULL
clinical_trials_harmonized.cm	cmindc	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cminvd	Keep	NULL
clinical_trials_harmonized.cm	cmioth	Keep	NULL
clinical_trials_harmonized.cm	cmirgr	Keep	NULL
clinical_trials_harmonized.cm	cmiron	Keep	NULL
clinical_trials_harmonized.cm	cmirvd	Keep	NULL
clinical_trials_harmonized.cm	cmisp	Keep	NULL
clinical_trials_harmonized.cm	cmlat	Keep	NULL
clinical_trials_harmonized.cm	cmlddtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.cm	cmlddt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmlddte	Keep	NULL
clinical_trials_harmonized.cm	cmlddtmp	Keep	NULL
clinical_trials_harmonized.cm	cmlddtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmlddtp	Keep	NULL
clinical_trials_harmonized.cm	cmldfqsp	Keep	NULL
clinical_trials_harmonized.cm	cmldose	Keep	NULL
clinical_trials_harmonized.cm	cmldosfq	Keep	NULL
clinical_trials_harmonized.cm	cmldosu	Keep	NULL
clinical_trials_harmonized.cm	cmldtce	Keep	NULL
clinical_trials_harmonized.cm	cmldtc	Keep	NULL
clinical_trials_harmonized.cm	cmldtp	Keep	NULL
clinical_trials_harmonized.cm	cmlnkid	Keep	NULL
clinical_trials_harmonized.cm	cmloc	Keep	NULL
clinical_trials_harmonized.cm	cmlot	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmmdose	Keep	NULL
clinical_trials_harmonized.cm	cmmdosu	Keep	NULL
clinical_trials_harmonized.cm	cmmodify	Keep	NULL
clinical_trials_harmonized.cm	cmndos	Keep	NULL
clinical_trials_harmonized.cm	cmnonrs	Keep	NULL
clinical_trials_harmonized.cm	cmnsaids	Keep	NULL
clinical_trials_harmonized.cm	cmnsaid	Keep	NULL
clinical_trials_harmonized.cm	cmoccrt	Keep	NULL
clinical_trials_harmonized.cm	cmoccur	Keep	NULL
clinical_trials_harmonized.cm	cmongoe	Keep	NULL
clinical_trials_harmonized.cm	cmongon	Keep	NULL
clinical_trials_harmonized.cm	cmongo	Keep	NULL
clinical_trials_harmonized.cm	cmouttrt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmpcdcd	Keep	NULL
clinical_trials_harmonized.cm	cmpcdl	Keep	NULL
clinical_trials_harmonized.cm	cmpcd	Keep	NULL
clinical_trials_harmonized.cm	cmpdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmpoch	Keep	NULL
clinical_trials_harmonized.cm	cmpoef	Keep	NULL
clinical_trials_harmonized.cm	cmprdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.cm	cmprdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmprdtp	Keep	NULL
clinical_trials_harmonized.cm	cmprdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmpredy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmpresp	Keep	NULL
clinical_trials_harmonized.cm	cmprev	Keep	NULL
clinical_trials_harmonized.cm	cmprior	Keep	NULL
clinical_trials_harmonized.cm	cmprobio	Keep	NULL
clinical_trials_harmonized.cm	cmprog	Keep	NULL
clinical_trials_harmonized.cm	cmpstrg	Keep	NULL
clinical_trials_harmonized.cm	cmpstrgu	Keep	NULL
clinical_trials_harmonized.cm	cmpt1	Keep	NULL
clinical_trials_harmonized.cm	cmpt2	Keep	NULL
clinical_trials_harmonized.cm	cmpt3	Keep	NULL
clinical_trials_harmonized.cm	cmpt4	Keep	NULL
clinical_trials_harmonized.cm	cmpt5	Keep	NULL
clinical_trials_harmonized.cm	cmpt6	Keep	NULL
clinical_trials_harmonized.cm	cmpt7	Keep	NULL
clinical_trials_harmonized.cm	cmptcd	Keep	NULL
clinical_trials_harmonized.cm	cmpt	Keep	NULL
clinical_trials_harmonized.cm	cmradtry	Keep	NULL
clinical_trials_harmonized.cm	cmraks	Keep	NULL
clinical_trials_harmonized.cm	cmrane	Keep	NULL
clinical_trials_harmonized.cm	cmrarm	Keep	NULL
clinical_trials_harmonized.cm	cmrasr	Keep	NULL
clinical_trials_harmonized.cm	cmrcbp	Keep	NULL
clinical_trials_harmonized.cm	cmrcom	Keep	NULL
clinical_trials_harmonized.cm	cmrcom_x	Keep	NULL
clinical_trials_harmonized.cm	cmrcvt1	Keep	NULL
clinical_trials_harmonized.cm	cmrcvt2	Keep	NULL
clinical_trials_harmonized.cm	cmrcvtn1	Keep	NULL
clinical_trials_harmonized.cm	cmrcvtn2	Keep	NULL
clinical_trials_harmonized.cm	cmrcvt	Keep	NULL
clinical_trials_harmonized.cm	cmrdiscd	Keep	NULL
clinical_trials_harmonized.cm	cmrdis	Keep	NULL
clinical_trials_harmonized.cm	cmrdos	Keep	NULL
clinical_trials_harmonized.cm	cmrdoth	Keep	NULL
clinical_trials_harmonized.cm	cmreas1	Keep	NULL
clinical_trials_harmonized.cm	cmreas	Keep	NULL
clinical_trials_harmonized.cm	cmrefdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmrefedt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmrefid1	Keep	NULL
clinical_trials_harmonized.cm	cmrefid2	Keep	NULL
clinical_trials_harmonized.cm	cmrefid3	Keep	NULL
clinical_trials_harmonized.cm	cmrefid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.cm	cmregn	Keep	NULL
clinical_trials_harmonized.cm	cmrelo	Keep	NULL
clinical_trials_harmonized.cm	cmrenne	Keep	NULL
clinical_trials_harmonized.cm	cmrera	Keep	NULL
clinical_trials_harmonized.cm	cmrescue	Keep	NULL
clinical_trials_harmonized.cm	cmrespcd	Keep	NULL
clinical_trials_harmonized.cm	cmrespl	Keep	NULL
clinical_trials_harmonized.cm	cmrespsp	Keep	NULL
clinical_trials_harmonized.cm	cmresp	Keep	NULL
clinical_trials_harmonized.cm	cmresp_x	Keep	NULL
clinical_trials_harmonized.cm	cmret	Keep	NULL
clinical_trials_harmonized.cm	cmrhp	Keep	NULL
clinical_trials_harmonized.cm	cmrhpt	Keep	NULL
clinical_trials_harmonized.cm	cmrhs	Keep	NULL
clinical_trials_harmonized.cm	cmrht	Keep	NULL
clinical_trials_harmonized.cm	cmrias	Keep	NULL
clinical_trials_harmonized.cm	cmrint	Keep	NULL
clinical_trials_harmonized.cm	cmrir	Keep	NULL
clinical_trials_harmonized.cm	cmrit	Keep	NULL
clinical_trials_harmonized.cm	cmrloe	Keep	NULL
clinical_trials_harmonized.cm	cmrlof	Keep	NULL
clinical_trials_harmonized.cm	cmrmcb	Keep	NULL
clinical_trials_harmonized.cm	cmrnar	Keep	NULL
clinical_trials_harmonized.cm	cmrnasr	Keep	NULL
clinical_trials_harmonized.cm	cmropr	Keep	NULL
clinical_trials_harmonized.cm	cmrort	Keep	NULL
clinical_trials_harmonized.cm	cmrothd	Keep	NULL
clinical_trials_harmonized.cm	cmroth	Keep	NULL
clinical_trials_harmonized.cm	cmroth_x	Keep	NULL
clinical_trials_harmonized.cm	cmrot	Keep	NULL
clinical_trials_harmonized.cm	cmroutcd	Keep	NULL
clinical_trials_harmonized.cm	cmroute	Keep	NULL
clinical_trials_harmonized.cm	cmroutl	Keep	NULL
clinical_trials_harmonized.cm	cmroutn	Keep	NULL
clinical_trials_harmonized.cm	cmroutsp	Keep	NULL
clinical_trials_harmonized.cm	cmrprg	Keep	NULL
clinical_trials_harmonized.cm	cmrprg_x	Keep	NULL
clinical_trials_harmonized.cm	cmrprm	Keep	NULL
clinical_trials_harmonized.cm	cmrpso	Keep	NULL
clinical_trials_harmonized.cm	cmrrem	Keep	NULL
clinical_trials_harmonized.cm	cmrres	Keep	NULL
clinical_trials_harmonized.cm	cmrres_x	Keep	NULL
clinical_trials_harmonized.cm	cmrrha	Keep	NULL
clinical_trials_harmonized.cm	cmrrs	Keep	NULL
clinical_trials_harmonized.cm	cmrsc	Keep	NULL
clinical_trials_harmonized.cm	cmrsd	Keep	NULL
clinical_trials_harmonized.cm	cmrsei	Keep	NULL
clinical_trials_harmonized.cm	cmrsoth	Keep	NULL
clinical_trials_harmonized.cm	cmrspa	Keep	NULL
clinical_trials_harmonized.cm	cmrsp	Keep	NULL
clinical_trials_harmonized.cm	cmrsp_x	Keep	NULL
clinical_trials_harmonized.cm	cmrssp	Keep	NULL
clinical_trials_harmonized.cm	cmrswo	Keep	NULL
clinical_trials_harmonized.cm	cmrtad	Keep	NULL
clinical_trials_harmonized.cm	cmrtox	Keep	NULL
clinical_trials_harmonized.cm	cmrtox_x	Keep	NULL
clinical_trials_harmonized.cm	cmrunk	Keep	NULL
clinical_trials_harmonized.cm	cmrun	Keep	NULL
clinical_trials_harmonized.cm	cmrvf	Keep	NULL
clinical_trials_harmonized.cm	cmscatcd	Keep	NULL
clinical_trials_harmonized.cm	cmscatsp	Keep	NULL
clinical_trials_harmonized.cm	cmscat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmsdmp	Keep	NULL
clinical_trials_harmonized.cm	cmsdm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmsdtce	Keep	NULL
clinical_trials_harmonized.cm	cmsdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.cm	cmsdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmsdtp	Keep	NULL
clinical_trials_harmonized.cm	cmsdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmsecd	Keep	NULL
clinical_trials_harmonized.cm	cmsedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmseq	Keep	NULL
clinical_trials_harmonized.cm	cmspid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.cm	cmsref	Keep	NULL
clinical_trials_harmonized.cm	cmstatfl	Keep	NULL
clinical_trials_harmonized.cm	cmstdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.cm	cmstdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmstdte	Keep	NULL
clinical_trials_harmonized.cm	cmstdtmp	Keep	NULL
clinical_trials_harmonized.cm	cmstdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmstdtp	Keep	NULL
clinical_trials_harmonized.cm	cmstdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmsted	Keep	NULL
clinical_trials_harmonized.cm	cmstedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmstpd	Keep	NULL
clinical_trials_harmonized.cm	cmstpdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmstpm	Keep	NULL
clinical_trials_harmonized.cm	cmstrf	Keep	NULL
clinical_trials_harmonized.cm	cmsttmc	Keep	NULL
clinical_trials_harmonized.cm	cmsttme	Keep	NULL
clinical_trials_harmonized.cm	cmsttmp	Keep	NULL
clinical_trials_harmonized.cm	cmsttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	cmsttmu	Keep	NULL
clinical_trials_harmonized.cm	cmstt	Keep	NULL
clinical_trials_harmonized.cm	cmsycs	Keep	NULL
clinical_trials_harmonized.cm	cmsyct	Keep	NULL
clinical_trials_harmonized.cm	cmsyst	Keep	NULL
clinical_trials_harmonized.cm	cmtcpot	Keep	NULL
clinical_trials_harmonized.cm	cmtkn	Keep	NULL
clinical_trials_harmonized.cm	cmtptnum	Keep	NULL
clinical_trials_harmonized.cm	cmtptref	Keep	NULL
clinical_trials_harmonized.cm	cmtpt	Keep	NULL
clinical_trials_harmonized.cm	cmtrdn	Keep	NULL
clinical_trials_harmonized.cm	cmtrscd	Keep	NULL
clinical_trials_harmonized.cm	cmtrs	Keep	NULL
clinical_trials_harmonized.cm	cmtrts1	Keep	NULL
clinical_trials_harmonized.cm	cmtrts2	Keep	NULL
clinical_trials_harmonized.cm	cmtrtsp	Keep	NULL
clinical_trials_harmonized.cm	cmtrts	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmtrt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	cmtrtstt	Keep	NULL
clinical_trials_harmonized.cm	cmudose	Keep	NULL
clinical_trials_harmonized.cm	cmudosfq	Keep	NULL
clinical_trials_harmonized.cm	cmudossp	Keep	NULL
clinical_trials_harmonized.cm	cmudosu	Keep	NULL
clinical_trials_harmonized.cm	cmufib	Keep	NULL
clinical_trials_harmonized.cm	cmurmed	Keep	NULL
clinical_trials_harmonized.cm	cmyn	Keep	NULL
clinical_trials_harmonized.cm	country	Keep	NULL
clinical_trials_harmonized.cm	cpevent	Keep	NULL
clinical_trials_harmonized.cm	dcmdate	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.cm	dcmname	Keep	NULL
clinical_trials_harmonized.cm	dcmsubnm	Keep	NULL
clinical_trials_harmonized.cm	dcmtime	Keep	NULL
clinical_trials_harmonized.cm	docnum	Keep	NULL
clinical_trials_harmonized.cm	domain	Keep	NULL
clinical_trials_harmonized.cm	dtdmcm	Keep	NULL
clinical_trials_harmonized.cm	dtspcm1	Keep	NULL
clinical_trials_harmonized.cm	dtstcm1	Keep	NULL
clinical_trials_harmonized.cm	edcix	Keep	NULL
clinical_trials_harmonized.cm	edcix_x	Keep	NULL
clinical_trials_harmonized.cm	epoch	Keep	NULL
clinical_trials_harmonized.cm	idvar	Keep	NULL
clinical_trials_harmonized.cm	idvarval	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.cm	invid	Redact	Detected Entity with tag PII "clinical_invid"
clinical_trials_harmonized.cm	invsite	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.cm	lockflag	Keep	NULL
clinical_trials_harmonized.cm	logints	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	lstchgts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.cm	nyongcm1	Keep	NULL
clinical_trials_harmonized.cm	pt	Keep	NULL
clinical_trials_harmonized.cm	qeval	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	qlabel	Keep	NULL
clinical_trials_harmonized.cm	qnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.cm	qorig	Keep	NULL
clinical_trials_harmonized.cm	qualifyv	Keep	NULL
clinical_trials_harmonized.cm	qval	Keep	NULL
clinical_trials_harmonized.cm	rdomain	Keep	NULL
clinical_trials_harmonized.cm	repeatsn	Keep	NULL
clinical_trials_harmonized.cm	route1	Keep	NULL
clinical_trials_harmonized.cm	rowid	Keep	NULL
clinical_trials_harmonized.cm	sched1	Keep	NULL
clinical_trials_harmonized.cm	steroid1	Keep	NULL
clinical_trials_harmonized.cm	studyid	Keep	Detected Entity "clinical_studyid"
clinical_trials_harmonized.cm	subjid	FPENumeric	Detected Entity with tag PII "clinical_subjid"
clinical_trials_harmonized.cm	subsetsn	Keep	NULL
clinical_trials_harmonized.cm	txcom1cm	Keep	NULL
clinical_trials_harmonized.cm	txcom2cm	Keep	NULL
clinical_trials_harmonized.cm	txcom3cm	Keep	NULL
clinical_trials_harmonized.cm	txdose1	Keep	NULL
clinical_trials_harmonized.cm	txdrug1	Keep	NULL
clinical_trials_harmonized.cm	txroute1	Keep	NULL
clinical_trials_harmonized.cm	txsched1	Keep	NULL
clinical_trials_harmonized.cm	txunit1	Keep	NULL
clinical_trials_harmonized.cm	txuse1	Keep	NULL
clinical_trials_harmonized.cm	unit1	Keep	NULL
clinical_trials_harmonized.cm	urecid	Keep	NULL
clinical_trials_harmonized.cm	use1	Keep	NULL
clinical_trials_harmonized.cm	usubjid	FPEAlphaNumeric	Detected Entity with tag PII "clinical_usubjid"
clinical_trials_harmonized.cm	visitnum	Keep	NULL
clinical_trials_harmonized.cm	visit	Keep	NULL
clinical_trials_harmonized.cm	source_dataset	Keep	NULL
clinical_trials_harmonized.de	accessts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.de	actevent	Keep	NULL
clinical_trials_harmonized.de	country	Keep	NULL
clinical_trials_harmonized.de	cpevent	Keep	NULL
clinical_trials_harmonized.de	dcmdate	SkewDate	DateAndTimestamp
clinical_trials_harmonized.de	dcmname	Keep	NULL
clinical_trials_harmonized.de	dcmsubnm	Keep	NULL
clinical_trials_harmonized.de	dcmtime	Keep	NULL
clinical_trials_harmonized.de	deaclrd	Keep	NULL
clinical_trials_harmonized.de	deautosp	Keep	NULL
clinical_trials_harmonized.de	decat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.de	dedecod	Keep	NULL
clinical_trials_harmonized.de	dedtce	Keep	NULL
clinical_trials_harmonized.de	dedtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.de	dedt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.de	dedte	Keep	NULL
clinical_trials_harmonized.de	dedtmp	Keep	NULL
clinical_trials_harmonized.de	dedtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.de	dedtp	Keep	NULL
clinical_trials_harmonized.de	dedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.de	deedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.de	degrpid	Keep	NULL
clinical_trials_harmonized.de	delrdra	Keep	NULL
clinical_trials_harmonized.de	delrdth	Keep	NULL
clinical_trials_harmonized.de	deoccur	Keep	NULL
clinical_trials_harmonized.de	depdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.de	depoch	Keep	NULL
clinical_trials_harmonized.de	depresp	Keep	NULL
clinical_trials_harmonized.de	descat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.de	desecd	Keep	NULL
clinical_trials_harmonized.de	deseq	Keep	NULL
clinical_trials_harmonized.de	despid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.de	destdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.de	destdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.de	determcd	Keep	NULL
clinical_trials_harmonized.de	determsp	Keep	NULL
clinical_trials_harmonized.de	determ	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.de	docnum	Keep	NULL
clinical_trials_harmonized.de	domain	Keep	NULL
clinical_trials_harmonized.de	edcix	Keep	NULL
clinical_trials_harmonized.de	epoch	Keep	NULL
clinical_trials_harmonized.de	idvar	Keep	NULL
clinical_trials_harmonized.de	idvarval	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.de	invid	Redact	Detected Entity with tag PII "clinical_invid"
clinical_trials_harmonized.de	invsite	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.de	lockflag	Keep	NULL
clinical_trials_harmonized.de	logints	SkewDate	DateAndTimestamp
clinical_trials_harmonized.de	lstchgts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.de	pt	Keep	NULL
clinical_trials_harmonized.de	qeval	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.de	qlabel	Keep	NULL
clinical_trials_harmonized.de	qnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.de	qorig	Keep	NULL
clinical_trials_harmonized.de	qualifyv	Keep	NULL
clinical_trials_harmonized.de	qval	Keep	NULL
clinical_trials_harmonized.de	rdomain	Keep	NULL
clinical_trials_harmonized.de	repeatsn	Keep	NULL
clinical_trials_harmonized.de	rowid	Keep	NULL
clinical_trials_harmonized.de	spdevid	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.de	studyid	Keep	Detected Entity "clinical_studyid"
clinical_trials_harmonized.de	subjid	FPENumeric	Detected Entity with tag PII "clinical_subjid"
clinical_trials_harmonized.de	subsetsn	Keep	NULL
clinical_trials_harmonized.de	usubjid	FPEAlphaNumeric	Detected Entity with tag PII "clinical_usubjid"
clinical_trials_harmonized.de	visitnum	Keep	NULL
clinical_trials_harmonized.de	visit	Keep	NULL
clinical_trials_harmonized.de	source_dataset	Keep	NULL
clinical_trials_harmonized.dm	accessts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	actarmcd	Keep	NULL
clinical_trials_harmonized.dm	actarm	Keep	NULL
clinical_trials_harmonized.dm	actevent	Keep	NULL
clinical_trials_harmonized.dm	agec	Age	Use Age for age column
clinical_trials_harmonized.dm	agece	Keep	NULL
clinical_trials_harmonized.dm	age	Age	Detected Facet with tag PII "clinical_age"
clinical_trials_harmonized.dm	ageu	Keep	NULL
clinical_trials_harmonized.dm	armcd	Keep	NULL
clinical_trials_harmonized.dm	arm	Keep	NULL
clinical_trials_harmonized.dm	brtdmp	Keep	NULL
clinical_trials_harmonized.dm	brtdm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	brtdtcc	Keep	NULL
clinical_trials_harmonized.dm	brtdtce	Keep	NULL
clinical_trials_harmonized.dm	brtdtcf	Keep	NULL
clinical_trials_harmonized.dm	brtdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	brtdtp	Keep	NULL
clinical_trials_harmonized.dm	brthdt_a	Keep	NULL
clinical_trials_harmonized.dm	brthdtc	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	brthdt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	brthdte	Keep	NULL
clinical_trials_harmonized.dm	brthdtmp	Keep	NULL
clinical_trials_harmonized.dm	brthdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	brthdtp	Keep	NULL
clinical_trials_harmonized.dm	brthdt_x	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	brthdt_y	Keep	NULL
clinical_trials_harmonized.dm	brthdt_z	Keep	NULL
clinical_trials_harmonized.dm	country	Keep	NULL
clinical_trials_harmonized.dm	cpevent	Keep	NULL
clinical_trials_harmonized.dm	crace2	Keep	NULL
clinical_trials_harmonized.dm	crace7	Keep	NULL
clinical_trials_harmonized.dm	cracec	Keep	NULL
clinical_trials_harmonized.dm	cracek	Keep	NULL
clinical_trials_harmonized.dm	cracet	Keep	NULL
clinical_trials_harmonized.dm	dcmdate	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dcmname	Keep	NULL
clinical_trials_harmonized.dm	dcmsubnm	Keep	NULL
clinical_trials_harmonized.dm	dcmtime	Keep	NULL
clinical_trials_harmonized.dm	dmabt	Keep	NULL
clinical_trials_harmonized.dm	dmadstdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dma_endt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmage2	Keep	NULL
clinical_trials_harmonized.dm	dmagecat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	dmamdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmamdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmamdte	Keep	NULL
clinical_trials_harmonized.dm	dmamdtp	Keep	NULL
clinical_trials_harmonized.dm	dmanum1	Keep	NULL
clinical_trials_harmonized.dm	dmanum2	Keep	NULL
clinical_trials_harmonized.dm	dmanumc	Keep	NULL
clinical_trials_harmonized.dm	dmanum	Keep	NULL
clinical_trials_harmonized.dm	dmanume	Keep	NULL
clinical_trials_harmonized.dm	dmanum_x	Keep	NULL
clinical_trials_harmonized.dm	dmarm_q	Keep	NULL
clinical_trials_harmonized.dm	dmarm_r	Keep	NULL
clinical_trials_harmonized.dm	dmarm_s	Keep	NULL
clinical_trials_harmonized.dm	dmbnaive	Keep	NULL
clinical_trials_harmonized.dm	dmb_stdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmb_sttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmbwt	Keep	NULL
clinical_trials_harmonized.dm	dmbwtu	Keep	NULL
clinical_trials_harmonized.dm	dmcinv	Keep	NULL
clinical_trials_harmonized.dm	dmcitt	Keep	NULL
clinical_trials_harmonized.dm	dmcntry	Keep	NULL
clinical_trials_harmonized.dm	dmcohort	Keep	NULL
clinical_trials_harmonized.dm	dmcomdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmcomtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmcontry	Keep	NULL
clinical_trials_harmonized.dm	dmdbendt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmdbflg	Keep	NULL
clinical_trials_harmonized.dm	dmdbstdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmdestdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmdostm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmdspr	Keep	NULL
clinical_trials_harmonized.dm	dmdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmdtp	Keep	NULL
clinical_trials_harmonized.dm	dmdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	dmedu	Keep	NULL
clinical_trials_harmonized.dm	dmedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	dmenrl	Keep	NULL
clinical_trials_harmonized.dm	dmependt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmethcd	Keep	NULL
clinical_trials_harmonized.dm	dmethgrp	Keep	NULL
clinical_trials_harmonized.dm	dmethnic	Keep	NULL
clinical_trials_harmonized.dm	dmetrdur	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	dmfdta	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmfdtr	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmfdtt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmfedta	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmfedtr	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmfedtt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmflcm	Keep	NULL
clinical_trials_harmonized.dm	dmflcoma	Keep	NULL
clinical_trials_harmonized.dm	dmflie	Keep	NULL
clinical_trials_harmonized.dm	dmflpp	Keep	NULL
clinical_trials_harmonized.dm	dmfrqc	Keep	NULL
clinical_trials_harmonized.dm	dmfrq	Keep	NULL
clinical_trials_harmonized.dm	dmftrdur	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	dmgady	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	dmgawk	Keep	NULL
clinical_trials_harmonized.dm	dmgroup	Keep	NULL
clinical_trials_harmonized.dm	dmgrpcd	Keep	NULL
clinical_trials_harmonized.dm	dmgrpid	Keep	NULL
clinical_trials_harmonized.dm	dmgrp	Keep	NULL
clinical_trials_harmonized.dm	dmicdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmicdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmicdte	Keep	NULL
clinical_trials_harmonized.dm	dmicdtp	Keep	NULL
clinical_trials_harmonized.dm	dmic	Keep	NULL
clinical_trials_harmonized.dm	dmilin	Keep	NULL
clinical_trials_harmonized.dm	dmitt	Keep	NULL
clinical_trials_harmonized.dm	dm_itt	Keep	NULL
clinical_trials_harmonized.dm	dmk1edtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmk1endt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmk1entm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmk1sdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmk1stdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmk1sttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmkmedtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmkmendt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmkmentm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmkmsdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmkmstdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmkmsttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmlpcm	Keep	NULL
clinical_trials_harmonized.dm	dmlpcomn	Keep	NULL
clinical_trials_harmonized.dm	dmlpdur	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	dmlpie	Keep	NULL
clinical_trials_harmonized.dm	dmlppp	Keep	NULL
clinical_trials_harmonized.dm	dmmaxdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmmdtce	Keep	NULL
clinical_trials_harmonized.dm	dmmdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmmdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmmeth	Keep	NULL
clinical_trials_harmonized.dm	dm_mitt	Keep	NULL
clinical_trials_harmonized.dm	dmnmtr	Keep	NULL
clinical_trials_harmonized.dm	dmnmty	Keep	NULL
clinical_trials_harmonized.dm	dmnumat	Keep	NULL
clinical_trials_harmonized.dm	dmnumrt	Keep	NULL
clinical_trials_harmonized.dm	dmolendt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmolflg	Keep	NULL
clinical_trials_harmonized.dm	dmolstdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmonlab	Keep	NULL
clinical_trials_harmonized.dm	dmpcp	Keep	NULL
clinical_trials_harmonized.dm	dmpdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	dmplendt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmpsnmsp	Keep	NULL
clinical_trials_harmonized.dm	dmpstnm	Keep	NULL
clinical_trials_harmonized.dm	dmpsubj1	Keep	NULL
clinical_trials_harmonized.dm	dmpsubj	Keep	NULL
clinical_trials_harmonized.dm	dmpsubst	Keep	NULL
clinical_trials_harmonized.dm	dmpver1	Keep	NULL
clinical_trials_harmonized.dm	dmpver2	Keep	NULL
clinical_trials_harmonized.dm	dmpversp	Keep	NULL
clinical_trials_harmonized.dm	dmpver	Keep	NULL
clinical_trials_harmonized.dm	dmpver_x	Keep	NULL
clinical_trials_harmonized.dm	dmquno	Keep	NULL
clinical_trials_harmonized.dm	dmrandom	Keep	NULL
clinical_trials_harmonized.dm	dmrandx	Keep	NULL
clinical_trials_harmonized.dm	dmrefdt1	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmrefdt2	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmrefdt3	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmrefdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmreftm2	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmreftm3	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmreftm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmregion	Keep	NULL
clinical_trials_harmonized.dm	dmrfrsp	Keep	NULL
clinical_trials_harmonized.dm	dmrfr	Keep	NULL
clinical_trials_harmonized.dm	dmrftm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmrsc	Keep	NULL
clinical_trials_harmonized.dm	dmrx2dt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmrx2tm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmrxdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmrxtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmsadtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmsadt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmsadtp	Keep	NULL
clinical_trials_harmonized.dm	dmsafety	Keep	NULL
clinical_trials_harmonized.dm	dmscfl_	Keep	NULL
clinical_trials_harmonized.dm	dmscfl	Keep	NULL
clinical_trials_harmonized.dm	dmscrfp1	Keep	NULL
clinical_trials_harmonized.dm	dmscrnid	Keep	NULL
clinical_trials_harmonized.dm	dmseas	Keep	NULL
clinical_trials_harmonized.dm	dmsecd	Keep	NULL
clinical_trials_harmonized.dm	dmsett	Keep	NULL
clinical_trials_harmonized.dm	dmslin	Keep	NULL
clinical_trials_harmonized.dm	dmsocedt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmspid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.dm	dmsrcd	Keep	NULL
clinical_trials_harmonized.dm	dmsrsp	Keep	NULL
clinical_trials_harmonized.dm	dmsr	Keep	NULL
clinical_trials_harmonized.dm	dmsstn	Keep	NULL
clinical_trials_harmonized.dm	dmssun	Keep	NULL
clinical_trials_harmonized.dm	dmstatcd	Keep	NULL
clinical_trials_harmonized.dm	dmstat	Keep	NULL
clinical_trials_harmonized.dm	dmstracd	Keep	NULL
clinical_trials_harmonized.dm	dmstra	Keep	NULL
clinical_trials_harmonized.dm	dmtgr1cd	Keep	NULL
clinical_trials_harmonized.dm	dmtgr2cd	Keep	NULL
clinical_trials_harmonized.dm	dmtgrp1	Keep	NULL
clinical_trials_harmonized.dm	dmtgrp2	Keep	NULL
clinical_trials_harmonized.dm	dmtgrpcd	Keep	NULL
clinical_trials_harmonized.dm	dmtgrp	Keep	NULL
clinical_trials_harmonized.dm	dmtrduru	Keep	NULL
clinical_trials_harmonized.dm	dmtrtcd	Keep	NULL
clinical_trials_harmonized.dm	dmtrtdur	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	dmtrtgrp	Keep	NULL
clinical_trials_harmonized.dm	dmtxedtc	Keep	NULL
clinical_trials_harmonized.dm	dmtxedt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dmtxedtp	Keep	NULL
clinical_trials_harmonized.dm	dmusubid	Keep	NULL
clinical_trials_harmonized.dm	dmvestdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	docnum	Keep	NULL
clinical_trials_harmonized.dm	domain	Keep	NULL
clinical_trials_harmonized.dm	dthdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dthdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	dthdtp	Keep	NULL
clinical_trials_harmonized.dm	dthfl	Keep	NULL
clinical_trials_harmonized.dm	edcix	Keep	NULL
clinical_trials_harmonized.dm	epoch	Keep	NULL
clinical_trials_harmonized.dm	ethnica	Keep	NULL
clinical_trials_harmonized.dm	ethnicc	Keep	NULL
clinical_trials_harmonized.dm	ethnice	Keep	NULL
clinical_trials_harmonized.dm	ethnichc	Keep	NULL
clinical_trials_harmonized.dm	ethnich	Keep	NULL
clinical_trials_harmonized.dm	ethnici	Keep	NULL
clinical_trials_harmonized.dm	ethnicj	Keep	NULL
clinical_trials_harmonized.dm	ethnick	Keep	NULL
clinical_trials_harmonized.dm	ethnicm	Keep	NULL
clinical_trials_harmonized.dm	ethnicn	Keep	NULL
clinical_trials_harmonized.dm	ethnico	Keep	NULL
clinical_trials_harmonized.dm	ethnic_r	Keep	NULL
clinical_trials_harmonized.dm	ethnics	Keep	NULL
clinical_trials_harmonized.dm	ethnic	Keep	NULL
clinical_trials_harmonized.dm	ethnict	Keep	NULL
clinical_trials_harmonized.dm	ethnic_x	Keep	NULL
clinical_trials_harmonized.dm	ethnihc	Keep	NULL
clinical_trials_harmonized.dm	ethnihe	Keep	NULL
clinical_trials_harmonized.dm	ethnihl	Keep	NULL
clinical_trials_harmonized.dm	ethnihn	Keep	NULL
clinical_trials_harmonized.dm	ethnih	Keep	NULL
clinical_trials_harmonized.dm	ethnij	Keep	NULL
clinical_trials_harmonized.dm	ethnisp	Keep	NULL
clinical_trials_harmonized.dm	ethoth	Keep	NULL
clinical_trials_harmonized.dm	eudract	Keep	NULL
clinical_trials_harmonized.dm	gndtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	gndt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	gndtp	Keep	NULL
clinical_trials_harmonized.dm	grp3b	Keep	NULL
clinical_trials_harmonized.dm	idvar	Keep	NULL
clinical_trials_harmonized.dm	idvarval	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.dm	invcnt	Keep	NULL
clinical_trials_harmonized.dm	invid	Redact	Detected Entity with tag PII "clinical_invid"
clinical_trials_harmonized.dm	invnamo	Keep	NULL
clinical_trials_harmonized.dm	invnam	Redact	Detected Facet with tag PII "clinical_invnam"
clinical_trials_harmonized.dm	invno	Keep	NULL
clinical_trials_harmonized.dm	invno_x	Keep	NULL
clinical_trials_harmonized.dm	invsite	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.dm	ipkgrp1	Keep	NULL
clinical_trials_harmonized.dm	ipkgrp2	Keep	NULL
clinical_trials_harmonized.dm	ipkgrp	Keep	NULL
clinical_trials_harmonized.dm	lockflag	Keep	NULL
clinical_trials_harmonized.dm	logints	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	lstchgts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	matchno	Keep	NULL
clinical_trials_harmonized.dm	pimsid	Keep	NULL
clinical_trials_harmonized.dm	pt	Keep	NULL
clinical_trials_harmonized.dm	pvanum	Keep	NULL
clinical_trials_harmonized.dm	qeval	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	qlabel	Keep	NULL
clinical_trials_harmonized.dm	qnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	qorig	Keep	NULL
clinical_trials_harmonized.dm	qualifyv	Keep	NULL
clinical_trials_harmonized.dm	qval	Keep	NULL
clinical_trials_harmonized.dm	raceac	Keep	NULL
clinical_trials_harmonized.dm	raceae	Keep	NULL
clinical_trials_harmonized.dm	racea	Keep	NULL
clinical_trials_harmonized.dm	racea_x	Keep	NULL
clinical_trials_harmonized.dm	racebc	Keep	NULL
clinical_trials_harmonized.dm	racebe	Keep	NULL
clinical_trials_harmonized.dm	raceb	Keep	NULL
clinical_trials_harmonized.dm	raceb_x	Keep	NULL
clinical_trials_harmonized.dm	racecd	Keep	NULL
clinical_trials_harmonized.dm	racehe	Keep	NULL
clinical_trials_harmonized.dm	raceh	Keep	NULL
clinical_trials_harmonized.dm	racenc	Keep	NULL
clinical_trials_harmonized.dm	racene	Keep	NULL
clinical_trials_harmonized.dm	racen	Keep	NULL
clinical_trials_harmonized.dm	raceoc	Keep	NULL
clinical_trials_harmonized.dm	raceoe	Keep	NULL
clinical_trials_harmonized.dm	raceo	Keep	NULL
clinical_trials_harmonized.dm	raceo_x	Keep	NULL
clinical_trials_harmonized.dm	race_r	Keep	NULL
clinical_trials_harmonized.dm	racespc	Keep	NULL
clinical_trials_harmonized.dm	racespe	Keep	NULL
clinical_trials_harmonized.dm	racesp	Keep	NULL
clinical_trials_harmonized.dm	racesp_x	Keep	NULL
clinical_trials_harmonized.dm	race	Keep	NULL
clinical_trials_harmonized.dm	racewc	Keep	NULL
clinical_trials_harmonized.dm	racewe	Keep	NULL
clinical_trials_harmonized.dm	racew	Keep	NULL
clinical_trials_harmonized.dm	racew_x	Keep	NULL
clinical_trials_harmonized.dm	rascat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.dm	rdomain	Keep	NULL
clinical_trials_harmonized.dm	refdmp	Keep	NULL
clinical_trials_harmonized.dm	refdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	refdtmp	Keep	NULL
clinical_trials_harmonized.dm	refdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	refdtp	Keep	NULL
clinical_trials_harmonized.dm	refedt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	refedtp	Keep	NULL
clinical_trials_harmonized.dm	refetp	Keep	NULL
clinical_trials_harmonized.dm	reftmc	Keep	NULL
clinical_trials_harmonized.dm	reftmp	Keep	NULL
clinical_trials_harmonized.dm	reftm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	repeatsn	Keep	NULL
clinical_trials_harmonized.dm	rfendtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	rficdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	rficdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	rficdtp	Keep	NULL
clinical_trials_harmonized.dm	rfpendtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	rfstdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	rfxendtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	rfxstdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.dm	rowid	Keep	NULL
clinical_trials_harmonized.dm	sexc	Keep	NULL
clinical_trials_harmonized.dm	sexe	Keep	NULL
clinical_trials_harmonized.dm	sexl	Keep	NULL
clinical_trials_harmonized.dm	sexn	Keep	NULL
clinical_trials_harmonized.dm	sex	Keep	NULL
clinical_trials_harmonized.dm	sex_x	Keep	NULL
clinical_trials_harmonized.dm	siteid	Keep	Detected Entity with tag PII "clinical_siteid"
clinical_trials_harmonized.dm	stdnum	Keep	NULL
clinical_trials_harmonized.dm	studyid	Keep	Detected Entity "clinical_studyid"
clinical_trials_harmonized.dm	subintc	Keep	NULL
clinical_trials_harmonized.dm	subinte	Keep	NULL
clinical_trials_harmonized.dm	subint	Keep	NULL
clinical_trials_harmonized.dm	subjid	FPENumeric	Detected Entity with tag PII "clinical_subjid"
clinical_trials_harmonized.dm	subjinit	Keep	NULL
clinical_trials_harmonized.dm	subjrpl	Keep	NULL
clinical_trials_harmonized.dm	subnum	Keep	NULL
clinical_trials_harmonized.dm	subsetsn	Keep	NULL
clinical_trials_harmonized.dm	urecid	Keep	NULL
clinical_trials_harmonized.dm	usubjid	FPEAlphaNumeric	Detected Entity with tag PII "clinical_usubjid"
clinical_trials_harmonized.dm	visitnum	Keep	NULL
clinical_trials_harmonized.dm	visit	Keep	NULL
clinical_trials_harmonized.dm	source_dataset	Keep	NULL
clinical_trials_harmonized.ds	accessts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	actevent	Keep	NULL
clinical_trials_harmonized.ds	country	Keep	NULL
clinical_trials_harmonized.ds	cpevent	Keep	NULL
clinical_trials_harmonized.ds	dcmdate	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dcmname	Keep	NULL
clinical_trials_harmonized.ds	dcmsubnm	Keep	NULL
clinical_trials_harmonized.ds	dcmtime	Keep	NULL
clinical_trials_harmonized.ds	docnum	Keep	NULL
clinical_trials_harmonized.ds	domain	Keep	NULL
clinical_trials_harmonized.ds	dsacons	Keep	NULL
clinical_trials_harmonized.ds	dsadtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dsadt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dsadtp	Keep	NULL
clinical_trials_harmonized.ds	dsady	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsaedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsaeit	Keep	NULL
clinical_trials_harmonized.ds	dsaenr	Keep	NULL
clinical_trials_harmonized.ds	dsaerd	Keep	NULL
clinical_trials_harmonized.ds	dsaerp	Keep	NULL
clinical_trials_harmonized.ds	dsae	Keep	NULL
clinical_trials_harmonized.ds	dsaetn	Keep	NULL
clinical_trials_harmonized.ds	dsaewr	Keep	NULL
clinical_trials_harmonized.ds	dsai	Keep	NULL
clinical_trials_harmonized.ds	dsaltth	Keep	NULL
clinical_trials_harmonized.ds	dsalv	Keep	NULL
clinical_trials_harmonized.ds	dsappr	Keep	NULL
clinical_trials_harmonized.ds	dsapr	Keep	NULL
clinical_trials_harmonized.ds	dsaqth	Keep	NULL
clinical_trials_harmonized.ds	dsar	Keep	NULL
clinical_trials_harmonized.ds	dsatr	Keep	NULL
clinical_trials_harmonized.ds	dsbmdecr	Keep	NULL
clinical_trials_harmonized.ds	dscat1	Keep	NULL
clinical_trials_harmonized.ds	dscat2	Keep	NULL
clinical_trials_harmonized.ds	dscatcd	Keep	NULL
clinical_trials_harmonized.ds	dscatl	Keep	NULL
clinical_trials_harmonized.ds	dscatn	Keep	NULL
clinical_trials_harmonized.ds	dscat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dscat_x	Keep	NULL
clinical_trials_harmonized.ds	dscmon	Keep	NULL
clinical_trials_harmonized.ds	dscmp	Keep	NULL
clinical_trials_harmonized.ds	dscmpt	Keep	NULL
clinical_trials_harmonized.ds	dscna	Keep	NULL
clinical_trials_harmonized.ds	dscomp	Keep	NULL
clinical_trials_harmonized.ds	dscom	Keep	NULL
clinical_trials_harmonized.ds	dscosp	Keep	NULL
clinical_trials_harmonized.ds	dscreg1	Keep	NULL
clinical_trials_harmonized.ds	dscreg2	Keep	NULL
clinical_trials_harmonized.ds	dscreg	Keep	NULL
clinical_trials_harmonized.ds	dscsoc	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dscterm	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsctrt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dscv19in	Keep	NULL
clinical_trials_harmonized.ds	dscv19lr	Keep	NULL
clinical_trials_harmonized.ds	dscyc	Keep	NULL
clinical_trials_harmonized.ds	dsdcv2	Keep	NULL
clinical_trials_harmonized.ds	dsdcv	Keep	NULL
clinical_trials_harmonized.ds	dsddtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dsddt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dsdeath	Keep	NULL
clinical_trials_harmonized.ds	dsdecod1	Keep	NULL
clinical_trials_harmonized.ds	dsdecod2	Keep	NULL
clinical_trials_harmonized.ds	dsdecod3	Keep	NULL
clinical_trials_harmonized.ds	dsdecod4	Keep	NULL
clinical_trials_harmonized.ds	dsdecod	Keep	NULL
clinical_trials_harmonized.ds	dsdia1	Keep	NULL
clinical_trials_harmonized.ds	dsdia2	Keep	NULL
clinical_trials_harmonized.ds	dsdia	Keep	NULL
clinical_trials_harmonized.ds	dsdispc	Keep	NULL
clinical_trials_harmonized.ds	dsdmstat	Keep	NULL
clinical_trials_harmonized.ds	dsdpbr	Keep	NULL
clinical_trials_harmonized.ds	dsdpcat1	Keep	NULL
clinical_trials_harmonized.ds	dsdpcat2	Keep	NULL
clinical_trials_harmonized.ds	dsdpcat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsdpcdp1	Keep	NULL
clinical_trials_harmonized.ds	dsdpcdp2	Keep	NULL
clinical_trials_harmonized.ds	dsdpcdp	Keep	NULL
clinical_trials_harmonized.ds	dsdpcd	Keep	NULL
clinical_trials_harmonized.ds	dsdpce	Keep	NULL
clinical_trials_harmonized.ds	dsdpcot1	Keep	NULL
clinical_trials_harmonized.ds	dsdpcot2	Keep	NULL
clinical_trials_harmonized.ds	dsdpcot	Keep	NULL
clinical_trials_harmonized.ds	dsdpcpe	Keep	NULL
clinical_trials_harmonized.ds	dsdpcsp1	Keep	NULL
clinical_trials_harmonized.ds	dsdpcsp2	Keep	NULL
clinical_trials_harmonized.ds	dsdpcsp	Keep	NULL
clinical_trials_harmonized.ds	dsdpc	Keep	NULL
clinical_trials_harmonized.ds	dsdpcwl	Keep	NULL
clinical_trials_harmonized.ds	dsdpnc	Keep	NULL
clinical_trials_harmonized.ds	dsdpot	Keep	NULL
clinical_trials_harmonized.ds	dsdppn	Keep	NULL
clinical_trials_harmonized.ds	dsdpprc	Keep	NULL
clinical_trials_harmonized.ds	dsdprg	Keep	NULL
clinical_trials_harmonized.ds	dsdpri	Keep	NULL
clinical_trials_harmonized.ds	dsdprl	Keep	NULL
clinical_trials_harmonized.ds	dsdpro	Keep	NULL
clinical_trials_harmonized.ds	dsdpr	Keep	NULL
clinical_trials_harmonized.ds	dsdpsa	Keep	NULL
clinical_trials_harmonized.ds	dsdpsp	Keep	NULL
clinical_trials_harmonized.ds	dsdr	Keep	NULL
clinical_trials_harmonized.ds	dsdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.ds	dsdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dsdtmp	Keep	NULL
clinical_trials_harmonized.ds	dsdtms	Keep	NULL
clinical_trials_harmonized.ds	dsdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dsdtp	Keep	NULL
clinical_trials_harmonized.ds	dsdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dseast	Keep	NULL
clinical_trials_harmonized.ds	dsebio	Keep	NULL
clinical_trials_harmonized.ds	dsecp	Keep	NULL
clinical_trials_harmonized.ds	dsecsp	Keep	NULL
clinical_trials_harmonized.ds	dsec	Keep	NULL
clinical_trials_harmonized.ds	dsedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dseitril	Keep	NULL
clinical_trials_harmonized.ds	dselv	Keep	NULL
clinical_trials_harmonized.ds	dsemed	Keep	NULL
clinical_trials_harmonized.ds	dsenum	Keep	NULL
clinical_trials_harmonized.ds	dsercl	Keep	NULL
clinical_trials_harmonized.ds	dsesrdsp	Keep	NULL
clinical_trials_harmonized.ds	dsesrd	Keep	NULL
clinical_trials_harmonized.ds	dsexcd	Keep	NULL
clinical_trials_harmonized.ds	dsext1	Keep	NULL
clinical_trials_harmonized.ds	dsext2	Keep	NULL
clinical_trials_harmonized.ds	dsextdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dsextdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dsextdtp	Keep	NULL
clinical_trials_harmonized.ds	dsextdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsextedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsexts	Keep	NULL
clinical_trials_harmonized.ds	dsext	Keep	NULL
clinical_trials_harmonized.ds	dsextvis	Keep	NULL
clinical_trials_harmonized.ds	dsext_x	Keep	NULL
clinical_trials_harmonized.ds	dsfail	Keep	NULL
clinical_trials_harmonized.ds	dsfcdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.ds	dsfcdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dsfcdtp	Keep	NULL
clinical_trials_harmonized.ds	dsfcli	Keep	NULL
clinical_trials_harmonized.ds	dsfin	Keep	NULL
clinical_trials_harmonized.ds	dsflwp	Keep	NULL
clinical_trials_harmonized.ds	dsflwp_x	Keep	NULL
clinical_trials_harmonized.ds	dsftec	Keep	NULL
clinical_trials_harmonized.ds	dsftre	Keep	NULL
clinical_trials_harmonized.ds	dsgrpid	Keep	NULL
clinical_trials_harmonized.ds	dshdia	Keep	NULL
clinical_trials_harmonized.ds	dshyca	Keep	NULL
clinical_trials_harmonized.ds	dsicdia	Keep	NULL
clinical_trials_harmonized.ds	dsiesp	Keep	NULL
clinical_trials_harmonized.ds	dsie	Keep	NULL
clinical_trials_harmonized.ds	dsig	Keep	NULL
clinical_trials_harmonized.ds	dsinab	Keep	NULL
clinical_trials_harmonized.ds	dsinbl	Keep	NULL
clinical_trials_harmonized.ds	dsine	Keep	NULL
clinical_trials_harmonized.ds	dsinju	Keep	NULL
clinical_trials_harmonized.ds	dsinvr	Keep	NULL
clinical_trials_harmonized.ds	dsinw2	Keep	NULL
clinical_trials_harmonized.ds	dskdtr	Keep	NULL
clinical_trials_harmonized.ds	dslcyl	Keep	NULL
clinical_trials_harmonized.ds	dslfdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dslfdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dslfdte	Keep	NULL
clinical_trials_harmonized.ds	dslfdtp	Keep	NULL
clinical_trials_harmonized.ds	dslfsp	Keep	NULL
clinical_trials_harmonized.ds	dsloe	Keep	NULL
clinical_trials_harmonized.ds	dslrwi	Keep	NULL
clinical_trials_harmonized.ds	dsltf1	Keep	NULL
clinical_trials_harmonized.ds	dsltf2	Keep	NULL
clinical_trials_harmonized.ds	dsltf	Keep	NULL
clinical_trials_harmonized.ds	dsmetc	Keep	NULL
clinical_trials_harmonized.ds	dsmis2	Keep	NULL
clinical_trials_harmonized.ds	dsmis3	Keep	NULL
clinical_trials_harmonized.ds	dsmis4	Keep	NULL
clinical_trials_harmonized.ds	dsmis7	Keep	NULL
clinical_trials_harmonized.ds	dsmisvis	Keep	NULL
clinical_trials_harmonized.ds	dsmsa	Keep	NULL
clinical_trials_harmonized.ds	dsnmr	Keep	NULL
clinical_trials_harmonized.ds	dsnrnd	Keep	NULL
clinical_trials_harmonized.ds	dsnscr	Keep	NULL
clinical_trials_harmonized.ds	dsoccur	Keep	NULL
clinical_trials_harmonized.ds	dsorescd	Keep	NULL
clinical_trials_harmonized.ds	dsores	Keep	NULL
clinical_trials_harmonized.ds	dsorres1	Keep	NULL
clinical_trials_harmonized.ds	dsorres2	Keep	NULL
clinical_trials_harmonized.ds	dsorres3	Keep	NULL
clinical_trials_harmonized.ds	dsorresc	Keep	NULL
clinical_trials_harmonized.ds	dsorres	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsothl	Keep	NULL
clinical_trials_harmonized.ds	dsothn	Keep	NULL
clinical_trials_harmonized.ds	dsoth	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsotrans	Keep	NULL
clinical_trials_harmonized.ds	dspctsp	Keep	NULL
clinical_trials_harmonized.ds	dspct	Keep	NULL
clinical_trials_harmonized.ds	dspdisl	Keep	NULL
clinical_trials_harmonized.ds	dspdisn	Keep	NULL
clinical_trials_harmonized.ds	dspdis	Keep	NULL
clinical_trials_harmonized.ds	dspdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dspers	Keep	NULL
clinical_trials_harmonized.ds	dsphydec	Keep	NULL
clinical_trials_harmonized.ds	dspoch	Keep	NULL
clinical_trials_harmonized.ds	dsprdv	Keep	NULL
clinical_trials_harmonized.ds	dspreg	Keep	NULL
clinical_trials_harmonized.ds	dspresp	Keep	NULL
clinical_trials_harmonized.ds	dsprimcd	Keep	NULL
clinical_trials_harmonized.ds	dspriml	Keep	NULL
clinical_trials_harmonized.ds	dsprimn	Keep	NULL
clinical_trials_harmonized.ds	dsprim	Keep	NULL
clinical_trials_harmonized.ds	dsprsp	Keep	NULL
clinical_trials_harmonized.ds	dsprv	Keep	NULL
clinical_trials_harmonized.ds	dsptst	Keep	NULL
clinical_trials_harmonized.ds	dsrcpl	Keep	NULL
clinical_trials_harmonized.ds	dsreasn	Keep	NULL
clinical_trials_harmonized.ds	dsreas	Keep	NULL
clinical_trials_harmonized.ds	dsrefid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ds	dsresr	Keep	NULL
clinical_trials_harmonized.ds	dsres	Keep	NULL
clinical_trials_harmonized.ds	dsrhcv	Keep	NULL
clinical_trials_harmonized.ds	dsrlbsp	Keep	NULL
clinical_trials_harmonized.ds	dsrlb	Keep	NULL
clinical_trials_harmonized.ds	dsrnedp	Keep	NULL
clinical_trials_harmonized.ds	dsrnedxa	Keep	NULL
clinical_trials_harmonized.ds	dsrneeb	Keep	NULL
clinical_trials_harmonized.ds	dsrneosp	Keep	NULL
clinical_trials_harmonized.ds	dsrneoth	Keep	NULL
clinical_trials_harmonized.ds	dsrnepcd	Keep	NULL
clinical_trials_harmonized.ds	dsrnep	Keep	NULL
clinical_trials_harmonized.ds	dsrnetvu	Keep	NULL
clinical_trials_harmonized.ds	dsrnexne	Keep	NULL
clinical_trials_harmonized.ds	dsrnrgcl	Keep	NULL
clinical_trials_harmonized.ds	dsrntrer	Keep	NULL
clinical_trials_harmonized.ds	dsroth1	Keep	NULL
clinical_trials_harmonized.ds	dsroth2	Keep	NULL
clinical_trials_harmonized.ds	dsroth	Keep	NULL
clinical_trials_harmonized.ds	dsrpm	Keep	NULL
clinical_trials_harmonized.ds	dsrprmed	Keep	NULL
clinical_trials_harmonized.ds	dsrpt	Keep	NULL
clinical_trials_harmonized.ds	dsrsoth1	Keep	NULL
clinical_trials_harmonized.ds	dsrsoth2	Keep	NULL
clinical_trials_harmonized.ds	dsrsoth	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dssae	Keep	NULL
clinical_trials_harmonized.ds	dssbmc	Keep	NULL
clinical_trials_harmonized.ds	dssbnm	Keep	NULL
clinical_trials_harmonized.ds	dsscat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsscfa	Keep	NULL
clinical_trials_harmonized.ds	dssct	Keep	NULL
clinical_trials_harmonized.ds	dssdta	Keep	NULL
clinical_trials_harmonized.ds	dssdth	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dssecd	Keep	NULL
clinical_trials_harmonized.ds	dsseq	Keep	NULL
clinical_trials_harmonized.ds	dssfvcd	Keep	NULL
clinical_trials_harmonized.ds	dssfv	Keep	NULL
clinical_trials_harmonized.ds	dssncsp	Keep	NULL
clinical_trials_harmonized.ds	dssnc	Keep	NULL
clinical_trials_harmonized.ds	dsspid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ds	dsspon	Keep	NULL
clinical_trials_harmonized.ds	dssrea	Keep	NULL
clinical_trials_harmonized.ds	dsstatcd	Keep	NULL
clinical_trials_harmonized.ds	dsstat	Keep	NULL
clinical_trials_harmonized.ds	dsstat_x	Keep	NULL
clinical_trials_harmonized.ds	dsstdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.ds	dsstdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dsstdte	Keep	NULL
clinical_trials_harmonized.ds	dsstdtp	Keep	NULL
clinical_trials_harmonized.ds	dsstdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsstedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsstpdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsstth	Keep	NULL
clinical_trials_harmonized.ds	dssucr	Keep	NULL
clinical_trials_harmonized.ds	dssuin	Keep	NULL
clinical_trials_harmonized.ds	dsswcd	Keep	NULL
clinical_trials_harmonized.ds	dstchg	Keep	NULL
clinical_trials_harmonized.ds	dsterm1	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsterm2	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsterm3	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dsterm4	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dstermsp	Keep	NULL
clinical_trials_harmonized.ds	dsterm	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	dstest	Keep	NULL
clinical_trials_harmonized.ds	dstg2	Keep	NULL
clinical_trials_harmonized.ds	dstg2t	Keep	NULL
clinical_trials_harmonized.ds	dstg3a	Keep	NULL
clinical_trials_harmonized.ds	dstg4a	Keep	NULL
clinical_trials_harmonized.ds	dstg4p	Keep	NULL
clinical_trials_harmonized.ds	dstgot	Keep	NULL
clinical_trials_harmonized.ds	dsthd	Keep	NULL
clinical_trials_harmonized.ds	dstnhd	Keep	NULL
clinical_trials_harmonized.ds	dstoxot	Keep	NULL
clinical_trials_harmonized.ds	dstoxsp	Keep	NULL
clinical_trials_harmonized.ds	dstox	Keep	NULL
clinical_trials_harmonized.ds	dstrtr	Keep	NULL
clinical_trials_harmonized.ds	dstvu	Keep	NULL
clinical_trials_harmonized.ds	dsunrd	Keep	NULL
clinical_trials_harmonized.ds	dsute	Keep	NULL
clinical_trials_harmonized.ds	dsvale	Keep	NULL
clinical_trials_harmonized.ds	dsvdra	Keep	NULL
clinical_trials_harmonized.ds	dsvitd	Keep	NULL
clinical_trials_harmonized.ds	dswbcva	Keep	NULL
clinical_trials_harmonized.ds	dswcsp1	Keep	NULL
clinical_trials_harmonized.ds	dswcsp2	Keep	NULL
clinical_trials_harmonized.ds	dswcsp	Keep	NULL
clinical_trials_harmonized.ds	dswc	Keep	NULL
clinical_trials_harmonized.ds	dswdtc1	Keep	NULL
clinical_trials_harmonized.ds	dswdtc2	Keep	NULL
clinical_trials_harmonized.ds	dswdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dswdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	dswdte	Keep	NULL
clinical_trials_harmonized.ds	dswdtp	Keep	NULL
clinical_trials_harmonized.ds	dswodcsp	Keep	NULL
clinical_trials_harmonized.ds	dswodc	Keep	NULL
clinical_trials_harmonized.ds	dswodpsp	Keep	NULL
clinical_trials_harmonized.ds	dswodp	Keep	NULL
clinical_trials_harmonized.ds	dswsp	Keep	NULL
clinical_trials_harmonized.ds	dsws	Keep	NULL
clinical_trials_harmonized.ds	edcix	Keep	NULL
clinical_trials_harmonized.ds	edcix_x	Keep	NULL
clinical_trials_harmonized.ds	epoch	Keep	NULL
clinical_trials_harmonized.ds	gnqq	Keep	NULL
clinical_trials_harmonized.ds	idvar	Keep	NULL
clinical_trials_harmonized.ds	idvarval	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ds	invid	Redact	Detected Entity with tag PII "clinical_invid"
clinical_trials_harmonized.ds	invsite	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ds	inv	Keep	NULL
clinical_trials_harmonized.ds	lockflag	Keep	NULL
clinical_trials_harmonized.ds	logints	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	lstchgts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ds	pt	Keep	NULL
clinical_trials_harmonized.ds	qeval	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	qlabel	Keep	NULL
clinical_trials_harmonized.ds	qnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	qorig	Keep	NULL
clinical_trials_harmonized.ds	qualifyv	Keep	NULL
clinical_trials_harmonized.ds	qval	Keep	NULL
clinical_trials_harmonized.ds	rdomain	Keep	NULL
clinical_trials_harmonized.ds	repeatsn	Keep	NULL
clinical_trials_harmonized.ds	rowid	Keep	NULL
clinical_trials_harmonized.ds	studyid	Keep	Detected Entity "clinical_studyid"
clinical_trials_harmonized.ds	study	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ds	subjid	FPENumeric	Detected Entity with tag PII "clinical_subjid"
clinical_trials_harmonized.ds	subsetsn	Keep	NULL
clinical_trials_harmonized.ds	usubjid	FPEAlphaNumeric	Detected Entity with tag PII "clinical_usubjid"
clinical_trials_harmonized.ds	visitnum	Keep	NULL
clinical_trials_harmonized.ds	visit	Keep	NULL
clinical_trials_harmonized.ds	source_dataset	Keep	NULL
clinical_trials_harmonized.ec	accessts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	actevent	Keep	NULL
clinical_trials_harmonized.ec	country	Keep	NULL
clinical_trials_harmonized.ec	cpevent	Keep	NULL
clinical_trials_harmonized.ec	dcmdate	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	dcmname	Keep	NULL
clinical_trials_harmonized.ec	dcmsubnm	Keep	NULL
clinical_trials_harmonized.ec	dcmtime	Keep	NULL
clinical_trials_harmonized.ec	docnum	Keep	NULL
clinical_trials_harmonized.ec	domain	Keep	NULL
clinical_trials_harmonized.ec	ecacdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecacdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecacdtp	Keep	NULL
clinical_trials_harmonized.ec	ecacdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecacedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecadj	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecasacn	Keep	NULL
clinical_trials_harmonized.ec	ecasmcd	Keep	NULL
clinical_trials_harmonized.ec	ecasm	Keep	NULL
clinical_trials_harmonized.ec	eccat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	eccompsp	Keep	NULL
clinical_trials_harmonized.ec	eccomp	Keep	NULL
clinical_trials_harmonized.ec	eccom	Keep	NULL
clinical_trials_harmonized.ec	ecdacmet	Keep	NULL
clinical_trials_harmonized.ec	ecdecdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecdecdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecdecdtp	Keep	NULL
clinical_trials_harmonized.ec	ecdecdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecdecedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecdesc	Keep	NULL
clinical_trials_harmonized.ec	ecdirfl	Keep	NULL
clinical_trials_harmonized.ec	ecdirfn	Keep	NULL
clinical_trials_harmonized.ec	ecdir	Keep	NULL
clinical_trials_harmonized.ec	ecdose	Keep	NULL
clinical_trials_harmonized.ec	ecdosfrm	Keep	NULL
clinical_trials_harmonized.ec	ecdosfrq	Keep	NULL
clinical_trials_harmonized.ec	ecdosrgm	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecdostkp	Keep	NULL
clinical_trials_harmonized.ec	ecdostot	Keep	NULL
clinical_trials_harmonized.ec	ecdostxt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecdosu	Keep	NULL
clinical_trials_harmonized.ec	ecdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecdte	Keep	NULL
clinical_trials_harmonized.ec	ecdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecdtp	Keep	NULL
clinical_trials_harmonized.ec	ecdur	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecdwt	Keep	NULL
clinical_trials_harmonized.ec	ecdwtu	Keep	NULL
clinical_trials_harmonized.ec	ecdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecendtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecendy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecentmc	Keep	NULL
clinical_trials_harmonized.ec	ecentm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecescdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecescdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecescdtp	Keep	NULL
clinical_trials_harmonized.ec	ecescdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecescedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecgrpid	Keep	NULL
clinical_trials_harmonized.ec	ecindc	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecircmet	Keep	NULL
clinical_trials_harmonized.ec	ecirdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecirdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecirdtp	Keep	NULL
clinical_trials_harmonized.ec	ecirdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	eciredy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecistwsh	Keep	NULL
clinical_trials_harmonized.ec	eclat	Keep	NULL
clinical_trials_harmonized.ec	eclnkid	Keep	NULL
clinical_trials_harmonized.ec	ecloc	Keep	NULL
clinical_trials_harmonized.ec	eclot	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecmood	Keep	NULL
clinical_trials_harmonized.ec	ecnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecoccur	Keep	NULL
clinical_trials_harmonized.ec	ecorcd	Keep	NULL
clinical_trials_harmonized.ec	ecorescd	Keep	NULL
clinical_trials_harmonized.ec	ecorresn	Keep	NULL
clinical_trials_harmonized.ec	ecorres	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecorresu	Keep	NULL
clinical_trials_harmonized.ec	ecorrsl	Keep	NULL
clinical_trials_harmonized.ec	ecorsp	Keep	NULL
clinical_trials_harmonized.ec	ecpdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecppwt	Keep	NULL
clinical_trials_harmonized.ec	ecppwtu	Keep	NULL
clinical_trials_harmonized.ec	ecpresp	Keep	NULL
clinical_trials_harmonized.ec	ecpstrg	Keep	NULL
clinical_trials_harmonized.ec	ecpstrgu	Keep	NULL
clinical_trials_harmonized.ec	ecrefid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ec	ecrftdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecroute	Keep	NULL
clinical_trials_harmonized.ec	ecroutsp	Keep	NULL
clinical_trials_harmonized.ec	ecscat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecsecd	Keep	NULL
clinical_trials_harmonized.ec	ecseq	Keep	NULL
clinical_trials_harmonized.ec	ecspid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ec	ecstdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecstdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecstdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ecstdtp	Keep	NULL
clinical_trials_harmonized.ec	ecstdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecstedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecstpdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ecsttmc	Keep	NULL
clinical_trials_harmonized.ec	ecsttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ectestcd	Keep	NULL
clinical_trials_harmonized.ec	ectest	Keep	NULL
clinical_trials_harmonized.ec	ectmc	Keep	NULL
clinical_trials_harmonized.ec	ectme	Keep	NULL
clinical_trials_harmonized.ec	ectm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	ectptnum	Keep	NULL
clinical_trials_harmonized.ec	ectptref	Keep	NULL
clinical_trials_harmonized.ec	ectpt	Keep	NULL
clinical_trials_harmonized.ec	ectrt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	ectsacn	Keep	NULL
clinical_trials_harmonized.ec	edcix	Keep	NULL
clinical_trials_harmonized.ec	edcix_x	Keep	NULL
clinical_trials_harmonized.ec	epoch	Keep	NULL
clinical_trials_harmonized.ec	idvar	Keep	NULL
clinical_trials_harmonized.ec	idvarval	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ec	invid	Redact	Detected Entity with tag PII "clinical_invid"
clinical_trials_harmonized.ec	invsite	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ec	lockflag	Keep	NULL
clinical_trials_harmonized.ec	logints	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	lstchgts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ec	pt	Keep	NULL
clinical_trials_harmonized.ec	qeval	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	qlabel	Keep	NULL
clinical_trials_harmonized.ec	qnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ec	qorig	Keep	NULL
clinical_trials_harmonized.ec	qualifyv	Keep	NULL
clinical_trials_harmonized.ec	qval	Keep	NULL
clinical_trials_harmonized.ec	rdomain	Keep	NULL
clinical_trials_harmonized.ec	repeatsn	Keep	NULL
clinical_trials_harmonized.ec	rowid	Keep	NULL
clinical_trials_harmonized.ec	studyid	Keep	Detected Entity "clinical_studyid"
clinical_trials_harmonized.ec	subjid	FPENumeric	Detected Entity with tag PII "clinical_subjid"
clinical_trials_harmonized.ec	subsetsn	Keep	NULL
clinical_trials_harmonized.ec	usubjid	FPEAlphaNumeric	Detected Entity with tag PII "clinical_usubjid"
clinical_trials_harmonized.ec	visitnum	Keep	NULL
clinical_trials_harmonized.ec	visit	Keep	NULL
clinical_trials_harmonized.ec	source_dataset	Keep	NULL
clinical_trials_harmonized.ex	accessts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	actevent	Keep	NULL
clinical_trials_harmonized.ex	country	Keep	NULL
clinical_trials_harmonized.ex	cpe_bl	Keep	NULL
clinical_trials_harmonized.ex	cpe_dos	Keep	NULL
clinical_trials_harmonized.ex	cpe_en	Keep	NULL
clinical_trials_harmonized.ex	cpe_st	Keep	NULL
clinical_trials_harmonized.ex	cpevent	Keep	NULL
clinical_trials_harmonized.ex	dcmdate	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	dcmname	Keep	NULL
clinical_trials_harmonized.ex	dcmsubnm	Keep	NULL
clinical_trials_harmonized.ex	dcmtime	Keep	NULL
clinical_trials_harmonized.ex	dmdswbch	Keep	NULL
clinical_trials_harmonized.ex	docnum	Keep	NULL
clinical_trials_harmonized.ex	domain	Keep	NULL
clinical_trials_harmonized.ex	dvorres2	Keep	NULL
clinical_trials_harmonized.ex	edcix1	Keep	NULL
clinical_trials_harmonized.ex	edcix2	Keep	NULL
clinical_trials_harmonized.ex	edcix	Keep	NULL
clinical_trials_harmonized.ex	edcix_x	Keep	NULL
clinical_trials_harmonized.ex	epoch	Keep	NULL
clinical_trials_harmonized.ex	ex1stdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	ex1stdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	ex1stdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	ex1stdtp	Keep	NULL
clinical_trials_harmonized.ex	ex1stdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	ex1stedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	ex1sttmc	Keep	NULL
clinical_trials_harmonized.ex	ex1sttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	ex2stdtc	Keep	NULL
clinical_trials_harmonized.ex	ex2stdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	ex2stdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	ex2stdtp	Keep	NULL
clinical_trials_harmonized.ex	ex2stdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	ex2stedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	ex2sttmc	Keep	NULL
clinical_trials_harmonized.ex	ex2sttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	ex3sttmc	Keep	NULL
clinical_trials_harmonized.ex	ex3sttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exadev	Keep	NULL
clinical_trials_harmonized.ex	exadjae	Keep	NULL
clinical_trials_harmonized.ex	exadjcd	Keep	NULL
clinical_trials_harmonized.ex	exadjind	Keep	NULL
clinical_trials_harmonized.ex	exadjn	Keep	NULL
clinical_trials_harmonized.ex	exadjot	Keep	NULL
clinical_trials_harmonized.ex	exadjsp	Keep	NULL
clinical_trials_harmonized.ex	exadj	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exadmncd	Keep	NULL
clinical_trials_harmonized.ex	exadmn	Keep	NULL
clinical_trials_harmonized.ex	exadtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exadt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exadte	Keep	NULL
clinical_trials_harmonized.ex	exadtp	Keep	NULL
clinical_trials_harmonized.ex	examtc	Keep	NULL
clinical_trials_harmonized.ex	examtcu	Keep	NULL
clinical_trials_harmonized.ex	exaper	Keep	NULL
clinical_trials_harmonized.ex	exapl	Keep	NULL
clinical_trials_harmonized.ex	exapowt	Keep	NULL
clinical_trials_harmonized.ex	exapowtu	Keep	NULL
clinical_trials_harmonized.ex	exappcn	Keep	NULL
clinical_trials_harmonized.ex	exappc	Keep	NULL
clinical_trials_harmonized.ex	exaprwt	Keep	NULL
clinical_trials_harmonized.ex	exaprwtu	Keep	NULL
clinical_trials_harmonized.ex	exatrt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exatyp	Keep	NULL
clinical_trials_harmonized.ex	exaucsp	Keep	NULL
clinical_trials_harmonized.ex	exauc	Keep	NULL
clinical_trials_harmonized.ex	exaucu	Keep	NULL
clinical_trials_harmonized.ex	exbklot	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exbldtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exbldt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exbldte	Keep	NULL
clinical_trials_harmonized.ex	exbldtp	Keep	NULL
clinical_trials_harmonized.ex	exbldy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exbledy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exblklot	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exblklt1	Keep	NULL
clinical_trials_harmonized.ex	exblklt2	Keep	NULL
clinical_trials_harmonized.ex	exbott1	Keep	NULL
clinical_trials_harmonized.ex	exbott2	Keep	NULL
clinical_trials_harmonized.ex	exbott	Keep	NULL
clinical_trials_harmonized.ex	exbsa	Keep	NULL
clinical_trials_harmonized.ex	exbsau	Keep	NULL
clinical_trials_harmonized.ex	excatcd	Keep	NULL
clinical_trials_harmonized.ex	excat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	excfap	Keep	NULL
clinical_trials_harmonized.ex	excflu	Keep	NULL
clinical_trials_harmonized.ex	excfodsp	Keep	NULL
clinical_trials_harmonized.ex	excfood	Keep	NULL
clinical_trials_harmonized.ex	exchcp	Keep	NULL
clinical_trials_harmonized.ex	excliqsp	Keep	NULL
clinical_trials_harmonized.ex	excliq	Keep	NULL
clinical_trials_harmonized.ex	excloc	Keep	NULL
clinical_trials_harmonized.ex	excohort	Keep	NULL
clinical_trials_harmonized.ex	excoid10	Keep	NULL
clinical_trials_harmonized.ex	excoid1	Keep	NULL
clinical_trials_harmonized.ex	excoid2	Keep	NULL
clinical_trials_harmonized.ex	excoid3	Keep	NULL
clinical_trials_harmonized.ex	excoid4	Keep	NULL
clinical_trials_harmonized.ex	excoid5	Keep	NULL
clinical_trials_harmonized.ex	excoid6	Keep	NULL
clinical_trials_harmonized.ex	excoid7	Keep	NULL
clinical_trials_harmonized.ex	excoid8	Keep	NULL
clinical_trials_harmonized.ex	excoid9	Keep	NULL
clinical_trials_harmonized.ex	excomc1	Keep	NULL
clinical_trials_harmonized.ex	excomc2	Keep	NULL
clinical_trials_harmonized.ex	excomcl	Keep	NULL
clinical_trials_harmonized.ex	excomcn	Keep	NULL
clinical_trials_harmonized.ex	excomc	Keep	NULL
clinical_trials_harmonized.ex	excompc1	Keep	NULL
clinical_trials_harmonized.ex	excompc2	Keep	NULL
clinical_trials_harmonized.ex	excompc3	Keep	NULL
clinical_trials_harmonized.ex	excompc4	Keep	NULL
clinical_trials_harmonized.ex	excompc5	Keep	NULL
clinical_trials_harmonized.ex	excompc6	Keep	NULL
clinical_trials_harmonized.ex	excompc7	Keep	NULL
clinical_trials_harmonized.ex	excompc8	Keep	NULL
clinical_trials_harmonized.ex	excompcd	Keep	NULL
clinical_trials_harmonized.ex	excompc	Keep	NULL
clinical_trials_harmonized.ex	excompn	Keep	NULL
clinical_trials_harmonized.ex	excompr	Keep	NULL
clinical_trials_harmonized.ex	excompsp	Keep	NULL
clinical_trials_harmonized.ex	excomp	Keep	NULL
clinical_trials_harmonized.ex	excompx	Keep	NULL
clinical_trials_harmonized.ex	excom	Keep	NULL
clinical_trials_harmonized.ex	excomty	Keep	NULL
clinical_trials_harmonized.ex	excosd	Keep	NULL
clinical_trials_harmonized.ex	excpossp	Keep	NULL
clinical_trials_harmonized.ex	excpos	Keep	NULL
clinical_trials_harmonized.ex	excross	Keep	NULL
clinical_trials_harmonized.ex	excycl	Keep	NULL
clinical_trials_harmonized.ex	exdchgn	Keep	NULL
clinical_trials_harmonized.ex	exdchg	Keep	NULL
clinical_trials_harmonized.ex	exddil	Keep	NULL
clinical_trials_harmonized.ex	exdedtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exdedt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exdedtp	Keep	NULL
clinical_trials_harmonized.ex	exdel	Keep	NULL
clinical_trials_harmonized.ex	exdevcd	Keep	NULL
clinical_trials_harmonized.ex	exdev	Keep	NULL
clinical_trials_harmonized.ex	exdfrd1	Keep	NULL
clinical_trials_harmonized.ex	exdfrd2	Keep	NULL
clinical_trials_harmonized.ex	exdfrd	Keep	NULL
clinical_trials_harmonized.ex	exdidtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exdidt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exdidtp	Keep	NULL
clinical_trials_harmonized.ex	exdidy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exdiedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exdir	Keep	NULL
clinical_trials_harmonized.ex	exdisp1	Keep	NULL
clinical_trials_harmonized.ex	exdisp2	Keep	NULL
clinical_trials_harmonized.ex	exdisp3	Keep	NULL
clinical_trials_harmonized.ex	exdisp4	Keep	NULL
clinical_trials_harmonized.ex	exdisp	Keep	NULL
clinical_trials_harmonized.ex	exdnum	Keep	NULL
clinical_trials_harmonized.ex	exdofd	Keep	NULL
clinical_trials_harmonized.ex	exdofol	Keep	NULL
clinical_trials_harmonized.ex	exdofon	Keep	NULL
clinical_trials_harmonized.ex	exdofo	Keep	NULL
clinical_trials_harmonized.ex	exdofql	Keep	NULL
clinical_trials_harmonized.ex	exdofqn	Keep	NULL
clinical_trials_harmonized.ex	exdofq	Keep	NULL
clinical_trials_harmonized.ex	exdopu1	Keep	NULL
clinical_trials_harmonized.ex	exdopu2	Keep	NULL
clinical_trials_harmonized.ex	exdos2u	Keep	NULL
clinical_trials_harmonized.ex	exdosa	Keep	NULL
clinical_trials_harmonized.ex	exdosc	Keep	NULL
clinical_trials_harmonized.ex	exdosd	Keep	NULL
clinical_trials_harmonized.ex	exdos	Keep	NULL
clinical_trials_harmonized.ex	exdose1	Keep	NULL
clinical_trials_harmonized.ex	exdose2	Keep	NULL
clinical_trials_harmonized.ex	exdose3	Keep	NULL
clinical_trials_harmonized.ex	exdose4	Keep	NULL
clinical_trials_harmonized.ex	exdosed	Keep	NULL
clinical_trials_harmonized.ex	exdose_	Keep	NULL
clinical_trials_harmonized.ex	exdose	Keep	NULL
clinical_trials_harmonized.ex	exdosee	Keep	NULL
clinical_trials_harmonized.ex	exdosesp	Keep	NULL
clinical_trials_harmonized.ex	exdoseu	Keep	NULL
clinical_trials_harmonized.ex	exdosfcd	Keep	NULL
clinical_trials_harmonized.ex	exdosfm_	Keep	NULL
clinical_trials_harmonized.ex	exdosfm	Keep	NULL
clinical_trials_harmonized.ex	exdosfq1	Keep	NULL
clinical_trials_harmonized.ex	exdosfq2	Keep	NULL
clinical_trials_harmonized.ex	exdosfq_	Keep	NULL
clinical_trials_harmonized.ex	exdosfq	Keep	NULL
clinical_trials_harmonized.ex	exdosfr1	Keep	NULL
clinical_trials_harmonized.ex	exdosfr2	Keep	NULL
clinical_trials_harmonized.ex	exdosfr3	Keep	NULL
clinical_trials_harmonized.ex	exdosfr4	Keep	NULL
clinical_trials_harmonized.ex	exdosfrm	Keep	NULL
clinical_trials_harmonized.ex	exdosfrq	Keep	NULL
clinical_trials_harmonized.ex	exdosfr	Keep	NULL
clinical_trials_harmonized.ex	exdosgrp	Keep	NULL
clinical_trials_harmonized.ex	exdosi	Keep	NULL
clinical_trials_harmonized.ex	exdosint	Keep	NULL
clinical_trials_harmonized.ex	exdoslam	Keep	NULL
clinical_trials_harmonized.ex	exdoslop	Keep	NULL
clinical_trials_harmonized.ex	exdosqcd	Keep	NULL
clinical_trials_harmonized.ex	exdosrgm	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exdosrit	Keep	NULL
clinical_trials_harmonized.ex	exdosta	Keep	NULL
clinical_trials_harmonized.ex	exdostau	Keep	NULL
clinical_trials_harmonized.ex	exdostkp	Keep	NULL
clinical_trials_harmonized.ex	exdostms	Keep	NULL
clinical_trials_harmonized.ex	exdosto1	Keep	NULL
clinical_trials_harmonized.ex	exdosto2	Keep	NULL
clinical_trials_harmonized.ex	exdostoc	Keep	NULL
clinical_trials_harmonized.ex	exdosto	Keep	NULL
clinical_trials_harmonized.ex	exdostos	Keep	NULL
clinical_trials_harmonized.ex	exdostot	Keep	NULL
clinical_trials_harmonized.ex	exdostou	Keep	NULL
clinical_trials_harmonized.ex	exdostr	Keep	NULL
clinical_trials_harmonized.ex	exdost	Keep	NULL
clinical_trials_harmonized.ex	exdostxt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exdosty	Keep	NULL
clinical_trials_harmonized.ex	exdosu1	Keep	NULL
clinical_trials_harmonized.ex	exdosu2	Keep	NULL
clinical_trials_harmonized.ex	exdosu3	Keep	NULL
clinical_trials_harmonized.ex	exdosu4	Keep	NULL
clinical_trials_harmonized.ex	exdosu_	Keep	NULL
clinical_trials_harmonized.ex	exdosu	Keep	NULL
clinical_trials_harmonized.ex	exdosvl	Keep	NULL
clinical_trials_harmonized.ex	exdosvlu	Keep	NULL
clinical_trials_harmonized.ex	exdoswg	Keep	NULL
clinical_trials_harmonized.ex	exdoswgu	Keep	NULL
clinical_trials_harmonized.ex	exdoszid	Keep	NULL
clinical_trials_harmonized.ex	exdotd1	Keep	NULL
clinical_trials_harmonized.ex	exdotd2	Keep	NULL
clinical_trials_harmonized.ex	exdotd	Keep	NULL
clinical_trials_harmonized.ex	exdototu	Keep	NULL
clinical_trials_harmonized.ex	exdott1	Keep	NULL
clinical_trials_harmonized.ex	exdott2	Keep	NULL
clinical_trials_harmonized.ex	exdott	Keep	NULL
clinical_trials_harmonized.ex	exdotu	Keep	NULL
clinical_trials_harmonized.ex	exdoud	Keep	NULL
clinical_trials_harmonized.ex	exdsphsp	Keep	NULL
clinical_trials_harmonized.ex	exdsph	Keep	NULL
clinical_trials_harmonized.ex	exdsphu	Keep	NULL
clinical_trials_harmonized.ex	exdstu	Keep	NULL
clinical_trials_harmonized.ex	exdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exdtot	Keep	NULL
clinical_trials_harmonized.ex	exdtott	Keep	NULL
clinical_trials_harmonized.ex	exdtottu	Keep	NULL
clinical_trials_harmonized.ex	exdtp	Keep	NULL
clinical_trials_harmonized.ex	exdur	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exduru	Keep	NULL
clinical_trials_harmonized.ex	exdwgt	Keep	NULL
clinical_trials_harmonized.ex	exdwgtu	Keep	NULL
clinical_trials_harmonized.ex	exdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exedmp	Keep	NULL
clinical_trials_harmonized.ex	exedtce	Keep	NULL
clinical_trials_harmonized.ex	exedtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exedtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exedtp	Keep	NULL
clinical_trials_harmonized.ex	exedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exeltm	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exendt_c	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exendtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.ex	exendt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exendte	Keep	NULL
clinical_trials_harmonized.ex	exendtmp	Keep	NULL
clinical_trials_harmonized.ex	exendtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exendtp	Keep	NULL
clinical_trials_harmonized.ex	exendy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exened	Keep	NULL
clinical_trials_harmonized.ex	exenedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exentmc	Keep	NULL
clinical_trials_harmonized.ex	exentme	Keep	NULL
clinical_trials_harmonized.ex	exentmp	Keep	NULL
clinical_trials_harmonized.ex	exentms	Keep	NULL
clinical_trials_harmonized.ex	exentm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exepdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exepdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exepdtp	Keep	NULL
clinical_trials_harmonized.ex	exepdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exepedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exepoch	Keep	NULL
clinical_trials_harmonized.ex	exetmp	Keep	NULL
clinical_trials_harmonized.ex	exfdac1	Keep	NULL
clinical_trials_harmonized.ex	exfdac2	Keep	NULL
clinical_trials_harmonized.ex	exfdac3	Keep	NULL
clinical_trials_harmonized.ex	exfdac4	Keep	NULL
clinical_trials_harmonized.ex	exfdac5	Keep	NULL
clinical_trials_harmonized.ex	exfdacpo	Keep	NULL
clinical_trials_harmonized.ex	exfdacpr	Keep	NULL
clinical_trials_harmonized.ex	exfdac	Keep	NULL
clinical_trials_harmonized.ex	exfddosu	Keep	NULL
clinical_trials_harmonized.ex	exfddtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.ex	exfddt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exfddte	Keep	NULL
clinical_trials_harmonized.ex	exfddtp	Keep	NULL
clinical_trials_harmonized.ex	exfdic	Keep	NULL
clinical_trials_harmonized.ex	exfido	Keep	NULL
clinical_trials_harmonized.ex	exfinlot	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exfinlt1	Keep	NULL
clinical_trials_harmonized.ex	exfinlt2	Keep	NULL
clinical_trials_harmonized.ex	exfmdos	Keep	NULL
clinical_trials_harmonized.ex	exfmdosu	Keep	NULL
clinical_trials_harmonized.ex	exfnlot	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exfqsp	Keep	NULL
clinical_trials_harmonized.ex	exfreq	Keep	NULL
clinical_trials_harmonized.ex	exfrqmd	Keep	NULL
clinical_trials_harmonized.ex	exgrpid	Keep	NULL
clinical_trials_harmonized.ex	exiaer1	Keep	NULL
clinical_trials_harmonized.ex	exiaer2	Keep	NULL
clinical_trials_harmonized.ex	exiaer3	Keep	NULL
clinical_trials_harmonized.ex	exiaer4	Keep	NULL
clinical_trials_harmonized.ex	exiaer5	Keep	NULL
clinical_trials_harmonized.ex	exindc	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exinfdr	Keep	NULL
clinical_trials_harmonized.ex	exinfdru	Keep	NULL
clinical_trials_harmonized.ex	exinfr	Keep	NULL
clinical_trials_harmonized.ex	exinfrea	Keep	NULL
clinical_trials_harmonized.ex	exinfru	Keep	NULL
clinical_trials_harmonized.ex	exinr1	Keep	NULL
clinical_trials_harmonized.ex	exinr2	Keep	NULL
clinical_trials_harmonized.ex	exinr	Keep	NULL
clinical_trials_harmonized.ex	exinru1	Keep	NULL
clinical_trials_harmonized.ex	exinru2	Keep	NULL
clinical_trials_harmonized.ex	exinru	Keep	NULL
clinical_trials_harmonized.ex	exintl	Keep	NULL
clinical_trials_harmonized.ex	exintn	Keep	NULL
clinical_trials_harmonized.ex	exintrup	Keep	NULL
clinical_trials_harmonized.ex	exint	Keep	NULL
clinical_trials_harmonized.ex	exinvo1	Keep	NULL
clinical_trials_harmonized.ex	exinvo2	Keep	NULL
clinical_trials_harmonized.ex	exinvo	Keep	NULL
clinical_trials_harmonized.ex	exinvou1	Keep	NULL
clinical_trials_harmonized.ex	exinvou2	Keep	NULL
clinical_trials_harmonized.ex	exinvou	Keep	NULL
clinical_trials_harmonized.ex	exirchg	Keep	NULL
clinical_trials_harmonized.ex	existwsh	Keep	NULL
clinical_trials_harmonized.ex	exivol	Keep	NULL
clinical_trials_harmonized.ex	exivolu	Keep	NULL
clinical_trials_harmonized.ex	exkit10	Keep	NULL
clinical_trials_harmonized.ex	exkit11	Keep	NULL
clinical_trials_harmonized.ex	exkit12	Keep	NULL
clinical_trials_harmonized.ex	exkit13	Keep	NULL
clinical_trials_harmonized.ex	exkit14	Keep	NULL
clinical_trials_harmonized.ex	exkit15	Keep	NULL
clinical_trials_harmonized.ex	exkit16	Keep	NULL
clinical_trials_harmonized.ex	exkit17	Keep	NULL
clinical_trials_harmonized.ex	exkit1	Keep	NULL
clinical_trials_harmonized.ex	exkit2	Keep	NULL
clinical_trials_harmonized.ex	exkit3	Keep	NULL
clinical_trials_harmonized.ex	exkit4	Keep	NULL
clinical_trials_harmonized.ex	exkit5	Keep	NULL
clinical_trials_harmonized.ex	exkit6	Keep	NULL
clinical_trials_harmonized.ex	exkit7	Keep	NULL
clinical_trials_harmonized.ex	exkit8	Keep	NULL
clinical_trials_harmonized.ex	exkit9	Keep	NULL
clinical_trials_harmonized.ex	exkit	Keep	NULL
clinical_trials_harmonized.ex	exlat	Keep	NULL
clinical_trials_harmonized.ex	exldds	Keep	NULL
clinical_trials_harmonized.ex	exlddtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exlddt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exlddte	Keep	NULL
clinical_trials_harmonized.ex	exlddtp	Keep	NULL
clinical_trials_harmonized.ex	exlidesc	Keep	NULL
clinical_trials_harmonized.ex	exliqac	Keep	NULL
clinical_trials_harmonized.ex	exliqc1	Keep	NULL
clinical_trials_harmonized.ex	exliqc2	Keep	NULL
clinical_trials_harmonized.ex	exliqcl	Keep	NULL
clinical_trials_harmonized.ex	exliqcn	Keep	NULL
clinical_trials_harmonized.ex	exliqcsp	Keep	NULL
clinical_trials_harmonized.ex	exliqc	Keep	NULL
clinical_trials_harmonized.ex	exliq	Keep	NULL
clinical_trials_harmonized.ex	exliqic1	Keep	NULL
clinical_trials_harmonized.ex	exliqic2	Keep	NULL
clinical_trials_harmonized.ex	exliqic	Keep	NULL
clinical_trials_harmonized.ex	exliqn	Keep	NULL
clinical_trials_harmonized.ex	exliqnu	Keep	NULL
clinical_trials_harmonized.ex	exliqu	Keep	NULL
clinical_trials_harmonized.ex	exlnkid	Keep	NULL
clinical_trials_harmonized.ex	exloccd	Keep	NULL
clinical_trials_harmonized.ex	exlocl	Keep	NULL
clinical_trials_harmonized.ex	exlocsp	Keep	NULL
clinical_trials_harmonized.ex	exloc	Keep	NULL
clinical_trials_harmonized.ex	exlot1	Keep	NULL
clinical_trials_harmonized.ex	exlot1_x	Keep	NULL
clinical_trials_harmonized.ex	exlot2	Keep	NULL
clinical_trials_harmonized.ex	exlot3	Keep	NULL
clinical_trials_harmonized.ex	exlot4	Keep	NULL
clinical_trials_harmonized.ex	exlot5	Keep	NULL
clinical_trials_harmonized.ex	exlot6	Keep	NULL
clinical_trials_harmonized.ex	exlotb	Keep	NULL
clinical_trials_harmonized.ex	exlotd	Keep	NULL
clinical_trials_harmonized.ex	exlotno	Keep	NULL
clinical_trials_harmonized.ex	exlotnum	Keep	NULL
clinical_trials_harmonized.ex	exlot_	Keep	NULL
clinical_trials_harmonized.ex	exlot	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exmanfsp	Keep	NULL
clinical_trials_harmonized.ex	exmanf	Keep	NULL
clinical_trials_harmonized.ex	exmdsc	Keep	NULL
clinical_trials_harmonized.ex	exmethcd	Keep	NULL
clinical_trials_harmonized.ex	exmethod	Keep	NULL
clinical_trials_harmonized.ex	exmlc1	Keep	NULL
clinical_trials_harmonized.ex	exmlc2	Keep	NULL
clinical_trials_harmonized.ex	exmlc	Keep	NULL
clinical_trials_harmonized.ex	exmldesc	Keep	NULL
clinical_trials_harmonized.ex	exmood	Keep	NULL
clinical_trials_harmonized.ex	exnpre1	Keep	NULL
clinical_trials_harmonized.ex	exnpre2	Keep	NULL
clinical_trials_harmonized.ex	exoccur	Keep	NULL
clinical_trials_harmonized.ex	exong	Keep	NULL
clinical_trials_harmonized.ex	exopen	Keep	NULL
clinical_trials_harmonized.ex	expdose1	Keep	NULL
clinical_trials_harmonized.ex	expdose2	Keep	NULL
clinical_trials_harmonized.ex	expdose3	Keep	NULL
clinical_trials_harmonized.ex	expdose4	Keep	NULL
clinical_trials_harmonized.ex	expdose	Keep	NULL
clinical_trials_harmonized.ex	expdossp	Keep	NULL
clinical_trials_harmonized.ex	expdosu1	Keep	NULL
clinical_trials_harmonized.ex	expdosu2	Keep	NULL
clinical_trials_harmonized.ex	expdosu3	Keep	NULL
clinical_trials_harmonized.ex	expdosu	Keep	NULL
clinical_trials_harmonized.ex	expdpcsp	Keep	NULL
clinical_trials_harmonized.ex	expdpc	Keep	NULL
clinical_trials_harmonized.ex	expdsc	Keep	NULL
clinical_trials_harmonized.ex	expdse1	Keep	NULL
clinical_trials_harmonized.ex	expdse2	Keep	NULL
clinical_trials_harmonized.ex	expdstot	Keep	NULL
clinical_trials_harmonized.ex	expdstou	Keep	NULL
clinical_trials_harmonized.ex	expdwgt	Keep	NULL
clinical_trials_harmonized.ex	expdwgtu	Keep	NULL
clinical_trials_harmonized.ex	expdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	expformc	Keep	NULL
clinical_trials_harmonized.ex	expform	Keep	NULL
clinical_trials_harmonized.ex	exphase	Keep	NULL
clinical_trials_harmonized.ex	explccd	Keep	NULL
clinical_trials_harmonized.ex	explcsp	Keep	NULL
clinical_trials_harmonized.ex	explc	Keep	NULL
clinical_trials_harmonized.ex	explev	Keep	NULL
clinical_trials_harmonized.ex	expnum	Keep	NULL
clinical_trials_harmonized.ex	expoch	Keep	NULL
clinical_trials_harmonized.ex	expopmp	Keep	NULL
clinical_trials_harmonized.ex	expopmpu	Keep	NULL
clinical_trials_harmonized.ex	exporad	Keep	NULL
clinical_trials_harmonized.ex	expora	Keep	NULL
clinical_trials_harmonized.ex	exporadu	Keep	NULL
clinical_trials_harmonized.ex	exporau	Keep	NULL
clinical_trials_harmonized.ex	exposcl	Keep	NULL
clinical_trials_harmonized.ex	exposcn	Keep	NULL
clinical_trials_harmonized.ex	exposcsp	Keep	NULL
clinical_trials_harmonized.ex	exposc	Keep	NULL
clinical_trials_harmonized.ex	exposyr	Keep	NULL
clinical_trials_harmonized.ex	exposyru	Keep	NULL
clinical_trials_harmonized.ex	exprdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exprdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exprdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exprdtp	Keep	NULL
clinical_trials_harmonized.ex	exprdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	expredy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	expresp	Keep	NULL
clinical_trials_harmonized.ex	exprpmp	Keep	NULL
clinical_trials_harmonized.ex	exprpmpu	Keep	NULL
clinical_trials_harmonized.ex	exprrad	Keep	NULL
clinical_trials_harmonized.ex	exprra	Keep	NULL
clinical_trials_harmonized.ex	exprradu	Keep	NULL
clinical_trials_harmonized.ex	exprrau	Keep	NULL
clinical_trials_harmonized.ex	exprsyr	Keep	NULL
clinical_trials_harmonized.ex	exprsyru	Keep	NULL
clinical_trials_harmonized.ex	exprtmc	Keep	NULL
clinical_trials_harmonized.ex	exprtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	expstrg	Keep	NULL
clinical_trials_harmonized.ex	expstrgu	Keep	NULL
clinical_trials_harmonized.ex	exqcad	Keep	NULL
clinical_trials_harmonized.ex	exrcno	Keep	NULL
clinical_trials_harmonized.ex	exrdaer1	Keep	NULL
clinical_trials_harmonized.ex	exrdaer2	Keep	NULL
clinical_trials_harmonized.ex	exrdaer3	Keep	NULL
clinical_trials_harmonized.ex	exrdaer4	Keep	NULL
clinical_trials_harmonized.ex	exrdaer5	Keep	NULL
clinical_trials_harmonized.ex	exrdctcd	Keep	NULL
clinical_trials_harmonized.ex	exrdctsp	Keep	NULL
clinical_trials_harmonized.ex	exrdct	Keep	NULL
clinical_trials_harmonized.ex	exreas	Keep	NULL
clinical_trials_harmonized.ex	exrefid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ex	exregdl	Keep	NULL
clinical_trials_harmonized.ex	exregd	Keep	NULL
clinical_trials_harmonized.ex	exregn1	Keep	NULL
clinical_trials_harmonized.ex	exregn2	Keep	NULL
clinical_trials_harmonized.ex	exregn3	Keep	NULL
clinical_trials_harmonized.ex	exregn4	Keep	NULL
clinical_trials_harmonized.ex	exregncd	Keep	NULL
clinical_trials_harmonized.ex	exregne	Keep	NULL
clinical_trials_harmonized.ex	exregnl	Keep	NULL
clinical_trials_harmonized.ex	exregn	Keep	NULL
clinical_trials_harmonized.ex	exreg	Keep	NULL
clinical_trials_harmonized.ex	exreg_u	Keep	NULL
clinical_trials_harmonized.ex	exrepasp	Keep	NULL
clinical_trials_harmonized.ex	exrepa	Keep	NULL
clinical_trials_harmonized.ex	exret1	Keep	NULL
clinical_trials_harmonized.ex	exret2	Keep	NULL
clinical_trials_harmonized.ex	exret3	Keep	NULL
clinical_trials_harmonized.ex	exret4	Keep	NULL
clinical_trials_harmonized.ex	exret	Keep	NULL
clinical_trials_harmonized.ex	exrgncd2	Keep	NULL
clinical_trials_harmonized.ex	exrhmtx	Keep	NULL
clinical_trials_harmonized.ex	exriae	Keep	NULL
clinical_trials_harmonized.ex	exricvin	Keep	NULL
clinical_trials_harmonized.ex	exricvlr	Keep	NULL
clinical_trials_harmonized.ex	exrilssc	Keep	NULL
clinical_trials_harmonized.ex	exrils	Keep	NULL
clinical_trials_harmonized.ex	exrintsp	Keep	NULL
clinical_trials_harmonized.ex	exrioc	Keep	NULL
clinical_trials_harmonized.ex	exrmodat	Keep	NULL
clinical_trials_harmonized.ex	exrmodrd	Keep	NULL
clinical_trials_harmonized.ex	exrmodsd	Keep	NULL
clinical_trials_harmonized.ex	exrmodsp	Keep	NULL
clinical_trials_harmonized.ex	exrmod	Keep	NULL
clinical_trials_harmonized.ex	exroud	Keep	NULL
clinical_trials_harmonized.ex	exroutcd	Keep	NULL
clinical_trials_harmonized.ex	exroute2	Keep	NULL
clinical_trials_harmonized.ex	exroute_	Keep	NULL
clinical_trials_harmonized.ex	exroute	Keep	NULL
clinical_trials_harmonized.ex	exroutn	Keep	NULL
clinical_trials_harmonized.ex	exroutsp	Keep	NULL
clinical_trials_harmonized.ex	exrout	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exrrdae	Keep	NULL
clinical_trials_harmonized.ex	exrrdlss	Keep	NULL
clinical_trials_harmonized.ex	exrrdoc	Keep	NULL
clinical_trials_harmonized.ex	exrrlssc	Keep	NULL
clinical_trials_harmonized.ex	exscat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exsdmp	Keep	NULL
clinical_trials_harmonized.ex	exsdtce	Keep	NULL
clinical_trials_harmonized.ex	exsdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exsdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exsdtp	Keep	NULL
clinical_trials_harmonized.ex	exsecd	Keep	NULL
clinical_trials_harmonized.ex	exsecdx	Keep	NULL
clinical_trials_harmonized.ex	exseq	Keep	NULL
clinical_trials_harmonized.ex	exsnum	Keep	NULL
clinical_trials_harmonized.ex	exspid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ex	exstat	Keep	NULL
clinical_trials_harmonized.ex	exstco	Keep	NULL
clinical_trials_harmonized.ex	exstdt_c	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exstdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exstdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exstdte	Keep	NULL
clinical_trials_harmonized.ex	exstdtmp	Keep	NULL
clinical_trials_harmonized.ex	exstdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exstdtp	Keep	NULL
clinical_trials_harmonized.ex	exstdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exsted	Keep	NULL
clinical_trials_harmonized.ex	exstedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exstmp	Keep	NULL
clinical_trials_harmonized.ex	exstpd	Keep	NULL
clinical_trials_harmonized.ex	exstpdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	exstpdyx	Keep	NULL
clinical_trials_harmonized.ex	exstrat	Keep	NULL
clinical_trials_harmonized.ex	exstr	Keep	NULL
clinical_trials_harmonized.ex	exsttmc	Keep	NULL
clinical_trials_harmonized.ex	exsttme	Keep	NULL
clinical_trials_harmonized.ex	exsttmp	Keep	NULL
clinical_trials_harmonized.ex	exsttms	Keep	NULL
clinical_trials_harmonized.ex	exsttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	exsvol	Keep	NULL
clinical_trials_harmonized.ex	extaken1	Keep	NULL
clinical_trials_harmonized.ex	extaken2	Keep	NULL
clinical_trials_harmonized.ex	extaken3	Keep	NULL
clinical_trials_harmonized.ex	extaken4	Keep	NULL
clinical_trials_harmonized.ex	extaken	Keep	NULL
clinical_trials_harmonized.ex	extakn1	Keep	NULL
clinical_trials_harmonized.ex	extauc	Keep	NULL
clinical_trials_harmonized.ex	extaucu	Keep	NULL
clinical_trials_harmonized.ex	extftme	Keep	NULL
clinical_trials_harmonized.ex	extftm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	extitrs1	Keep	NULL
clinical_trials_harmonized.ex	extitrs2	Keep	NULL
clinical_trials_harmonized.ex	extitrs	Keep	NULL
clinical_trials_harmonized.ex	extitr	Keep	NULL
clinical_trials_harmonized.ex	extkn	Keep	NULL
clinical_trials_harmonized.ex	extotal	Keep	NULL
clinical_trials_harmonized.ex	extotdos	Keep	NULL
clinical_trials_harmonized.ex	extpt1	Keep	NULL
clinical_trials_harmonized.ex	extpt2	Keep	NULL
clinical_trials_harmonized.ex	extptn	Keep	NULL
clinical_trials_harmonized.ex	extptnum	Keep	NULL
clinical_trials_harmonized.ex	extptref	Keep	NULL
clinical_trials_harmonized.ex	extpt	Keep	NULL
clinical_trials_harmonized.ex	extrt1	Keep	NULL
clinical_trials_harmonized.ex	extrt2	Keep	NULL
clinical_trials_harmonized.ex	extrt3	Keep	NULL
clinical_trials_harmonized.ex	extrt4	Keep	NULL
clinical_trials_harmonized.ex	extrtan_	Keep	NULL
clinical_trials_harmonized.ex	extrtan	Keep	NULL
clinical_trials_harmonized.ex	extrta	Keep	NULL
clinical_trials_harmonized.ex	extrtcd1	Keep	NULL
clinical_trials_harmonized.ex	extrtcd2	Keep	NULL
clinical_trials_harmonized.ex	extrtcd	Keep	NULL
clinical_trials_harmonized.ex	extrtd1	Keep	NULL
clinical_trials_harmonized.ex	extrtd2	Keep	NULL
clinical_trials_harmonized.ex	extrtday	Keep	NULL
clinical_trials_harmonized.ex	extrtdl	Keep	NULL
clinical_trials_harmonized.ex	extrtd	Keep	NULL
clinical_trials_harmonized.ex	extrtint	Keep	NULL
clinical_trials_harmonized.ex	extrtl	Keep	NULL
clinical_trials_harmonized.ex	extrtr1	Keep	NULL
clinical_trials_harmonized.ex	extrtr2	Keep	NULL
clinical_trials_harmonized.ex	extrtr	Keep	NULL
clinical_trials_harmonized.ex	extrtsp	Keep	NULL
clinical_trials_harmonized.ex	extrt_	Keep	NULL
clinical_trials_harmonized.ex	extrt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	extrt_x	Keep	NULL
clinical_trials_harmonized.ex	extrtx	Keep	NULL
clinical_trials_harmonized.ex	exttsp1	Keep	NULL
clinical_trials_harmonized.ex	exttsp2	Keep	NULL
clinical_trials_harmonized.ex	extudi	Keep	NULL
clinical_trials_harmonized.ex	extvol	Keep	NULL
clinical_trials_harmonized.ex	extvolu	Keep	NULL
clinical_trials_harmonized.ex	exudos1	Keep	NULL
clinical_trials_harmonized.ex	exudos2	Keep	NULL
clinical_trials_harmonized.ex	exvisit	Keep	NULL
clinical_trials_harmonized.ex	exvol1	Keep	NULL
clinical_trials_harmonized.ex	exvol2	Keep	NULL
clinical_trials_harmonized.ex	exvolact	Keep	NULL
clinical_trials_harmonized.ex	exvol	Keep	NULL
clinical_trials_harmonized.ex	exvolpbo	Keep	NULL
clinical_trials_harmonized.ex	exvolu1	Keep	NULL
clinical_trials_harmonized.ex	exvolu2	Keep	NULL
clinical_trials_harmonized.ex	exvolume	Keep	NULL
clinical_trials_harmonized.ex	exvolu	Keep	NULL
clinical_trials_harmonized.ex	exvoni	Keep	NULL
clinical_trials_harmonized.ex	exvoniu	Keep	NULL
clinical_trials_harmonized.ex	exwatc	Keep	NULL
clinical_trials_harmonized.ex	exwatcu	Keep	NULL
clinical_trials_harmonized.ex	exwdose	Keep	NULL
clinical_trials_harmonized.ex	exwdosu	Keep	NULL
clinical_trials_harmonized.ex	exweek	Keep	NULL
clinical_trials_harmonized.ex	idvar	Keep	NULL
clinical_trials_harmonized.ex	idvarval	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ex	invid	Redact	Detected Entity with tag PII "clinical_invid"
clinical_trials_harmonized.ex	invsite	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.ex	lockflag	Keep	NULL
clinical_trials_harmonized.ex	logints	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	lstchgts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.ex	pt	Keep	NULL
clinical_trials_harmonized.ex	qeval	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	qlabel	Keep	NULL
clinical_trials_harmonized.ex	qnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.ex	qorig	Keep	NULL
clinical_trials_harmonized.ex	qualifyv	Keep	NULL
clinical_trials_harmonized.ex	qval	Keep	NULL
clinical_trials_harmonized.ex	rdomain	Keep	NULL
clinical_trials_harmonized.ex	repeatsn	Keep	NULL
clinical_trials_harmonized.ex	rowid	Keep	NULL
clinical_trials_harmonized.ex	studyid	Keep	Detected Entity "clinical_studyid"
clinical_trials_harmonized.ex	subjid	FPENumeric	Detected Entity with tag PII "clinical_subjid"
clinical_trials_harmonized.ex	subsetsn	Keep	NULL
clinical_trials_harmonized.ex	usubjid	FPEAlphaNumeric	Detected Entity with tag PII "clinical_usubjid"
clinical_trials_harmonized.ex	visitnum	Keep	NULL
clinical_trials_harmonized.ex	visit	Keep	NULL
clinical_trials_harmonized.ex	source_dataset	Keep	NULL
clinical_trials_harmonized.lb	accessts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	actevent	Keep	NULL
clinical_trials_harmonized.lb	aerefid1	Keep	NULL
clinical_trials_harmonized.lb	aerefid2	Keep	NULL
clinical_trials_harmonized.lb	aerefid3	Keep	NULL
clinical_trials_harmonized.lb	aerefid4	Keep	NULL
clinical_trials_harmonized.lb	aerefid5	Keep	NULL
clinical_trials_harmonized.lb	bsage	Age	Use Age for age column
clinical_trials_harmonized.lb	country	Keep	NULL
clinical_trials_harmonized.lb	cpevent	Keep	NULL
clinical_trials_harmonized.lb	dcmdate	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	dcmname	Keep	NULL
clinical_trials_harmonized.lb	dcmqgnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	dcmsubnm	Keep	NULL
clinical_trials_harmonized.lb	dcmtime	Keep	NULL
clinical_trials_harmonized.lb	docnum	Keep	NULL
clinical_trials_harmonized.lb	domain	Keep	NULL
clinical_trials_harmonized.lb	edcix	Keep	NULL
clinical_trials_harmonized.lb	edcix_x	Keep	NULL
clinical_trials_harmonized.lb	edcslf	Keep	NULL
clinical_trials_harmonized.lb	epoch	Keep	NULL
clinical_trials_harmonized.lb	evaltype	Keep	NULL
clinical_trials_harmonized.lb	gname1	Keep	NULL
clinical_trials_harmonized.lb	gname2	Keep	NULL
clinical_trials_harmonized.lb	gname	Keep	NULL
clinical_trials_harmonized.lb	hirang	Keep	NULL
clinical_trials_harmonized.lb	idvar	Keep	NULL
clinical_trials_harmonized.lb	idvarval	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.lb	invid	Redact	Detected Entity with tag PII "clinical_invid"
clinical_trials_harmonized.lb	invsite	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.lb	inv	Keep	NULL
clinical_trials_harmonized.lb	labid	Keep	NULL
clinical_trials_harmonized.lb	labsub	Keep	NULL
clinical_trials_harmonized.lb	labunit	Keep	NULL
clinical_trials_harmonized.lb	labu	Keep	NULL
clinical_trials_harmonized.lb	lbabcesp	Keep	NULL
clinical_trials_harmonized.lb	lbabce	Keep	NULL
clinical_trials_harmonized.lb	lbadtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbage	Age	Use Age for age column
clinical_trials_harmonized.lb	lbageu	Keep	NULL
clinical_trials_harmonized.lb	lbalfl	Keep	NULL
clinical_trials_harmonized.lb	lbanmeth	Keep	NULL
clinical_trials_harmonized.lb	lbblfl	Keep	NULL
clinical_trials_harmonized.lb	lbcatcd	Keep	NULL
clinical_trials_harmonized.lb	lbcat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbcspec	Keep	NULL
clinical_trials_harmonized.lb	lbday	Keep	NULL
clinical_trials_harmonized.lb	lbdesc	Keep	NULL
clinical_trials_harmonized.lb	lbdirfl	Keep	NULL
clinical_trials_harmonized.lb	lbdirf	Keep	NULL
clinical_trials_harmonized.lb	lbdirhi	Keep	NULL
clinical_trials_harmonized.lb	lbdirlo	Keep	NULL
clinical_trials_harmonized.lb	lbdrng	Keep	NULL
clinical_trials_harmonized.lb	lbdrvfl	Keep	NULL
clinical_trials_harmonized.lb	lbdstdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbdstdt	Keep	NULL
clinical_trials_harmonized.lb	lbdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbdte	Keep	NULL
clinical_trials_harmonized.lb	lbdtmp	Keep	NULL
clinical_trials_harmonized.lb	lbdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbdtmx	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbdtp	Keep	NULL
clinical_trials_harmonized.lb	lbdy2	Keep	NULL
clinical_trials_harmonized.lb	lbdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbedy2	Keep	NULL
clinical_trials_harmonized.lb	lbedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbeltm	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbendtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbendt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbendtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbendtp	Keep	NULL
clinical_trials_harmonized.lb	lbendy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbenedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbentmc	Keep	NULL
clinical_trials_harmonized.lb	lbentm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbfast2	Keep	NULL
clinical_trials_harmonized.lb	lbfastl	Keep	NULL
clinical_trials_harmonized.lb	lbfastn	Keep	NULL
clinical_trials_harmonized.lb	lbfast	Keep	NULL
clinical_trials_harmonized.lb	lbgrpid	Keep	NULL
clinical_trials_harmonized.lb	lbhfastc	Keep	NULL
clinical_trials_harmonized.lb	lbhfast	Keep	NULL
clinical_trials_harmonized.lb	lbhfdf	Keep	NULL
clinical_trials_harmonized.lb	lbhfstdf	Keep	NULL
clinical_trials_harmonized.lb	lbhfst	Keep	NULL
clinical_trials_harmonized.lb	lbhftc	Keep	NULL
clinical_trials_harmonized.lb	lbhftn	Keep	NULL
clinical_trials_harmonized.lb	lbhgbfl	Keep	NULL
clinical_trials_harmonized.lb	lbhrast	Keep	NULL
clinical_trials_harmonized.lb	lblage	Age	Use Age for age column
clinical_trials_harmonized.lb	lblagu	Keep	NULL
clinical_trials_harmonized.lb	lblloq	Keep	NULL
clinical_trials_harmonized.lb	lblnkid	Keep	NULL
clinical_trials_harmonized.lb	lbloc	Keep	NULL
clinical_trials_harmonized.lb	lbloinc	Keep	NULL
clinical_trials_harmonized.lb	lbmethcd	Keep	NULL
clinical_trials_harmonized.lb	lbmethod	Keep	NULL
clinical_trials_harmonized.lb	lbmethsp	Keep	NULL
clinical_trials_harmonized.lb	lbnacd	Keep	NULL
clinical_trials_harmonized.lb	lbnamcd1	Keep	NULL
clinical_trials_harmonized.lb	lbnamcd	Keep	NULL
clinical_trials_harmonized.lb	lbnamcdx	Keep	NULL
clinical_trials_harmonized.lb	lbnam	Redact	Detected Facet with tag PII "clinical_lbnam"
clinical_trials_harmonized.lb	lbnam_x	Keep	NULL
clinical_trials_harmonized.lb	lbnrind	Keep	NULL
clinical_trials_harmonized.lb	lbornrhc	Keep	NULL
clinical_trials_harmonized.lb	lbornrhi	Keep	NULL
clinical_trials_harmonized.lb	lbornrlc	Keep	NULL
clinical_trials_harmonized.lb	lbornrlo	Keep	NULL
clinical_trials_harmonized.lb	lbornr	Keep	NULL
clinical_trials_harmonized.lb	lborresn	Keep	NULL
clinical_trials_harmonized.lb	lborres	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lborresu	Keep	NULL
clinical_trials_harmonized.lb	lborsusp	Keep	NULL
clinical_trials_harmonized.lb	lbpcon	Keep	NULL
clinical_trials_harmonized.lb	lbpdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbpoch	Keep	NULL
clinical_trials_harmonized.lb	lbptstcd	Keep	NULL
clinical_trials_harmonized.lb	lbqlp	Keep	NULL
clinical_trials_harmonized.lb	lbreas1	Keep	NULL
clinical_trials_harmonized.lb	lbreas2	Keep	NULL
clinical_trials_harmonized.lb	lbreas3	Keep	NULL
clinical_trials_harmonized.lb	lbreas4	Keep	NULL
clinical_trials_harmonized.lb	lbreas5	Keep	NULL
clinical_trials_harmonized.lb	lbreasnd	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbreas	Keep	NULL
clinical_trials_harmonized.lb	lbrefid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.lb	lbrescat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbrptfl	Keep	NULL
clinical_trials_harmonized.lb	lbrtsn	Keep	NULL
clinical_trials_harmonized.lb	lbsae	Keep	NULL
clinical_trials_harmonized.lb	lbsaide	Keep	NULL
clinical_trials_harmonized.lb	lbsaid	Keep	NULL
clinical_trials_harmonized.lb	lbsaid_x	Keep	NULL
clinical_trials_harmonized.lb	lbscatcd	Keep	NULL
clinical_trials_harmonized.lb	lbscat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbsecd	Keep	NULL
clinical_trials_harmonized.lb	lbseq	Keep	NULL
clinical_trials_harmonized.lb	lbsex	Keep	NULL
clinical_trials_harmonized.lb	lbspccnd	Keep	NULL
clinical_trials_harmonized.lb	lbspcufl	Keep	NULL
clinical_trials_harmonized.lb	lbspec_a	Keep	NULL
clinical_trials_harmonized.lb	lbspecc	Keep	NULL
clinical_trials_harmonized.lb	lbspec	Keep	NULL
clinical_trials_harmonized.lb	lbspec_x	Keep	NULL
clinical_trials_harmonized.lb	lbspec_y	Keep	NULL
clinical_trials_harmonized.lb	lbspec_z	Keep	NULL
clinical_trials_harmonized.lb	lbspes	Keep	NULL
clinical_trials_harmonized.lb	lbspid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.lb	lbspstc	Keep	NULL
clinical_trials_harmonized.lb	lbspst	Keep	NULL
clinical_trials_harmonized.lb	lbstat	Keep	NULL
clinical_trials_harmonized.lb	lbstdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.lb	lbstdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbstdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbstdtp	Keep	NULL
clinical_trials_harmonized.lb	lbstdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbstedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbstnrc	Keep	NULL
clinical_trials_harmonized.lb	lbstnrhi	Keep	NULL
clinical_trials_harmonized.lb	lbstnrlo	Keep	NULL
clinical_trials_harmonized.lb	lbstresc	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbstresn	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	lbstresu	Keep	NULL
clinical_trials_harmonized.lb	lbsttmc	Keep	NULL
clinical_trials_harmonized.lb	lbsttme	Keep	NULL
clinical_trials_harmonized.lb	lbsttm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbsubset	Keep	NULL
clinical_trials_harmonized.lb	lbtest2	Keep	NULL
clinical_trials_harmonized.lb	lbtestcd	Keep	Detected Entity "clinical_lbtestcd"
clinical_trials_harmonized.lb	lbtest	Keep	Detected Entity "clinical_lbtest"
clinical_trials_harmonized.lb	lbtmc	Keep	NULL
clinical_trials_harmonized.lb	lbtmc_x	Keep	NULL
clinical_trials_harmonized.lb	lbtme	Keep	NULL
clinical_trials_harmonized.lb	lbtmp	Keep	NULL
clinical_trials_harmonized.lb	lbtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbtm_x	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbtmx	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lbtob	Keep	NULL
clinical_trials_harmonized.lb	lbtpcd	Keep	NULL
clinical_trials_harmonized.lb	lbtptcd	Keep	NULL
clinical_trials_harmonized.lb	lbtpte	Keep	NULL
clinical_trials_harmonized.lb	lbtptnum	Keep	NULL
clinical_trials_harmonized.lb	lbtptref	Keep	NULL
clinical_trials_harmonized.lb	lbtpt	Keep	NULL
clinical_trials_harmonized.lb	lbtstdtl	Keep	NULL
clinical_trials_harmonized.lb	lbtube	Keep	NULL
clinical_trials_harmonized.lb	lbtubno	Keep	NULL
clinical_trials_harmonized.lb	lbusid	Keep	NULL
clinical_trials_harmonized.lb	lbusnrhi	Keep	NULL
clinical_trials_harmonized.lb	lbusnrlo	Keep	NULL
clinical_trials_harmonized.lb	lbusresn	Keep	NULL
clinical_trials_harmonized.lb	lbusresu	Keep	NULL
clinical_trials_harmonized.lb	lbvol	Keep	NULL
clinical_trials_harmonized.lb	lbvolu	Keep	NULL
clinical_trials_harmonized.lb	lbvs	Keep	NULL
clinical_trials_harmonized.lb	lbvsflg	Keep	NULL
clinical_trials_harmonized.lb	lbvstp	Keep	NULL
clinical_trials_harmonized.lb	lbvstxt	Keep	NULL
clinical_trials_harmonized.lb	lockflag	Keep	NULL
clinical_trials_harmonized.lb	logints	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lowrang	Keep	NULL
clinical_trials_harmonized.lb	lparm	Keep	NULL
clinical_trials_harmonized.lb	lstchgts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.lb	lvalstd	Keep	NULL
clinical_trials_harmonized.lb	lvaluen	Keep	NULL
clinical_trials_harmonized.lb	lvalue	Keep	NULL
clinical_trials_harmonized.lb	nlbreas1	Keep	NULL
clinical_trials_harmonized.lb	nlbreas2	Keep	NULL
clinical_trials_harmonized.lb	nlbreas3	Keep	NULL
clinical_trials_harmonized.lb	nlbreas4	Keep	NULL
clinical_trials_harmonized.lb	nlbreas5	Keep	NULL
clinical_trials_harmonized.lb	nlbreas6	Keep	NULL
clinical_trials_harmonized.lb	nlbreas7	Keep	NULL
clinical_trials_harmonized.lb	nlbreas8	Keep	NULL
clinical_trials_harmonized.lb	nlbreas9	Keep	NULL
clinical_trials_harmonized.lb	nlbreas	Keep	NULL
clinical_trials_harmonized.lb	nlbreasx	Keep	NULL
clinical_trials_harmonized.lb	nlbrea_x	Keep	NULL
clinical_trials_harmonized.lb	nlbrea_y	Keep	NULL
clinical_trials_harmonized.lb	nlbres1	Keep	NULL
clinical_trials_harmonized.lb	nlbres2	Keep	NULL
clinical_trials_harmonized.lb	obssd	Keep	NULL
clinical_trials_harmonized.lb	panicflg	Keep	NULL
clinical_trials_harmonized.lb	panichi	Keep	NULL
clinical_trials_harmonized.lb	paniclo	Keep	NULL
clinical_trials_harmonized.lb	panicun	Keep	NULL
clinical_trials_harmonized.lb	pt	Keep	NULL
clinical_trials_harmonized.lb	qeval	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	qlabel	Keep	NULL
clinical_trials_harmonized.lb	qnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	qorig	Keep	NULL
clinical_trials_harmonized.lb	qualifyv	Keep	NULL
clinical_trials_harmonized.lb	qualval	Keep	NULL
clinical_trials_harmonized.lb	qval	Keep	NULL
clinical_trials_harmonized.lb	rdomain	Keep	NULL
clinical_trials_harmonized.lb	reflexyn	Keep	NULL
clinical_trials_harmonized.lb	repeatsn	Keep	NULL
clinical_trials_harmonized.lb	rngflag	Keep	NULL
clinical_trials_harmonized.lb	rowid	Keep	NULL
clinical_trials_harmonized.lb	saslabel	Keep	NULL
clinical_trials_harmonized.lb	sasname	Keep	NULL
clinical_trials_harmonized.lb	sex	Keep	NULL
clinical_trials_harmonized.lb	slsrn	Keep	NULL
clinical_trials_harmonized.lb	stdhirng	Keep	NULL
clinical_trials_harmonized.lb	stdlorng	Keep	NULL
clinical_trials_harmonized.lb	stdtype	Keep	NULL
clinical_trials_harmonized.lb	stdunit	Keep	NULL
clinical_trials_harmonized.lb	studyid	Keep	Detected Entity "clinical_studyid"
clinical_trials_harmonized.lb	study	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	subjid	FPENumeric	Detected Entity with tag PII "clinical_subjid"
clinical_trials_harmonized.lb	subsetsn	Keep	NULL
clinical_trials_harmonized.lb	usubjid	FPEAlphaNumeric	Detected Entity with tag PII "clinical_usubjid"
clinical_trials_harmonized.lb	visitdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.lb	visitnum	Keep	NULL
clinical_trials_harmonized.lb	visit	Keep	NULL
clinical_trials_harmonized.lb	source_dataset	Keep	NULL
clinical_trials_harmonized.mh	accessts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	actevent	Keep	NULL
clinical_trials_harmonized.mh	country	Keep	NULL
clinical_trials_harmonized.mh	cpevent	Keep	NULL
clinical_trials_harmonized.mh	dcmdate	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	dcmname	Keep	NULL
clinical_trials_harmonized.mh	dcmsubnm	Keep	NULL
clinical_trials_harmonized.mh	dcmtime	Keep	NULL
clinical_trials_harmonized.mh	docnum	Keep	NULL
clinical_trials_harmonized.mh	domain	Keep	NULL
clinical_trials_harmonized.mh	dtmh	Keep	NULL
clinical_trials_harmonized.mh	dtstmh1	Keep	NULL
clinical_trials_harmonized.mh	dtstmh2	Keep	NULL
clinical_trials_harmonized.mh	dtstmh3	Keep	NULL
clinical_trials_harmonized.mh	dtstmh4	Keep	NULL
clinical_trials_harmonized.mh	dtstmh5	Keep	NULL
clinical_trials_harmonized.mh	dtstmh6	Keep	NULL
clinical_trials_harmonized.mh	dtstmh7	Keep	NULL
clinical_trials_harmonized.mh	dtstmh8	Keep	NULL
clinical_trials_harmonized.mh	edcix	Keep	NULL
clinical_trials_harmonized.mh	edcix_x	Keep	NULL
clinical_trials_harmonized.mh	epoch	Keep	NULL
clinical_trials_harmonized.mh	hei	Keep	NULL
clinical_trials_harmonized.mh	idvar	Keep	NULL
clinical_trials_harmonized.mh	idvarval	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.mh	invid	Redact	Detected Entity with tag PII "clinical_invid"
clinical_trials_harmonized.mh	invsite	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.mh	lockflag	Keep	NULL
clinical_trials_harmonized.mh	logints	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	lstchgts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	mh1toxgr	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mh2toxgr	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mh3toxgr	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mh4toxgr	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mh5toxgr	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mh6toxgr	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mh7toxgr	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mh8toxgr	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhaddx	Keep	NULL
clinical_trials_harmonized.mh	mhbdsycd	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhbdsysc	Keep	NULL
clinical_trials_harmonized.mh	mhbodcc	Keep	NULL
clinical_trials_harmonized.mh	mhbodcl	Keep	NULL
clinical_trials_harmonized.mh	mhbodcn	Keep	NULL
clinical_trials_harmonized.mh	mhbodc	Keep	NULL
clinical_trials_harmonized.mh	mhbodscd	Keep	NULL
clinical_trials_harmonized.mh	mhbodsys	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhcatcd	Keep	NULL
clinical_trials_harmonized.mh	mhcat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhcomor	Keep	NULL
clinical_trials_harmonized.mh	mhcontrt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhctce	Keep	NULL
clinical_trials_harmonized.mh	mhctc	Keep	NULL
clinical_trials_harmonized.mh	mhdecod	Keep	NULL
clinical_trials_harmonized.mh	mhdesc1	Keep	NULL
clinical_trials_harmonized.mh	mhdesc2	Keep	NULL
clinical_trials_harmonized.mh	mhdesc	Keep	NULL
clinical_trials_harmonized.mh	mhdict	Keep	NULL
clinical_trials_harmonized.mh	mhdictv	Keep	NULL
clinical_trials_harmonized.mh	mhdtcc	Keep	NULL
clinical_trials_harmonized.mh	mhdtce	Keep	NULL
clinical_trials_harmonized.mh	mhdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.mh	mhdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	mhdte	Keep	NULL
clinical_trials_harmonized.mh	mhdtmp	Keep	NULL
clinical_trials_harmonized.mh	mhdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	mhdtp	Keep	NULL
clinical_trials_harmonized.mh	mhdur	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhduru	Keep	NULL
clinical_trials_harmonized.mh	mhdxdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.mh	mhdxdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	mhdxdtp	Keep	NULL
clinical_trials_harmonized.mh	mhdxdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhdxedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhendtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.mh	mhendy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhenrtpt	Keep	NULL
clinical_trials_harmonized.mh	mhentpt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	mhevintx	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhevtyp	Keep	NULL
clinical_trials_harmonized.mh	mhgrpid	Keep	NULL
clinical_trials_harmonized.mh	mhhenm	Keep	NULL
clinical_trials_harmonized.mh	mhhgtcd	Keep	NULL
clinical_trials_harmonized.mh	mhhgt	Keep	NULL
clinical_trials_harmonized.mh	mhhlgtcd	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhhlgt	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhhltcd	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhhlt	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhlat	Keep	NULL
clinical_trials_harmonized.mh	mhlltcd	Keep	NULL
clinical_trials_harmonized.mh	mhllt	Keep	NULL
clinical_trials_harmonized.mh	mhlnkid	Keep	NULL
clinical_trials_harmonized.mh	mhloc	Keep	NULL
clinical_trials_harmonized.mh	mhmodify	Keep	NULL
clinical_trials_harmonized.mh	mhmodinf	Keep	NULL
clinical_trials_harmonized.mh	mhoccur	Keep	NULL
clinical_trials_harmonized.mh	mhongo	Keep	NULL
clinical_trials_harmonized.mh	mhpdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhpoch	Keep	NULL
clinical_trials_harmonized.mh	mhpresp	Keep	NULL
clinical_trials_harmonized.mh	mhptcd	Keep	NULL
clinical_trials_harmonized.mh	mhpt	Keep	NULL
clinical_trials_harmonized.mh	mhrelpd	Keep	NULL
clinical_trials_harmonized.mh	mhscatcd	Keep	NULL
clinical_trials_harmonized.mh	mhscat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhsdmp	Keep	NULL
clinical_trials_harmonized.mh	mhsdm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	mhsdtce	Keep	NULL
clinical_trials_harmonized.mh	mhsdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.mh	mhsdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	mhsdtp	Keep	NULL
clinical_trials_harmonized.mh	mhsdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhsecd	Keep	NULL
clinical_trials_harmonized.mh	mhsedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhseq	Keep	NULL
clinical_trials_harmonized.mh	mhsevcd	Keep	NULL
clinical_trials_harmonized.mh	mhsev	Keep	NULL
clinical_trials_harmonized.mh	mhsoccd	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhsoc	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhspid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.mh	mhstdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.mh	mhstdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	mhstdte	Keep	NULL
clinical_trials_harmonized.mh	mhstdtmp	Keep	NULL
clinical_trials_harmonized.mh	mhstdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.mh	mhstdtp	Keep	NULL
clinical_trials_harmonized.mh	mhstdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhstedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhstrf	Keep	NULL
clinical_trials_harmonized.mh	mhstrtpt	Keep	NULL
clinical_trials_harmonized.mh	mhsttpt	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.mh	mhtecd	Keep	NULL
clinical_trials_harmonized.mh	mhtermcd	Keep	NULL
clinical_trials_harmonized.mh	mhtermsp	Keep	NULL
clinical_trials_harmonized.mh	mhterm	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhtmot	Keep	NULL
clinical_trials_harmonized.mh	mhtoxgr	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	mhtox	Keep	NULL
clinical_trials_harmonized.mh	nyaemh	Keep	NULL
clinical_trials_harmonized.mh	nymh1trt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	nymh2trt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	nymh3trt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	nymh4trt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	nymh5trt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	nymh6trt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	nymh7trt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	nymh8trt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	nymh	Keep	NULL
clinical_trials_harmonized.mh	nyongmh1	Keep	NULL
clinical_trials_harmonized.mh	nyongmh2	Keep	NULL
clinical_trials_harmonized.mh	nyongmh3	Keep	NULL
clinical_trials_harmonized.mh	nyongmh4	Keep	NULL
clinical_trials_harmonized.mh	nyongmh5	Keep	NULL
clinical_trials_harmonized.mh	nyongmh6	Keep	NULL
clinical_trials_harmonized.mh	nyongmh7	Keep	NULL
clinical_trials_harmonized.mh	nyongmh8	Keep	NULL
clinical_trials_harmonized.mh	nywhbl	Keep	NULL
clinical_trials_harmonized.mh	pt	Keep	NULL
clinical_trials_harmonized.mh	qeval	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	qlabel	Keep	NULL
clinical_trials_harmonized.mh	qnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.mh	qorig	Keep	NULL
clinical_trials_harmonized.mh	qualifyv	Keep	NULL
clinical_trials_harmonized.mh	qval	Keep	NULL
clinical_trials_harmonized.mh	rdomain	Keep	NULL
clinical_trials_harmonized.mh	repeatsn	Keep	NULL
clinical_trials_harmonized.mh	rowid	Keep	NULL
clinical_trials_harmonized.mh	studyid	Keep	Detected Entity "clinical_studyid"
clinical_trials_harmonized.mh	subjid	FPENumeric	Detected Entity with tag PII "clinical_subjid"
clinical_trials_harmonized.mh	subsetsn	Keep	NULL
clinical_trials_harmonized.mh	txcom1mh	Keep	NULL
clinical_trials_harmonized.mh	txcom2mh	Keep	NULL
clinical_trials_harmonized.mh	txcom3mh	Keep	NULL
clinical_trials_harmonized.mh	txmh1	Keep	NULL
clinical_trials_harmonized.mh	txmh2	Keep	NULL
clinical_trials_harmonized.mh	txmh3	Keep	NULL
clinical_trials_harmonized.mh	txmh4	Keep	NULL
clinical_trials_harmonized.mh	txmh5	Keep	NULL
clinical_trials_harmonized.mh	txmh6	Keep	NULL
clinical_trials_harmonized.mh	txmh7	Keep	NULL
clinical_trials_harmonized.mh	txmh8	Keep	NULL
clinical_trials_harmonized.mh	urecid	Keep	NULL
clinical_trials_harmonized.mh	usubjid	FPEAlphaNumeric	Detected Entity with tag PII "clinical_usubjid"
clinical_trials_harmonized.mh	visitnum	Keep	NULL
clinical_trials_harmonized.mh	visit	Keep	NULL
clinical_trials_harmonized.mh	source_dataset	Keep	NULL
clinical_trials_harmonized.rn	accessts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	actevent	Keep	NULL
clinical_trials_harmonized.rn	armord	Keep	NULL
clinical_trials_harmonized.rn	bcrfail	Keep	NULL
clinical_trials_harmonized.rn	blockid	Keep	NULL
clinical_trials_harmonized.rn	cname	Keep	NULL
clinical_trials_harmonized.rn	com	Keep	NULL
clinical_trials_harmonized.rn	country	Keep	NULL
clinical_trials_harmonized.rn	cpevent	Keep	NULL
clinical_trials_harmonized.rn	dcmdate	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	dcmname	Keep	NULL
clinical_trials_harmonized.rn	dcmsubnm	Keep	NULL
clinical_trials_harmonized.rn	dcmtime	Keep	NULL
clinical_trials_harmonized.rn	docnum	Keep	NULL
clinical_trials_harmonized.rn	domain	Keep	NULL
clinical_trials_harmonized.rn	ecog	Keep	NULL
clinical_trials_harmonized.rn	edcix	Keep	NULL
clinical_trials_harmonized.rn	epoch	Keep	NULL
clinical_trials_harmonized.rn	expsaf1	Keep	NULL
clinical_trials_harmonized.rn	expsaf2	Keep	NULL
clinical_trials_harmonized.rn	expsaf3	Keep	NULL
clinical_trials_harmonized.rn	expsaf4	Keep	NULL
clinical_trials_harmonized.rn	extrt	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.rn	gnqq	Keep	NULL
clinical_trials_harmonized.rn	invid	Redact	Detected Entity with tag PII "clinical_invid"
clinical_trials_harmonized.rn	invsite	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.rn	inv	Keep	NULL
clinical_trials_harmonized.rn	lockflag	Keep	NULL
clinical_trials_harmonized.rn	logints	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	lstchgts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	perfdt1	Keep	NULL
clinical_trials_harmonized.rn	perfdt2	Keep	NULL
clinical_trials_harmonized.rn	perfdt3	Keep	NULL
clinical_trials_harmonized.rn	perfdt4	Keep	NULL
clinical_trials_harmonized.rn	perftm1	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	perftm2	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	perftm3	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	perftm4	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	phase	Keep	NULL
clinical_trials_harmonized.rn	pt	Keep	NULL
clinical_trials_harmonized.rn	qres1	Keep	NULL
clinical_trials_harmonized.rn	qres2	Keep	NULL
clinical_trials_harmonized.rn	qualifyv	Keep	NULL
clinical_trials_harmonized.rn	qval1	Keep	NULL
clinical_trials_harmonized.rn	qval2	Keep	NULL
clinical_trials_harmonized.rn	qval3	Keep	NULL
clinical_trials_harmonized.rn	qval4	Keep	NULL
clinical_trials_harmonized.rn	qval5	Keep	NULL
clinical_trials_harmonized.rn	randcd	Keep	NULL
clinical_trials_harmonized.rn	randco	Keep	NULL
clinical_trials_harmonized.rn	randgp	Keep	NULL
clinical_trials_harmonized.rn	randgrp	Redact	PossibleFreeText
clinical_trials_harmonized.rn	randl	Keep	NULL
clinical_trials_harmonized.rn	randno	Keep	NULL
clinical_trials_harmonized.rn	random	Keep	NULL
clinical_trials_harmonized.rn	randseq	Keep	NULL
clinical_trials_harmonized.rn	randsq	Keep	NULL
clinical_trials_harmonized.rn	randx	Keep	NULL
clinical_trials_harmonized.rn	rannr	Keep	NULL
clinical_trials_harmonized.rn	rantype	Keep	NULL
clinical_trials_harmonized.rn	repeatsn	Keep	NULL
clinical_trials_harmonized.rn	rnarmcd	Keep	NULL
clinical_trials_harmonized.rn	rnarm	Keep	NULL
clinical_trials_harmonized.rn	rncacd	Keep	NULL
clinical_trials_harmonized.rn	rncatcd	Keep	NULL
clinical_trials_harmonized.rn	rncat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.rn	rncohocd	Keep	NULL
clinical_trials_harmonized.rn	rncohort	Keep	NULL
clinical_trials_harmonized.rn	rncrimc	Keep	NULL
clinical_trials_harmonized.rn	rncrim	Keep	NULL
clinical_trials_harmonized.rn	rndosgrp	Keep	NULL
clinical_trials_harmonized.rn	rndrseq	Keep	NULL
clinical_trials_harmonized.rn	rndtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	rndt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	rndte	Keep	NULL
clinical_trials_harmonized.rn	rndtmp	Keep	NULL
clinical_trials_harmonized.rn	rndtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	rndtp	Keep	NULL
clinical_trials_harmonized.rn	rndtseq	Keep	NULL
clinical_trials_harmonized.rn	rndy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.rn	rnedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.rn	rngrpccd	Keep	NULL
clinical_trials_harmonized.rn	rngrpc	Keep	NULL
clinical_trials_harmonized.rn	rngrpid	Keep	NULL
clinical_trials_harmonized.rn	rnnrseq	Keep	NULL
clinical_trials_harmonized.rn	rnntseq	Keep	NULL
clinical_trials_harmonized.rn	rnpdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.rn	rnphase	Keep	NULL
clinical_trials_harmonized.rn	rnresrn	Keep	NULL
clinical_trials_harmonized.rn	rnresr	Keep	NULL
clinical_trials_harmonized.rn	rnrnm	Keep	NULL
clinical_trials_harmonized.rn	rnsecd	Keep	NULL
clinical_trials_harmonized.rn	rnspid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.rn	rnstgr	Keep	NULL
clinical_trials_harmonized.rn	rnstgrx	Keep	NULL
clinical_trials_harmonized.rn	rnsubstd	Keep	NULL
clinical_trials_harmonized.rn	rnsub	Keep	NULL
clinical_trials_harmonized.rn	rntgrp2	Keep	NULL
clinical_trials_harmonized.rn	rntgrp3	Keep	NULL
clinical_trials_harmonized.rn	rntmp	Keep	NULL
clinical_trials_harmonized.rn	rntm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.rn	rntrtcd	Keep	NULL
clinical_trials_harmonized.rn	rntrtgrp	Keep	NULL
clinical_trials_harmonized.rn	rntrtseq	Keep	NULL
clinical_trials_harmonized.rn	rnvisit	Keep	NULL
clinical_trials_harmonized.rn	rowid	Keep	NULL
clinical_trials_harmonized.rn	stdyprt	Keep	NULL
clinical_trials_harmonized.rn	stracdx1	Keep	NULL
clinical_trials_harmonized.rn	stracdx2	Keep	NULL
clinical_trials_harmonized.rn	stracdx3	Keep	NULL
clinical_trials_harmonized.rn	stracdx4	Keep	NULL
clinical_trials_harmonized.rn	strat1	Keep	NULL
clinical_trials_harmonized.rn	strat2	Keep	NULL
clinical_trials_harmonized.rn	strat3	Keep	NULL
clinical_trials_harmonized.rn	strat4	Keep	NULL
clinical_trials_harmonized.rn	stratccd	Keep	NULL
clinical_trials_harmonized.rn	stratcd1	Keep	NULL
clinical_trials_harmonized.rn	stratcd2	Keep	NULL
clinical_trials_harmonized.rn	stratcd3	Keep	NULL
clinical_trials_harmonized.rn	stratcd4	Keep	NULL
clinical_trials_harmonized.rn	stratcd	Keep	NULL
clinical_trials_harmonized.rn	strat	Keep	NULL
clinical_trials_harmonized.rn	stratx1	Keep	NULL
clinical_trials_harmonized.rn	stratx2	Keep	NULL
clinical_trials_harmonized.rn	stratx3	Keep	NULL
clinical_trials_harmonized.rn	stratx4	Keep	NULL
clinical_trials_harmonized.rn	studyid	Keep	Detected Entity "clinical_studyid"
clinical_trials_harmonized.rn	study	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.rn	subjid	FPENumeric	Detected Entity with tag PII "clinical_subjid"
clinical_trials_harmonized.rn	subsetsn	Keep	NULL
clinical_trials_harmonized.rn	trt433	Keep	NULL
clinical_trials_harmonized.rn	trtcd	Keep	NULL
clinical_trials_harmonized.rn	trtgrp	Redact	PossibleFreeText
clinical_trials_harmonized.rn	trtseq	Keep	NULL
clinical_trials_harmonized.rn	trtyp	Keep	NULL
clinical_trials_harmonized.rn	usubjid	FPEAlphaNumeric	Detected Entity with tag PII "clinical_usubjid"
clinical_trials_harmonized.rn	visitnum	Keep	NULL
clinical_trials_harmonized.rn	visit	Keep	NULL
clinical_trials_harmonized.rn	source_dataset	Keep	NULL
clinical_trials_harmonized.vs	accessts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.vs	actevent	Keep	NULL
clinical_trials_harmonized.vs	bmid	Keep	NULL
clinical_trials_harmonized.vs	bpdia	Keep	NULL
clinical_trials_harmonized.vs	bpsys	Keep	NULL
clinical_trials_harmonized.vs	country	Keep	NULL
clinical_trials_harmonized.vs	cpevent	Keep	NULL
clinical_trials_harmonized.vs	cyclevs	Keep	NULL
clinical_trials_harmonized.vs	dcmdate	SkewDate	DateAndTimestamp
clinical_trials_harmonized.vs	dcmdd	SkewDate	DateAndTimestamp
clinical_trials_harmonized.vs	dcmname	Keep	NULL
clinical_trials_harmonized.vs	dcmsubnm	Keep	NULL
clinical_trials_harmonized.vs	dcmtime	Keep	NULL
clinical_trials_harmonized.vs	docnum	Keep	NULL
clinical_trials_harmonized.vs	domain	Keep	NULL
clinical_trials_harmonized.vs	dtvs	Keep	NULL
clinical_trials_harmonized.vs	edcix	Keep	NULL
clinical_trials_harmonized.vs	eghr	Keep	NULL
clinical_trials_harmonized.vs	epoch	Keep	NULL
clinical_trials_harmonized.vs	hgtcm	Keep	NULL
clinical_trials_harmonized.vs	hgt	Keep	NULL
clinical_trials_harmonized.vs	hgtu	Keep	NULL
clinical_trials_harmonized.vs	idvar	Keep	NULL
clinical_trials_harmonized.vs	idvarval	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.vs	invid	Redact	Detected Entity with tag PII "clinical_invid"
clinical_trials_harmonized.vs	invsite	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.vs	inv	Keep	NULL
clinical_trials_harmonized.vs	lockflag	Keep	NULL
clinical_trials_harmonized.vs	logints	SkewDate	DateAndTimestamp
clinical_trials_harmonized.vs	lstchgts	SkewDate	DateAndTimestamp
clinical_trials_harmonized.vs	nyvs	Keep	NULL
clinical_trials_harmonized.vs	positn	Keep	NULL
clinical_trials_harmonized.vs	pt	Keep	NULL
clinical_trials_harmonized.vs	pulse	Keep	NULL
clinical_trials_harmonized.vs	pulseu	Keep	NULL
clinical_trials_harmonized.vs	qeval	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	qlabel	Keep	NULL
clinical_trials_harmonized.vs	qnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	qorig	Keep	NULL
clinical_trials_harmonized.vs	qualifyv	Keep	NULL
clinical_trials_harmonized.vs	qval	Keep	NULL
clinical_trials_harmonized.vs	rdomain	Keep	NULL
clinical_trials_harmonized.vs	repeatsn	Keep	NULL
clinical_trials_harmonized.vs	ressu	Keep	NULL
clinical_trials_harmonized.vs	rowid	Keep	NULL
clinical_trials_harmonized.vs	rsprt	Keep	NULL
clinical_trials_harmonized.vs	spdevid	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	studyid	Keep	Detected Entity "clinical_studyid"
clinical_trials_harmonized.vs	study	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	subjid	FPENumeric	Detected Entity with tag PII "clinical_subjid"
clinical_trials_harmonized.vs	subsetsn	Keep	NULL
clinical_trials_harmonized.vs	tempc	Keep	NULL
clinical_trials_harmonized.vs	temp	Keep	NULL
clinical_trials_harmonized.vs	tempf	Keep	NULL
clinical_trials_harmonized.vs	tempuq	Keep	NULL
clinical_trials_harmonized.vs	tempu	Keep	NULL
clinical_trials_harmonized.vs	txcom1vs	Keep	NULL
clinical_trials_harmonized.vs	txcom2vs	Keep	NULL
clinical_trials_harmonized.vs	txcom3vs	Keep	NULL
clinical_trials_harmonized.vs	urecid	Keep	NULL
clinical_trials_harmonized.vs	usubjid	FPEAlphaNumeric	Detected Entity with tag PII "clinical_usubjid"
clinical_trials_harmonized.vs	visitnum	Keep	NULL
clinical_trials_harmonized.vs	visit	Keep	NULL
clinical_trials_harmonized.vs	visitvs	Keep	NULL
clinical_trials_harmonized.vs	vsarmcm	Keep	NULL
clinical_trials_harmonized.vs	vsarm	Keep	NULL
clinical_trials_harmonized.vs	vsarmin	Keep	NULL
clinical_trials_harmonized.vs	vsarmu	Keep	NULL
clinical_trials_harmonized.vs	vsblfl	Keep	NULL
clinical_trials_harmonized.vs	vsbmi1	Keep	NULL
clinical_trials_harmonized.vs	vsbmi_d	Keep	NULL
clinical_trials_harmonized.vs	vsbmi	Keep	NULL
clinical_trials_harmonized.vs	vsbmiu	Keep	NULL
clinical_trials_harmonized.vs	vsbpu1	Keep	NULL
clinical_trials_harmonized.vs	vsbpu2	Keep	NULL
clinical_trials_harmonized.vs	vsbpul	Keep	NULL
clinical_trials_harmonized.vs	vsbpun	Keep	NULL
clinical_trials_harmonized.vs	vsbpu	Keep	NULL
clinical_trials_harmonized.vs	vsbpu_x	Keep	NULL
clinical_trials_harmonized.vs	vsbsac	Keep	NULL
clinical_trials_harmonized.vs	vsbsa	Keep	NULL
clinical_trials_harmonized.vs	vsbsau	Keep	NULL
clinical_trials_harmonized.vs	vscatcd	Keep	NULL
clinical_trials_harmonized.vs	vscat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	vschcm	Keep	NULL
clinical_trials_harmonized.vs	vsch	Keep	NULL
clinical_trials_harmonized.vs	vschin	Keep	NULL
clinical_trials_harmonized.vs	vschu	Keep	NULL
clinical_trials_harmonized.vs	vscuff	Keep	NULL
clinical_trials_harmonized.vs	vsday	Keep	NULL
clinical_trials_harmonized.vs	vsdiabp1	Keep	NULL
clinical_trials_harmonized.vs	vsdiabp2	Keep	NULL
clinical_trials_harmonized.vs	vsdiabp	Keep	NULL
clinical_trials_harmonized.vs	vsdiabpf	Keep	NULL
clinical_trials_harmonized.vs	vsdiab_x	Keep	NULL
clinical_trials_harmonized.vs	vsdiac	Keep	NULL
clinical_trials_harmonized.vs	vsdia	Keep	NULL
clinical_trials_harmonized.vs	vsdiae	Keep	NULL
clinical_trials_harmonized.vs	vsdtce	Keep	NULL
clinical_trials_harmonized.vs	vsdtc	SkewDate	MultipleDateAndTimestamp
clinical_trials_harmonized.vs	vsdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.vs	vsdte	Keep	NULL
clinical_trials_harmonized.vs	vsdtm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.vs	vsdtmp	Keep	NULL
clinical_trials_harmonized.vs	vsdtp	Keep	NULL
clinical_trials_harmonized.vs	vsdy2	Keep	NULL
clinical_trials_harmonized.vs	vsdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	vsedy2	Keep	NULL
clinical_trials_harmonized.vs	vsedy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	vselbcm	Keep	NULL
clinical_trials_harmonized.vs	vselb	Keep	NULL
clinical_trials_harmonized.vs	vselbin	Keep	NULL
clinical_trials_harmonized.vs	vselbu	Keep	NULL
clinical_trials_harmonized.vs	vseltm	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	vsfht	Keep	NULL
clinical_trials_harmonized.vs	vsfhtu	Keep	NULL
clinical_trials_harmonized.vs	vsgrpid	Keep	NULL
clinical_trials_harmonized.vs	vsgrst	Keep	NULL
clinical_trials_harmonized.vs	vsgrstu	Keep	NULL
clinical_trials_harmonized.vs	vsgsha	Keep	NULL
clinical_trials_harmonized.vs	vsgt	Keep	NULL
clinical_trials_harmonized.vs	vshpcm	Keep	NULL
clinical_trials_harmonized.vs	vshp	Keep	NULL
clinical_trials_harmonized.vs	vshpin	Keep	NULL
clinical_trials_harmonized.vs	vshpu	Keep	NULL
clinical_trials_harmonized.vs	vshrc	Keep	NULL
clinical_trials_harmonized.vs	vshr	Keep	NULL
clinical_trials_harmonized.vs	vshre	Keep	NULL
clinical_trials_harmonized.vs	vshrf	Keep	NULL
clinical_trials_harmonized.vs	vshrul	Keep	NULL
clinical_trials_harmonized.vs	vshrun	Keep	NULL
clinical_trials_harmonized.vs	vshru	Keep	NULL
clinical_trials_harmonized.vs	vsht1	Keep	NULL
clinical_trials_harmonized.vs	vsht2	Keep	NULL
clinical_trials_harmonized.vs	vsht3	Keep	NULL
clinical_trials_harmonized.vs	vshtcm1	Keep	NULL
clinical_trials_harmonized.vs	vshtcm2	Keep	NULL
clinical_trials_harmonized.vs	vshtcm	Keep	NULL
clinical_trials_harmonized.vs	vshtc	Keep	NULL
clinical_trials_harmonized.vs	vsht	Keep	NULL
clinical_trials_harmonized.vs	vshte	Keep	NULL
clinical_trials_harmonized.vs	vshtf	Keep	NULL
clinical_trials_harmonized.vs	vshtflg	Keep	NULL
clinical_trials_harmonized.vs	vshtft	Keep	NULL
clinical_trials_harmonized.vs	vshtin1	Keep	NULL
clinical_trials_harmonized.vs	vshtin2	Keep	NULL
clinical_trials_harmonized.vs	vshtin	Keep	NULL
clinical_trials_harmonized.vs	vshtu1	Keep	NULL
clinical_trials_harmonized.vs	vshtu2	Keep	NULL
clinical_trials_harmonized.vs	vshtuc	Keep	NULL
clinical_trials_harmonized.vs	vshtue	Keep	NULL
clinical_trials_harmonized.vs	vshtul	Keep	NULL
clinical_trials_harmonized.vs	vshtun	Keep	NULL
clinical_trials_harmonized.vs	vshtu	Keep	NULL
clinical_trials_harmonized.vs	vshtvl	Keep	NULL
clinical_trials_harmonized.vs	vshtvlu	Keep	NULL
clinical_trials_harmonized.vs	vsinha	Keep	NULL
clinical_trials_harmonized.vs	vslnkid	Keep	NULL
clinical_trials_harmonized.vs	vsloc	Keep	NULL
clinical_trials_harmonized.vs	vsmacm	Keep	NULL
clinical_trials_harmonized.vs	vsma	Keep	NULL
clinical_trials_harmonized.vs	vsmain	Keep	NULL
clinical_trials_harmonized.vs	vsmapc	Keep	NULL
clinical_trials_harmonized.vs	vsmap	Keep	NULL
clinical_trials_harmonized.vs	vsmau	Keep	NULL
clinical_trials_harmonized.vs	vsmetho1	Keep	NULL
clinical_trials_harmonized.vs	vsmetho2	Keep	NULL
clinical_trials_harmonized.vs	vsmethod	Keep	NULL
clinical_trials_harmonized.vs	vsmethsp	Keep	NULL
clinical_trials_harmonized.vs	vsmht	Keep	NULL
clinical_trials_harmonized.vs	vsmhtu	Keep	NULL
clinical_trials_harmonized.vs	vsmtcm	Keep	NULL
clinical_trials_harmonized.vs	vsmt	Keep	NULL
clinical_trials_harmonized.vs	vsmtin	Keep	NULL
clinical_trials_harmonized.vs	vsmtu	Keep	NULL
clinical_trials_harmonized.vs	vsnam	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	vsorresn	Keep	NULL
clinical_trials_harmonized.vs	vsorres	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	vsorresu	Keep	NULL
clinical_trials_harmonized.vs	vsoxsat	Keep	NULL
clinical_trials_harmonized.vs	vsoxsatu	Keep	NULL
clinical_trials_harmonized.vs	vspdtcc	Keep	NULL
clinical_trials_harmonized.vs	vspdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.vs	vspdt	SkewDate	DateAndTimestamp
clinical_trials_harmonized.vs	vspdtp	Keep	NULL
clinical_trials_harmonized.vs	vspdy	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	vspht	Keep	NULL
clinical_trials_harmonized.vs	vsphtu	Keep	NULL
clinical_trials_harmonized.vs	vspoch	Keep	NULL
clinical_trials_harmonized.vs	vspos1	Keep	NULL
clinical_trials_harmonized.vs	vspos2	Keep	NULL
clinical_trials_harmonized.vs	vsposc1	Keep	NULL
clinical_trials_harmonized.vs	vsposcd	Keep	NULL
clinical_trials_harmonized.vs	vsposc	Keep	NULL
clinical_trials_harmonized.vs	vsposl	Keep	NULL
clinical_trials_harmonized.vs	vsposn	Keep	NULL
clinical_trials_harmonized.vs	vspos	Keep	NULL
clinical_trials_harmonized.vs	vspos_x	Keep	NULL
clinical_trials_harmonized.vs	vspump	Keep	NULL
clinical_trials_harmonized.vs	vsreasnd	Redact	PossibleFreeText --> As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	vsrefid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.vs	vsrrc	Keep	NULL
clinical_trials_harmonized.vs	vsrr	Keep	NULL
clinical_trials_harmonized.vs	vsrre	Keep	NULL
clinical_trials_harmonized.vs	vsrrf	Keep	NULL
clinical_trials_harmonized.vs	vsrru	Keep	NULL
clinical_trials_harmonized.vs	vsscat	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	vssecd	Keep	NULL
clinical_trials_harmonized.vs	vsseq	Keep	NULL
clinical_trials_harmonized.vs	vsspid	FPEAlphaNumeric	Recode ID variable
clinical_trials_harmonized.vs	vsstat	Keep	NULL
clinical_trials_harmonized.vs	vsstresc	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	vsstresn	Keep	As per PhUSE SDTM 3.2 rules
clinical_trials_harmonized.vs	vsstresu	Keep	NULL
clinical_trials_harmonized.vs	vssysbp1	Keep	NULL
clinical_trials_harmonized.vs	vssysbp2	Keep	NULL
clinical_trials_harmonized.vs	vssysbp	Keep	NULL
clinical_trials_harmonized.vs	vssysbpf	Keep	NULL
clinical_trials_harmonized.vs	vssysb_x	Keep	NULL
clinical_trials_harmonized.vs	vssysc	Keep	NULL
clinical_trials_harmonized.vs	vssys	Keep	NULL
clinical_trials_harmonized.vs	vssyse	Keep	NULL
clinical_trials_harmonized.vs	vstempcc	Keep	NULL
clinical_trials_harmonized.vs	vstempc	Keep	NULL
clinical_trials_harmonized.vs	vstempcf	Keep	NULL
clinical_trials_harmonized.vs	vstemp	Keep	NULL
clinical_trials_harmonized.vs	vstempe	Keep	NULL
clinical_trials_harmonized.vs	vstempf	Keep	NULL
clinical_trials_harmonized.vs	vstempff	Keep	NULL
clinical_trials_harmonized.vs	vstempu	Keep	NULL
clinical_trials_harmonized.vs	vstestcd	Keep	NULL
clinical_trials_harmonized.vs	vstest	Keep	NULL
clinical_trials_harmonized.vs	vstmc	Keep	NULL
clinical_trials_harmonized.vs	vstm	SkewDate	DateAndTimestamp
clinical_trials_harmonized.vs	vstme	Keep	NULL
clinical_trials_harmonized.vs	vstmpc	Keep	NULL
clinical_trials_harmonized.vs	vstmp	Keep	NULL
clinical_trials_harmonized.vs	vstmpf	Keep	NULL
clinical_trials_harmonized.vs	vstmpml	Keep	NULL
clinical_trials_harmonized.vs	vstmpm	Keep	NULL
clinical_trials_harmonized.vs	vstmpuc	Keep	NULL
clinical_trials_harmonized.vs	vstmpue	Keep	NULL
clinical_trials_harmonized.vs	vstmpul	Keep	NULL
clinical_trials_harmonized.vs	vstmpun	Keep	NULL
clinical_trials_harmonized.vs	vstmpu	Keep	NULL
clinical_trials_harmonized.vs	vstmsp	Keep	NULL
clinical_trials_harmonized.vs	vstms	Keep	NULL
clinical_trials_harmonized.vs	vstptl	Keep	NULL
clinical_trials_harmonized.vs	vstptn	Keep	NULL
clinical_trials_harmonized.vs	vstptnum	Keep	NULL
clinical_trials_harmonized.vs	vstptref	Keep	NULL
clinical_trials_harmonized.vs	vstpt	Keep	NULL
clinical_trials_harmonized.vs	vststdtl	Keep	NULL
clinical_trials_harmonized.vs	vsusresn	Keep	NULL
clinical_trials_harmonized.vs	vsusresu	Keep	NULL
clinical_trials_harmonized.vs	vsvis	Keep	NULL
clinical_trials_harmonized.vs	vsvisflg	Keep	NULL
clinical_trials_harmonized.vs	vsvisit	Keep	NULL
clinical_trials_harmonized.vs	vsvs	Keep	NULL
clinical_trials_harmonized.vs	vsvstp	Keep	NULL
clinical_trials_harmonized.vs	vsvstxt	Keep	NULL
clinical_trials_harmonized.vs	vswscm	Keep	NULL
clinical_trials_harmonized.vs	vsws	Keep	NULL
clinical_trials_harmonized.vs	vswsin	Keep	NULL
clinical_trials_harmonized.vs	vswsu	Keep	NULL
clinical_trials_harmonized.vs	vswt1	Keep	NULL
clinical_trials_harmonized.vs	vswt2	Keep	NULL
clinical_trials_harmonized.vs	vswtc	Keep	NULL
clinical_trials_harmonized.vs	vswt	Keep	NULL
clinical_trials_harmonized.vs	vswte	Keep	NULL
clinical_trials_harmonized.vs	vswtf	Keep	NULL
clinical_trials_harmonized.vs	vswtkg1	Keep	NULL
clinical_trials_harmonized.vs	vswtkg2	Keep	NULL
clinical_trials_harmonized.vs	vswtkg	Keep	NULL
clinical_trials_harmonized.vs	vswtlb1	Keep	NULL
clinical_trials_harmonized.vs	vswtlb2	Keep	NULL
clinical_trials_harmonized.vs	vswtlb	Keep	NULL
clinical_trials_harmonized.vs	vswtu1	Keep	NULL
clinical_trials_harmonized.vs	vswtu2	Keep	NULL
clinical_trials_harmonized.vs	vswtuc	Keep	NULL
clinical_trials_harmonized.vs	vswtue	Keep	NULL
clinical_trials_harmonized.vs	vswtul	Keep	NULL
clinical_trials_harmonized.vs	vswtun	Keep	NULL
clinical_trials_harmonized.vs	vswtu	Keep	NULL
clinical_trials_harmonized.vs	vsxdtce	Keep	NULL
clinical_trials_harmonized.vs	vsxdtc	SkewDate	DateAndTimestamp
clinical_trials_harmonized.vs	wei	Keep	NULL
clinical_trials_harmonized.vs	weilb	Keep	NULL
clinical_trials_harmonized.vs	wgt	Keep	NULL
clinical_trials_harmonized.vs	wgtkg	Keep	NULL
clinical_trials_harmonized.vs	wgtu	Keep	NULL
clinical_trials_harmonized.vs	source_dataset	Keep	NULL
