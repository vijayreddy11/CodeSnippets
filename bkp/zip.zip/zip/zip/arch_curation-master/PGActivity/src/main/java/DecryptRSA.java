import org.apache.commons.io.FileUtils;
import utility.JSONUtils;
import utility.RSAEncryptionUtils;

import java.io.File;
import java.io.IOException;
import java.util.Map;

public class DecryptRSA {
    public static void main(String[] args) throws Exception {
        String jsonString = FileUtils.readFileToString(new File("C:\\Users\\gudurvk\\Workarea\\test\\PGActivity\\src\\main\\resources\\postgres_arch_dev.json"), "UTF-8");
        Map<String, Object> jdbcConfig = JSONUtils.jsonToMap(jsonString);

        String password = jdbcConfig.get("password").toString();
        password ="JSvQSUtnSHWjtrDTbwF3miJ7OSQEVeKubwrifKh56EIfbhACWu82wocJHkUwMAMvw9nyT6ncaR1oC9MDJ9xLGxJN98ahE3urKZNelWgRm+mHxsmcuzUZIjf396gNKKd7sQEXL/QSFI9LX8kyPDQCeg5LqYLF4IyX4vCjtRK+8pgpLS20aNH5bSiq7MXhrFzfPXD9anYF7AC2SDvkq6Ro2fN38tPx5VzDTWZtzCRNoqiUuNWGb18L0uQGRFwcu5XVrJP4S7IlrDJS5GD4eDN9EiLVtkMsLWyCI+5ARYvxfODerGMyNwMSgXKPdekbg+VKvNE7JGz0tXtmz8vXnfgE8g==";
        String encryptedPassword = jdbcConfig.get("encrypted_password").toString();
        if (encryptedPassword != null && encryptedPassword.equalsIgnoreCase("Y")) {
            String privateKeyPath = jdbcConfig.get("privateKeyPath").toString();
            password = RSAEncryptionUtils.decryptPassword(password, privateKeyPath);
            System.out.println(password);
        }
    }
}