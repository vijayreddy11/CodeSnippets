package utility;//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;


public class RSAEncryptionUtils {


    public RSAEncryptionUtils() {
    }

    public static Map<String, Object> getRSAKeys() throws Exception {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        PrivateKey privateKey = keyPair.getPrivate();
        PublicKey publicKey = keyPair.getPublic();
        Map<String, Object> keys = new HashMap();
        keys.put("privateKey_old", privateKey);
        keys.put("publicKey", publicKey);
        return keys;
    }

    public static void generateRSAKeys(String filePath) throws Exception {
        Map<String, Object> keys = getRSAKeys();
        PrivateKey privateKey = (PrivateKey)keys.get("privateKey_old");
        PublicKey publicKey = (PublicKey)keys.get("publicKey");
        writeToFile(filePath + File.separator + "publicKey", publicKey.getEncoded());
        writeToFile(filePath + File.separator + "privateKey_old", privateKey.getEncoded());
    }

    public static byte[] decryptUsingRSA(byte[] encryptedText, String privateKeyPath) throws Exception {
        return decryptUsingRSA(encryptedText, getPrivateKey(privateKeyPath));
    }

    public static byte[] decryptUsingRSA(byte[] encryptedBytes, PrivateKey privateKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(2, privateKey);
        return cipher.doFinal(encryptedBytes);
    }

    public static byte[] encryptUsingRSA(byte[] bytesFromPlainText, String publicKeyPath) throws Exception {
        return encryptUsingRSA(bytesFromPlainText, getPublicKey(publicKeyPath));
    }

    public static byte[] encryptUsingRSA(byte[] bytesFromPlainText, PublicKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(1, publicKey);
        return cipher.doFinal(bytesFromPlainText);
    }

    public static String decryptPassword(String encryptedText, String privateKeyPath) throws Exception {
        return decryptPassword(encryptedText, getPrivateKey(privateKeyPath));
    }

    public static String decryptPassword(String encryptedText, PrivateKey privateKey) throws Exception {
        byte[] bytesInEncryptedPassword = Base64.getDecoder().decode(encryptedText);
        return new String(decryptUsingRSA(bytesInEncryptedPassword, privateKey), StandardCharsets.UTF_8);
    }

    public static String encryptPassword(String toBeEncryptedText, String publicKeyPath) throws Exception {
        return encryptPassword(toBeEncryptedText, getPublicKey(publicKeyPath));
    }

    public static String encryptPassword(String toBeEncryptedText, PublicKey publicKey) throws Exception {
        byte[] bytesInToBeEncryptedText = toBeEncryptedText.getBytes();
        return Base64.getEncoder().encodeToString(encryptUsingRSA(bytesInToBeEncryptedText, publicKey));
    }

    public static PrivateKey getPrivateKey(String filePath) throws Exception {
        if (filePath != null) {
            File f = new File(filePath);
            if (f.exists()) {
                byte[] keyBytes = Files.readAllBytes((new File(filePath)).toPath());
                PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
                KeyFactory kf = KeyFactory.getInstance("RSA");
                return kf.generatePrivate(spec);
            } else {
                throw new Exception("File not found in location " + filePath);
            }
        } else {
            throw new NullPointerException("null file");
        }
    }

    public static PublicKey getPublicKey(String filePath) throws Exception {
        if (filePath != null) {
            File f = new File(filePath);
            if (f.exists()) {
                byte[] keyBytes = Files.readAllBytes((new File(filePath)).toPath());
                X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
                KeyFactory kf = KeyFactory.getInstance("RSA");
                return kf.generatePublic(spec);
            } else {
                throw new Exception("File not found in location " + filePath);
            }
        } else {
            throw new NullPointerException("null file");
        }
    }

    private static void writeToFile(String path, byte[] keyInBytes) throws Exception {
        FileOutputStream fop = null;

        try {
            File file = new File(path);
            fop = new FileOutputStream(file);
            if (!file.exists()) {
                file.createNewFile();
            }

            fop.write(keyInBytes);
            fop.flush();
            fop.close();
        } catch (Exception var12) {
            throw new Exception("Failed to write into file  " + path, var12);
        } finally {
            try {
                if (fop != null) {
                    fop.close();
                }
            } catch (IOException var11) {
                var11.printStackTrace();
            }

        }

    }
}
