import java.sql.*;

public class CreateSAS {
    public static void main(String[] args) throws Exception {
        Class.forName("com.dullesopen.jdbc.Driver").newInstance();
        Connection connection =
                DriverManager.getConnection(
                        "jdbc:carolina:bulk:libnames=(mylib='/home/gudurvk/sas');");
        try (final Statement create = connection.createStatement()) {
            create.execute("create table mydata( " +
                    "n numeric label='my numeric' format='F3.', " +
                    "c character(20) format='$HEX40.', " +
                    "d date, " +
                    "t time informat='TIME7.' format='TIME5.' label='My Time', " +
                    "dt datetime)");
        }
        try (final PreparedStatement insert = connection.prepareStatement(
                "insert into mydata values (?,?,?,?,?)")) {
            insert.setDouble(1, 123);
            insert.setString(2, "abc");
            insert.setDate(3, Date.valueOf("2017-11-23"));
            insert.setTime(4, Time.valueOf("14:15:16"));
            insert.setTimestamp(5, Timestamp.valueOf("2017-11-23 14:15:16"));
            insert.execute();
        }
        connection.commit();
    }
}
