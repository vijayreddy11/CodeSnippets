import org.apache.commons.io.FileUtils;
import utility.JSONUtils;
import utility.RSAEncryptionUtils;
import utility.Utils;

import java.io.File;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class PgAdmin {
    protected Connection conn = null;
    protected Utils utils = new Utils();

    protected void initDB() throws Exception {
        String jsonString = FileUtils.readFileToString(new File("C:\\Users\\gudurvk\\Workarea\\test\\PGActivity\\src\\main\\resources\\postgres_arch_dev.json"), "UTF-8");
        Map<String, Object> jdbcConfig = JSONUtils.jsonToMap(jsonString);

        String password = jdbcConfig.get("password").toString();
        String encryptedPassword = jdbcConfig.get("encrypted_password").toString();
        if (encryptedPassword != null && encryptedPassword.equalsIgnoreCase("Y")) {
            String privateKeyPath = jdbcConfig.get("privateKeyPath").toString();
            password = RSAEncryptionUtils.decryptPassword(password, privateKeyPath);
        }
        try {
            Class.forName(jdbcConfig.get("jdbc_driver").toString());
            conn = DriverManager.getConnection(jdbcConfig.get("jdbc_url").toString(), jdbcConfig.get("username").toString(), password);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
    }

    protected String getRefreshFreq(int i) {
        SimpleDateFormat formatter = new SimpleDateFormat("00 mm HH dd MM ? yyyy");
        java.util.Date date = new Date(System.currentTimeMillis()
                - TimeUnit.HOURS.toMillis(5) - TimeUnit.MINUTES.toMillis(30)
                + TimeUnit.MINUTES.toMillis(i));
        return formatter.format(date);
    }
}
