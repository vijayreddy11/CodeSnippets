import utility.RSAEncryptionUtils;

public class EncryptRSA {
    public static void main(String[] args) throws Exception {

        String password = "zU7dKvnVqD";
        String publicKeyPath = "C:\\Users\\gudurvk\\Workarea\\test\\PGActivity\\src\\main\\resources\\publicKey";
        password = RSAEncryptionUtils.encryptPassword(password, publicKeyPath);
        System.out.println(password);

    }
}
