import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;

public class test {
    public static void main(String[] args) {
        STGroup stGroup = new STGroupFile("C:\\Users\\gudurvk\\Workarea\\test\\PGActivity\\src\\main\\java\\test.stg", '$', '$');
        String sql = stGroup.getInstanceOf("tmp")
                .add("var", null)
                .render();
        System.out.println("Sql:"+sql);
    }
}
