import java.sql.SQLException;

public class PGSelect extends PgAdmin {
    public static void main(String[] args) throws Exception {
        PGSelect pgSelect =new PGSelect();
        pgSelect.init("select data_movement_additional_info from nabu.data_movement_physical where data_movement_id =1335");
    }
    private void init(String query) {
        try {
            initDB();
            System.out.println(utils.executeQuery(conn,query));
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                if(!conn.isClosed())
                    conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
