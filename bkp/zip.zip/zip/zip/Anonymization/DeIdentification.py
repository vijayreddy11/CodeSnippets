from pyspark.sql import SparkSession
from pyspark.sql.types import *
from Rules import Rules
import logging
import psycopg2
import requests
from concurrent.futures import ThreadPoolExecutor

logging.basicConfig(level = logging.INFO)
spark = SparkSession.builder \
            .appName('DeIdentification') \
            .enableHiveSupport() \
            .getOrCreate()

class DeIdentification:
    def process(self, source_db, datastore_name, table, suffix, host, user, password, dbname, s3_path, target_db):
        try:
            table_name = source_db + "." + table
            logging.info("De-identification started for table : {}".format(table_name))
            anon_table_name = target_db + "." + table + suffix
            target_s3_path = s3_path + target_db + ".db/" + anon_table_name.split('.')[1]

            rules = Rules()
            delete_profile = rules.delete_profile(table_name)
            insert_profile = rules.insert_profile(table_name, datastore_name)
            delete_report = rules.delete_report(table_name)
            insert_report = rules.insert_report(table_name, anon_table_name)
            select_report = rules.select_report(table_name)

            conn = psycopg2.connect(host=host, user=user, password=password, port=5432, dbname=dbname)
            curs = conn.cursor()
            conn.autocommit = True
            curs.execute(delete_profile)
            curs.execute(insert_profile)
            curs.execute(delete_report)
            curs.execute(insert_report)
            curs.execute(select_report)
            report = curs.fetchall()

            valuedbasedcolumns = []
            nonvaluedbasedcolumns = []
            for row in report:
                if row[6] == 'Y':
                    valuedbasedcolumns.append(row[2])
                else:
                    nonvaluedbasedcolumns.append(row)
            usubjid_checker = report[0][5]
            valued_based_report = []
            for column_name in valuedbasedcolumns:
                value_based_report_for_column = rules.value_based_report(table_name,column_name)
                curs.execute(value_based_report_for_column)
                valued_based_report.append(curs.fetchall())

            curs.close()
            conn.close()

            rules_list = []
            for row in nonvaluedbasedcolumns:
                column_name = row[2]
                anon_func = row[3]
                if anon_func == "SkewDate":
                    #usubjid_checker = row[5]
                    rules_list.append(rules.__getattribute__(anon_func)(column_name,usubjid_checker))
                else:
                    rules_list.append(rules.__getattribute__(anon_func)(column_name))

            for row in valued_based_report:
                column_name = row[0][1]
                reference_column_name = row[0][2]
                reference_column_value = row[0][3]
                applied_anon_func = row[0][5]
                override_anon_func = row[0][6]
                applied_str = rules.__getattribute__(applied_anon_func)(column_name) if applied_anon_func != "SkewDateValueBased" else rules.__getattribute__(applied_anon_func)(column_name, usubjid_checker)
                override_str = rules.__getattribute__(override_anon_func)(column_name) if override_anon_func != "SkewDateValueBased" else rules.__getattribute__(override_anon_func)(column_name, usubjid_checker)
                
                if(reference_column_value != None):
                    rules_list.append("""case when {} = '{}' then {}
                            else {} end as {}""".format(reference_column_name, reference_column_value, override_str, applied_str, column_name))
                else:
                    rules_list.append("""case when {} is not null then {}
                            else {} end as {}""".format(reference_column_name, override_str, applied_str, column_name))

            columns_info = spark.table(table_name).dtypes
            schema = "{}".format( ', '.join(['{} {}'.format(value[0],value[1] if value[0].lower() != 'age' else 'string') for value in columns_info])) 
            result = spark.createDataFrame(data = [], schema = schema)
            result.write.mode('overwrite').format('parquet').option('path',target_s3_path).saveAsTable(anon_table_name)

            spark.sql("""with temp_table as (select {} from {})
		        insert into {} select {} from temp_table""".format(','.join([x for x in rules_list]), table_name, anon_table_name, ','.join([x[0] for x in columns_info])))
            logging.info("De-identification finished for table :{} and table {} is created".format(table_name, anon_table_name))
        except Exception as ex:
            logging.error("De_identification is failed for {} with exception {}".format(table, ex))

if __name__ == "__main__":
    token = spark.conf.get("spark.nabu.token")
    fireshots_url = spark.conf.get("spark.nabu.fireshots_url")
    datastore_name = spark.conf.get("spark.driver.datastore_name")
    source_db = spark.conf.get("spark.driver.source_db")
    target = spark.conf.get("spark.driver.target").split(" ")
    kosh = spark.conf.get("spark.driver.kosh").split(" ")
    threadPoolSize = spark.conf.get("spark.driver.threadPoolSize")
    suffix = spark.conf.get("spark.driver.suffix")
    source_type = spark.conf.get("spark.driver.source_type")

    cred_id = kosh[0]
    cred_type = kosh[1]
    host = kosh[2]
    dbname = kosh[3]
    credentials = requests.post(fireshots_url, 
                headers = {"Content-Type" : "application/json", "Authorization" : token, "Accept": "application/json"},
                json = {"credential_id": cred_id, "credential_type_id": cred_type}).json()

    user = credentials['data']['username']
    password = credentials['data']['password']
    target_db = target[0]
    s3_path = target[1]

    if source_type == 'DATABASE':
        tables_list = spark.sql("show tables in {}".format(source_db)) \
            .select("tableName") \
            .rdd.flatMap(lambda x: x).collect()
    elif source_type == 'SET':
        tables_list = spark.conf.get("spark.driver.tables_list").split(",")
    elif source_type == 'FILE':
        source_path = spark.conf.get("spark.driver.source_path")
        file = open(source_path)
        tables_list = file.read().replace(' ','').split(",")
    else:
        import sys
        sys.exit("Enter valid source type")

    logging.info("Total no. of tables : {}".format(len(tables_list)))
    rules = Rules()
    rules.date_validator(host, user, password, dbname)
    deId = DeIdentification()

    with ThreadPoolExecutor(max_workers=int(threadPoolSize)) as executor:
        for table in tables_list:
            executor.submit(deId.process, source_db, datastore_name, table, suffix, host, user, password, dbname, s3_path, target_db)
    logging.info("De_identification process is completed")
