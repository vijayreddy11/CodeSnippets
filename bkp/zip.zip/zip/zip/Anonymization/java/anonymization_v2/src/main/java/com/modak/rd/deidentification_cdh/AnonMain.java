package com.modak.rd.deidentification_cdh;

import org.apache.commons.cli.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AnonMain {
    private static final Logger LOGGER = LogManager.getLogger(AnonMain.class.getSimpleName());

    public static void main(String[] args) {
        Options options = new Options();
        options.addOption("h", "help", false, "show help");
        options.addOption("t", "tables", true, "txt file with list of tables");
        options.addOption("r", "configuration", true, "configuration to anonymizes the table");
        options.addOption("d", "deidentify", false, "flag to anonymize the tables");
        options.addOption("p", "profile", false, "flag to anon profile the tables");
        CommandLineParser commandLineParser = new DefaultParser();
        try {
            CommandLine commandLine = commandLineParser.parse(options, args);
            HelpFormatter helpFormatter = new HelpFormatter();
            if (commandLine.hasOption("h")) {
                helpFormatter.printHelp("", options);
                System.exit(0);
            }
            String resourceFile = null;
            if (commandLine.hasOption("r")) {
                resourceFile = commandLine.getOptionValue("r");
            } else {
                helpFormatter.printHelp("", options);
                System.exit(0);
            }
            String tablesFilePath = null;
            if(commandLine.hasOption("t")){
                tablesFilePath = commandLine.getOptionValue("t");
            }else{
                System.exit(0);
            }
            if (commandLine.hasOption("p") && commandLine.hasOption("d")) {
                helpFormatter.printHelp("", options);
            }
            if(commandLine.hasOption("p")){
                Configurator.initialize(null,"config/profile_log4j2.xml");
            }
            if(commandLine.hasOption("d")){
                Configurator.initialize(null,"config/deidentify_log4j2.xml");
            }
            Utils utils = new Utils();
            HashMap<String, Object> resourceMap = utils.readJsonToHashMap(resourceFile);
            Stream<String> fileStream = Files.lines(Paths.get(tablesFilePath));
            List<String> tablesList = fileStream.map(String::valueOf)
                    .filter(s -> !s.isEmpty())
                    .map(String::trim)
                    .collect(Collectors.toList());
            LOGGER.info(AnonCommon.TOTAL_TABLES + tablesList.size());
            if (commandLine.hasOption("p")) {
                LOGGER.info(AnonCommon.ANON_PROFILING_STARTED);
                AnonProfile anonProfile = new AnonProfile(tablesList, resourceMap);
                anonProfile.profile();
                LOGGER.info(AnonCommon.JOB_COMPLETED);
            } else if (commandLine.hasOption("d")) {
                Anonymizer anonymizer = new Anonymizer(tablesList, resourceMap);
                anonymizer.anonymize();
                LOGGER.info(AnonCommon.JOB_COMPLETED);
            } else {
                helpFormatter.printHelp("", options);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
