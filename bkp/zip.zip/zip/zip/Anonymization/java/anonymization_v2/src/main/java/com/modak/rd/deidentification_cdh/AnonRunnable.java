package com.modak.rd.deidentification_cdh;

import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AnonRunnable implements Runnable {
    private final HashMap<String, Object> resourceMap;
    private final HikariDataSource hiveDataSource;
    private final HikariDataSource postgresDataSource;
    private final String anonTableName;
    private final String nonAnonTableName;
    private List<String> totalColumns;
    private STGroup templateGroup = null;
    private Utils utils = new Utils();
    private static final Logger LOGGER = LogManager.getLogger(AnonRunnable.class.getSimpleName());

    public AnonRunnable(HashMap<String, Object> resourceMap,
                        HikariDataSource hiveDataSource,
                        HikariDataSource postgresDataSource,
                        String anonTableName,
                        String nonAnonTableName, List<String> totalColumns) {
        this.resourceMap = resourceMap;
        this.hiveDataSource = hiveDataSource;
        this.postgresDataSource = postgresDataSource;
        this.anonTableName = anonTableName;
        this.nonAnonTableName = nonAnonTableName;
        this.totalColumns = totalColumns;
    }

    @Override
    public void run() {
        try {
            String templateFile = resourceMap.get(AnonCommon.TEMPLATE_FILE).toString();
            templateGroup = new STGroupFile(templateFile, AnonCommon.DELIMITER, AnonCommon.DELIMITER);
            String deleteQuery = templateGroup.getInstanceOf(AnonCommon.DELETE_ANON_REPORT)
                    .add(AnonCommon.NON_ANON_TABLENAME, nonAnonTableName)
                    .render();
//            LOGGER.info(deleteQuery);
            String insertQuery = templateGroup.getInstanceOf(AnonCommon.INSERT_ANON_REPORT)
                    .add(AnonCommon.NON_ANON_TABLENAME, nonAnonTableName)
                    .add(AnonCommon.ANON_TABLENAME, anonTableName)
                    .render();
//            LOGGER.info(insertQuery);
            utils.executeUpdateQuery(postgresDataSource, deleteQuery);
            LOGGER.info(AnonCommon.DELETED_ANON_REPORT + nonAnonTableName);
            utils.executeUpdateQuery(postgresDataSource, insertQuery);
            LOGGER.info(AnonCommon.INSERTED_ANON_REPORT + nonAnonTableName);
            String selectAnonReportQuery = templateGroup.getInstanceOf(AnonCommon.SELECT_ANON_REPORT)
                    .add(AnonCommon.NON_ANON_TABLENAME, nonAnonTableName).render();
            List<HashMap<String, Object>> anonReport = utils.executeQuery(postgresDataSource, selectAnonReportQuery);
//            LOGGER.info("selected anon report for " + nonAnonTableName + ":" + identifierValue);
            List<Map<String, Object>> valueBasedColumns = anonReport.stream()
                    .filter(m -> m.get(AnonCommon.VALUE_BASED_ANON).toString().equalsIgnoreCase("Y"))
                    .collect(Collectors.toList());
            List<Map<String, Object>> restOfTheColumns = anonReport.stream()
                    .filter(m -> m.get(AnonCommon.VALUE_BASED_ANON).toString().equalsIgnoreCase("N"))
                    .collect(Collectors.toList());
            List<List<HashMap<String, Object>>> allValueBasedColumns = getValueBasedDataForAllColumns(valueBasedColumns);
            String anonQuery = templateGroup.getInstanceOf(AnonCommon.ANON_QUERY)
                    .add(AnonCommon.NON_ANON_TABLENAME, nonAnonTableName)
                    .add(AnonCommon.ANON_TABLENAME, anonTableName)
                    .add(AnonCommon.VALUE_BASED_COLUMNS_DATA, allValueBasedColumns)
                    .add(AnonCommon.NON_VALUE_BASED_COLUMNS_DATA, restOfTheColumns)
                    .add(AnonCommon.TOTAL_COLUMNS, totalColumns)
                    .render();
//            LOGGER.info(anonQuery);
            File queriesFile = new File(AnonCommon.OUTPUT_QUERY_FILE);
            FileUtils.write(queriesFile, anonQuery, Charset.defaultCharset(), true);
            utils.executeUpdateQuery(hiveDataSource, anonQuery);
            LOGGER.info(AnonCommon.ANON_DATA + anonTableName);
        } catch (Exception e) {
            LOGGER.error(AnonCommon.NON_ANON_TABLENAME + " : " + nonAnonTableName + " - " + AnonCommon.ANON_TABLENAME + " : " + anonTableName, e);
        }
    }

    /**
     * Query value based table for each value based column and store the result into a list
     *
     * @param valueBased anon report of the columns which are detected as value based
     * @return returns the list with data (list of maps) present in value based table for each column
     */
    private List<List<HashMap<String, Object>>> getValueBasedDataForAllColumns(List<Map<String, Object>> valueBased)
            throws Exception {
        List<List<HashMap<String, Object>>> vbReport = new ArrayList<>();
        for (Map<String, Object> valueBasedRow : valueBased) {
            String columnName = valueBasedRow.get(AnonCommon.COLUMN_NAME).toString();
            String valueBasedQuery = templateGroup.getInstanceOf(AnonCommon.VALUE_BASED_REPORT_FOR_COLUMN)
                    .add(AnonCommon.COLUMN_NAME, columnName)
                    .add(AnonCommon.NON_ANON_TABLENAME, nonAnonTableName)
                    .render();
            List<HashMap<String, Object>> valBasedColInfo = utils.executeQuery(postgresDataSource, valueBasedQuery);
            vbReport.add(valBasedColInfo);
        }
        return vbReport;
    }
}
