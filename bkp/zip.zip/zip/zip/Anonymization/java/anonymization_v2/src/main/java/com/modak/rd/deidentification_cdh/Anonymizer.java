package com.modak.rd.deidentification_cdh;

import com.modak.hive.HiveKerberosConnectionManager;
import com.modak.utils.JDBCConnectionManager;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class Anonymizer {

    private final List<String> tablesList;
    private final HashMap<String, Object> resourceMap;
    private HikariDataSource postgresDataSource;
    private JDBCConnectionManager postgresConnectionManager;
    private HiveKerberosConnectionManager hiveKerberosConnectionManager;
    private HikariDataSource hiveDataSource;
    private static final Logger LOGGER = LogManager.getLogger(Anonymizer.class.getSimpleName());
    private Utils utils = new Utils();

    public Anonymizer(List<String> tablesList, HashMap<String, Object> resourceMap) {
        this.tablesList = tablesList;
        this.resourceMap = resourceMap;
    }


    public void anonymize() {
        try {
            initDB();
            process();
        } catch (Exception e) {
            LOGGER.error("", e);
        }
        finally {
            closeDB();
        }
    }

    private void process() {
        String templateFile = resourceMap.get(AnonCommon.TEMPLATE_FILE).toString();
        STGroup templateGroup = new STGroupFile(templateFile, AnonCommon.DELIMITER, AnonCommon.DELIMITER);
        int threadPoolSize = Integer.valueOf(resourceMap.get(AnonCommon.THREADPOOL_SIZE).toString());
        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
        try {
            File queriesFile = new File(AnonCommon.OUTPUT_QUERY_FILE);
            boolean mkdirs = queriesFile.mkdirs();
            boolean delete = queriesFile.delete();
            LOGGER.info(AnonCommon.QUERY_FILE_DELETED + delete);
            if (delete || !queriesFile.exists()) {
                boolean newFile = queriesFile.createNewFile();
                LOGGER.info(AnonCommon.QUERY_FILE_CREATED + newFile);
            }
            for (String nonAnonTableName : tablesList) {
                    String anonTableName = nonAnonTableName + resourceMap.get(AnonCommon.SUFFIX).toString();
                    anonTableName = anonTableName.split("\\.")[1];
                    anonTableName = resourceMap.get(AnonCommon.DESTINATION_DATABASE).toString() + "." + anonTableName;
                    String describeQuery = templateGroup.getInstanceOf(AnonCommon.DESCRIBE_TABLE)
                            .add(AnonCommon.NON_ANON_TABLENAME, nonAnonTableName).render();
                    LOGGER.info(describeQuery);
                    List<HashMap<String, Object>> describeResult = utils.executeQuery(hiveDataSource, describeQuery);
                    List<String> totalColumns = describeResult.stream()
                            .map(m -> m.get(AnonCommon.COL_NAME))
                            .map(String::valueOf)
                            .collect(Collectors.toList());
                    String dropQuery = templateGroup.getInstanceOf(AnonCommon.DROP_ANONTABLE)
                            .add(AnonCommon.ANON_TABLENAME, anonTableName)
                            .render();
                    String createQuery = templateGroup.getInstanceOf(AnonCommon.CREATE_ANONTABLE)
                            .add(AnonCommon.DESCRIBE_RESULT, describeResult)
                            .add(AnonCommon.ANON_TABLENAME, anonTableName).render();
                    utils.dropCreateTable(dropQuery, createQuery, hiveDataSource);
                    LOGGER.info(AnonCommon.DROP_CREATE_ANONTABLE + anonTableName);
                    AnonRunnable anonRunnable = new AnonRunnable(resourceMap,
                            hiveDataSource,
                            postgresDataSource,
                            anonTableName,
                            nonAnonTableName,
                            totalColumns);
//                    anonRunnable.run();
                    executorService.execute(anonRunnable);
            }
        } catch (Exception e) {
            LOGGER.error("", e);
        } finally {
            executorService.shutdown();
            try {
                executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                LOGGER.error("", e);
            }
        }
    }


    private void closeDB() {
        try {
            if (hiveDataSource != null && !(hiveDataSource.isClosed())) {
                hiveDataSource.close();
                hiveKerberosConnectionManager.shutdownHikariDatasource();
                LOGGER.info(AnonCommon.HIVE_DB_POOL_CLOSED);
            }
        } catch (Exception e) {
            LOGGER.error("", e);
        }
        try {
            if (postgresDataSource != null && !(postgresDataSource.isClosed())) {
                postgresDataSource.close();
                postgresConnectionManager.shutdownHikariDatasource();
                LOGGER.info(AnonCommon.POSTGRES_DB_POOL_CLOSED);
            }
        } catch (Exception e) {
            LOGGER.error("", e);
        }
    }


    private void initDB() throws Exception {
        String postgresFilePath = resourceMap.get(AnonCommon.POSTGRES).toString();
        HashMap<String, Object> postgresConfig = utils.readJsonToHashMap(postgresFilePath);
        postgresConnectionManager = new JDBCConnectionManager();
        postgresConnectionManager.configureHikariDataSource(postgresConfig);
        postgresDataSource = postgresConnectionManager.getHikariDataSource();
        LOGGER.info(AnonCommon.POSTGRES_DB_POOL_CONFIGURED);

        String hiveFilePath = resourceMap.get(AnonCommon.HIVE).toString();
        HashMap<String, Object> hiveConfig = utils.readJsonToHashMap(hiveFilePath);
        hiveKerberosConnectionManager = new HiveKerberosConnectionManager();
        hiveKerberosConnectionManager.configureHikariDataSource(hiveConfig);
        hiveDataSource = hiveKerberosConnectionManager.getHikariDataSource();
        LOGGER.info(AnonCommon.HIVE_DB_POOL_CONFIGURED);
    }
}
