package com.modak.rd.deidentification_cdh;

public class AnonCommon {
    public static final String THREADPOOL_SIZE = "thread_pool_size";
    public static final String TEMPLATE_FILE = "template_file";
    public static final String ANON_TABLENAME = "anon_tablename";
    public static final String NON_ANON_TABLENAME = "non_anon_tablename";
    public static final String TOTAL_COLUMNS = "total_columns";
    public static final String COLUMN_NAME = "column_name";

    public static final String VALUE_BASED_ANON = "value_based_anon";
    public static final String ANON_QUERY = "anon_query";
    public static final String VALUE_BASED_COLUMNS_DATA = "value_based_columns_data";
    public static final String NON_VALUE_BASED_COLUMNS_DATA = "non_value_based_columns_data";
    public static final String VALUE_BASED_REPORT_FOR_COLUMN = "value_based_report_for_column";
    public static final String DELETE_ANON_PROFILE = "delete_anon_profile";
    public static final String INSERT_ANON_PROFILE = "insert_anon_profile";
    public static final String DELETE_ANON_REPORT = "delete_anon_report";
    public static final String INSERT_ANON_REPORT = "insert_anon_report";
    public static final String SELECT_ANON_REPORT = "select_anon_report";
    public static final String DROP_ANONTABLE = "drop_anon_table";
    public static final String CREATE_ANONTABLE = "create_anon_table";

    public static final String DESTINATION_DATABASE = "destination_database";
    public static final String DESCRIBE_TABLE = "describe_table";
    public static final String COL_NAME = "col_name";
    public static final String DESCRIBE_RESULT = "describe_result";
    public static final String POSTGRES = "postgres";
    public static final String HIVE = "hive";
    public static final String DATASTORE_NAME = "datastore_name";
    public static final String SUFFIX = "anon_suffix";
    public static final String IDENTIFIER = "identifier_value";
    public static final String OUTPUT_QUERY_FILE = "output/queries.sql";
    public static final Character DELIMITER = '$';

    public static final String POSTGRES_DB_POOL_CONFIGURED = "POSTGRES DB POOL CONFIGURED";
    public static final String HIVE_DB_POOL_CONFIGURED = "HIVE DB POOL CONFIGURED";
    public static final String HIVE_DB_POOL_CLOSED = "HIVE DB POOL CLOSED";
    public static final String POSTGRES_DB_POOL_CLOSED = "POSTGRES DB POOL CLOSED";
    public static final String DROP_CREATE_ANONTABLE = "drop created anon table: ";
    public static final String QUERY_FILE_DELETED = "queries file deleted: ";
    public static final String QUERY_FILE_CREATED = "queries file created: ";
    public static final String TOTAL_TABLES = "Total tables given: ";
    public static final String ANON_PROFILING_STARTED = "ANON PROFILING STARTED";
    public static final String JOB_COMPLETED = "JOB COMPLETED";
    public static final String DELETED_ANON_PROFILE_RECORDS = "deleted anon profile records for ";
    public static final String INSERTED_ANON_PROFILE_RECORDS = "inserted anon profile records for ";
    public static final String DELETED_ANON_REPORT = "DELETED ANON REPORT: ";
    public static final String INSERTED_ANON_REPORT = "INSERTED ANON REPORT: ";
    public static final String ANON_DATA = "ANON DATA PRODUCED: ";

}
