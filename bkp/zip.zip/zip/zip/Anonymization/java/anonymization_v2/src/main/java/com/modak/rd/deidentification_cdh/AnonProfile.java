package com.modak.rd.deidentification_cdh;

import com.modak.utils.JDBCConnectionManager;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;

import java.util.HashMap;
import java.util.List;

public class AnonProfile {
    private static final Logger LOGGER = LogManager.getLogger(AnonProfile.class.getSimpleName());
    private final List<String> tablesList;
    private HikariDataSource postgresDataSource;
    private JDBCConnectionManager postgresConnectionManager;
    private final HashMap<String, Object> resourceMap;
    private final Utils utils = new Utils();

    public AnonProfile(List<String> tablesList, HashMap<String, Object> resourceMap) {
        this.tablesList = tablesList;
        this.resourceMap = resourceMap;
    }

    public void profile() {
        try {
            initDB();
            process();
        } catch (Exception e) {
            LOGGER.error("", e);
        } finally {
            closeDB();
        }
    }

    private void closeDB() {
        try {
            if (postgresDataSource != null && !(postgresDataSource.isClosed())) {
                postgresDataSource.close();
                postgresConnectionManager.shutdownHikariDatasource();
                LOGGER.info(AnonCommon.POSTGRES_DB_POOL_CLOSED);
            }
        } catch (Exception e) {
            LOGGER.error("", e);
        }
    }

    private void process() {
        String templateFile = resourceMap.get(AnonCommon.TEMPLATE_FILE).toString();
        String datastore_name = resourceMap.get(AnonCommon.DATASTORE_NAME).toString();
        STGroup templateGroup = new STGroupFile(templateFile, AnonCommon.DELIMITER, AnonCommon.DELIMITER);
        for (String nonAnonTableName : tablesList) {
            String deleteAnonProfileQuery = templateGroup.getInstanceOf(AnonCommon.DELETE_ANON_PROFILE)
                    .add(AnonCommon.NON_ANON_TABLENAME, nonAnonTableName)
                    .add(AnonCommon.IDENTIFIER, null)
                    .render();
            String anonProfileQuery = templateGroup.getInstanceOf(AnonCommon.INSERT_ANON_PROFILE)
                    .add(AnonCommon.NON_ANON_TABLENAME, nonAnonTableName)
                    .add(AnonCommon.IDENTIFIER, null)
                    .add(AnonCommon.DATASTORE_NAME, datastore_name)
                    .render();
            LOGGER.info(anonProfileQuery);
            try {
                utils.executeUpdateQuery(postgresDataSource, deleteAnonProfileQuery);
                LOGGER.info(AnonCommon.DELETED_ANON_PROFILE_RECORDS + nonAnonTableName);
                utils.executeUpdateQuery(postgresDataSource, anonProfileQuery);
                LOGGER.info(AnonCommon.INSERTED_ANON_PROFILE_RECORDS + nonAnonTableName);
            } catch (Exception e) {
                LOGGER.error("", e);
            }
        }
    }

    private void initDB() throws Exception {
        String postgresFilePath = resourceMap.get(AnonCommon.POSTGRES).toString();
        HashMap<String, Object> postgresConfig = utils.readJsonToHashMap(postgresFilePath);
        postgresConnectionManager = new JDBCConnectionManager();
        postgresConnectionManager.configureHikariDataSource(postgresConfig);
        postgresDataSource = postgresConnectionManager.getHikariDataSource();
        LOGGER.info(AnonCommon.POSTGRES_DB_POOL_CONFIGURED);
    }
}
