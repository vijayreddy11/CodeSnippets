package com.modak.utils;

import org.apache.logging.log4j.LogManager;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroupFile;
import org.stringtemplate.v4.StringRenderer;

import java.util.HashMap;

/**
 * This class is used to render the templates
 */
public class StringTemplateUtils {

    private static final org.apache.logging.log4j.Logger logger = LogManager.getLogger("StringTemplateUtils");

    private StringTemplateUtils() {
        //Private Constructor
    }

    /**
     * This method returns the string after rendering the template
     *
     * @param templateGroupName To which group the template belongs to
     * @param templateName      The name that is to be used in the template
     * @param attributeName     The attribute to which the data needs to be sent
     * @param inputMap          The data to be sent
     * @return returns string after rendering the template
     */
    public static String renderTemplate(String templateGroupName, String templateName, String attributeName, Object inputMap) {
//        String templateServiceResponseString = null;
//
//        HashMap<String, Object> STMapResponse = JSONUtils.jsonToMap(templateServiceResponseString);

        STGroupFile stfile = new STGroupFile(templateGroupName, '$', '$');
        stfile.registerRenderer(String.class, new StringRenderer());
        ST temp = null;
        if (!templateName.isEmpty() && templateName != null) {
            temp = stfile.getInstanceOf(templateName);
        } else {
            logger.error("Template name provided is empty");
        }
        if (temp == null) {
            throw new NullPointerException("Template " + templateName + " is not defined in " + stfile.getFileName());
        }
        temp.add(attributeName, inputMap);
        String retval = temp.render();
        return retval;
    }

    /**
     * This method returns the string after rendering the template
     *
     * @param templateGroupName To which group the template belongs to
     * @param templateName      The name that is to be used in the template
     * @param templateInputs    The data to be sent for the required template name
     * @return returns string after rendering the template
     */
    public static String renderTemplate(String templateGroupName, String templateName, HashMap<String, Object> templateInputs) {
        STGroupFile stfile = new STGroupFile(templateGroupName, '$', '$');
        stfile.registerRenderer(String.class, new StringRenderer());
        ST temp = null;
        if (!templateName.isEmpty() && templateName != null) {
            temp = stfile.getInstanceOf(templateName);
        } else {
            logger.error("Template name provided is empty");
        }
        if (temp == null) {
            throw new NullPointerException("Template " + templateName + " is not defined in " + stfile.getFileName());
        }
        for (String attributeName : templateInputs.keySet()) {
            temp.add(attributeName, templateInputs.get(attributeName));
        }
        String retval = temp.render();
        return retval;
    }


}
