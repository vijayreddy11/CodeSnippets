package com.modak.utils;

import com.modak.utils.JSONUtils;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.security.UserGroupInformation;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Utils {

    private static final Logger LOGGER = LogManager.getLogger(Utils.class.getSimpleName());

    public Connection getHiveConnection() throws Exception {
        Connection connection = null;
        Configuration conf = new Configuration();
        conf.set("hadoop.security.authentication", "kerberos");
        UserGroupInformation.setConfiguration(conf);
        String principal = "srv_modak_service_account@CDPDEVEN.ACX5-VCQK.CLOUDERA.SITE";
        String jdbcUrl = "jdbc:hive2://devdatahub1-master0.cdpdeven.acx5-vcqk.cloudera.site:2181/default;httpPath=cliservice;principal=hive/_HOST@CDPDEVEN.ACX5-VCQK.CLOUDERA.SITE;serviceDiscoveryMode=zooKeeper;ssl=true;sslTrustStore=./configs/client_truststore.jks;trustStorePassword=4xvsWr8dAB;transportMode=http;zooKeeperNamespace=hiveserver2";
        UserGroupInformation.loginUserFromKeytab(principal, "configs/srv_modak_service_account.keytab");
        Class.forName("org.apache.hive.jdbc.HiveDriver");
        connection = DriverManager.getConnection(jdbcUrl);
        if (connection == null) {
            throw new Exception("null connection");
        }
        return connection;
    }

    /**
     * Converts Json file to HashMap of String key and object value
     *
     * @param filepath String Json filepath
     * @return HashMap converted Json
     */
    public HashMap<String, Object> readJsonToHashMap(String filepath) {
        HashMap<String, Object> stringObjectHashMap = new HashMap<>();
        try {
            File file = new File(filepath);
            if (file.exists()) {
                stringObjectHashMap = JSONUtils.jsonToMap(
                        FileUtils.readFileToString(file, StandardCharsets.UTF_8));
            }
            else {
                LOGGER.error("File not found: " + filepath);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return stringObjectHashMap;
    }

    public void executeUpdateQuery(HikariDataSource dataSource, String sql) throws Exception {
        if (dataSource == null) {
            throw new NullPointerException("Null dataSource");
        }
        else {
            Connection conn = dataSource.getConnection();
            executeUpdateQuery(conn, sql);
        }
    }


    public void executeUpdateQuery(Connection conn, String sql) throws Exception {
        if (conn == null) {
            throw new NullPointerException("Null connection");
        }
        else if (sql == null) {
            close(conn);
            throw new NullPointerException("Null SQL statement");
        }
        else {
            Statement stmt = null;

            try {
                stmt = conn.createStatement();
                stmt.execute(sql);
                close(stmt);
                close(conn);
            }
            catch (Exception var7) {
                throw new Exception("Failed to execute query : " + var7.getMessage());
            }
            finally {
                close(stmt);
                close(conn);
            }

        }
    }


    public List<HashMap<String, Object>> executeQuery(HikariDataSource dataSource, String sql) throws Exception {
        if (dataSource == null) {
            throw new NullPointerException("Null dataSource");
        }
        else {
            Connection conn = dataSource.getConnection();
            return executeQuery(conn, sql);
        }
    }

    public List<HashMap<String, Object>> executeQuery(Connection conn, String sql) throws Exception {
        if (conn == null) {
            throw new NullPointerException("Null connection");
        }
        else if (sql == null) {
            close(conn);
            throw new NullPointerException("Null SQL statement");
        }
        else {
            List<HashMap<String, Object>> listOfResult = new ArrayList<>();
            ResultSet rs = null;
            Statement stmt = null;

            try {
                stmt = conn.createStatement();
                rs = stmt.executeQuery(sql);
                if (rs != null) {
                    int columnCount = rs.getMetaData().getColumnCount();
                    int counter = 0;
                    while (true) {
                        if (!rs.next()) {
                            close(rs);
                            close(stmt);
                            close(conn);
                            break;
                        }
                        HashMap<String, Object> resultSet = new HashMap<>();
                        for (int i = 0; i < columnCount; ++i) {
                            resultSet.put(rs.getMetaData().getColumnLabel(i + 1).toLowerCase(), rs.getObject(i + 1));
                        }
                        if (++counter == 1000000) {
                            LOGGER.info("read 1 million rows");
                            counter = 0;
                        }

                        listOfResult.add(resultSet);
                    }
                }
            }
            catch (Exception var11) {
                var11.printStackTrace();
                throw new Exception("Failed to  : " + var11.getMessage());
            }
            finally {
                close(rs);
                close(stmt);
                close(conn);
            }

            return listOfResult;
        }
    }

    public void close(Connection conn) {
        try {
            if (conn != null) {
                conn.close();
            }
        }
        catch (SQLException e) {
            LOGGER.error("", e);

        }

    }

    public void close(ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
        }
        catch (SQLException e) {
            LOGGER.error("", e);
        }

    }

    public void close(Statement stmt) {
        try {
            if (stmt != null) {
                stmt.close();
            }
        }
        catch (SQLException e) {
            LOGGER.error("", e);
        }

    }

    public void dropCreateTable(String dropQuery, String createQuery,
                                HikariDataSource hikariDataSource) throws Exception {
        try {
            executeUpdateQuery(hikariDataSource, dropQuery);
            executeUpdateQuery(hikariDataSource, createQuery);
        }
        catch (Exception e) {
            LOGGER.error("Failed drop creating anon table", e);
            throw new Exception("Table creation failure");
        }
    }
}
