import com.modak.utils.encryption.RSAEncryptionUtils;

public class Encrypt {
    public static void main(String[] args) throws Exception {
        RSAEncryptionUtils rsa = new RSAEncryptionUtils();
//        RSAEncryptionUtils.generateRSAKeys("src/main/resources/keypair");
        String publicKeyPath = "src/main/resources/keypair/publicKey";
        String privateKeyPath = "src/main/resources/keypair/privateKey";
        String password = "kPS9rhtMFtev";
        String encryptedPassword = RSAEncryptionUtils.encryptPassword(password, publicKeyPath);
        String decryptedPassword = RSAEncryptionUtils.decryptPassword(encryptedPassword, privateKeyPath);
        System.out.println("password given: "+ password);
        System.out.println("encrypted password: "+ encryptedPassword);
        System.out.println("decrypted password: "+ decryptedPassword);
    }
}
