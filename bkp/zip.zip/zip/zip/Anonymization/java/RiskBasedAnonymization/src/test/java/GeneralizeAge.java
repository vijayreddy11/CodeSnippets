public class GeneralizeAge {
    public static void main(String[] args) {
        GeneralizeAge gen = new GeneralizeAge();
        String range = gen.evaluate(1, 2);
        System.out.println("range: "+ range );

    }
    public String evaluate(int number, int offset){
        int upper = number;
        int lower = 0;
        int  remainder = number% offset;
        if(remainder !=0){
            upper = number + (offset -remainder);
            lower = upper -offset;
        }
        else {
            if(number!= offset){
                upper = upper + offset;
                lower = upper - offset;
            }
        }

        return Integer.toString(lower) + "-" + Integer.toString(upper);
    }
}
