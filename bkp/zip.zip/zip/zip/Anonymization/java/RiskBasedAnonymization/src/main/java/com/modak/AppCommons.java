package com.modak;

public class AppCommons {
    public static final String TEMPLATE_FILE = "template";

    public static final String HIVE = "hive_config";
    public static final String THREAD = "thread_count";
    public static final String INPUT_TABLE = "table";

    public static final String QUASI_IDENTIFIERS = "Quasi Identifiers";
    public static final String INPUT_MAP_IS_NULL = "provided input map is null";
    public static final String KEY_IS_NULL = "provided key is null";
    public static final String EXP_NULL_OR_EMPTY_VALUE = "null or empty key value";
    public static final String COLUMNS = "columns";
    public static final String SEPERATOR = "=====================================================================================";
}
