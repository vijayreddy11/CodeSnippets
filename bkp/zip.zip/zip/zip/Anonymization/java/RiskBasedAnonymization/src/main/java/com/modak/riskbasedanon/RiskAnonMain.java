package com.modak.riskbasedanon;

import com.modak.AppCommons;
import com.modak.hive.HiveKerberosConnectionManager;
import com.modak.utils.Utils;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.STGroupFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RiskAnonMain {
    private static final Logger LOGGER = LogManager.getLogger(RiskAnonMain.class.getSimpleName());
    private final HashMap<String, Object> inputConfig;
    STGroupFile stGroup;
    private HiveKerberosConnectionManager hiveKerberosConnectionManager;
    //    private final JDBCConnectionManager jdbcConnectionManager = new JDBCConnectionManager();
    private HikariDataSource hiveDataSource = null;

    public RiskAnonMain(HashMap<String, Object> inputConfig) {
        this.inputConfig = inputConfig;
    }


    public void initDB() throws Exception {
        try {
            File hiveConfigFile = new File(inputConfig.get(AppCommons.HIVE).toString());
//        jdbcConnectionManager.configureHikariDataSource(hiveConfigFile);
//        hiveDataSource = jdbcConnectionManager.getHikariDataSource();
            hiveKerberosConnectionManager = new HiveKerberosConnectionManager();
            hiveKerberosConnectionManager.configureHikariDataSource(hiveConfigFile);
            hiveDataSource = hiveKerberosConnectionManager.getHikariDataSource();
            System.out.println("\n");
            LOGGER.info("hive connection pool configured");
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception();
        }
    }


    public void process() throws Exception {
        stGroup = new STGroupFile(inputConfig.get(AppCommons.TEMPLATE_FILE).toString(), '$', '$');
        Utils utils = new Utils();
        int threadCount = Integer.parseInt(inputConfig.getOrDefault(AppCommons.THREAD, "1").toString());
        List<String> tablesList = parseInputTables();
        ExecutorService executorService = Executors.newFixedThreadPool(threadCount);
        LOGGER.info("input table count: " + tablesList.size());

        try {
            for (String inputNonAnonTableName : tablesList) {
                String describeQuery = stGroup.getInstanceOf("describeTable")
                        .add("table_name", inputNonAnonTableName).render();
                LOGGER.info("input table name: " + inputNonAnonTableName);
                List<HashMap<String, Object>> describeResult = utils.executeQuery(hiveDataSource, describeQuery);
                List<String> columnsList = describeResult.stream().map(m -> m.get("col_name").toString()).collect(Collectors.toList());
                executorService.execute(new RiskAnonRun(hiveDataSource, inputNonAnonTableName, columnsList, inputConfig));
//                RiskAnonRun riskAnonRun = new RiskAnonRun(hiveDataSource, inputNonAnonTableName, columnsList, inputConfig);
//                riskAnonRun.run();
            }
        } catch (Exception e) {
            e.printStackTrace();
            try {
                executorService.shutdown();
                executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
        } finally {
            try {
                executorService.shutdown();
                executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        LOGGER.info("process completed");
    }

    public List<String> parseInputTables() {
        Stream<String> fileStream = null;
        List<String> tablesList = new ArrayList<>();
        String inputFilePath = inputConfig.get(AppCommons.INPUT_TABLE).toString();
        LOGGER.info("parsing input file: " + inputFilePath);
        try {
            fileStream = Files.lines(Paths.get(inputFilePath));
            tablesList = fileStream.map(String::valueOf)
//                    .map(line -> Arrays.asList(line.split("\\t")))
//                    .peek(LOGGER::info)
//                    .filter(l -> l.size() > 0)
//                    .map(arrayList -> arrayList.get(1))
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.toList());
        } catch (IOException e) {
            LOGGER.error("Failed reading input tables file", e);
        } finally {
            if (fileStream != null) {
                fileStream.close();
            }
        }
        return tablesList;
    }

    public void close() throws Exception {
        try {
            if (hiveDataSource.getConnection() != null && !(hiveDataSource.isClosed())) {
                hiveDataSource.close();
                LOGGER.info("hive connection closed");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
