package com.modak.riskbasedanon;

import com.modak.AppCommons;
import com.modak.utils.MapUtils;
import com.modak.utils.Utils;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroupFile;

import java.sql.Connection;
import java.util.*;

public class RiskAnonRun implements Runnable {
    private final Logger logger = LogManager.getLogger(RiskAnonRun.class.getSimpleName());
    private final HikariDataSource hiveDataSource;
    private final String tableName;
    private final List<String> columnsList;
    private final HashMap<String, Object> inputConfig;
    private final STGroupFile stGroup;
    private final Utils utils;
    private Double threshold;
    Map<String, String> quasiMap = new HashMap<String, String>();
    private String total_row_count;

    public RiskAnonRun(HikariDataSource hiveDataSource, String tableName, List<String> columnsList, HashMap<String, Object> inputConfig) {
        this.hiveDataSource = hiveDataSource;
        this.tableName = tableName;
        this.columnsList = columnsList;
        this.inputConfig = inputConfig;
        utils = new Utils();
        stGroup = new STGroupFile(inputConfig.get("template").toString(), '$', '$');
    }

    @Override
    public void run() {
        try {
            threshold = (Double) inputConfig.get("threshold");
            logger.info("threshold: " + threshold);
            Map<String, Object> quasiIdentifiersMap = MapUtils.getMap(inputConfig, AppCommons.QUASI_IDENTIFIERS);
//            logger.info("detecting quasi-identifiers in table: "+ tableName);
            for (String column : columnsList) {
                for (Map.Entry<String, Object> entry : quasiIdentifiersMap.entrySet()) {
                    String quasiIdentifier = entry.getKey();
                    HashMap<String, Object> quasiIdentifierMap = (HashMap<String, Object>) entry.getValue();
                    ArrayList quasiIdentifierColumnsList = null;
                    quasiIdentifierColumnsList = MapUtils.getArrayList(quasiIdentifierMap, AppCommons.COLUMNS);
                    if (quasiIdentifierColumnsList.contains(column) && !(quasiMap.containsKey(column))) {
                        quasiMap.put(quasiIdentifier, column);
                    }
                }
            }
            if (quasiMap.size() > 0) {
                logger.info("quasi-identifiers detected " + tableName + ": " + quasiMap.values());
                riskAnonymization();
            } else {
                logger.error("NO QUASI-IDENTIFIERS DETECTED IN " + tableName);
                logger.error("skipping Risk Based Anonymization");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void riskAnonymization() throws Exception {
        int level = 1;
        String prevRiskTableName = null;
        Object generalizeLevels = inputConfig.get("Risk Anonymization Levels");
        String destination_db = inputConfig.get("destination_db").toString();

        for (Object levelObj : (List) generalizeLevels) {
            HashMap<String, Object> displayInfoMap = new LinkedHashMap<>();
            displayInfoMap.put("level", level);
            if (prevRiskTableName == null) {
                displayInfoMap.put("table_name", tableName);
            } else {
                displayInfoMap.put("table_name", prevRiskTableName);
            }

            Map levelMap = (Map) levelObj;
            String riskTableName = stGroup.getInstanceOf("risk_table_name")
                    .add("destination_db", destination_db)
                    .add("table_name", tableName.replaceAll(".*\\.(.*)", "$1"))
                    .add("level", level).render();

            logger.info(AppCommons.SEPERATOR);

            HashMap<String, Object> riskMeasureRiskMap = checkRisk(level == 1 ? tableName : prevRiskTableName);
            HashMap<String, Object> scoreMap = new LinkedHashMap<>();

//            displayInfoMap.put("unique_row_count", riskMeasureRiskMap.get("unique_row_count").toString());
//            displayInfoMap.put("total_row_count", riskMeasureRiskMap.get("total_row_count").toString());

            Double compoundDisclosureRisk = (Double) riskMeasureRiskMap.get("compound_disclousure_risk");
            if (compoundDisclosureRisk > threshold) logger.warn("Compound Disclosure Risk  >  threshold");
            scoreMap.put("compound_disclosure_risk", compoundDisclosureRisk);
            scoreMap.put("threshold", threshold);
            prettyPrintMap(scoreMap);

            displayInfoMap.put("compound_disclosure_risk", compoundDisclosureRisk);
            displayInfoMap.put("threshold", threshold);

            logger.info("Calculating number of equivalence classes at Risk...");
            HashMap<String, Object> classMap = new LinkedHashMap<>();
            classMap.put("num_equi_max_risk", riskMeasureRiskMap.get("num_equi_max_risk").toString());
            classMap.put("num_equi_classes", riskMeasureRiskMap.get("num_equi_classes").toString());
            prettyPrintMap(classMap);

//            displayInfoMap.put("num_equi_max_risk", riskMeasureRiskMap.get("num_equi_max_risk").toString());
//            displayInfoMap.put("num_equi_classes", riskMeasureRiskMap.get("num_equi_classes").toString());

            logger.info("Calculating Unique Rows...");
            String uniqueRows = stGroup.getInstanceOf("uniqueRows")
                    .add("table_name", tableName)
                    .add("quasi_map", quasiMap).render();
            List<HashMap<String, Object>> uniqueRowsResult = utils.executeQuery(hiveDataSource, uniqueRows);
            HashMap<String, Object> uniqueRowsResultMap = uniqueRowsResult.get(0);
            HashMap<String, Object> rowMap = new LinkedHashMap<>();

            rowMap.put("unique_row_counts", uniqueRowsResultMap.get("unique_rows").toString());
            total_row_count = riskMeasureRiskMap.get("total_count").toString();
            rowMap.put("total_row_count", riskMeasureRiskMap.get("total_count").toString());
            prettyPrintMap(rowMap);

//            displayInfoMap.put("unique_row_counts",uniqueRowsResultMap.get("unique_rows").toString());
//            displayInfoMap.put("total_row_count", riskMeasureRiskMap.get("total_count").toString());


            boolean riskBool = false;
            if (compoundDisclosureRisk > threshold) {
                riskBool = true;
            }
            if (!riskBool) {
                logger.info("Risk free Anonymized table created at level :" + (level - 1));
                logger.info("table name: " + prevRiskTableName);
                break;
            }
            logger.info("Applying Generalization Rules");
            HashMap<String, Object> ruleMap = new LinkedHashMap<>();

//            logger.info("Generalization at level: " + level + ", applying " + levelMap.get("templates") +
//                    ", identifiers: " + levelMap.get(AppCommons.QUASI_IDENTIFIERS));
            ruleMap.put("Generalization Rule Applied", levelMap.get("templates"));
//            displayInfoMap.put("generalization rule applied", levelMap.get("templates"));

            if (prevRiskTableName != null) {
                ST dropRiskTableST = stGroup.getInstanceOf("drop_risk_table")
                        .add("table_name", prevRiskTableName);
                String dropRiskTableQuery = dropRiskTableST.render();
                utils.executeUpdateQuery(hiveDataSource, dropRiskTableQuery);

            }
            List<String> columnsWithoutGroupingColumns = new ArrayList<String>();
            columnsWithoutGroupingColumns.addAll(columnsList);
            boolean skipLevel = false;
            for (String quasiIdentifier : (List<String>) levelMap.get(AppCommons.QUASI_IDENTIFIERS)) {
                columnsWithoutGroupingColumns.remove(quasiMap.get(quasiIdentifier));
                if (!quasiMap.containsKey(quasiIdentifier)) {
                    skipLevel = true;
                }
            }
            if (!skipLevel) {
                ST dropRiskTableST = stGroup.getInstanceOf("drop_risk_table").add("table_name", riskTableName);
                String dropRiskTableQuery = dropRiskTableST.render();
                utils.executeUpdateQuery(hiveDataSource, dropRiskTableQuery);
//                helper.updateQuery(dropRiskTableST.render(), hiveDataSouce);
                ST createRiskTable = stGroup.getInstanceOf("create_risk_table");
                createRiskTable.add("risk_table_name", riskTableName);
                createRiskTable.add("table_name", tableName);
                createRiskTable.add("columns", columnsWithoutGroupingColumns);
                createRiskTable.add("quasi_map", quasiMap);
                createRiskTable.add("templates", levelMap.get("templates"));
                String createRiskTableQuery = createRiskTable.render();
                ruleMap.put("Risk-Free Anon Table Name", riskTableName);
//                displayInfoMap.put("risk-free Anon Table Name", riskTableName);
                prettyPrintMap(ruleMap);
//                prettyPrintMap(displayInfoMap);

                logger.info("Creating Risk Free Anon Table...");
                utils.executeUpdateQuery(hiveDataSource, createRiskTableQuery);
                logger.info("Risk table created : " + riskTableName);

                prevRiskTableName = riskTableName;
            }

            level++;
        }
        if (level != 1) {
            logger.info(AppCommons.SEPERATOR);
            HashMap<String, Object> resultMap = new LinkedHashMap<>();
            logger.info("Calculating Unique Rows...");
            String uniqueRows = stGroup.getInstanceOf("uniqueRows")
                    .add("table_name", prevRiskTableName)
                    .add("quasi_map", quasiMap).render();
            List<HashMap<String, Object>> uniqueRowsResult = utils.executeQuery(hiveDataSource, uniqueRows);
            resultMap.put("unique_row_count", uniqueRowsResult.get(0).get("unique_rows").toString());
            resultMap.put("total_row_count", total_row_count);
            logger.info("Calculating Compound Disclosure Risk... ");
            String compoundDisclosureRisk = stGroup.getInstanceOf("risk_measure_query")
                    .add("table_name", prevRiskTableName)
                    .add("quasi_map", quasiMap)
                    .add("threshold", threshold).render();
            List<HashMap<String, Object>> compoundDisclosureRiskResult = utils.executeQuery(hiveDataSource, compoundDisclosureRisk);
            HashMap<String, Object> cdrMap = compoundDisclosureRiskResult.get(0);
            String cdr = cdrMap.get("compound_disclousure_risk").toString();
            if (Double.parseDouble(cdr) < threshold) {
                logger.info("Compound Disclosure Risk  <  threshold");
            }
            resultMap.put("num_equi_max_risk", cdrMap.get("num_equi_max_risk").toString());
            resultMap.put("num_equi_classes", cdrMap.get("num_equi_classes").toString());
            resultMap.put("Final Compound Disclosure Risk", cdr);
            resultMap.put("Risk Free Table Name", prevRiskTableName);
            prettyPrintMap(resultMap);
        }

    }

    private void prettyPrintMap(HashMap<String, Object> map) {
        logger.info("{");
        for (String key : map.keySet()) {
            logger.info(" " + key + " : " + map.get(key));
        }
        logger.info("}");
        logger.info("");
    }


    private HashMap<String, Object> checkRisk(String tableName) throws Exception {

        String riskMeasureQuery = stGroup.getInstanceOf("risk_measure_query")
                .add("table_name", tableName)
                .add("quasi_map", quasiMap)
                .add("threshold", threshold).render();

//        String uniqueRows = stGroup.getInstanceOf("uniqueRows")
//                .add("table_name", tableName)
//                .add("quasi_map", quasiMap).render();

        logger.info("Calculating Compound Disclosure Risk...");
//
        List<HashMap<String, Object>> measureMapList = utils.executeQuery(hiveDataSource, riskMeasureQuery);
        return measureMapList.get(0);

    }
}
