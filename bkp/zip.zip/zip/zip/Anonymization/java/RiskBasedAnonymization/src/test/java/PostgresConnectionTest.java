import com.modak.hive.HiveKerberosConnectionManager;
import com.modak.utils.JDBCConnectionManager;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;

import java.io.File;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

public class PostgresConnectionTest {
    private static JDBCConnectionManager jdbcConnectionManager= new JDBCConnectionManager();

    public static void main(String[] args) throws Exception {
        File postgresCon = new File("src/main/resources/postgres.json");
        jdbcConnectionManager.configureHikariDataSource(postgresCon);
        HikariDataSource postgresDataSource = jdbcConnectionManager.getHikariDataSource();
        if (postgresDataSource != null){
            System.out.println("connection pool configured ");
        }
        else {
            System.out.println("connection not configured: "+ postgresDataSource);
        }
        Connection connection = postgresDataSource.getConnection();
        System.out.println(connection);
        String query = "select * from de_identification.table_anon_profile limit 100";
        QueryRunner queryRunner = new QueryRunner();
        List<Map<String, Object>> result = queryRunner.query(connection, query, new MapListHandler());
        System.out.println(result);
        connection.close();
    }
}
