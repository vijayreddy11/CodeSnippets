package com.modak;


import com.modak.riskbasedanon.RiskAnonMain;
import com.modak.utils.Utils;
import org.apache.commons.cli.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

public class App {
    private static Logger LOGGER = LogManager.getLogger(App.class.getSimpleName());

    public static void main(String[] args) {
        Options options = new Options();
        options.addOption("h", "help", false, "show help");
        options.addOption("c", "config", true, "input configuration path");
        options.addOption("i", "input", true, "input tables path");
//        options.addOption("p", "process", true, "process name");
        CommandLineParser commandLineParser = new DefaultParser();
        App app = new App();
        Utils utils2 = new Utils();
//        Helper helper = new Helper();
        try {
            CommandLine commandLine = commandLineParser.parse(options, args);
            if (commandLine.hasOption("h")) {
                HelpFormatter helpFormatter = new HelpFormatter();
                helpFormatter.printHelp("help string", options);
                System.exit(0);
            }
            if (commandLine.hasOption("i")) {
                String inputTablesPath = commandLine.getOptionValue("i");
                Path tablesPath = Paths.get(inputTablesPath);
                if (Files.isReadable(tablesPath)) {
                    if (commandLine.hasOption("c")) {
                        String inputConfigPath = commandLine.getOptionValue("c");
                        Path path = Paths.get(inputConfigPath);
                        if (Files.isReadable(path)) {
                            HashMap<String, Object> inputConfig = utils2.readJsonToHashMap(inputConfigPath);
                            inputConfig.put(AppCommons.INPUT_TABLE, inputTablesPath);
                            Path templatePath = Paths.get(inputConfig.get("template").toString());
                            if (Files.isReadable(templatePath)) {
                                app.start(inputConfig);
                            } else {
                                LOGGER.error("template file doesn't exist or is not accessible");
                            }

                        } else {
                            LOGGER.error("input config doesn't exist or is not accessible");
                        }
                    } else {
                        LOGGER.error("input tables path doesn't exist, given path: " + inputTablesPath);
                    }
                }


            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void start(HashMap<String, Object> inputConfig) {
        boolean processFinished = false;
        try {
            RiskAnonMain riskAnonMain = new RiskAnonMain(inputConfig);
            riskAnonMain.initDB();
            riskAnonMain.process();
            riskAnonMain.close();
            processFinished = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
