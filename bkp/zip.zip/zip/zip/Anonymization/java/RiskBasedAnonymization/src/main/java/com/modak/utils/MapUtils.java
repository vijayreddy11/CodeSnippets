package com.modak.utils;


import com.modak.AppCommons;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.postgresql.util.PGobject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * At Modak, we use HashMap instead of POJO. This allows us to extend the structure of POJO class without actually modifying the class definition.
 * This HashMap can have multiple levels of other Maps and Lists to store other POJOs.
 * e.g. Instead of creating a class Person, we can use HashMap to store its attributes (e.g. Name, Age, Gender)
 * Other complex attributes like Addresses, PhoneNumbers etc can be stored as HashMap with the same name.
 * <p>
 * This class provides utility methods to set/get the attributes from HashMap using multilevel key. E.g Address.HouseNumber
 * Created by Saisandeep Neeli on 01/22/2018.
 */
public class MapUtils {
    
    private MapUtils() {
        //Private Constructor
    }

    private static final Logger logger = LogManager.getLogger(MapUtils.class.getName());

    /**
     * The key can be a multilevel key e.g. "data.address".
     *
     * @param sourceMap
     * @param key
     * @return the HashMap based on a key. Null if the element is not found or is not of the type HashMap
     */
    public static HashMap<String, Object> getMap(HashMap<String, Object> sourceMap, String key) {
        if (sourceMap == null) {
            logger.warn(AppCommons.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(AppCommons.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof HashMap) {

            return (HashMap<String, Object>) sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.tags".
     *
     * @param sourceMap
     * @param key
     * @return the ArrayList based on a key. Null if the element is not found or is not of the type ArrayList
     */
    public static ArrayList getArrayList(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(AppCommons.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(AppCommons.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof ArrayList) {

            return (ArrayList) sourceMap.get(parts[i]);

        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.name".
     *
     * @param sourceMap
     * @param key
     * @return the String based on a key. Null if the element is not found or is not of the type String
     */
    public static String getString(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(AppCommons.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(AppCommons.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof String) {

            return (String) sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.age".
     *
     * @param sourceMap
     * @param key
     * @return the String based on a key. Null if the element is not found or is not of the type Integer
     */
    public static Integer getInteger(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(AppCommons.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(AppCommons.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }

        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof Integer) {

            return (Integer) sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.income".
     *
     * @param sourceMap
     * @param key
     * @return the String based on a key. Null if the element is not found or is not of the type Long
     */
    public static Long getLong(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(AppCommons.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(AppCommons.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (!sourceMap.containsKey(parts[i])) {
            logger.error("Unable to find key " + parts[i] + " in provided input map " + sourceMap);
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof Long) {

            return (Long) sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.fetch".
     *
     * @param sourceMap
     * @param key
     * @return the String based on a key. Null if the element is not found or is not of the type Boolean
     */
    public static Boolean getBoolean(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(AppCommons.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(AppCommons.KEY_IS_NULL);
            return null;

        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof Boolean) {
            return (Boolean) sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.phone".
     *
     * @param sourceMap
     * @param key
     * @return the Object based on a key. Null if the element is not found
     */
    public static Object get(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(AppCommons.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(AppCommons.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null) {
            return sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.id".
     *
     * @param sourceMap
     * @param key
     * @param value
     * @return the Object based on a key. Null if the element is not found
     */
    public static void put(HashMap<String, Object> sourceMap, String key, Object value) throws Exception {
        if (sourceMap == null) {
            logger.warn(AppCommons.INPUT_MAP_IS_NULL);

        }
        if (key == null) {
            logger.warn(AppCommons.KEY_IS_NULL);
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap != null) {
            sourceMap.put(parts[i], value);
        } else {
            logger.warn("Parent maps not found");
        }
    }

    public static HashMap pgObjectToMap(HashMap<String, Object> sourceMap) {
        HashMap retMap = new HashMap();
        for (Map.Entry<String, Object> entry : sourceMap.entrySet()) {
            Object object = entry.getValue();
            if (object instanceof PGobject) {
                PGobject pGobject = (PGobject) object;
                object = JSONUtils.jsonToObject(pGobject.toString());

            }
            retMap.put(entry.getKey(), object);
        }
        return retMap;
    }


    public static String getNonEmptyString(HashMap<String, Object> sourceMap, String key) throws Exception {
        String val = getString(sourceMap, key);
        if (StringUtils.isBlank(val)) {
            throw new Exception(AppCommons.EXP_NULL_OR_EMPTY_VALUE + key);
        }
        return val;
    }

    /**
     * The key can be a multilevel key e.g. "data.age".
     *
     * @param sourceMap
     * @param key
     * @return the String based on a key. Null if the element is not found or is not of the type Integer
     */
    public static Integer getInteger(HashMap<String, Object> sourceMap, String key, int default_value) throws Exception {
        if (sourceMap == null) {
            logger.warn(AppCommons.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(AppCommons.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof Integer) {

            return (Integer) sourceMap.get(parts[i]);
        }
        return default_value;
    }
}
