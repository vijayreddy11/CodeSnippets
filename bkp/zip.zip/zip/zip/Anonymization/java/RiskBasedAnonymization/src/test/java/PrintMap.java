import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class PrintMap {
    public static void main(String[] args) {
        HashMap<String, String> result = new LinkedHashMap<>();
        result.put("name", "rahul");
        result.put("country", "India");
        result.put("nationality", "Indian");
        result.put("language", "Hindi");
        result.put("age","23");

        STGroup stGroup =  new STGroupFile("src/main/resources/risk_based_anon.stg" , '$', '$');
        String prettyPrint = stGroup.getInstanceOf("pretty").add("map", result).render();
        System.out.println(prettyPrint);
    }
}
