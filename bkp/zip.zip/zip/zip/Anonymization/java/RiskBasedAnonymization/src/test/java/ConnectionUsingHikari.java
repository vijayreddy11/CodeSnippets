import com.modak.hive.HiveKerberosConnectionManager;
import com.modak.utils.Helper;
import com.modak.utils.JDBCConnectionManager;
import com.zaxxer.hikari.HikariDataSource;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.FileHandler;

public class ConnectionUsingHikari {
    private static Helper helper;
//    private static HiveKerberosConnectionManager hiveKerberosConnectionManager = new HiveKerberosConnectionManager();
    private static HikariDataSource hiveDataSource= null;
    private static JDBCConnectionManager jdbcConnectionManager = new JDBCConnectionManager();


    public static void main(String[] args) throws Exception {
        helper = new Helper();
        String inputConfigPath = "src/main/resources/input_config.json";
        HashMap<String, Object> inputConfig = helper.readJsonToHashMap(inputConfigPath);
        File hiveConfigFile = new File(inputConfig.get("hive_config").toString());

        jdbcConnectionManager.configureHikariDataSource(hiveConfigFile);
        hiveDataSource = jdbcConnectionManager.getHikariDataSource();

        String query = "show tables in clinical_trial";
        List<Map<String, Object>> result = helper.executeQuery(query, hiveDataSource);
        System.out.println(result);
    }
}

