package com.modak;

public interface AnonApp {

    public void initDB() throws Exception;
    public void process() throws Exception;
    public void close() throws Exception;
}
