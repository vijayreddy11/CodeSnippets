package com.modak.utils;

import com.modak.AppCommons;
import com.modak.utils.JSONUtils;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.management.ManagementFactory;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.modak.utils.DBUtils.executeUpdateQuery;

public class Helper {
    private  static final Logger LOGGER = LogManager.getLogger(Helper.class.getSimpleName());
//    private static final org.apache.logging.log4j.Logger LOGGER = org.apache.logging.log4j.LogManager.getLogger(
//            Helper.class.getSimpleName());


    /**
     * Executes SELECT DML statement and returns the resultset
     *
     * @param query            String SQL query
     * @param hikariDataSource HikariDataSource object
     * @return resultset of the SQL query
     */
    public List<Map<String, Object>> executeQuery(String query, HikariDataSource hikariDataSource) {
        List<Map<String, Object>> mapList = new ArrayList<>();
        Connection connection = null;
        QueryRunner queryRunner = new QueryRunner();
        try {
            connection = hikariDataSource.getConnection();
            mapList = queryRunner.query(connection, query, new MapListHandler());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null && !(connection.isClosed())) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return mapList;
    }

    public List<Map<String, Object>> executeQueryWithStatement(String query, HikariDataSource hikariDataSource) {
        List<Map<String, Object>> mapList = new ArrayList<>();
        Connection connection = null;
        Statement statement = null;
        ResultSet resultset = null;
        ResultSetMetaData resultSetMetaData;
        try {
            connection = hikariDataSource.getConnection();
            statement = connection.createStatement();
            resultset = statement.executeQuery(query);
            resultSetMetaData = resultset.getMetaData();
            mapList = resultSetToArrayList(resultset, resultSetMetaData);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (statement != null && !(statement.isClosed())) {
                    statement.close();
                }
                if (resultset != null && !(resultset.isClosed())) {
                    resultset.close();
                }
                if (connection != null && !(connection.isClosed())) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return mapList;
    }

    private List<Map<String, Object>> resultSetToArrayList(ResultSet resultset, ResultSetMetaData resultSetMetaData) throws Exception {
        int count = 0;
        int totalCount = 0;
        List<Map<String, Object>> mapList = new ArrayList<>();
        while (resultset.next()) {
            Map<String, Object> map = new HashMap<>();
            for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
                map.put(resultSetMetaData.getColumnName(i), resultset.getObject(i));
            }
            if (count == 1000000) {
                totalCount = totalCount + count;
                LOGGER.info("Rows read " + totalCount);
                count = 0;
            }
            count++;
            mapList.add(map);
        }
        return mapList;
    }

    public static HashMap<String, Object> getMap(HashMap<String, Object> sourceMap, String key) {
        if (sourceMap == null) {
            LOGGER.warn(AppCommons.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            LOGGER.warn(AppCommons.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof HashMap) {

            return (HashMap<String, Object>) sourceMap.get(parts[i]);
        }
        return null;
    }

    public static ArrayList getArrayList(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            LOGGER.warn(AppCommons.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            LOGGER.warn(AppCommons.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof ArrayList) {

            return (ArrayList) sourceMap.get(parts[i]);

        }
        return null;
    }

    /**
     * Executes the DML statements i.e., UPDATE, INSERT, DROP, DELETE and returns the status
     *
     * @param query            String SQL query
     * @param hikariDataSource HikariDataSource object
     * @return true if update successful else false
     */
    public boolean updateQuery(String query, HikariDataSource hikariDataSource) {
        Connection connection = null;
        boolean updated = false;
        try {
            QueryRunner queryRunner = new QueryRunner();
            connection = hikariDataSource.getConnection();
            queryRunner.update(connection, query);
            updated = true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null && !(connection.isClosed())) {
                    connection.close();
                }
            } catch (SQLException e) {
                LOGGER.error("", e);
            }
        }
        return updated;
    }

    public boolean dropCreateTable(String dropQuery, String createQuery,
                                   HikariDataSource hikariDataSource) {
        Helper helper = new Helper();
        boolean dropCreated = false;
        try {
            boolean dropped = helper.updateQuery(dropQuery, hikariDataSource);
            if (dropped) {
                boolean created = helper.updateQuery(createQuery, hikariDataSource);
                if (created) {
                    dropCreated = true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dropCreated;
    }

    /**
     * Converts Json file to HashMap of String key and object value
     *
     * @param filepath String Json filepath
     * @return HashMap converted Json
     */
    public HashMap<String, Object> readJsonToHashMap(String filepath) {
        HashMap<String, Object> stringObjectHashMap = new HashMap<>();
        try {
            File file = new File(filepath);
            if (file.exists()) {
                stringObjectHashMap = JSONUtils.jsonToMap(
                        FileUtils.readFileToString(file, StandardCharsets.UTF_8));
            } else {
                LOGGER.error("File not found: " + filepath);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return stringObjectHashMap;
    }



    public void jobException(Exception e, HashMap<String, Object> processConfig,
                             HikariDataSource postgresDataSource) throws Exception {
        String templateFile = processConfig.get(AppCommons.TEMPLATE_FILE).toString();
        long pid = (long) processConfig.get("pid");
        STGroup stGroup = new STGroupFile(templateFile, '$', '$');
        String insertQuery = stGroup.getInstanceOf("pipeline_job_error")
                .add("pid", pid)
                .add("error_message", e.toString())
                .add("job_user", processConfig.get("jobUser").toString()).render();
        executeUpdateQuery(postgresDataSource, insertQuery);
    }

    public void  jobOutput(String jobName, STGroup stGroup, String processInput, String processOutput,
                           String validationStatus,String start_ts, String end_ts,
                           HikariDataSource postgresDataSource) throws Exception{
        String vmName = ManagementFactory.getRuntimeMXBean().getName();
        int p = vmName.indexOf("@");
        String pid = vmName.substring(0, p);
        String jobUser = System.getProperty("user.name");
        String insertQuery = stGroup.getInstanceOf("pipeline_job_output")
                .add("pid",pid)
                .add("job_name", jobName)
                .add("job_user", jobUser)
                .add("process_input", processInput)
                .add("process_output", processOutput)
                .add("validation_status", validationStatus)
                .add("start_ts", start_ts)
                .add("end_ts", end_ts).render();
        updateQuery(insertQuery, postgresDataSource);
    }

    public void updateJobTracker(String status, String jobName,STGroup stGroup,
                                 HikariDataSource postgresDataSource) throws Exception {
        String vmName = ManagementFactory.getRuntimeMXBean().getName();
        int p = vmName.indexOf("@");
        String pid = vmName.substring(0, p);
        String userName = System.getProperty("user.name");
        String insertQuery = stGroup.getInstanceOf("pipeline_job_tracker")
                .add("pid", pid)
                .add("job_name", jobName)
                .add("job_status", status)
                .add("job_user", userName).render();
        executeUpdateQuery(postgresDataSource, insertQuery);
    }

    public void jobException(Exception e, String job_name,STGroup stGroup,
                             HikariDataSource postgresDataSource) {
        try {
            String vmName = ManagementFactory.getRuntimeMXBean().getName();
            StringWriter exceptionWriter = new StringWriter();
            e.printStackTrace(new PrintWriter(exceptionWriter));
            String exceptionString = exceptionWriter.toString();
            int p = vmName.indexOf("@");
            String pid = vmName.substring(0, p);
            String userName = System.getProperty("user.name");
            String insertQuery = stGroup.getInstanceOf("pipeline_exception_tracker")
                    .add("pid", pid)
                    .add("job_name", job_name)
                    .add("error_message", exceptionString)
                    .add("job_user", userName).render();
            executeUpdateQuery(postgresDataSource, insertQuery);
        }
        catch (Exception e1) {
            LOGGER.error("", e1);
        }
    }


    public void jobError(String errorMessage,String job_name,STGroup stGroup, HikariDataSource postgresFndDataSource) {
            try {
                String vmName = ManagementFactory.getRuntimeMXBean().getName();
                int p = vmName.indexOf("@");
                String pid = vmName.substring(0, p);
                String userName = System.getProperty("user.name");
                String insertQuery = stGroup.getInstanceOf("pipeline_exception_tracker")
                        .add("pid", pid)
                        .add("job_name", job_name)
                        .add("error_message", errorMessage)
                        .add("job_user", userName).render();
                executeUpdateQuery(postgresFndDataSource, insertQuery);
            } catch (Exception e1) {
                LOGGER.error("", e1);
            }
    }
}
