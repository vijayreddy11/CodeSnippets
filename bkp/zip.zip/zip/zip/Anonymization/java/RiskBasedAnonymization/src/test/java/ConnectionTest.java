import com.modak.utils.JSONUtils;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.HashMap;

public class ConnectionTest {
    public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException {
        String configPath = "src/main/resources/input_config.json";
        HashMap<String, Object> inputConfig = JSONUtils.jsonToMap(FileUtils.readFileToString(new File(configPath)));
        HashMap<String, Object> hiveConfig = (HashMap<String, Object>) inputConfig.get("hive");
        String driver = hiveConfig.get("jdbc_driver").toString();
        String jdbc_url = hiveConfig.get("jdbc_url").toString();
        String user = hiveConfig.get("username").toString();
        String password = hiveConfig.get("password").toString();
        Class.forName(driver);
        Connection connection = DriverManager.getConnection(jdbc_url, user, password);
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("show tables in clinical_trial");
        while (resultSet.next()) {
            System.out.println(resultSet.getString(1));
        }
        resultSet.close();
        statement.close();
        connection.close();

        if (!connection.isClosed() || connection != null) {
            System.out.println("connection not closed");
            connection.close();
            if (connection.isClosed()){
                System.out.println("now it is closed");
            }
        } else {
            System.out.println("connection closed");
        }

    }

}