class Rules:
    def delete_profile(self, table_name):
        return "DELETE FROM de_identification.table_anon_profile WHERE table_name = '{}'".format(table_name)
    def insert_profile(self, table_name, datastore_name):
        return """
        INSERT INTO de_identification.table_anon_profile (table_name, table_id, column_name, column_id, ordinal_position, detected_anon_func, detected_reason, date_format)
        WITH PROFILE_INFO AS (
        SELECT   table_name,
                LOWER(column_name) AS column_name,
                date_format,
                ordinal_position,
                column_datatype,
                has_date,
                non_null_count,
                cp.num_of_spaces,
                distinct_count,
                table_id,
                column_id,
                datastore_id,
                dataplace_id
        from nabu.column_profile cp
        where 1=1
        and table_name = '{0}'
        and valid_to_ts = '9999-12-31'
        and datastore_id in (
        select datastore_id
        from nabu.datastore_physical
        where 1=1
        and datastore_name = '{1}')
        )
        , COLUMN_FREQUENCY as (
        SELECT   table_name,
                column_name,
                top_column_value
        FROM     nabu.column_frequency
        WHERE    1=1
        and table_id in (select distinct table_id from profile_info)
        --ignoring null values
        and top_column_value is not null
        and valid_to_ts = '9999-12-31'
        )

        ,SKEWDATE_COL_MAPPER_STEP1 AS (
        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy-MM-dd' AS date_format
        FROM    COLUMN_FREQUENCY
        GROUP BY table_name, column_name
        HAVING   SUM(CASE WHEN top_column_value ~ '^\d{{4}}-\d{{2}}-\d{{2}}$' THEN 1 ELSE 0 END) > 0 and column_name !~*'qval$|tsval$'

        union

        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy/MM/dd' AS date_format
        FROM    COLUMN_FREQUENCY
        GROUP BY table_name, column_name
        HAVING   SUM(CASE WHEN top_column_value ~ '^\d{{4}}/\d{{2}}/\d{{2}}$' THEN 1 ELSE 0 END) > 0

        union

        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'MM/dd/yyyy' AS date_format
        FROM    COLUMN_FREQUENCY
        GROUP BY table_name, column_name
        HAVING   SUM(CASE WHEN top_column_value ~ '^\d{{1,2}}/\d{{1,2}}/\d{{4}}$' THEN 1 ELSE 0 END) > 0

        union

        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy-MM-dd HH:mm:ss' AS date_format
        FROM    COLUMN_FREQUENCY
        GROUP BY table_name, column_name
        HAVING   SUM(CASE WHEN top_column_value ~ '^\d{{4}}-\d{{2}}-\d{{2}} \d{{2}}:\d{{2}}:\d{{1,3}}$' THEN 1 ELSE 0 END) > 0

        union

        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy-MM-dd''T''HH:mm:ss' AS date_format
        FROM    COLUMN_FREQUENCY
        GROUP BY table_name, column_name
        HAVING   SUM(CASE WHEN top_column_value ~ '^\d{{4}}-\d{{2}}-\d{{2}}''T''\d{{2}}:\d{{2}}:\d{{1,3}}$' THEN 1 ELSE 0 END) > 0

        union

        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy-MM-ddTHH:mm:ss' AS date_format
        FROM    COLUMN_FREQUENCY
        GROUP BY table_name, column_name
        HAVING   SUM(CASE WHEN top_column_value ~ '^\d{{4}}-\d{{2}}-\d{{2}}T\d{{2}}:\d{{2}}:\d{{1,3}}$' THEN 1 ELSE 0 END) > 0

        union

        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy-MM-ddTHH:mm' AS date_format
        FROM    COLUMN_FREQUENCY
        GROUP BY table_name, column_name
        HAVING   SUM(CASE WHEN top_column_value ~ '^\d{{4}}-\d{{2}}-\d{{2}}T\d{{2}}:\d{{2}}$' THEN 1 ELSE 0 END) > 0

        union

        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy-MM-dd HH:mm' AS date_format
        FROM    COLUMN_FREQUENCY
        GROUP BY table_name, column_name
        HAVING   SUM(CASE WHEN top_column_value ~ '^\d{{4}}-\d{{2}}-\d{{2}} \d{{2}}:\d{{2}}$' THEN 1 ELSE 0 END) > 0

        union

        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy-MM-dd''T''HH:mm' AS date_format
        FROM    COLUMN_FREQUENCY
        GROUP BY table_name, column_name
        HAVING   SUM(CASE WHEN top_column_value ~ '^\d{{4}}-\d{{2}}-\d{{2}}''T''\d{{2}}:\d{{2}}$' THEN 1 ELSE 0 END) > 0

        union

        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy-MM-dd HH:mm:ss.SSS' AS date_format
        FROM    COLUMN_FREQUENCY
        GROUP BY table_name, column_name
        HAVING   SUM(CASE WHEN top_column_value ~ '^\d{{4}}-\d{{2}}-\d{{2}} \d{{2}}:\d{{2}}:\d{{1,3}}\.\d+$' THEN 1 ELSE 0 END) > 0

        -- for yyyyMMdd format
        union
        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyyMMdd' AS date_format
        FROM    COLUMN_FREQUENCY
        where is_date(top_column_value) = 8 and column_name ~*'DTC$|DT(\d)*|DATE$|TPT$'
        GROUP BY table_name, column_name

        union
        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyyMM' AS date_format
        FROM    COLUMN_FREQUENCY
        where is_date(top_column_value) = 6 and column_name ~*'DTC$|DT(\d)*|DATE$|TPT$'
        GROUP BY table_name, column_name

        union
        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy' AS date_format
        FROM    COLUMN_FREQUENCY
        where is_date(top_column_value) = 4 and column_name ~*'DTC$|DT(\d)*|DATE$|TPT$'
        GROUP BY table_name, column_name

        union
        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy-MM' AS date_format
        FROM    COLUMN_FREQUENCY
        where is_date(top_column_value) = 71 and column_name ~*'DTC$|DT(\d)*|DATE$|TPT$'
        GROUP BY table_name, column_name

        union
        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                'yyyy/MM' AS date_format
        FROM    COLUMN_FREQUENCY
        where is_date(top_column_value) = 72 and column_name ~*'DTC$|DT(\d)*|DATE$|TPT$'
        GROUP BY table_name, column_name

        union

        SELECT   table_name,
                column_name,
                'SkewDate'::text AS anon_func,
                'DateAndTimestamp'::text AS reason,
                date_format
        FROM     PROFILE_INFO
        WHERE    has_date = TRUE
        )
        , SKEWDATE_COL_MAPPER AS (
        select table_name,
        column_name,
        anon_func,
        case when array_length(date_formats ,1)>1 then 'MultipleDateAndTimestamp' else reason end as reason,
        cast(date_formats as text) as date_format
        FROM
        (select table_name,column_name, anon_func,reason,array_remove(array_agg(date_format) ,NULL) as date_formats
        from SKEWDATE_COL_MAPPER_STEP1
        group by table_name,column_name, anon_func,reason)t
        )
        ,FREETEXT_COL_MAPPER AS (
        SELECT   table_name,
                column_name,
                'Redact'::text AS anon_func,
                'PossibleFreeText'::text AS reason
        FROM     PROFILE_INFO
        WHERE    non_null_count > 0
        AND      num_of_spaces IS NOT NULL
        AND      distinct_count*1.0/non_null_count > .1
        AND      num_of_spaces*2.0/non_null_count > 1
        AND      distinct_count > 4
        AND      column_name !~* 'LLT$|HLT$|^VISIT$'

        UNION

        SELECT   table_name,
                column_name,
                'Redact'::text AS anon_func,
                'PossibleFreeText'::text AS reason
        FROM     PROFILE_INFO
        WHERE    non_null_count > 0
        AND      num_of_spaces IS NOT NULL
        AND      num_of_spaces*2.0/non_null_count > 2.9
        AND      distinct_count > 200
        AND      column_name !~* 'LLT$|HLT$|^VISIT$'
        )
        ,age as (
        SELECT table_name,
                column_name,
                'Age'::text AS anon_func,
                'Use Age for age column'::text AS reason
        FROM     PROFILE_INFO
        WHERE    ((column_name = 'age' and column_datatype = 'INTEGER') OR (column_name ~*'lbage$|lbagehi$|lbagelo$|agec$') or (column_name ~*'age$' and column_name !~* 'dhstage$|gasage$'))
        )
        ,sdtm_ig as(
        SELECT table_name,
                column_name,
                'FPEAlphaNumeric' as anon_func,
                'Recode ID variable'::text AS reason
        FROM PROFILE_INFO
        WHERE column_name ~*'SPID$|REFID$|IDVARVAL$|INVSITE$|STDYSITE$'

        UNION

        SELECT table_name,
                column_name,
                'Redact' as anon_func,
                'PossibleFreeText --> As per PhUSE SDTM 3.2 rules'::text AS reason
        FROM PROFILE_INFO
        WHERE column_name ~*'REASND$|ACNOTH$|ACNDEV$|INDC$|DOSTXT$|REASEX$|DOSRGM$|ADJ$|SPDEVID$|TRT$|PARTY$|PRTYID$|XFN$|NAM$|LOT$|INVID$|BRTHDT|BRTDT|SVUPDES$|AEMODIFY$|TERM(\d)*$|AERELNST$|DSRSOTH$|DSOTH$|CMTRTS$|f_name$|l_name$|invnamo$'
		
        UNION

        SELECT table_name,
                column_name,
                'Keep' as anon_func,
                'As per PhUSE SDTM 3.2 rules'::text AS reason
        FROM PROFILE_INFO
        WHERE column_name ~*'HLT$|HLTCD$|HLGT$|HLGTCD$|CAT$|BODSYS$|BDSYCD$|SOC$|SOCCD$|OUT$|SCAN$|SCONG$|SDISAB$|SDTH$|SHOSP$|SLIFE$|SMIE$|TOXGR$|STRESC$|STRESN$|EVAL$|SCAT$|EVALID$|DTHREL$|DY$|STDY$|ENDY$|DUR$|ELTM$|STINT$|ENINT$|DETECT$|EVLINT$|EVINTX$'
        )
        ,entity_matches as (
        select pi.*,  etm.entity_id, ep.entity_name, te.tag_label_id ,
        case when etm.entity_id is not null then 'Keep' end as anon_func,
        'Detected Entity "' || entity_name || '"' as reason
        from profile_info pi
        left outer join
        (select distinct entity_id,column_id
        from nabu_data_catalog.entity_table_matches
        where valid_to_ts = '9999-12-31'
        and (
        entity_rule_id in (select entity_rule_id from nabu_data_catalog.entity_fingerprint_rule_physical where valid_to_ts = '9999-12-31')
        or
        entity_rule_id in (select entity_rule_id from nabu_data_catalog.entity_metadata_rule_physical where valid_to_ts = '9999-12-31')
        )
        ) etm
        on pi.column_id  = etm.column_id
        left outer join
        (select entity_id,entity_name
        from nabu_data_catalog.entity_physical
        where valid_to_ts = '9999-12-31'
        and datastore_id in (
        select datastore_id
        from nabu.datastore_physical
        where 1=1
        and datastore_name = '{1}')
        ) ep
        on etm.entity_id  = ep.entity_id
        left outer join (select * from nabu_ui.tag_entity where valid_to_ts = '9999-12-31 00:00:00' ) te
        on etm.entity_id = te.entity_id
        )

        ,entity_matches1 as (
        select x.table_name,
        lower(x.column_name) AS column_name,
        x.date_format,
        x.ordinal_position,
        x.has_date,
        x.non_null_count,
        x.num_of_spaces,
        x.distinct_count,
        x.table_id,
        x.column_id,
        x.datastore_id,
        x.dataplace_id,
        tul.tag_label_name ,x.tag_label_id , tul.tag_category_id,
        case when tbr.tag_label_id is not null then tbr.anon_func end as anon_func,
        case when tbr.tag_label_id is not null then 'Detected Entity with tag ' || tul.tag_label_name || ' "' || entity_name || '"' end as reason
        from entity_matches x
        left outer join nabu_ui.tag_user_labels tul
        on x.tag_label_id = tul.tag_label_id
        left outer join de_identification.tag_based_rules tbr
        on x.entity_id = tbr.entity_facet_id
		and tbr.type = 'Entity'
        )

        ,facet_matches as (
        select em.*,  ftm.facet_id, fp.facet_name, tf.tag_label_id,
        case when ftm.facet_id is not null then 'Keep' end as anon_func,
        'Detected Facet "' || facet_name || '"' as reason
        from profile_info em
        left outer join (
        select distinct facet_id,column_id
        from nabu_data_catalog.facet_table_matches
        where valid_to_ts = '9999-12-31'
        and (
        facet_rule_id in (select facet_rule_id from nabu_data_catalog.facet_fingerprint_rule_physical where valid_to_ts = '9999-12-31')
        or
        facet_rule_id in (select facet_rule_id from nabu_data_catalog.facet_metadata_rule_physical where valid_to_ts = '9999-12-31')
        )
        ) ftm
        on em.column_id  = ftm.column_id
        left outer join
        (select facet_id,facet_name
        from nabu_data_catalog.facet
        where valid_to_ts = '9999-12-31'
        and datastore_id in (
        select datastore_id
        from nabu.datastore_physical
        where 1=1
        and datastore_name = '{1}')
        ) fp
        on ftm.facet_id  = fp.facet_id
        left outer join (select * from nabu_ui.tag_facet where valid_to_ts = '9999-12-31 00:00:00' ) tf
        on ftm.facet_id = tf.facet_id
        )
        ,facet_matches1 as (
        select x.table_name,
        LOWER(x.column_name) AS column_name,
        x.date_format,
        x.ordinal_position,
        x.has_date,
        x.non_null_count,
        x.num_of_spaces,
        x.distinct_count,
        x.table_id,
        x.column_id,
        x.datastore_id,
        x.dataplace_id,  tul.tag_label_name ,x.tag_label_id , tul.tag_category_id,
        case when tbr.tag_label_id is not null then tbr.anon_func end as anon_func,
        case when tbr.tag_label_id is not null then 'Detected Facet with tag ' || tul.tag_label_name || ' "'|| facet_name || '"' end as reason
        from facet_matches x
        left outer join nabu_ui.tag_user_labels tul
        on x.tag_label_id = tul.tag_label_id
        left outer join de_identification.tag_based_rules tbr
        on x.facet_id = tbr.entity_facet_id
		and tbr.type = 'Facet'
        )
        SELECT table_name,
                table_id,
            column_name,
                column_id,
            ordinal_position,
            detected_anon_func,
            detected_reason,
            date_format
            FROM   (SELECT   pi.table_name,
                        pi.table_id,
                        pi.column_id,
                        pi.column_name,
                        pi.ordinal_position,
                        COALESCE(em1.anon_func,fm1.anon_func,em.anon_func,fm.anon_func,ig.anon_func,skcm.anon_func,fcm.anon_func,ag.anon_func,'Keep')  AS detected_anon_func,
                        COALESCE(em1.reason,fm1.reason,em.reason,fm.reason,ig.reason,skcm.reason,fcm.reason,ag.reason) AS detected_reason,
                        skcm.date_format
                FROM     PROFILE_INFO pi
                        LEFT OUTER JOIN SKEWDATE_COL_MAPPER AS skcm
                            ON pi.column_name = skcm.column_name
                        LEFT OUTER JOIN FREETEXT_COL_MAPPER AS fcm
                            ON pi.column_name = fcm.column_name
                        LEFT OUTER JOIN age AS ag
                            ON pi.column_name = ag.column_name
                        LEFT OUTER JOIN sdtm_ig AS ig
                            ON pi.column_name = ig.column_name
                        left outer join facet_matches as fm
                            on pi.column_name = fm.column_name
                            and pi.column_id = fm.column_id
                        left outer join entity_matches as em
                            on pi.column_name = em.column_name
                            and pi.column_id = em.column_id
                        left outer join facet_matches1 as fm1
                            on pi.column_name = fm1.column_name
                            and pi.column_id = fm1.column_id
                        left outer join entity_matches1 as em1
                            on pi.column_name = em1.column_name
                            and pi.column_id = em1.column_id
                )sq
        ORDER BY table_id, ORDINAL_POSITION""".format(table_name, datastore_name)
    
    def delete_report(self, table_name):
        return "DELETE FROM de_identification.table_anon_report WHERE table_name = '{}'".format(table_name)
    def insert_report(self, table_name, anon_table_name):
        return """
        insert into de_identification.table_anon_report(table_name,table_id, anon_table_name,column_name, column_id,
        ordinal_position,applied_anon_func, applied_reason, date_format, value_based_anon ,value_based_maps, "comments")
        WITH table_anon_profile AS (
        select *,
        '{}' AS anon_table_name
        from de_identification.table_anon_profile
        where table_name = '{}'
        )
        , hardcode_rules as (
        select * from(
        select tap.table_name,
        tap.anon_table_name,
        tap.column_name,
        tap.ordinal_position,
        coalesce(ahr2.anon_func, ahr.anon_func) as anon_func,
        'user hardcoded rule' as reason,
        tap.date_format,
        coalesce(ahr2."comments" , ahr."comments") as "comments"
        from table_anon_profile tap
        left outer join de_identification.anon_hardcoded_rules ahr
        on tap.column_name = ahr.column_name
        left outer join de_identification.anon_hardcoded_rules ahr2
        on tap.column_name = ahr2.column_name
        and tap.table_name = ahr2.table_name
        )hr
        where anon_func is not null
        )
        , value_based_rules as(
        select  distinct table_name,
        column_name,
        detected_anon_func,
        value_based_anon,
        case when value_based_anon = 'Y' then string_agg(
        concat(coalesce (table_name,'NULL'),':',reference_column_name,':',coalesce (reference_column_value,'NULL'),':',anon_func)
        ,';') OVER (PARTITION BY column_name)
        else null end as value_based_maps,
        'user value based rule' as reason,
        "comments"
        FROM (
        select tap.table_name,
        tap.column_name,
        tap.detected_anon_func,
        avbr.anon_func,
        case
        when avbr.table_name is not null and avbr.table_name = tap.table_name and avbr.anon_func is not null then 'Y'
        when avbr.table_name is null and avbr.anon_func is not null then 'Y'
        else 'N' end as value_based_anon,
        avbr.reference_column_name ,
        avbr.reference_column_value,
        avbr."comments"
        FROM table_anon_profile tap
        LEFT OUTER JOIN de_identification.anon_value_based_rules avbr
        on tap.column_name = avbr.column_name
        )vbr
        where value_based_anon = 'Y'
        )

        SELECT tap.table_name,
            tap.table_id,
            tap.anon_table_name,
            tap.column_name,
            tap.column_id,
            tap.ordinal_position,
            coalesce(hr.anon_func,tap.detected_anon_func,'Keep')  as applied_anon_func,
            coalesce(vbr.reason,hr.reason,tap.detected_reason) as applied_reason,
            tap.date_format,
            coalesce(vbr.value_based_anon,'N') as value_based_anon,
            vbr.value_based_maps,
            coalesce(hr."comments",vbr."comments") as "comments"
        from table_anon_profile tap
        left outer join hardcode_rules hr
        on tap.column_name = hr.column_name
        left outer join value_based_rules vbr
        on tap.column_name = vbr.column_name
        order by tap.ordinal_position
        """.format(anon_table_name, table_name)

    def select_report(self,table_name):
        return """WITH REPORT_INFO AS (
            select *
            from de_identification.table_anon_report
            where table_name = '{}'
            )
            SELECT table_name,
            anon_table_name,
            column_name,
            applied_anon_func,
            date_format,
            CASE 
                WHEN (SELECT count(*) as count from REPORT_INFO where column_name ='usubjid')>0 THEN true 
                ELSE false
            END as usubjid_checker,
            value_based_anon
            from REPORT_INFO""".format(table_name)
 
    def value_based_report(self,table_name,column_name):
        return """with value_based_info as (
                            select   distinct table_name,
                                    column_name,
                                    reference_column_name,
                                    reference_column_value,
                                    anon_func,
                                    row_number() over(partition by reference_column_name,reference_column_value order by reviewed_ts) as row_num
                            from     de_identification.anon_value_based_rules avbr
                            where    table_name = '{}'
                            and column_name = '{}'
                        )
                        select * from (
                            select  distinct x.table_name, x.column_name, x.reference_column_name, x.reference_column_value,
                                    y.date_format,
                                    y.applied_anon_func || 'ValueBased' as applied_anon_func,
                                    x.anon_func || 'ValueBased' as override_anon_func
                            from    value_based_info x
                            left outer join de_identification.table_anon_report y
                            on x.column_name = y.column_name
                            and x.table_name = y.table_name
                            and x.row_num = 1
                        ) sq""".format(table_name,column_name)

    def Keep(self, column_name):
        return column_name

    def Redact(self, column_name):
        return """case when `{0}` is null then null 
                        when `{0}` = '-9999' then '-9999'
                        when `{0}` = '#NA#' then '#NA#'
                        when `{0}` = '9999-12-31' then '9999-12-31'
                        when trim(cast(`{0}` as string)) = '' then ''
                else '* Redact *' end as `{0}`""".format(column_name)
        
    def Hash(self, column_name):
        return """case when `{0}` is null then null else sha256hex(`{0}`) end as `{0}`""".format(column_name)

    def FPENumeric(self, column_name):
        return """case when `{0}` is null then null
                        when `{0}` = -9999 then '-9999'
                        when `{0}` = '#NA#' then '#NA#'
			when (`{0}` < 0 and length(cast(`{0}` as string)) < 3) then encrypt_to_token(concat('-0',regexp_replace(`{0}`,'^-','')),83249, 6)
                        when length(cast(`{0}` as string)) < 2 then encrypt_to_token(concat('0',cast(`{0}` as string)),83249,6)
			when length(regexp_replace(`{0}`,'[^A-Za-z0-9]+','')) < 2 then `{0}`
                else encrypt_to_token(cast(`{0}` as string),83249,6) 
            end as `{0}`""".format(column_name)

    def FPEAlphaNumeric(self, column_name):
        return """case when `{0}` is null then null 
                when `{0}` = -9999 then '-9999'
                when `{0}` = '#NA#' then '#NA#'
                when (`{0}` < 0 and length(cast(`{0}` as string)) < 3) then encrypt_to_token(concat('-0',regexp_replace(`{0}`,'^-','')),83249, 0)
                when length(cast(`{0}` as string)) < 2 then encrypt_to_token(concat('0',`{0}`),83249, 0)
                when length(regexp_replace(`{0}`,'[^A-Za-z0-9]+','')) < 2 then `{0}`
            else encrypt_to_token(`{0}`,83249, 0) 
            end as `{0}`""".format(column_name)

    def Age(self, column_name):
        return """case when `{0}` = -9999 then '-9999'
                when `{0}` = '#NA#' then '#NA#'
                when `{0}` > 89 then '90 or above' 
        else (cast(cast({0} as int)-pmod(cast({0} as int) ,10) as int) ||'-'||  cast(cast({0} as int) +10-pmod(cast({0} as int),10) as int))
        end as `{0}`""".format(column_name)
    
    def SkewDate(self, column_name, usubjid_checker):
        if usubjid_checker is True:
            return """case
                when {0} is null then null
                when {0} = '9999-12-31' then '9999-12-31'
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm:ss") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END), "T", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm:ss"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END), " ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"), CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END), "T", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"), CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END), " ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"dd-MMM-yyyy") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"dd-MMM-yyyy"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END)
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END)
                when unix_timestamp(cast({0} as string),"MM/dd/yy") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"MM/dd/yy"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END)
                when unix_timestamp(cast({0} as string),"yyyy/MM/dd") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy/MM/dd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END)
                when unix_timestamp(cast({0} as string),"yyyyMMdd") is not null then from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyyMMdd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END),"yyyy-MM-dd"),"yyyyMMdd")
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss.SSS") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END)," ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss."),'HH:mm:ss.'),split(cast({0} as string),'\\.')[1])
                else cast({0} as string)
            end AS {0}""".format(column_name)
        else:
            return """case
                when {0} is null then null
                when {0} = '9999-12-31' then '9999-12-31'
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm:ss") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),-10), "T", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm:ss"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),-10), " ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"), -10), "T", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),-10), " ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"dd-MMM-yyyy") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"dd-MMM-yyyy"),"yyyy-MM-dd"),-10)
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),-10)
                when unix_timestamp(cast({0} as string),"MM/dd/yy") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"MM/dd/yy"),"yyyy-MM-dd"),-10)
                when unix_timestamp(cast({0} as string),"yyyy/MM/dd") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy/MM/dd"),"yyyy-MM-dd"),-10)
                when unix_timestamp(cast({0} as string),"yyyyMMdd") is not null then from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyyMMdd"),"yyyy-MM-dd"),-10),"yyyy-MM-dd"),"yyyyMMdd")
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss.SSS") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),-10)," ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss."),'HH:mm:ss.'),split(cast({0} as string),'\\.')[1])
                else cast({0} as string)
            end AS {0}""".format(column_name)

    KeepValueBased = Keep

    def RedactValueBased(self, column_name):
        return """(case when `{0}` is null then null
                        when trim(cast(`{0}` as string)) = '' then ''
                        else '* Redact *' end)""".format(column_name)

    def SkewDateValueBased(self, column_name, usubjid_checker):
        if usubjid_checker is True:
            return """( case
                when {0} is null then null
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm:ss") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END), "T", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm:ss"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END), " ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"), CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END), "T", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"), CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END), " ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"dd-MMM-yyyy") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"dd-MMM-yyyy"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END)
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END)
                when unix_timestamp(cast({0} as string),"MM/dd/yy") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"MM/dd/yy"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END)
                when unix_timestamp(cast({0} as string),"yyyy/MM/dd") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy/MM/dd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END)
                when unix_timestamp(cast({0} as string),"yyyyMMdd") is not null then from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyyMMdd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END),"yyyy-MM-dd"),"yyyyMMdd")
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss.SSS") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),CASE WHEN {0} IS NOT NULL THEN CAST(((CASE WHEN fnv_hash(usubjid) < 0 THEN -1 ELSE 1 END)*(ABS(fnv_hash(usubjid)) % 10 + 1)) AS INT) ELSE -10 END)," ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss."),'HH:mm:ss.'),split(cast({0} as string),'\\.')[1])
                else cast({0} as string)
            end )""".format(column_name)
        else:
            return """( case
                when {0} is null then null
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm:ss") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),-10), "T", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm:ss"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),-10), " ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"), -10), "T", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd'T'HH:mm"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),-10), " ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm"),'HH:mm:ss'))
                when unix_timestamp(cast({0} as string),"dd-MMM-yyyy") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"dd-MMM-yyyy"),"yyyy-MM-dd"),-10)
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),-10)
                when unix_timestamp(cast({0} as string),"MM/dd/yy") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"MM/dd/yy"),"yyyy-MM-dd"),-10)
                when unix_timestamp(cast({0} as string),"yyyy/MM/dd") is not null then date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy/MM/dd"),"yyyy-MM-dd"),-10)
                when unix_timestamp(cast({0} as string),"yyyyMMdd") is not null then from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyyMMdd"),"yyyy-MM-dd"),-10),"yyyy-MM-dd"),"yyyyMMdd")
                when unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss.SSS") is not null then concat(date_add(from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd"),"yyyy-MM-dd"),-10)," ", from_unixtime(unix_timestamp(cast({0} as string),"yyyy-MM-dd HH:mm:ss."),'HH:mm:ss.'),split(cast({0} as string),'\\.')[1])
                else cast({0} as string)
            end )""".format(column_name)
         
    def date_validator(self, host, user, password, dbname):
        import psycopg2
        conn = psycopg2.connect(host=host, user=user, password=password, port=5432, dbname=dbname)
        curs = conn.cursor()
        query =  """create or replace function is_date(s varchar) returns int as $$
                begin
                        IF length(s)=8 THEN
                                perform s::date;
                                return 8;
                        ELSIF length(s)=6 THEN
                                perform concat(s,'01')::date;
                                return 6;
                        ELSIF length(s)=4 THEN
                                perform concat(s,'0101')::date;
                                return 4;
                        ELSIF length(s)=7 and s ~*'-' THEN
                                perform concat(s,'-01')::date;
                                return 71;
                        ELSIF length(s)=7 and s ~*'/' THEN
                                perform concat(s,'/01')::date;
                                return 72;
                        ELSE
                                return 0;
                        END IF;
                        
                        exception when others then
                                return 0;
                end;
                $$ language plpgsql"""
        curs.execute(query)
        conn.commit()
        curs.close()
        conn.close()
