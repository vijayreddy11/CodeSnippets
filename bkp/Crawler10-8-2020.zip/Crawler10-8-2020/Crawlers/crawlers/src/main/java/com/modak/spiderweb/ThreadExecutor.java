package com.modak.spiderweb;


import java.util.Map;

public class ThreadExecutor implements Runnable {
    Map value;

    public void init(Map value) {
        this.value = value;
    }

    public void run() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Child Thread "+value);
    }
}
