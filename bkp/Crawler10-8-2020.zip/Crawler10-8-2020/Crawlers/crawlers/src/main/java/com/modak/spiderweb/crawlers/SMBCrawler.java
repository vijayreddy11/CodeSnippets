//package com.modak.spiderweb.crawlers;
//
//import com.hierynomus.msdtyp.AccessMask;
//import com.hierynomus.msfscc.FileAttributes;
//import com.hierynomus.msfscc.fileinformation.FileAllInformation;
//import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
//import com.hierynomus.mssmb2.SMB2CreateDisposition;
//import com.hierynomus.mssmb2.SMB2ShareAccess;
//import com.hierynomus.protocol.commons.EnumWithValue;
//import com.hierynomus.smbj.share.DiskShare;
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.DelimitedFileFormatUtil;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.SemiStructuredUtils;
//import com.modak.utility.TimeStampUtils;
//import com.modak.utility.connector.FileShareConnector;
//import com.modak.utils.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.io.FilenameUtils;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//import java.io.File;
//import java.io.IOException;
//import java.io.InputStream;
//import java.util.*;
//
//public class SMBCrawler extends BaseCrawler {
//    private static final Logger logger = LogManager.getLogger(SMBCrawler.class);
//
//    private DiskShare share;
//    private final int BATCH_SIZE = 1000;
//    private FileShareConnector fileShareConnector;
//    private String path;
//    private String hostName;
//    private List<Object[]> list_of_objects_array = new ArrayList<>();
//    protected SemiStructuredUtils semiStructuredUtils;
//    protected DelimitedFileFormatUtil delimitedFileFormatUtil;
//
//    @Override
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                fileShareConnector = new FileShareConnector();
//                HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes,CrawlerCommon.SOURCE_INFO_DETAILS);
//                String shareName = HashMapUtility.getString(sourceInfo, CrawlerCommon.SHARE_NAME);
//                String domain = HashMapUtility.getString(sourceInfo, CrawlerCommon.DOMAIN);
//                path = HashMapUtility.getString(sourceInfo, CrawlerCommon.PATH);
//                hostName = HashMapUtility.getString(sourceInfo, CrawlerCommon.HOST_NAME);
//                sourceAttributes.put(CrawlerCommon.PATH, path);
//                sourceAttributes.put(CrawlerCommon.DIRECTORY_NAME, shareName);
//                String creds = this.getCredentialsForSource();
//                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
//                String userName = credentials.get(CrawlerCommon.USER_NAME).toString();
//                if (userName == null) {
//                    throw new NullPointerException(CrawlerCommon.USER_NAME + CrawlerCommon.IS_NULL);
//                }
//                String password = credentials.get(CrawlerCommon.PASSWORD).toString();
//                if (password == null) {
//                    throw new NullPointerException(CrawlerCommon.PASSWORD + CrawlerCommon.IS_NULL);
//                }
//                fileShareConnector.initShare(hostName, domain, shareName, userName, password);
//                share = fileShareConnector.getDiskShare();
//                if (share == null) {
//                    throw new NullPointerException(CrawlerCommon.SHARE_IS_NULL + share);
//                }
//                boolean fetchColumnMetadata = HashMapUtility.getBoolean(sourceInfo, CrawlerCommon.FETCH_COLUMN_METADATA);
//                sourceAttributes.put(CrawlerCommon.FETCH_COLUMN_METADATA, fetchColumnMetadata);
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//
//        } catch (Exception e) {
//            try {
//                logger.error(ExceptionUtils.getStackTrace(e));
//                this.insertError(e);
//            } catch (Exception ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        this.getDirectories();
//    }
//
//    @Override
//    public void doCrawling() {
//        String directory = "";
//        directory = path;
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = HashMapUtility.getString(crawlingTemplateMap,CrawlerCommon.TEMPLATE_GROUP);
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = dependentMap.get(CrawlerCommon.QUERY_TYPE).toString();
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                        dataMap.put(templateName, list_of_map);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else {
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_FILEMETADATA)) {
//                            processDirectory(share, directory, query);
//                            if (list_of_objects_array.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                list_of_objects_array.clear();
//                            }
//                        } else {
//                            if (sourceAttributes.containsKey(CrawlerCommon.FETCH_COLUMN_METADATA)) {
//                                if (HashMapUtility.getBoolean(sourceAttributes, CrawlerCommon.FETCH_COLUMN_METADATA)) {
//                                    processColumnMetadata(share, directory, query);
//                                    if (list_of_objects_array.size() > 0) {
//                                        jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                        list_of_objects_array.clear();
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            try {
//                logger.error(ExceptionUtils.getStackTrace(e));
//                insertError(e);
//            } catch (Exception ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//
//    private void processDirectory(DiskShare share, String path, String query) throws Exception {
//        try {
//            for (FileIdBothDirectoryInformation f : share.list(path)) {
//                if (!f.getFileName().startsWith(".")) {
//                    Set<FileAttributes> set = EnumWithValue.EnumUtils
//                            .toEnumSet(f.getFileAttributes(), FileAttributes.class);
//                    String filepath = path.equalsIgnoreCase("") ? f.getFileName() : path + File.separator + f.getFileName();
//                    if (set.contains(FileAttributes.FILE_ATTRIBUTE_DIRECTORY)) {
//                        processDirectory(share, filepath, query);
//                    } else {
//                        Object[] obj = processFile(share, filepath);
//                        if (obj != null) {
//                            list_of_objects_array.add(obj);
//                            if (list_of_objects_array.size() >= BATCH_SIZE) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                list_of_objects_array.clear();
//                            }
//                        }
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    private Object[] processFile(DiskShare share, String path) throws Exception {
//        com.hierynomus.smbj.share.File file = share.openFile(path, EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null);
//        FileAllInformation fileInfo;
//        String source_abs_path;
//        InputStream inputStream = null;
//        try {
//            fileInfo = file.getFileInformation();
//            if (fileInfo != null && fileInfo.getNameInformation() != null) {
//                String[] filename_parts = path.split("/");
//                String filename = filename_parts[filename_parts.length - 1];
//                source_abs_path = CrawlerCommon.SMB_SCHEME + hostName + CrawlerCommon.FILE_SEPARATOR + share.getSmbPath().getShareName() + CrawlerCommon.FILE_SEPARATOR + path.replaceAll("\\\\", "/").replace("//", "/");
//                String fileFormat = FilenameUtils.getExtension(filename);
//                inputStream = fileShareConnector.getFileAsStream(path);
//                String delimiterFileFormat = null;
//                delimitedFileFormatUtil = new DelimitedFileFormatUtil();
//                if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                    delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//                } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                    delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//                }
//                Object obj[] = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        filename,
//                        fileFormat,
//                        source_abs_path,
//                        path,
//                        TimeStampUtils.changeToTimeStamp(fileInfo.getBasicInformation().getLastAccessTime().toEpochMillis()),
//                        false,
//                        fileInfo.getStandardInformation().isDirectory(),
//                        false,
//                        fileInfo.getStandardInformation().getEndOfFile(),
//                        "",
//                        "",
//                        delimiterFileFormat,
//                        null
//                };
//                return obj;
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            file.close();
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            }catch (IOException e){
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//        return null;
//    }
//
//
//    private void processColumnMetadata(DiskShare share, String path, String query) throws Exception {
//        try {
//            for (FileIdBothDirectoryInformation f : share.list(path)) {
//                if (!f.getFileName().startsWith(".")) {
//                    Set<FileAttributes> set = EnumWithValue.EnumUtils
//                            .toEnumSet(f.getFileAttributes(), FileAttributes.class);
//                    String filepath = path.equalsIgnoreCase("") ? f.getFileName() : path + File.separator + f.getFileName();
//                    if (set.contains(FileAttributes.FILE_ATTRIBUTE_DIRECTORY)) {
//                        processColumnMetadata(share, filepath, query);
//                    } else {
//                        processFileColumns(share, filepath, query);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//
//    private void processFileColumns(DiskShare share, String path, String query) throws Exception {
//        InputStream inputStream = null;
//        try (com.hierynomus.smbj.share.File file = share.openFile(path, EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null)) {
//            FileAllInformation fileInfo;
//            String source_abs_path;
//            fileInfo = file.getFileInformation();
//            if (fileInfo != null && fileInfo.getNameInformation() != null) {
//                String[] filename_parts = path.split("/");
//                String filename = filename_parts[filename_parts.length - 1];
//                String fileFormat = FilenameUtils.getExtension(filename);
//                source_abs_path = CrawlerCommon.SMB_SCHEME + hostName + "/" + share.getSmbPath().getShareName() + "/" + path.replaceAll("\\\\", "/").replace("//", "/");
//                semiStructuredUtils = new SemiStructuredUtils();
//                if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                    inputStream = fileShareConnector.getFileAsStream(path);
//                    String delimiterFileFormat;
//                    if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                        delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//                    } else {
//                        delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//                    }
//                    HashMap<String, Object> delimiterFileFormatMap = com.modak.utility.json.JSONUtils.jsonToMap(delimiterFileFormat);
//                    Object header = HashMapUtility.get(delimiterFileFormatMap, CrawlerCommon.HEADER);
//                    if (header.equals(CrawlerCommon.TRUE)) {
//                        list_of_objects_array.addAll(getCSVMetadata(path, filename, source_abs_path, fileFormat));
//                    }
//                } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.AVRO)) {
//                    list_of_objects_array.addAll(getAvroMetadata(path, filename, source_abs_path));
//                }
////                else if (fileFormat.equalsIgnoreCase(CrawlerCommon.PARQUET)) {
////                    list_of_objects_array.addAll(getParquetMetadata(path, filename, source_abs_path));
////                }
//                if (list_of_objects_array.size() >= BATCH_SIZE) {
//                    jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                    list_of_objects_array.clear();
//                }
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//
//    public List<Object[]> getAvroMetadata(String relativePath, String fileName, String absolutePath) throws Exception{
//        InputStream inputStream = null;
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        try {
//            inputStream = fileShareConnector.getFileAsStream(relativePath);
//            List<HashMap<String,Object>> listMap = semiStructuredUtils.getAvroColMetadata(inputStream);
//            for (HashMap<String,Object> map : listMap) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        fileName,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//
//    public List<Object[]> getCSVMetadata(String relativePath, String fileName, String absolutePath, String fileFormat) throws Exception{
//        InputStream inputStream = null;
//        try {
//            List<Object[]> list_of_objects_array = new ArrayList<>();
//            inputStream = fileShareConnector.getFileAsStream(relativePath);
//            List<HashMap<String,Object>> listMap = semiStructuredUtils.getCSVColMetadata(inputStream, fileFormat);
//            for (HashMap<String,Object> map : listMap) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        fileName,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//
//    @Override
//    public void closeResources() {
//
//    }
//}
