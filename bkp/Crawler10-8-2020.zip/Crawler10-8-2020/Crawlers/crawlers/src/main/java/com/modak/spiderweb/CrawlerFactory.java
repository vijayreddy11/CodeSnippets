package com.modak.spiderweb;

import com.modak.spiderweb.common.CrawlerCommon;

import java.util.HashMap;

public class CrawlerFactory {
    public Crawler getCrawlerInstance(HashMap<String, Object> sourceAttributes) {
        try {
            String className = sourceAttributes.get(CrawlerCommon.CLASSNAME).toString();
            if (className != null) {
                Crawler crawler = (Crawler) Class.forName(className).newInstance();
                return crawler;
            } else {

            }
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
}