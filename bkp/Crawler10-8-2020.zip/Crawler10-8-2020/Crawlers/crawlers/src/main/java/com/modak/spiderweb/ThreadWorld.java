package com.modak.spiderweb;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadWorld {

    public static void main(String[] args) {
         ExecutorService executors;
        executors = Executors.newFixedThreadPool(3);
        BaseThread baseThread =new BaseThread();
        executors.execute(baseThread);
    }
}
