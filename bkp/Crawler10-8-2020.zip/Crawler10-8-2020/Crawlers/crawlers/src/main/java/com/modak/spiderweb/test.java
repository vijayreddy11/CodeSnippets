package com.modak.spiderweb;

import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class test {
    HashMap dataMap = new HashMap();
    private ExecutorService executors;

    public static void main(String[] args) throws InterruptedException {
        final test tst = new test();
        tst.executors = Executors.newFixedThreadPool(5);
        for (int i = 0; i < 5; i++) {
            tst.dataMap.put(i, i);
            final HashMap cloneMap = new HashMap();
            cloneMap.putAll(tst.dataMap);
            final Integer resourceID =1;

            tst.dataMap.put("234",resourceID);
                    tst.executors.execute(new Runnable() {
                public void run() {

                    System.out.println("Hello: " + cloneMap + Thread.currentThread());
                    System.out.println("datamap: " + tst.dataMap);
                    try {
                        tst.method(cloneMap);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            tst.dataMap.clear();
        }
//        tst.executors.shutdown();
    }

    private void method(HashMap cloneMap) throws InterruptedException {
        Thread.sleep(5000);
        System.out.println("Method: " + cloneMap + Thread.currentThread());
    }
}
