//package com.modak.spiderweb.crawlers;
//
//import com.amazonaws.auth.AWSStaticCredentialsProvider;
//import com.amazonaws.auth.BasicAWSCredentials;
//import com.amazonaws.services.glue.AWSGlue;
//import com.amazonaws.services.glue.AWSGlueClientBuilder;
//import com.amazonaws.services.glue.model.Column;
//import com.amazonaws.services.glue.model.GetTablesRequest;
//import com.amazonaws.services.glue.model.Table;
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.HashMapUtility;
//import com.modak.utils.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//import java.util.*;
//
//public class GlueCrawler extends BaseCrawler {
//    protected AWSGlue connectionGlue = null;
//    private static final Logger logger = LogManager.getLogger(GlueCrawler.class);
//
//    @Override
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//
//                String creds = this.getCredentialsForSource();
//                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
//
//                String accessKey = HashMapUtility.getString(credentials, CrawlerCommon.ACCESS_KEY);
//                if (accessKey == null) {
//                    throw new NullPointerException(CrawlerCommon.ACCESS_KEY + CrawlerCommon.IS_NULL);
//                }
//                String secretKey = HashMapUtility.getString(credentials, CrawlerCommon.SECRET_KEY);
//                if (secretKey == null) {
//                    throw new NullPointerException(CrawlerCommon.SECRET_KEY + CrawlerCommon.IS_NULL);
//                }
//
//                HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.SOURCE_INFO_DETAILS);
//                String bucketName = HashMapUtility.getString(sourceInfo, CrawlerCommon.BUCKET);
//                String databaseName = HashMapUtility.getString(sourceInfo, CrawlerCommon.DATABASE_NAME);
//                String region = HashMapUtility.getString(sourceInfo, CrawlerCommon.REGION);
//
//                BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(accessKey, secretKey);
//                connectionGlue = AWSGlueClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).withRegion(region).build();
//                sourceAttributes.put(CrawlerCommon.BUCKET, bucketName);
//                sourceAttributes.put(CrawlerCommon.DATABASE_NAME, databaseName);
//                connectionGlue.getTables(new GetTablesRequest().withDatabaseName(databaseName)).getTableList();
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            try {
//                logger.error(ExceptionUtils.getStackTrace(e));
//                this.insertError(e);
//            } catch (Exception ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        List<String> schemas = new ArrayList<>();
//        schemas.add(HashMapUtility.getString(sourceAttributes, CrawlerCommon.DATABASE_NAME));
//        this.getSchemasForCloudRelationalSources(schemas);
//    }
//
//    @Override
//    public void doCrawling() {
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = HashMapUtility.getString(crawlingTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                        dataMap.put(templateName, list_of_map);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else {
//                        List<Object[]> list_of_objects_array = new ArrayList<>();
//                        String bucketName = HashMapUtility.getString(sourceAttributes, CrawlerCommon.BUCKET);
//                        String databaseName = HashMapUtility.getString(sourceAttributes, CrawlerCommon.DATABASE_NAME);
//                        int BATCH_SIZE = 1000;
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_TABLEMETADATA)) {
//                            for (Table table : connectionGlue.getTables(new GetTablesRequest().withDatabaseName(databaseName)).getTableList()) {
//                                list_of_objects_array.add(convertMapToObjectArray(getTableMetadata(table)));
//                                if (list_of_objects_array.size() >= BATCH_SIZE) {
//                                    jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                    list_of_objects_array.clear();
//                                }
//                            }
//                            if (list_of_objects_array.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                list_of_objects_array.clear();
//                            }
//                        }
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_COLUMNMETADATA)) {
//                            for (Table table : connectionGlue.getTables(new GetTablesRequest().withDatabaseName(databaseName)).getTableList()) {
//                                for (Column column : table.getStorageDescriptor().getColumns()) {
//                                    list_of_objects_array.add(convertColsMapToObjectArray(getColumnMetadata(table, column)));
//                                }
//                                if (list_of_objects_array.size() >= BATCH_SIZE) {
//                                    jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                    list_of_objects_array.clear();
//                                }
//                            }
//                            if (list_of_objects_array.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                list_of_objects_array.clear();
//                            }
//                        }
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            try {
//                logger.error(ExceptionUtils.getStackTrace(e));
//                insertError(e);
//            } catch (Exception ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            } finally {
//                connectionGlue.shutdown();
//            }
//        }
//    }
//
//    @Override
//    public void closeResources() {
//    }
//
//    private Object[] convertMapToObjectArray(HashMap<String, Object> tableStats) throws Exception {
//        try {
//            return new Object[]{
//                    HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                    HashMapUtility.get(sourceAttributes, CrawlerCommon.SCHEMA_ID),
//                    HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                    HashMapUtility.get(tableStats, CrawlerCommon.SCHEMA_NAME),
//                    HashMapUtility.get(tableStats, CrawlerCommon.TABLE_NAME),
//                    HashMapUtility.get(tableStats, CrawlerCommon.TABLE_OWNER),
//                    null,
//                    HashMapUtility.get(tableStats, CrawlerCommon.ESTIMATED_ROWS),
//                    null,
//                    null,
//                    null,
//                    null,
//                    HashMapUtility.getString(tableStats, CrawlerCommon.CREATE_TABLE_TS),
//                    HashMapUtility.getString(tableStats, CrawlerCommon.MODIFY_TABLE_TS),
//                    HashMapUtility.get(tableStats, CrawlerCommon.TABLE_SIZE),
//                    CrawlerCommon.SOURCE,
//                    HashMapUtility.get(tableStats, CrawlerCommon.LOCATION_PATH),
//                    null,
//                    HashMapUtility.get(tableStats, CrawlerCommon.TABLE_TYPE),
//                    CrawlerCommon.GLUE,
//                    false,
//                    HashMapUtility.get(tableStats, CrawlerCommon.IS_COMPRESSED),
//                    null,
//                    null
//            };
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    private Object[] convertColsMapToObjectArray(HashMap<String, Object> columnStats) throws Exception {
//        try {
//            return new Object[]{
//                    HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                    HashMapUtility.get(sourceAttributes, CrawlerCommon.SCHEMA_ID),
//                    HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                    HashMapUtility.get(columnStats, CrawlerCommon.SCHEMA_NAME),
//                    HashMapUtility.get(columnStats, CrawlerCommon.TABLE_OWNER),
//                    HashMapUtility.get(columnStats, CrawlerCommon.TABLE_NAME),
//                    HashMapUtility.get(columnStats, CrawlerCommon.COLUMN_NAME),
//                    HashMapUtility.get(columnStats, CrawlerCommon.DATA_TYPE),
//                    null,
//                    null,
//                    null,
//                    CrawlerCommon.IS_NULLABLE,
//                    HashMapUtility.get(columnStats, CrawlerCommon.ORDINAL_POSITION),
//                    null,
//                    null,
//                    null,
//                    HashMapUtility.get(columnStats, CrawlerCommon.COLUMN_COMMENT),
//                    null,
//                    null,
//                    null
//            };
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//
//    private HashMap<String, Object> getTableMetadata(Table table) throws Exception {
//        try {
//            HashMap<String, Object> map = new HashMap<>();
//            map.put(CrawlerCommon.TABLE_NAME, table.getName());
//            map.put(CrawlerCommon.SCHEMA_NAME, table.getDatabaseName());
//            map.put(CrawlerCommon.CREATE_TABLE_TS, table.getCreateTime());
//            map.put(CrawlerCommon.TABLE_OWNER, table.getOwner());
//            map.put(CrawlerCommon.TABLE_SIZE, table.getParameters().size());
//            if (table.getTableType().equals(CrawlerCommon.EXTERNAL_TABLE))
//                map.put(CrawlerCommon.TABLE_TYPE, CrawlerCommon.TABLE);
//            else
//                map.put(CrawlerCommon.TABLE_TYPE, CrawlerCommon.VIEW);
//            map.put(CrawlerCommon.IS_COMPRESSED, !table.getParameters().get(CrawlerCommon.COMPRESSION_TYPE).equals(CrawlerCommon.NONE));
//            map.put(CrawlerCommon.MODIFY_TABLE_TS, table.getUpdateTime());
//            map.put(CrawlerCommon.ESTIMATED_ROWS, table.getParameters().get(CrawlerCommon.RECORD_COUNT));
//            map.put(CrawlerCommon.LOCATION_PATH, table.getStorageDescriptor().getLocation());
//            return map;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    private HashMap<String, Object> getColumnMetadata(Table table, Column column) throws Exception {
//        try {
//            HashMap<String, Object> map = new HashMap<>();
//            map.put(CrawlerCommon.TABLE_NAME, table.getName());
//            map.put(CrawlerCommon.TABLE_OWNER, table.getOwner());
//            map.put(CrawlerCommon.SCHEMA_NAME, table.getDatabaseName());
//            map.put(CrawlerCommon.COLUMN_NAME, column.getName());
//            map.put(CrawlerCommon.DATA_TYPE, column.getType());
//            map.put(CrawlerCommon.COLUMN_COMMENT, column.getComment());
//            map.put(CrawlerCommon.ORDINAL_POSITION, table.getStorageDescriptor().getColumns().indexOf(column) + 1);
//            return map;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//}
