package com.modak.spiderweb;

import com.modak.spiderweb.common.CrawlerCommon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BaseThread implements Runnable{
    private ExecutorService executors;
    protected HashMap<String, Object> sourceAttributes=new HashMap<>();
    protected List<Map<String, Object>> listOfSources=new ArrayList<>();
    protected HashMap<String, Object> dataMap1 = new HashMap<String, Object>();

    public void run() {
        executors = Executors.newFixedThreadPool(3);

        HashMap forMap=new HashMap();
        HashMap forMap3=new HashMap();
        HashMap forMap4=new HashMap();
        HashMap forMap5=new HashMap();
        HashMap forMap6=new HashMap();
        HashMap forMap7=new HashMap();
        HashMap forMap8=new HashMap();
        HashMap forMap9=new HashMap();
        HashMap forMap10=new HashMap();

        forMap.put("schema_name","chembl");
        listOfSources.add(forMap);
        HashMap forMap2=new HashMap();
        forMap2.put("schema_name","chembl2");
        listOfSources.add(forMap2);
        forMap3.put("schema_name","chembl3");

        listOfSources.add(forMap3);
        forMap4.put("schema_name","chembl4");
        listOfSources.add(forMap4);
        forMap5.put("schema_name","chembl5");
        listOfSources.add(forMap5);
        forMap6.put("schema_name","chembl6");
        listOfSources.add(forMap6);
        forMap7.put("schema_name","chembl7");
        listOfSources.add(forMap7);
        forMap8.put("schema_name","chembl8");
        listOfSources.add(forMap8);
        forMap9.put("schema_name","chembl9");
        listOfSources.add(forMap9);
        forMap10.put("schema_name","chembl10");
        listOfSources.add(forMap10);
        System.out.println(listOfSources);

        for (Map schema:listOfSources) {
            sourceAttributes.put(CrawlerCommon.SCHEMA_ID, listOfSources.indexOf(schema));
            Map cloneMap=new HashMap();
            cloneMap.putAll(schema);
            dataMap1.putAll( sourceAttributes);
            cloneMap.putAll(dataMap1);
            cloneMap.put(CrawlerCommon.RESOURCE_ID, 0);
         //   cloneMap.putAll( sourceAttributes);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            ThreadExecutor threadExecutor = new ThreadExecutor();
            threadExecutor.init(dataMap1);
            executors.execute(threadExecutor);
            System.out.println("Main Thread:"+dataMap1);

        }
    }
}
