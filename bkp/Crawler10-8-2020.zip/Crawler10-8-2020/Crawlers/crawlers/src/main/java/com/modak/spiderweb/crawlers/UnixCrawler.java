//package com.modak.spiderweb.crawlers;
//
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.DelimitedFileFormatUtil;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.SemiStructuredUtils;
//import com.modak.utility.TimeStampUtils;
//import com.modak.utility.json.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.io.FilenameUtils;
//import org.apache.commons.lang.SystemUtils;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.hadoop.conf.Configuration;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.apache.parquet.hadoop.ParquetFileReader;
//import org.apache.parquet.hadoop.util.HadoopInputFile;
//
//import java.io.*;
//import java.nio.file.*;
//import java.nio.file.attribute.BasicFileAttributes;
//import java.nio.file.attribute.FileTime;
//import java.nio.file.attribute.PosixFileAttributes;
//import java.util.*;
//
//import static java.nio.file.FileVisitResult.CONTINUE;
//
//public class UnixCrawler extends BaseCrawler {
//    private static final Logger logger = LogManager.getLogger(UnixCrawler.class);
//    private List<Object[]> list_of_objects_array = new ArrayList<>();
//    private Path root_location_path;
//    private final int BATCH_SIZE = 1000;
//    protected SemiStructuredUtils semiStructuredUtils;
//    protected DelimitedFileFormatUtil delimitedFileFormatUtil;
//
//    @Override
//    public void initSourceConnection() {
//        Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//        if (connectToSource && !isErrored) {
//            logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                    HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                    HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.SOURCE_INFO_DETAILS);
//            String path = HashMapUtility.getString(sourceInfo, CrawlerCommon.PATH);
//            root_location_path = Paths.get(path);
//            sourceAttributes.put(CrawlerCommon.PATH, path);
//            if (root_location_path.toString().equals("")) {
//                logger.info(CrawlerCommon.NOT_VALID_LOCATION_PATH, root_location_path);
//                try {
//                    throw new Exception(CrawlerCommon.SPECIFIED_PATH_IS_NOT_VALID + root_location_path);
//                } catch (Exception e) {
//                    logger.error(ExceptionUtils.getStackTrace(e));
//                    insertError(e);
//                }
//            }
//            boolean fetchColumnMetadata = HashMapUtility.getBoolean(sourceInfo, CrawlerCommon.FETCH_COLUMN_METADATA);
//            sourceAttributes.put(CrawlerCommon.FETCH_COLUMN_METADATA, fetchColumnMetadata);
//
//        } else {
//            logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        this.getDirectories();
//    }
//
//    @Override
//    public void doCrawling() {
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = HashMapUtility.getString(crawlingTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                        dataMap.put(templateName, list_of_map);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else {
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_FILEMETADATA)) {
//                            processDirectory(query);
//                            if (list_of_objects_array.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                list_of_objects_array.clear();
//                            }
//                        } else {
//                            if (HashMapUtility.getBoolean(sourceAttributes, CrawlerCommon.FETCH_COLUMN_METADATA)) {
//                                processColumnMetadata(query);
//                                if (list_of_objects_array.size() > 0) {
//                                    jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                    list_of_objects_array.clear();
//                                }
//                            }
//                        }
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            try {
//                logger.error(ExceptionUtils.getStackTrace(e));
//                insertError(e);
//            } catch (Exception ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//
//    private void processDirectory(final String query) throws Exception {
//        try {
//            Files.walkFileTree(root_location_path, new SimpleFileVisitor<Path>() {
//                @Override
//                public FileVisitResult visitFile(Path filepath, BasicFileAttributes attr) {
//                    InputStream inputStream = null;
//                    try {
//                        File file = new File(filepath.toString());
//                        if (!file.getAbsolutePath().contains("/.snapshot")) {
//                            FileTime dateCreate = attr.creationTime();
//                            String owner_id = null;
//                            String owner_grp = null;
//                            if (SystemUtils.IS_OS_LINUX || SystemUtils.IS_OS_UNIX) {
//                                PosixFileAttributes posixattr = Files.readAttributes(filepath,
//                                        PosixFileAttributes.class);
//                                owner_id = posixattr.owner().toString();
//                                owner_grp = posixattr.group().toString();
//                            }
//                            String absolutePath = file.getAbsolutePath();
//                            String relativePath = filepath.toString().replace(root_location_path.toString(), "");
//                            relativePath = relativePath.replaceFirst("/", "");
//                            String fileName = filepath.getFileName().toString();
//                            String fileFormat = FilenameUtils.getExtension(fileName);
//                            inputStream = new BufferedInputStream(new FileInputStream(absolutePath));
//                            String delimiterFileFormat = null;
//                            delimitedFileFormatUtil = new DelimitedFileFormatUtil();
//                            if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                                delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//                            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                                delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//                            }
//
//                            Object[] obj = {
//                                    sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                                    sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                                    sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                                    fileName,
//                                    fileFormat,
//                                    absolutePath,
//                                    relativePath,
//                                    TimeStampUtils.changeToTimeStamp(dateCreate.toMillis()),
//                                    attr.isSymbolicLink(),
//                                    attr.isDirectory(),
//                                    attr.isRegularFile(),
//                                    attr.size(),
//                                    owner_id,
//                                    owner_grp,
//                                    delimiterFileFormat,
//                                    null,
//                            };
//                            list_of_objects_array.add(obj);
//                            if (list_of_objects_array.size() >= BATCH_SIZE) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                list_of_objects_array.clear();
//                            }
//                        }
//                    } catch (Exception e) {
//                        logger.error(ExceptionUtils.getStackTrace(e));
//                        insertError(e);
//                    } finally {
//                        try {
//                            if (inputStream != null)
//                                inputStream.close();
//                        } catch (IOException e) {
//                            logger.error(ExceptionUtils.getStackTrace(e));
//                        }
//                    }
//                    return CONTINUE;
//                }
//
//                @Override
//                public FileVisitResult preVisitDirectory(Path filepath, BasicFileAttributes attr) {
//                    File file = new File(filepath.toString());
//                    if (file.getAbsolutePath().contains("/.snapshot")) {
//                        return FileVisitResult.SKIP_SUBTREE;
//                    } else {
//                        return FileVisitResult.CONTINUE;
//                    }
//                }
//
//                @Override
//                public FileVisitResult visitFileFailed(Path filepath, IOException exc) {
//                    logger.error(CrawlerCommon.ERROR_FOR_FILE, filepath, exc.getMessage());
//                    insertError(exc);
//                    return CONTINUE;
//                }
//            });
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//
//    private void processColumnMetadata(final String query) throws Exception {
//        try {
//            Files.walkFileTree(root_location_path, new SimpleFileVisitor<Path>() {
//                @Override
//                public FileVisitResult visitFile(Path filepath, BasicFileAttributes attr) {
//                    InputStream inputStream = null;
//                    try {
//                        File file = new File(filepath.toString());
//                        if (!file.getAbsolutePath().contains("/.snapshot")) {
//                            String absolutePath = file.getAbsolutePath();
//                            String fileName = filepath.getFileName().toString();
//                            String fileFormat = FilenameUtils.getExtension(fileName);
//                            semiStructuredUtils = new SemiStructuredUtils();
//                            if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                                inputStream = new BufferedInputStream(new FileInputStream(absolutePath));
//                                String delimiterFileFormat;
//                                if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                                    delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//                                } else {
//                                    delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//                                }
//                                HashMap<String, Object> delimiterFileFormatMap = JSONUtils.jsonToMap(delimiterFileFormat);
//                                boolean header = (boolean) HashMapUtility.get(delimiterFileFormatMap, CrawlerCommon.HEADER);
//                                if (header) {
//                                    list_of_objects_array.addAll(getCSVMetadata(absolutePath, fileName, fileFormat));
//                                }
//                            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.AVRO)) {
//                                list_of_objects_array.addAll(getAvroMetadata(absolutePath, fileName));
//                            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.PARQUET)) {
//                                list_of_objects_array.addAll(getParquetMetadata(absolutePath, fileName));
//                            }
//
//                            if (list_of_objects_array.size() >= BATCH_SIZE) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                list_of_objects_array.clear();
//                            }
//                        }
//                    } catch (Exception e) {
//                        logger.error(ExceptionUtils.getStackTrace(e));
//                        insertError(e);
//                    } finally {
//                        try {
//                            if (inputStream != null)
//                                inputStream.close();
//                        } catch (IOException e) {
//                            logger.error(ExceptionUtils.getStackTrace(e));
//                        }
//                    }
//                    return CONTINUE;
//                }
//
//                @Override
//                public FileVisitResult preVisitDirectory(Path filepath, BasicFileAttributes attr) {
//                    File file = new File(filepath.toString());
//                    if (file.getAbsolutePath().contains("/.snapshot")) {
//                        return FileVisitResult.SKIP_SUBTREE;
//                    } else {
//                        return FileVisitResult.CONTINUE;
//                    }
//                }
//
//                @Override
//                public FileVisitResult visitFileFailed(Path filepath, IOException exc) {
//                    logger.error(CrawlerCommon.ERROR_FOR_FILE, filepath, exc.getMessage());
//                    insertError(exc);
//                    return CONTINUE;
//                }
//            });
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//
//    public List<Object[]> getParquetMetadata(String absolutePath, String fileName) throws Exception {
//        ParquetFileReader reader = null;
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        try {
//            reader = ParquetFileReader.open(HadoopInputFile.fromPath(new org.apache.hadoop.fs.Path(absolutePath), new Configuration()));
//            List<LinkedHashMap<String, Object>> listMap = semiStructuredUtils.getParquetColMetadata(reader);
//            for (LinkedHashMap<String, Object> map : listMap) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        fileName,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        listMap.indexOf(map),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (reader != null)
//                    reader.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//
//    public List<Object[]> getAvroMetadata(String absolutePath, String fileName) throws Exception {
//        InputStream inputStream = null;
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        try {
//            inputStream = new BufferedInputStream(new FileInputStream(absolutePath));
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getAvroColMetadata(inputStream);
//            for (HashMap<String, Object> map : listMap) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        fileName,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//
//    public List<Object[]> getCSVMetadata(String absolutePath, String fileName, String fileFormat) throws Exception {
//        InputStream inputStream = null;
//        try {
//            List<Object[]> list_of_objects_array = new ArrayList<>();
//            inputStream = new BufferedInputStream(new FileInputStream(absolutePath));
//
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getCSVColMetadata(inputStream, fileFormat);
//
//            for (HashMap<String, Object> map : listMap) {
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        fileName,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//
//    @Override
//    public void closeResources() {
//    }
//}
