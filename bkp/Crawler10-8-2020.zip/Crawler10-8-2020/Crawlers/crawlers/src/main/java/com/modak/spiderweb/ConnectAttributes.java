package com.modak.spiderweb;

import java.util.HashMap;

public class ConnectAttributes extends HashMap {
}
