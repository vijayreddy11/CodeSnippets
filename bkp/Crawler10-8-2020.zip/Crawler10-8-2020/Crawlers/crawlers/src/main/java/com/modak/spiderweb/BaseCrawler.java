package com.modak.spiderweb;

import com.jayway.jsonpath.JsonPath;
import com.modak.spiderweb.common.CrawlerCommon;
import com.modak.utility.CredentialFetchWebServiceUtil;
import com.modak.utility.HashMapUtility;
import com.modak.utility.db.DBUtils;
import com.modak.utility.db.JDBCUtility;
import com.modak.utility.json.JSONUtility;
import com.modak.utility.jwt.AuthTokenGenerator;
import com.modak.utility.st.STTemplateFactory;
import com.modak.utility.st.STTemplateRenderer;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.dbutils.handlers.ColumnListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.net.InetAddress;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class BaseCrawler implements Crawler {
    private static final Logger logger = LogManager.getLogger(BaseCrawler.class);
    protected HashMap<String, Object> sourceAttributes;
    protected HashMap<String, Object> koshTemplateMap;
    protected HashMap<String, Object> rest_config;
    protected HashMap<String, Object> crawlerConfigMap;
    protected HashMap<String, Object> runAttributes;
    protected HikariDataSource dataSource;
    protected JDBCUtility jdbcUtility;
    protected HashMap<String, Object> crawlerRulesMap;
    protected HashMap<String, Object> errorTemplateConfigMap;
    protected String errorTemplateGroup;
    protected HashMap<String, Object> dataMap1 = new HashMap<String, Object>();
    protected StagingSchemaPool<Integer> stagingTablePoolReference;
    protected boolean isErrored = false;
    protected STTemplateRenderer templateRenderer;
    protected List<Map<String, Object>> listOfSources;
    protected List<String> noCrawlingSchemaList;
    protected HashMap<String, Object> templateConfigDataplaceMap;
    protected String source_type;
    protected String jsonString;
    protected InetAddress ip;
    private ExecutorService executors;
    protected HikariDataSource sourceHikariConnectionPool;
//    protected Crawler crawler;

    public void init(HashMap<String, Object> sourceAttributes, HikariDataSource dataSource,
                     HashMap<String, Object> runAttributes, StagingSchemaPool<Integer> stagingTablePoolReference,
                     HashMap<String, Object> crawlerConfigMap) {
        this.sourceAttributes = sourceAttributes;
        this.dataSource = dataSource;
        this.runAttributes = runAttributes;
        this.stagingTablePoolReference = stagingTablePoolReference;
        this.crawlerConfigMap = crawlerConfigMap;
    }

    public abstract void initSourceConnection() throws Exception;

    public void initialize() {
        try {
            ip = InetAddress.getLocalHost();
            sourceAttributes.put(CrawlerCommon.IP_ADDRESS, ip);
            dataMap1.put(CrawlerCommon.SOURCEATTRIBUTES, sourceAttributes);
            jdbcUtility = new JDBCUtility();
            source_type = HashMapUtility.getString(sourceAttributes, CrawlerCommon.SOURCE_TYPE);
            crawlerRulesMap = JSONUtility.jsonToMap(FileUtils.readFileToString(new File(runAttributes.get(CrawlerCommon.RESOURCES_PATH) +
                    File.separator + CrawlerCommon.CRAWLER_RULES + File.separator + source_type + ".json"), Charset.defaultCharset()));
            jsonString = FileUtils.readFileToString(new File(runAttributes.get(CrawlerCommon.RESOURCES_PATH) +
                    File.separator + CrawlerCommon.CRAWLER_RULES + File.separator + source_type + ".json"), Charset.defaultCharset());
            rest_config = HashMapUtility.getMap(crawlerConfigMap, CrawlerCommon.KEY_TEMPLATE_CONFIG);
            templateRenderer = STTemplateFactory.getTemplateRenderer(rest_config);
            List<String> templateGroupList = JsonPath.read(jsonString, "$..templateGroup");
            templateRenderer.loadTemplateGroups((ArrayList<String>) templateGroupList);
            errorTemplateConfigMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.ERROR);
            errorTemplateGroup = HashMapUtility.getString(errorTemplateConfigMap, CrawlerCommon.TEMPLATE_GROUP);
            templateConfigDataplaceMap = HashMapUtility.getMap(crawlerConfigMap, CrawlerCommon.TEMPLATE_CONFIG_DATAPLACE);
            noCrawlingSchemaList = new ArrayList<>();

        } catch (Exception e) {
            logger.error(ExceptionUtils.getStackTrace(e));
            insertError(e);
        }
    }

    public void doRollBack(HashMap<String, Object> dataMap) {
        try {
            boolean doRollBack = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOROLLBACK);
            if (doRollBack && !isErrored) {
                logger.info(CrawlerCommon.STARTED_ROLLBACK, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
                HashMap<String, Object> rollBackTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.ROLLBACK);
                String templateGroup = HashMapUtility.getString(rollBackTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
                HashMap<String, Object> templateMap = HashMapUtility.getMap(rollBackTemplateMap, CrawlerCommon.TEMPLATE_MAP);
                for (String templateName : templateMap.keySet()) {
                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
                    if (!query.equalsIgnoreCase("")) {
                        HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
                        String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
                        if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
                            List<Map<String, Object>> resultMapList = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
                            dataMap.put(templateName, resultMapList);
                        } else {
                            jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
                        }
                    }
                }
            } else {
                logger.info(CrawlerCommon.ROLLBACK_DISABLED);
            }
        } catch (Exception e) {
            try {
                logger.error(ExceptionUtils.getStackTrace(e));
                insertError(e);
            } catch (Exception ex) {
                logger.error(ExceptionUtils.getStackTrace(ex));
            }
        }
    }

    public abstract void connectToSource();

    public abstract void doCrawling(HashMap<String, Object> dataMap) throws Exception;

    public abstract void closeResources();

    public void doCDC(HashMap<String, Object> dataMap) {
        Connection connection = null;
        try {
            Boolean doCDC = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCDC);
            if (doCDC && !isErrored) {
                logger.info(CrawlerCommon.CDC_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
                connection = dataSource.getConnection();

                if (connection != null) {
                    connection.setAutoCommit(false);
                    HashMap<String, Object> cdcTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CDC);
                    String templateGroup = HashMapUtility.getString(cdcTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
                    HashMap<String, Object> templateMap = HashMapUtility.getMap(cdcTemplateMap, CrawlerCommon.TEMPLATE_MAP);
                    for (String templateName : templateMap.keySet()) {
                        String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
                        HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
                        String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
                        if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
                            List<Map<String, Object>> resultMapList = jdbcUtility.executeSelectQuery(query, connection, false, new MapListHandler());
                            dataMap.put(templateName, resultMapList);
                        } else {
                            jdbcUtility.executeUpdateQuery(query, connection, false);
                        }
                    }
                    connection.commit();
                    if (connection != null) {
                        try {
                            connection.close();
                        } catch (SQLException e) {
                            logger.error(ExceptionUtils.getStackTrace(e));
                        }
                    }
                    logger.info(CrawlerCommon.CDC_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
                            HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility
                                    .get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
                }

            } else {
                logger.info(CrawlerCommon.CDC_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility
                                .get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));

            }
        } catch (Exception e) {
            try {
                logger.debug("dataMap :" + dataMap);
                logger.error(ExceptionUtils.getStackTrace(e));
                insertError(e);
            } catch (Exception ex) {
                logger.error(ExceptionUtils.getStackTrace(ex));
            }
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    logger.error(ExceptionUtils.getStackTrace(e));
                }
            }
        }
    }


    public void run() {
        final Integer resourceID = getStagingSchemaID();
        try {
            int mutliStagingSchemaPoolSize = HashMapUtility.getInteger(crawlerConfigMap, CrawlerCommon.MULTI_STAGING_SCHEMA_POOL_SIZE);
            ArrayList<Integer> schemaResources = new ArrayList<Integer>();
            for (int i = 0; i < mutliStagingSchemaPoolSize; i++) {
                schemaResources.add(i);
            }
            dataMap1.put(CrawlerCommon.RESOURCE_ID, resourceID);
            final MultiStagingSchemaPool<Integer> multiStagingSchemaPoolReference = new MultiStagingSchemaPool<>(schemaResources);
            initialize();
            initSourceConnection();
            connectToSource();
            executors = Executors.newFixedThreadPool(mutliStagingSchemaPoolSize);
            try {
                if (!isErrored && listOfSources.size() > 0) {
                    for (Map<String, Object> eachSource : listOfSources) {

                        String dataplace_component_type_id = HashMapUtility.getString(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID);
                        if (dataplace_component_type_id.equals("1")) {
                            sourceAttributes.put(CrawlerCommon.SCHEMA_ID, eachSource.get(CrawlerCommon.SCHEMA_ID));
                            sourceAttributes.put(CrawlerCommon.SCHEMA_NAME, eachSource.get(CrawlerCommon.SCHEMA_NAME));
                        } else {
                            sourceAttributes.put(CrawlerCommon.DIRECTORY_ID, eachSource.get(CrawlerCommon.DIRECTORY_ID));
                        }

                        final HashMap<String, Object> tempMap = new HashMap<>();
                        tempMap.putAll(sourceAttributes);
                        dataMap1.put(CrawlerCommon.SOURCEATTRIBUTES, tempMap);

                        final HashMap<String, Object> cloneMap = new HashMap<>();
                        cloneMap.putAll(dataMap1);

                        executors.execute(new Runnable() {
                            public void run() {
                                Integer schemaResourceID = getMultiStagingSchemaID(multiStagingSchemaPoolReference);
                                try {
                                    cloneMap.put(CrawlerCommon.RESOURCE_ID, resourceID + "_" + schemaResourceID);
                                   // initSourceConnection();
                                    doRollBack(cloneMap);
                                    doCrawling(cloneMap);
                                    doCDC(cloneMap);
                                    isErrored = false;
                                } catch (Exception e) {
                                    e.printStackTrace();
                                } finally {
                                    logger.info(CrawlerCommon.MULTI_RESOURCE_RELEASED, resourceID + "_" + schemaResourceID);
                                    multiStagingSchemaPoolReference.returnStagingSchema(schemaResourceID);
                                    cloneMap.clear();
                                    tempMap.clear();
                                }
                            }
                        });
                    }
                } else {
                    logger.info(CrawlerCommon.INCORRECT_SOURCE_DETAILS, HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
                            HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                logger.info(CrawlerCommon.RESOURCE_RELEASED, resourceID);
                stagingTablePoolReference.returnStagingSchema(resourceID);
                dataMap1.clear();
            }
        } catch (Exception e) {
            logger.error(ExceptionUtils.getStackTrace(e));
            insertError(e);
        } finally {
              //closeResources();
        }
    }

//    public void batchOperation(Crawler crawler){
//        this.crawler=crawler;
//    }

    public Integer getStagingSchemaID() {
        Integer resourceID;
        while (true) {
            resourceID = stagingTablePoolReference.getStagingSchema();
            String name = resourceID != null ? CrawlerCommon.RESOURCE_ID_IS + resourceID.toString()
                    : CrawlerCommon.WAITING_FOR_STAGE_TO_ALLOCATE + Thread.currentThread();
            logger.info(name);
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                logger.error(ExceptionUtils.getStackTrace(e));
            }
            if (resourceID != null) {
                break;
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                logger.error(ExceptionUtils.getStackTrace(e));
            }
        }
        return resourceID;
    }

    public Integer getMultiStagingSchemaID(MultiStagingSchemaPool<Integer> multiStagingSchemaPoolReference) {
        Integer schemaResourceID;
        while (true) {
            schemaResourceID = multiStagingSchemaPoolReference.getStagingSchema();
            String name = schemaResourceID != null ? CrawlerCommon.MULTI_RESOURCE_ID_IS + schemaResourceID.toString()
                    : CrawlerCommon.WAITING_FOR_STAGE_TO_ALLOCATE + Thread.currentThread();
            logger.info(name);
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                logger.error(ExceptionUtils.getStackTrace(e));
            }
            if (schemaResourceID != null) {
                break;
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                logger.error(ExceptionUtils.getStackTrace(e));
            }
        }
        return schemaResourceID;
    }


    public List<Object[]> convertToObjectArray(List<HashMap<String, Object>> dataMapList) {
        List<Object[]> list_of_object_array = new ArrayList();
        for (int i = 0; i < dataMapList.size(); i++) {
            Collection<Object> values = dataMapList.get(i).values();
            list_of_object_array.add(values.toArray());
        }
        return list_of_object_array;
    }

    public void executeBatchUpdateQuery(HashMap<String, Object> dataMap, List<String> dependentKeyList, String query,
                                        Connection connection, boolean closeConnection) throws Exception {
        List<Object[]> list_of_objects_array = new ArrayList();
        if (dependentKeyList != null) {
            for (int i = 0; i < dependentKeyList.size(); i++) {
                list_of_objects_array.addAll(convertToObjectArray((List) dataMap.get(dependentKeyList.get(i))));
            }
            jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, connection, closeConnection);
        }
    }


    public void executeListOfQueries(Connection sourceConnection, HashMap<String, Object> dataMap) {

        try {
            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
            if (doCrawling && !isErrored) {
                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
                String templateGroup = HashMapUtility.getString(crawlingTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
                for (String templateName : templateMap.keySet()) {
                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
                    logger.info("SQLQUERY: "+query);
                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
                    String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
                        String connection_type = HashMapUtility.getString(dependentMap, CrawlerCommon.CONNECTION_TYPE);
                        if (connection_type.equalsIgnoreCase(CrawlerCommon.SOURCE)) {
                            if (sourceConnection != null) {
                                List<LinkedHashMap<String, Object>> listOfMaps = DBUtils.executeQuery(sourceConnection, query);
                                dataMap.put(templateName, listOfMaps);
                            } else {
                                logger.error(CrawlerCommon.SOURCE_CONNECTION_OBJECT_IS_NULL);
                            }
                        } else {
                            List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
                            dataMap.put(templateName, list_of_map);
                        }
                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT_INSERT)) {
                        HashMap<String, Object> tempMap = HashMapUtility.getMap(templateMap, templateName);
                        String selectQueryTemplate = HashMapUtility.getString(tempMap, CrawlerCommon.SELECT_QUERY);
                        String selectQuery = templateRenderer.renderTemplate(templateGroup, selectQueryTemplate, CrawlerCommon.DATA, dataMap);
                        String insertQueryTemplate = HashMapUtility.getString(tempMap, CrawlerCommon.INSERT_QUERY);
                        String insertQuery = templateRenderer.renderTemplate(templateGroup, insertQueryTemplate, CrawlerCommon.DATA, dataMap);
                        logger.info("CRAWLINGTEMP: "+insertQuery);
                        jdbcUtility.executeSelectInsertBatchMode(sourceConnection, selectQuery, dataSource.getConnection(), insertQuery, true);
                    }

                }
                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
            } else {
                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
            }
        } catch (Exception e) {
            try {
                logger.error(ExceptionUtils.getStackTrace(e));
                insertError(e);
            } catch (Exception ex) {
                logger.error(ExceptionUtils.getStackTrace(ex));
            }
        } finally {
            if (sourceConnection != null) {
                try {
                    sourceConnection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public void getSchemas(HikariDataSource hikariConnectionPool) {
        Connection sourceConnection = null;
        try {
            if (!isErrored) {
                List<String> schemaListFromRelationalComponent = this.getSchemaListFromRelationalComponent();
                List<String> crawlSchemaList = new ArrayList<>();
                this.sourceHikariConnectionPool = hikariConnectionPool;
                sourceConnection = sourceHikariConnectionPool.getConnection();

                DatabaseMetaData databaseMetaData = null;
                databaseMetaData = sourceConnection.getMetaData();

                if (databaseMetaData != null) {
                    if (sourceAttributes.get(CrawlerCommon.SOURCE_TYPE).equals(CrawlerCommon.MYSQL) || sourceAttributes.get(CrawlerCommon.SOURCE_TYPE).equals(CrawlerCommon.HIVE) || sourceAttributes.get(CrawlerCommon.SOURCE_TYPE).equals(CrawlerCommon.ATHENA)) {
                        crawlSchemaList.add(HashMapUtility.getString(sourceAttributes, CrawlerCommon.DATABASE_NAME));
                    } else {
                        ResultSet schemaList = databaseMetaData.getSchemas();
                        while (schemaList.next()) {
                            if (!noCrawlingSchemaList.contains(schemaList.getString(1))) {
                                crawlSchemaList.add(schemaList.getString(1));
                            }
                        }
                    }
                }
                this.updateSchemasInfoInRelationalComponent(crawlSchemaList, schemaListFromRelationalComponent);
            }
        } catch (Exception e) {
            logger.error(ExceptionUtils.getStackTrace(e));
            insertError(e);
        } finally {
            if (sourceConnection != null) {
                try {
                    sourceConnection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public List<String> getSchemaListFromRelationalComponent() throws Exception {
        String templateGroup = HashMapUtility.getString(templateConfigDataplaceMap, CrawlerCommon.TEMPLATEGROUP);
        String templateName = HashMapUtility.getString(templateConfigDataplaceMap, CrawlerCommon.TEMPLATENAME);
        STTemplateRenderer templateRenderer = STTemplateFactory.getTemplateRenderer(templateConfigDataplaceMap);
        String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, sourceAttributes);
        List<String> schemaListFromRelationalComponent = (List<String>) jdbcUtility
                .executeSelectQuery(query, dataSource.getConnection(), true, new ColumnListHandler());

        noCrawlingSchemaList.add("information_schema");
        noCrawlingSchemaList.add("pg_catalog");
        noCrawlingSchemaList.add("pg_temp_1");
        noCrawlingSchemaList.add("pg_toast");
        noCrawlingSchemaList.add("pg_toast_temp_1");
        noCrawlingSchemaList.add("sqlj");
        noCrawlingSchemaList.add("public");
        noCrawlingSchemaList.add("staging");
        noCrawlingSchemaList.add("db_accessadmin");
        noCrawlingSchemaList.add("db_backupoperator");
        noCrawlingSchemaList.add("db_datareader");
        noCrawlingSchemaList.add("db_datawriter");
        noCrawlingSchemaList.add("db_ddladmin");
        noCrawlingSchemaList.add("db_denydatareader");
        noCrawlingSchemaList.add("db_denydatawriter");
        noCrawlingSchemaList.add("db_owner");
        noCrawlingSchemaList.add("db_securityadmin");
        noCrawlingSchemaList.add("guest");
        noCrawlingSchemaList.add("INFORMATION_SCHEMA");
        noCrawlingSchemaList.add("sys");
        noCrawlingSchemaList.add("ANONYMOUS");
        noCrawlingSchemaList.add("APPQOSSYS");
        noCrawlingSchemaList.add("AUDSYS");
        noCrawlingSchemaList.add("CTXSYS");
        noCrawlingSchemaList.add("DBSFWUSER");
        noCrawlingSchemaList.add("DBSNMP");
        noCrawlingSchemaList.add("DIP");
        noCrawlingSchemaList.add("DVF");
        noCrawlingSchemaList.add("DVSYS");
        noCrawlingSchemaList.add("GGSYS");
        noCrawlingSchemaList.add("GSMCATUSER");
        noCrawlingSchemaList.add("GSMUSER");
        noCrawlingSchemaList.add("HR");
        noCrawlingSchemaList.add("LBACSYS");
        noCrawlingSchemaList.add("MDDATA");
        noCrawlingSchemaList.add("MDSYS");
        noCrawlingSchemaList.add("OJVMSYS");
        noCrawlingSchemaList.add("OLAPSYS");
        noCrawlingSchemaList.add("ORACLE_OCM");
        noCrawlingSchemaList.add("ORDDATA");
        noCrawlingSchemaList.add("ORDPLUGINS");
        noCrawlingSchemaList.add("ORDSYS");
        noCrawlingSchemaList.add("GSMADMIN_INTERNAL");
        noCrawlingSchemaList.add("OUTLN");
        noCrawlingSchemaList.add("REMOTE_SCHEDULER_AGENT");
        noCrawlingSchemaList.add("RETAIL");
        noCrawlingSchemaList.add("SI_INFORMTN_SCHEMA");
        noCrawlingSchemaList.add("SPATIAL_CSW_ADMIN_USR");
        noCrawlingSchemaList.add("SYS");
        noCrawlingSchemaList.add("SYS$UMF");
        noCrawlingSchemaList.add("SYSBACKUP");
        noCrawlingSchemaList.add("SYSDG");
        noCrawlingSchemaList.add("SYSKM");
        noCrawlingSchemaList.add("SYSRAC");
        noCrawlingSchemaList.add("SYSTEM");
        noCrawlingSchemaList.add("WMSYS");
        noCrawlingSchemaList.add("XDB");
        noCrawlingSchemaList.add("XS$NULL");
        noCrawlingSchemaList.add("pg_internal");
        noCrawlingSchemaList.add("APEX_030200");
        noCrawlingSchemaList.add("APEX_PUBLIC_USER");
        noCrawlingSchemaList.add("BI");
        noCrawlingSchemaList.add("EXFSYS");
        noCrawlingSchemaList.add("FLOWS_FILES");
        noCrawlingSchemaList.add("IX");
        noCrawlingSchemaList.add("MGMT_VIEW");
        noCrawlingSchemaList.add("OE");
        noCrawlingSchemaList.add("OWBSYS");
        noCrawlingSchemaList.add("OWBSYS_AUDIT");
        noCrawlingSchemaList.add("PM");
        noCrawlingSchemaList.add("SCOTT");
        noCrawlingSchemaList.add("SH");
        noCrawlingSchemaList.add("SPATIAL_WFS_ADMIN_USR");
        noCrawlingSchemaList.add("SYSMAN");
        noCrawlingSchemaList.add("SYSTEM");
        noCrawlingSchemaList.add("APEX_040200");
        noCrawlingSchemaList.add("default");
        return schemaListFromRelationalComponent;
    }


    public void updateSchemasInfoInRelationalComponent(List<String> crawlSchemaList, List<String> schemaListFromRelationalComponent) throws Exception {
        STTemplateRenderer templateRenderer = STTemplateFactory.getTemplateRenderer(templateConfigDataplaceMap);
        String templateGroup = HashMapUtility.getString(templateConfigDataplaceMap, CrawlerCommon.TEMPLATEGROUP);
        Object dataplace_id = HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID);
        Object dataplace_component_type_id = HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID);
        Object is_active = HashMapUtility.get(sourceAttributes, CrawlerCommon.IS_ACTIVE);
        Object is_sensitive = HashMapUtility.get(sourceAttributes, CrawlerCommon.IS_SENSITIVE);
        for (String schema : crawlSchemaList) {
            if (!schemaListFromRelationalComponent.contains(schema)) {
                HashMap<String, Object> sourceInputMap = new HashMap<>();
                sourceInputMap.put(CrawlerCommon.SCHEMA_NAME, schema);
                sourceInputMap.put(CrawlerCommon.DATAPLACE_ID, dataplace_id);
                sourceInputMap.put(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID, dataplace_component_type_id);
                sourceInputMap.put(CrawlerCommon.IS_ACTIVE, is_active);
                sourceInputMap.put(CrawlerCommon.IS_SENSITIVE, is_sensitive);
                String insertQuery = templateRenderer.renderTemplate(templateGroup, CrawlerCommon.INSERT_INFORM_SCHEMA, CrawlerCommon.DATA, sourceInputMap);
                jdbcUtility.executeUpdateQuery(insertQuery, dataSource.getConnection(), true);
            }
        }

        for (String schema : schemaListFromRelationalComponent) {
            if (!crawlSchemaList.contains(schema)) {
                HashMap<String, Object> sourceInputMap = new HashMap<>();
                sourceInputMap.put(CrawlerCommon.SCHEMA_NAME, schema);
                sourceInputMap.put(CrawlerCommon.DATAPLACE_ID, dataplace_id);
                sourceInputMap.put(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID, dataplace_component_type_id);
                String updateQuery = templateRenderer.renderTemplate(templateGroup, CrawlerCommon.INACTIVE_SOURCE, CrawlerCommon.DATA, sourceInputMap);
                jdbcUtility.executeUpdateQuery(updateQuery, dataSource.getConnection(), true);
            }
        }
        String querySource = templateRenderer.renderTemplate(templateGroup, CrawlerCommon.GET_SOURCES, CrawlerCommon.DATA, sourceAttributes);
        listOfSources = (List<Map<String, Object>>) jdbcUtility
                .executeSelectQuery(querySource, dataSource.getConnection(), true, new MapListHandler());

    }


    public void getSchemasForCloudRelationalSources(List<String> schemas) {
        try {
            if (!isErrored) {
                List<String> schemaListFromRelationalComponent = this.getSchemaListFromRelationalComponent();
                List<String> crawlSchemaList = new ArrayList<>();
                for (String schema : schemas) {
                    if (!noCrawlingSchemaList.contains(schema)) {
                        crawlSchemaList.add(schema);
                    }
                }
                this.updateSchemasInfoInRelationalComponent(crawlSchemaList, schemaListFromRelationalComponent);
            }
        } catch (Exception e) {
            logger.error(ExceptionUtils.getStackTrace(e));
            insertError(e);
        }
    }


    public void getDirectories() {
        try {
            if (!isErrored) {
                HashMap<String, Object> templateConfigDataplaceMap = HashMapUtility.getMap(crawlerConfigMap, CrawlerCommon.TEMPLATE_CONFIG_CLOUD);
                String templateGroup = HashMapUtility.getString(templateConfigDataplaceMap, CrawlerCommon.TEMPLATEGROUP);
                String templateName = HashMapUtility.getString(templateConfigDataplaceMap, CrawlerCommon.TEMPLATENAME);
                STTemplateRenderer templateRenderer = STTemplateFactory.getTemplateRenderer(templateConfigDataplaceMap);
                String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, sourceAttributes);
                List<String> directoryListFromFileSystemComponent = (List<String>) jdbcUtility
                        .executeSelectQuery(query, dataSource.getConnection(), true, new ColumnListHandler());

                Object dataplace_id = HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID);
                Object dataplace_component_type_id = HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID);
                Object is_active = HashMapUtility.get(sourceAttributes, CrawlerCommon.IS_ACTIVE);
                Object is_sensitive = HashMapUtility.get(sourceAttributes, CrawlerCommon.IS_SENSITIVE);

                List<String> crawlDirectoryList = new ArrayList<>();
                String path = HashMapUtility.getString(sourceAttributes, CrawlerCommon.PATH);
                String directoryName;

                String directory_path = path;

                String source_type = HashMapUtility.getString(sourceAttributes, CrawlerCommon.SOURCE_TYPE);
                if (source_type.equalsIgnoreCase(CrawlerCommon.UNIX) || source_type.equalsIgnoreCase(CrawlerCommon.FTP) || source_type.equalsIgnoreCase(CrawlerCommon.SFTP)) {
                    directoryName = null;
                    directory_path = null;
                    crawlDirectoryList.add(path);

                } else {
                    directoryName = HashMapUtility.getString(sourceAttributes, CrawlerCommon.DIRECTORY_NAME);
                    crawlDirectoryList.add(directoryName);
                }
                for (String directory : crawlDirectoryList) {
                    if (!directoryListFromFileSystemComponent.contains(directory)) {
                        HashMap<String, Object> sourceInputMap = new HashMap<>();
                        sourceInputMap.put(CrawlerCommon.SOURCE_TYPE, source_type);
                        sourceInputMap.put(CrawlerCommon.DATAPLACE_ID, dataplace_id);
                        sourceInputMap.put(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID, dataplace_component_type_id);
                        sourceInputMap.put(CrawlerCommon.DIRECTORY_NAME, directoryName);
                        sourceInputMap.put(CrawlerCommon.ROOT_LOCATION_PATH, path);
                        sourceInputMap.put(CrawlerCommon.IS_ACTIVE, is_active);
                        sourceInputMap.put(CrawlerCommon.IS_SENSITIVE, is_sensitive);
                        sourceInputMap.put(CrawlerCommon.DIRECTORY_PATH, directory_path);
                        String insertQuery = templateRenderer.renderTemplate(templateGroup, CrawlerCommon.INSERT_DIRECTORY, CrawlerCommon.DATA, sourceInputMap);
                        jdbcUtility.executeUpdateQuery(insertQuery, dataSource.getConnection(), true);
                    }
                }

                for (String directory : directoryListFromFileSystemComponent) {
                    if (!crawlDirectoryList.contains(directory)) {
                        HashMap<String, Object> sourceInputMap = new HashMap<>();
                        sourceInputMap.put(CrawlerCommon.DIRECTORY_NAME, directory);
                        sourceInputMap.put(CrawlerCommon.DATAPLACE_ID, dataplace_id);
                        sourceInputMap.put(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID, dataplace_component_type_id);
                        String updateQuery = templateRenderer.renderTemplate(templateGroup, CrawlerCommon.INACTIVE_DIRECTORY, CrawlerCommon.DATA, sourceInputMap);
                        jdbcUtility.executeUpdateQuery(updateQuery, dataSource.getConnection(), true);
                    }
                }
                String querySource = templateRenderer.renderTemplate(templateGroup, CrawlerCommon.GET_CLOUD_SOURCES, CrawlerCommon.DATA, sourceAttributes);
                listOfSources = (List<Map<String, Object>>) jdbcUtility
                        .executeSelectQuery(querySource, dataSource.getConnection(), true, new MapListHandler());
            }
        } catch (Exception e) {
            logger.error(ExceptionUtils.getStackTrace(e));
            insertError(e);
        }
    }

    public String getCredentialsForSource() throws Exception {
        String creds = null;
        try {
            HashMap<String, Object> templateConfigDataplaceMap = HashMapUtility.getMap(crawlerConfigMap, CrawlerCommon.TEMPLATE_CONFIG_CLOUD);
            String templateGroup = HashMapUtility.getString(templateConfigDataplaceMap, CrawlerCommon.TEMPLATEGROUP);
            STTemplateRenderer templateRenderer = STTemplateFactory.getTemplateRenderer(templateConfigDataplaceMap);
            String query = templateRenderer.renderTemplate(templateGroup, CrawlerCommon.GET_CREDS);
            List<Map<String, Object>> credDetails = (List<Map<String, Object>>) jdbcUtility
                    .executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
            Map<String, Object> credDetailsMap = credDetails.get(0);

            HashMap<String, Object> redisConfigMap = new HashMap<>();
            redisConfigMap.put(CrawlerCommon.REDIS_URL, credDetailsMap.get(CrawlerCommon.REDISURL));
            redisConfigMap.put(CrawlerCommon.PASSWORD, credDetailsMap.get(CrawlerCommon.PASSWORD));
            redisConfigMap.put(CrawlerCommon.ENCRYPTED_PASSWORD, credDetailsMap.get(CrawlerCommon.ENCRYPTED_PASSWORD));
            redisConfigMap.put("PrivateKey", credDetailsMap.get("privateKey"));


            HashMap<String, Object> jwtConfigMap = new HashMap<>();
            jwtConfigMap.put(CrawlerCommon.JWT_PUBLIC_KEY, credDetailsMap.get("publickey"));
            jwtConfigMap.put(CrawlerCommon.JWT_PRIVATE_KEY, credDetailsMap.get("privateKey"));
            jwtConfigMap.put(CrawlerCommon.AUTH_CLASS, CrawlerCommon.JWT_HANDLER);
            jwtConfigMap.put(CrawlerCommon.JWTTTL, credDetailsMap.get(CrawlerCommon.JWT_TTL));

            HashMap<String, Object> userdetailsMap = new HashMap<>();
            String userID = credDetailsMap.get(CrawlerCommon.USERID).toString().replace("[", "");
            userID = userID.replace("]", "");
            userdetailsMap.put(CrawlerCommon.USER_ID, userID);
            userdetailsMap.put(CrawlerCommon.PASSWORD, credDetailsMap.get(CrawlerCommon.USER_PASS));

            String credEndPoint = credDetailsMap.get(CrawlerCommon.HOST).toString() + ":" + credDetailsMap.get(CrawlerCommon.PORT).toString() + CrawlerCommon.FORWARD_SLASH + credDetailsMap.get(CrawlerCommon.ENDPOINT);
            AuthTokenGenerator authTokenGenerator = new AuthTokenGenerator();
            String authToken = authTokenGenerator.generateAuthToken(jwtConfigMap, redisConfigMap, userdetailsMap);
            if (authToken == null) {
                logger.error(CrawlerCommon.AUTH_TOKEN_IS_NULL, authToken);
                throw new NullPointerException(CrawlerCommon.AUTH_TOKEN_IS_NULL + authToken);
            } else {
                int credential_id = HashMapUtility.getInteger(sourceAttributes, CrawlerCommon.CREDENTIAL_ID);
                int credential_type_id = HashMapUtility.getInteger(sourceAttributes, CrawlerCommon.CREDENTIAL_TYPE_ID);
                creds = CredentialFetchWebServiceUtil.getCredentials(authToken, credential_id, credential_type_id, credEndPoint);
                if (creds == null) {
                    logger.error(CrawlerCommon.CREDENTIALS_ARE_NOT_APPROPRIATE, creds);
                    throw new NullPointerException(CrawlerCommon.CREDENTIALS_ARE_NOT_APPROPRIATE);
                }
            }
        } catch (Exception e) {
            logger.error(ExceptionUtils.getStackTrace(e));
            throw new Exception(e);
        }
        return creds;
    }

    public void insertError(Exception e) {
        try {
            isErrored = true;
            dataMap1.put(CrawlerCommon.ERROR_MESSAGE, ExceptionUtils.getStackTrace(e).replaceAll("'", "''"));
            String query = templateRenderer.renderTemplate(errorTemplateGroup, CrawlerCommon.INSERT_ERROR, CrawlerCommon.DATA, dataMap1);
            jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
        } catch (Exception ex) {
            logger.error(ExceptionUtils.getStackTrace(ex));
        }
    }

    public void insertSASFileConversionError(Exception e) {
        try {
            dataMap1.put(CrawlerCommon.ERROR_MESSAGE, ExceptionUtils.getStackTrace(e).replaceAll("'", "''"));
            String query = templateRenderer.renderTemplate(errorTemplateGroup, CrawlerCommon.INSERT_ERROR, CrawlerCommon.DATA, dataMap1);
            jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
        } catch (Exception ex) {
            logger.error(ExceptionUtils.getStackTrace(ex));
        }
    }

}