package com.modak.spiderweb;

import com.zaxxer.hikari.HikariDataSource;

import java.util.HashMap;

public interface Crawler extends Runnable {
    void init(HashMap<String, Object> sourceAttributes, HikariDataSource dataSource,
              HashMap<String, Object> runAttributes,
              StagingSchemaPool<Integer> stagingTablePoolReference,
              HashMap<String, Object> crawlerConfigMap);

    void initSourceConnection() throws Exception;

    void connectToSource() throws Exception;

    void doRollBack(HashMap<String, Object> dataMap) throws Exception;

    void doCrawling(HashMap<String, Object> dataMap) throws Exception;

    void doCDC(HashMap<String, Object> dataMap) throws Exception;

    void closeResources() throws Exception;



}
