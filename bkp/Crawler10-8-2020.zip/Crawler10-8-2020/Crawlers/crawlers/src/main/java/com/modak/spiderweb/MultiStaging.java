//package com.modak.spiderweb;
//
//import com.modak.spiderweb.common.CrawlerCommon;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.Map;
//
//public class MultiStaging  implements Runnable{
//    private HashMap<String, Object> clonedDataMap;
//    private Crawler crawler;
//    private Integer resourceID;
//    private MultiStagingSchemaPool<Integer> multiStagingSchemaPool;
//    private Integer mutliStagingSchemaPoolSize;
//    public void init(Crawler crawler ,HashMap<String, Object> clonedDataMap, Integer resourceID,MultiStagingSchemaPool<Integer> multiStagingSchemaPool,Integer mutliStagingSchemaPoolSize){
//        this.clonedDataMap=clonedDataMap;
//        this.crawler=crawler;
//        this.resourceID=resourceID;
//        this.multiStagingSchemaPool=multiStagingSchemaPool;
//        this.mutliStagingSchemaPoolSize=mutliStagingSchemaPoolSize;
//    }
//    public void run(){
//
//        ArrayList<Integer> schemaResources = new ArrayList<Integer>();
//        for (int i = 0; i < mutliStagingSchemaPoolSize; i++) {
//            schemaResources.add(i);
//        }
//        Integer schemaResourceID = getMultiStagingSchemaID(multiStagingSchemaPool);
//        try {
//            clonedDataMap.put(CrawlerCommon.RESOURCE_ID, resourceID + "_" + schemaResourceID);
//            Map map= new HashMap();
//            map= (Map) clonedDataMap.get("sourceAttributes");
//            System.out.println("Schema Names: "+map.get("schema_name")+" ResourceID:"+resourceID+ " MultiID:"+schemaResourceID);
//            crawler.doRollBack(clonedDataMap);
//            crawler.doCrawling(clonedDataMap);
//            crawler.doCDC(clonedDataMap);
//            //isErrored = false;
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            //   logger.info(CrawlerCommon.MULTI_RESOURCE_RELEASED, resourceID + "_" + schemaResourceID);
//            multiStagingSchemaPool.returnStagingSchema(schemaResourceID);
//            clonedDataMap.clear();
//        }
//    }
//
//    public Integer getMultiStagingSchemaID(MultiStagingSchemaPool<Integer> multiStagingSchemaPoolReference) {
//        Integer schemaResourceID;
//        while (true) {
//            schemaResourceID = multiStagingSchemaPoolReference.getStagingSchema();
//            String name = schemaResourceID != null ? CrawlerCommon.MULTI_RESOURCE_ID_IS + schemaResourceID.toString()
//                    : CrawlerCommon.WAITING_FOR_STAGE_TO_ALLOCATE + Thread.currentThread();
//            //logger.info(name);
//            try {
//                Thread.sleep(50);
//            } catch (InterruptedException e) {
//            //    logger.error(ExceptionUtils.getStackTrace(e));
//            }
//            if (schemaResourceID != null) {
//                break;
//            }
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//            //    logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//        return schemaResourceID;
//    }
//
//
//
//}
