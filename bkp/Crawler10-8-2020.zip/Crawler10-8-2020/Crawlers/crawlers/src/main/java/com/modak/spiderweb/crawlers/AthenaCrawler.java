//package com.modak.spiderweb.crawlers;
//
//import com.modak.utils.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.db.DBUtils;
//
//import java.sql.*;
//import java.util.*;
//
//public class AthenaCrawler extends BaseCrawler {
//
//    private static final Logger logger = LogManager.getLogger(AthenaCrawler.class);
//    private Connection sourceConnection;
//
//    @Override
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                HashMap<String, Object> additionalInfo = (HashMap<String, Object>) sourceAttributes.get(CrawlerCommon.ADDITIONAL_INFO);
//                String jdbcDriver = additionalInfo.get(CrawlerCommon.JDBC_DRIVER).toString();
//                sourceAttributes.put(CrawlerCommon.JDBC_DRIVER, jdbcDriver);
//                Class.forName(sourceAttributes.get(CrawlerCommon.JDBC_DRIVER).toString());
//
//                String creds = this.getCredentialsForSource();
//                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
//                String accesskeyid = credentials.get(CrawlerCommon.ACCESS_KEY).toString();
//                if (accesskeyid == null) {
//                    throw new NullPointerException(CrawlerCommon.ACCESS_KEY + CrawlerCommon.IS_NULL);
//                }
//                String secretkey = credentials.get(CrawlerCommon.SECRET_KEY).toString();
//                if (secretkey == null) {
//                    throw new NullPointerException(CrawlerCommon.SECRET_KEY + CrawlerCommon.IS_NULL);
//                }
//
//                HashMap<String, Object> sourceInfo = (HashMap<String, Object>) sourceAttributes.get(CrawlerCommon.SOURCE_INFO_DETAILS);
//                String jdbcURL = (String) sourceAttributes.get(CrawlerCommon.JDBC_URL);
//                String region_athena = (String) sourceInfo.get(CrawlerCommon.REGION);
//                String s3OutputLocation = "s3://" + (String) sourceInfo.get(CrawlerCommon.BUCKET) + "/athena-s3-result/";
//                String awsCredentialProviderClass = CrawlerCommon.AWS_CREDENTIAL_PROVIDER_CLASS;
//                String region = "AwsRegion=" + region_athena;
//                jdbcURL = jdbcURL.replace(CrawlerCommon.REGION, region) + ";";
//                sourceAttributes.put(CrawlerCommon.JDBC_URL, jdbcURL);
//                String databaseName = (String) sourceInfo.get(CrawlerCommon.DATABASE_NAME);
//                sourceAttributes.put(CrawlerCommon.DATABASE_NAME, databaseName);
//
//
//                Properties prop = new Properties();
//                System.setProperty("aws.accesskeyId", accesskeyid);
//                System.setProperty("aws.secretKey", secretkey);
//                prop.setProperty("s3OutputLocation", s3OutputLocation);
//                prop.setProperty("AwsCredentialProviderClass", awsCredentialProviderClass);
//                prop.put("UID", accesskeyid);
//                prop.put("PWD", secretkey);
//                sourceConnection = DriverManager.getConnection(jdbcURL, prop);
//
//                sourceConnection = DriverManager.getConnection(jdbcURL, prop);
//                if (sourceConnection == null) {
//                    throw new NullPointerException(CrawlerCommon.SOURCE_CONNECTION_IS_NULL);
//                }
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            try {
//                logger.error(ExceptionUtils.getStackTrace(e));
//                this.insertError(e);
//            } catch (Exception ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        this.getSchemas(sourceConnection);
//    }
//
//    @Override
//    public void doCrawling() {
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//
//                List<Map<String, Object>> list_of_map = null;
//                List<LinkedHashMap<String, Object>> listOfMaps = null;
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = crawlingTemplateMap.get(CrawlerCommon.TEMPLATE_GROUP).toString();
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = dependentMap.get(CrawlerCommon.QUERY_TYPE).toString();
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        String connection_type = HashMapUtility.getString(dependentMap, CrawlerCommon.CONNECTION_TYPE);
//                        if (connection_type.equalsIgnoreCase(CrawlerCommon.SOURCE)) {
//                            if (sourceConnection != null) {
//                                listOfMaps = DBUtils.executeQuery(sourceConnection, query);
////                                if (templateName.equals("query_dba_all_tables")) {
////                                    listOfMaps = updateCountAndEncryption(sourceConnection, listOfMaps);
////                                }
//                                dataMap.put(templateName, listOfMaps);
//                            } else {
//                                logger.error(CrawlerCommon.SOURCE_CONNECTION_OBJECT_IS_NULL);
//                            }
//                        } else {
//                            list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                            dataMap.put(templateName, list_of_map);
//                        }
//
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT_INSERT)) {
//                        HashMap<String, Object> tempMap = (HashMap<String, Object>) templateMap.get(templateName);
//                        String connection_type = HashMapUtility.getString(tempMap, CrawlerCommon.CONNECTION_TYPE);
//                        String selectQueryTemplate = HashMapUtility.getString(tempMap, CrawlerCommon.SELECT_QUERY);
//                        String selectQuery = templateRenderer.renderTemplate(templateGroup, selectQueryTemplate, CrawlerCommon.DATA, dataMap);
//                        String insertQueryTemplate = HashMapUtility.getString(tempMap, CrawlerCommon.INSERT_QUERY);
//                        String insertQuery = templateRenderer.renderTemplate(templateGroup, insertQueryTemplate, CrawlerCommon.DATA, dataMap);
//                        if (connection_type.equalsIgnoreCase(CrawlerCommon.SOURCE_KOSH)) {
//                            jdbcUtility.executeSelectInsertBatchMode(sourceConnection, selectQuery, dataSource.getConnection(), insertQuery, true);
//                        } else {
//                            jdbcUtility.executeSelectInsertBatchMode(dataSource.getConnection(), selectQuery, dataSource.getConnection(), insertQuery, true);
//                        }
//                    } else {
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_ESTIMATED_ROWS)) {
//                            updateCountAndEncryption(sourceConnection, listOfMaps);
//                            if (formats.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery((List<Object[]>) formats, query, dataSource.getConnection(), true);
//                                formats.clear();
//                            }
//                        }
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            try {
//                logger.error(ExceptionUtils.getStackTrace(e));
//                insertError(e);
//            } catch (Exception ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    private List<LinkedHashMap<String, Object>> updateCountAndEncryption(Connection sourceConnection) throws SQLException {
//        Statement st = sourceConnection.createStatement();
//
//
//        List<String> tables =select table_name from informatin_schema.tables limit 1000 offset  where
//
//        ResultSet rs = st.executeQuery("select count(*) from " + sourceAttributes.get(CrawlerCommon.SCHEMA_NAME).toString() + "." + listOfMap.get("table_name").toString());
//            while (rs.next()) {
//                listOfMap.put("estimated_rows", rs.getString(1));
//            }
//            ResultSet rs2 = st.executeQuery("SHOW TBLPROPERTIES " + listOfMap.get("table_owner").toString() + "." + listOfMap.get("table_name").toString());
//            while (rs2.next()) {
//                listOfMap.put("is_encrypted", rs2.getString(2));
//            }
//        }
//        return listOfMaps;
//    }
//
//    @Override
//    public void closeResources() {
//        if (sourceConnection != null) {
//            try {
//                sourceConnection.close();
//            } catch (SQLException e) {
//                logger.error(e.getMessage(), e);
//                e.printStackTrace();
//            }
//        }
//    }
//}
