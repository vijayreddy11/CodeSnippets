package com.modak.components.scheduler;

import com.modak.components.Common.BotCommon;
//import botworld.messagebus.mqtt.BaseComponent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

public class JobSchedulerStatusPublisher {
    protected ConcurrentLinkedQueue<HashMap> messages = new ConcurrentLinkedQueue();

    private static final Logger logger = LogManager.getLogger(JobSchedulerStatusPublisher.class);
    private static JobSchedulerStatusPublisher jobSchedulerStatusPublisher = null;
    private static boolean isInitialized = false;
    private String outputTopic = null;

    private JobSchedulerStatusPublisher() {

    }

    public synchronized static JobSchedulerStatusPublisher getJobSchedulerStatusPublisher() throws Exception {
        if (jobSchedulerStatusPublisher == null) {
            throw new Exception("JobStatusMessagePublisher not initialized call init first");
        }
        return jobSchedulerStatusPublisher;
    }


    public ArrayList<String> getClientTopics() {
        ArrayList<String> retval = new ArrayList<String>();
        return retval;
    }

    protected long getSleepInterval() {
        return BotCommon.DEFAULT_LONG_SLEEP;
    }


    public void publish(HashMap<String, Object> msg) {
        addMessage(msg);

    }

    protected void addMessage(HashMap msg) {
        messages.add(msg);
    }

}
