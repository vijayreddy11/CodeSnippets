package com.modak.components.scheduler;

import com.modak.components.Common.BotCommon;
import com.modak.components.base.MessageUtils;
import com.modak.utils.compression.StringCompression;
import com.modak.utils.encryption.EncryptionUtils;
import com.modak.utils.encryption.RSAEncryptionUtils;
import com.modak.components.Common.CPCommon;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import com.modak.utility.HashMapUtility;
import com.modak.utility.KafkaUtility;
import com.modak.utility.MiscUtility;
import com.modak.utility.json.JSONUtility;
import com.modak.utility.st.STTemplateFactory;
import com.modak.utility.st.STTemplateRenderer;

import java.security.PublicKey;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;

public class JobMessagesPublisher implements Job {

    private static final Logger logger = LogManager.getLogger(JobMessagesPublisher.class);
    KafkaProducer producer = null;

    public static synchronized long generateLongNumber() {
        SimpleDateFormat f = new SimpleDateFormat(CPCommon.DATE_FORMAT);
        return Long.parseLong(f.format(new Date()));
    }

    public void execute(JobExecutionContext jobExecutionContext) {
        try {
            JobDataMap jobDataMap = jobExecutionContext.getJobDetail().getJobDataMap();
            Map sourceDataMap = jobDataMap.getWrappedMap();
            HashMap<String, Object> sourceMap = (HashMap<String, Object>) sourceDataMap.get(CPCommon.DATA);
            String configFileLocation = jobDataMap.get(CPCommon.CONFIG_FILE_PATH).toString();
            publishInitialStartMessage(sourceMap, configFileLocation);
            if (jobExecutionContext.getNextFireTime() != null) {
                logger.info("job : {} has scheduled to run next at: " + jobExecutionContext.getNextFireTime(),
                        HashMapUtility.getString(sourceMap, CPCommon.JOB_KEY));
                logger.info("job : {} has scheduled to run next at: " + jobExecutionContext.getNextFireTime(),
                        HashMapUtility.getString(sourceMap, CPCommon.JOB_KEY));
            }
        } catch (Exception e) {
            logger.error("failed to publish message ", e);
        } finally {
            try {
                if (producer != null) {
                    producer.close();
                }
            } catch (Exception e) {
                logger.error("Failed to close producer ", e);
            }
        }
    }

    public void publishInitialStartMessage(HashMap<String, Object> dataMap, String configFileLocation) {
        try {
            HashMap<String, Object> configMap = JSONUtility.loadJSONFile(configFileLocation);
            HashMap<String, Object> templateConfigMap = HashMapUtility.getMap(configMap, CPCommon.TEMPLATE_CONFIG);
            String templateGroup = HashMapUtility.getString(dataMap, CPCommon.OUTPUT_TEMPLATE_GROUP);
            String templateName = HashMapUtility.getString(dataMap, CPCommon.OUTPUT_TEMPLATE_NAME);
            Object jobMetadataObj = HashMapUtility.get(dataMap, CPCommon.JOB_METADATA);
            if (jobMetadataObj != null) {
                HashMap<String, Object> jobMetadataMap = JSONUtility.jsonToMap(jobMetadataObj.toString());
                dataMap.put(CPCommon.JOB_METADATA_MAP, jobMetadataMap);
            }
            STTemplateRenderer templateRenderer = STTemplateFactory.getTemplateRenderer(templateConfigMap);
            Long suffix = HashMapUtility.getLong(dataMap, CPCommon.JOB_SPEC_ID);
            String jobId = generateLongNumber() + suffix.toString();
            dataMap.put(BotCommon.KEY_JOB_ID, Long.valueOf(jobId));
            dataMap.put(BotCommon.UNIQUE_ID, MessageUtils.generateId());

            HashMap<String, Object> kafkaConfigMap = HashMapUtility.getMap(configMap, CPCommon.KAFKA_CONFIG);
            publishInitialBotMessage(templateGroup, templateName, templateRenderer, dataMap, kafkaConfigMap);
            ArrayList<String> messages = new ArrayList<String>();
            HashMap<String, Object> inputMap = new HashMap<String, Object>();
            inputMap.put(BotCommon.KEY_BOT_NAME, BotCommon.SCHEDULER);
            inputMap.put(BotCommon.KEY_BOT_UUID, UUID.nameUUIDFromBytes(BotCommon.SCHEDULER.getBytes()).toString());

            HashMap<String, Object> jobMetadata = new HashMap<String, Object>();
            jobMetadata.put(BotCommon.KEY_JOB_ID, HashMapUtility.getLong(dataMap, BotCommon.KEY_JOB_ID));
            jobMetadata.put(BotCommon.KEY_JOB_NAME, HashMapUtility.getString(dataMap, BotCommon.KEY_JOB_NAME));
            jobMetadata.put(BotCommon.KEY_JOB_DESCRIPTION, HashMapUtility.getString(dataMap, BotCommon.KEY_JOB_DESCRIPTION));
            jobMetadata.put(BotCommon.KEY_TYPE_OF_JOB, HashMapUtility.getString(dataMap, BotCommon.KEY_TYPE_OF_JOB));
            jobMetadata.put(BotCommon.KEY_FUNCTIONAL_ID, HashMapUtility.getString(dataMap, BotCommon.KEY_FUNCTIONAL_ID));

            String jobStatusMessage = MessageUtils.buildJobStatusMessage(BotCommon.JobStatus.STARTED, jobMetadata, inputMap);
            HashMap<String, Object> jobStatusMessageMap = JSONUtility.jsonToMap(jobStatusMessage);
            JobSchedulerStatusPublisher.getJobSchedulerStatusPublisher().publish(jobStatusMessageMap);
        } catch (Exception e) {
            logger.error("Failed to publish initial message", e);
        }
    }

    public void publishInitialBotMessage(String templateGroup, String templateName, STTemplateRenderer templateRenderer,
                                         HashMap<String, Object> dataMap,
                                         HashMap<String, Object> kafkaConfigMap) throws Exception {
        KafkaProducer kafkaProducer = null;
        try {
            KafkaUtility kafkaUtility = new KafkaUtility();
            kafkaProducer = kafkaUtility.createKafkaProducer(kafkaConfigMap);
            HashMap<String, Object> currentMetadataMap = new HashMap<String, Object>();
            currentMetadataMap.put(BotCommon.MESSAGE_UUID, UUID.randomUUID().toString());
            currentMetadataMap.put(BotCommon.CURRENT_TIMESTAMP, Timestamp.from(Instant.now()));
            currentMetadataMap.put(BotCommon.UNIQUE_ID, MessageUtils.generateId());

            HashMap<String, Object> templateInputs = new HashMap<String, Object>();
            templateInputs.put(BotCommon.DATA, dataMap);
            templateInputs.put(BotCommon.CURRENT_METADATA, currentMetadataMap);

            String outputMessage = templateRenderer.renderTemplate(templateGroup, templateName, templateInputs);
            logger.info("output message : {}", MiscUtility.formatString(outputMessage, true));
            HashMap<String, Object> outputMessageMap = JSONUtility.jsonToMap(outputMessage);
            String outputMessageTopic = HashMapUtility.getString(outputMessageMap, BotCommon.MESSAGE_TOPIC_KEY);
            byte[] compressedBytes = StringCompression.compressUsingGZIP(outputMessage);
            String encryptKeyPath = HashMapUtility.getString(kafkaConfigMap, BotCommon.PUBLIC_KEY);
            PublicKey publicKey = RSAEncryptionUtils.getPublicKey(encryptKeyPath);
            byte[] encryptedBytes = EncryptionUtils.encryptLargeByteArrayUsingRSA(compressedBytes, publicKey);
            kafkaProducer.send(new ProducerRecord(String.valueOf(outputMessageTopic), encryptedBytes));
            logger.info("Published message");
        } catch (Exception e) {
            logger.info("Failed to publish message ", e);
        } finally {
            try {
                if (kafkaProducer != null) {
                    kafkaProducer.close();
                }
            } catch (Exception e) {
                logger.error("Failed to close kafka producer ", e);
            }
        }
    }

//    private void publishStatusMessages(ArrayList<String> brokers,ArrayList<String> messages,String topic,
//                                       String vaultConfig,String vaultKey) throws Exception{
//        if(brokers!=null && brokers.size()>0){
//            for(String broker:brokers){
//                String id=UUID.randomUUID().toString();
//                MqttClient client;
//                try {
//                    ISecretVault secretVault = new VaultUtility();
//                    secretVault.init(JSONUtility.loadJSONFile(vaultConfig));
//                    HashMap<String, Object> vaultHMap = new HashMap<String, Object>(secretVault.getCredentialsMap(vaultKey));
//                    String uid = HashMapUtility.getNonEmptyString(vaultHMap, BotCommon.USER_NAME);
//                    String pwd = HashMapUtility.getNonEmptyString(vaultHMap, BotCommon.PASSWORD);
//
//                    client = new MqttClient(broker, id);
//                    MqttConnectOptions opts = MqttConnectOptions();
//                    opts.setUserName(uid);
//                    opts.setPassword(pwd.toCharArray());
//                    opts.setCleanSession(true);
//                    MemoryPersistence persist = new MemoryPersistence();
//                    persist.open(id, broker);
//                    client.connect(opts);
//
//                    for (String msg : messages) {
//                        MqttMessage message = new MqttMessage();
//                        message.setPayload(msg.getBytes());
//                        client.publish(topic, message);
//                        logger.info("published message on topic {} {} : {} ", broker, topic, message);
//                    }
//                    client.disconnect();
//                    break;
//                }catch(Exception e){
//                    logger.error("failed to publish message on broker {}", broker ,e);
//                }
//            }
//        }
//        else{
//            throw new Exception("no brokers available");
//        }
//    }
}