package com.modak.utility;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;


public class MapUtils {


    private MapUtils() {
        //Private Constructor
    }

    private static final Logger logger = LogManager.getLogger(MapUtils.class.getSimpleName());

    /**
     * The key can be a multilevel key e.g. "data.address".
     *
     * @param sourceMap
     * @param key
     * @return the HashMap based on a key. Null if the element is not found or is not of the type HashMap
     */
    public static HashMap<String, Object> getMap(HashMap<String, Object> sourceMap, String key) {
        if (sourceMap == null) {
            logger.warn(UtilConfig.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(UtilConfig.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof HashMap) {

            return (HashMap<String, Object>) sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.tags".
     *
     * @param sourceMap
     * @param key
     * @return the ArrayList based on a key. Null if the element is not found or is not of the type ArrayList
     */
    public static ArrayList getArrayList(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(UtilConfig.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(UtilConfig.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof ArrayList) {

            return (ArrayList) sourceMap.get(parts[i]);

        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.name".
     *
     * @param sourceMap
     * @param key
     * @return the String based on a key. Null if the element is not found or is not of the type String
     */
    public static String getString(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(UtilConfig.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(UtilConfig.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof String) {

            return (String) sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.age".
     *
     * @param sourceMap
     * @param key
     * @return the String based on a key. Null if the element is not found or is not of the type Integer
     */
    public static Integer getInteger(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(UtilConfig.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(UtilConfig.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }

        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof Integer) {

            return (Integer) sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.income".
     *
     * @param sourceMap
     * @param key
     * @return the String based on a key. Null if the element is not found or is not of the type Long
     */
    public static Long getLong(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(UtilConfig.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(UtilConfig.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (!sourceMap.containsKey(parts[i])) {
            logger.error("Unable to find key " + parts[i] + " in provided input map " + sourceMap);
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof Long) {

            return (Long) sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.fetch".
     *
     * @param sourceMap
     * @param key
     * @return the String based on a key. Null if the element is not found or is not of the type Boolean
     */
    public static Boolean getBoolean(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(UtilConfig.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(UtilConfig.KEY_IS_NULL);
            return null;

        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null && sourceMap.get(parts[i]) instanceof Boolean) {
            return (Boolean) sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.phone".
     *
     * @param sourceMap
     * @param key
     * @return the Object based on a key. Null if the element is not found
     */
    public static Object get(HashMap<String, Object> sourceMap, String key) throws Exception {
        if (sourceMap == null) {
            logger.warn(UtilConfig.INPUT_MAP_IS_NULL);
            return null;
        }
        if (key == null) {
            logger.warn(UtilConfig.KEY_IS_NULL);
            return null;
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap.get(parts[i]) != null) {
            return sourceMap.get(parts[i]);
        }
        return null;
    }

    /**
     * The key can be a multilevel key e.g. "data.id".
     *
     * @param sourceMap
     * @param key
     * @param value
     * @return the Object based on a key. Null if the element is not found
     */
    public static void put(HashMap<String, Object> sourceMap, String key, Object value) throws Exception {
        if (sourceMap == null) {
            logger.warn(UtilConfig.INPUT_MAP_IS_NULL);

        }
        if (key == null) {
            logger.warn(UtilConfig.KEY_IS_NULL);
        }
        String[] parts = key.split("\\.");
        int i = 0;
        while (i < parts.length - 1) {
            sourceMap = getMap(sourceMap, parts[i]);
            i++;
        }
        if (sourceMap != null) {
            sourceMap.put(parts[i], value);
        } else {
            logger.warn("Parent maps not found");
        }
    }
}