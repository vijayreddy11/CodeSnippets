package com.modak.utility.exception;

public class UnAuthorizedServiceException extends Exception {
    public UnAuthorizedServiceException(String message)
    {
        super(message);
    }
}
