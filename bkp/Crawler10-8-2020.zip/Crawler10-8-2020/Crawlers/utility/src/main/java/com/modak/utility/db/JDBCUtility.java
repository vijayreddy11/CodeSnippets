package com.modak.utility.db;

import com.modak.utility.UtilityCommon;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.*;

public class JDBCUtility {
    private static Logger logger = LoggerFactory.getLogger(JDBCUtility.class);

    public <T> T executeSelectQuery(String query, Connection connection, boolean closeConnection, QueryRunner queryRunner,
                                    ResultSetHandler<T> rsh) throws Exception {
        T output;
        try {
            output = queryRunner.query(connection, query, rsh);
        } catch (Exception e) {
            throw new Exception(UtilityCommon.QUERY_EXECUTION_ERROR, e);
        } finally {
            if (closeConnection && connection != null) {
                closeConnection(connection);
            }
        }
        return output;
    }

    public <T> T executeSelectQuery(String query, Connection connection, boolean closeConnection, ResultSetHandler<T> rsh) throws Exception {
        return executeSelectQuery(query, connection, closeConnection, new QueryRunner(), rsh);
    }

    public <T> T executeSelectQuery(String query, HikariDataSource hikariDataSource, ResultSetHandler<T> rsh) throws Exception {
        Connection connection = hikariDataSource.getConnection();
        return executeSelectQuery(query, connection, true, new QueryRunner(), rsh);
    }

    public int executeUpdateQuery(String query, Connection connection, boolean closeConnection) throws Exception {
        QueryRunner queryRunner = new QueryRunner();
        int affected_rows;
        try {
            logger.debug("query:" + query);
            affected_rows = queryRunner.update(connection, query);
        } catch (Exception e) {
            throw new Exception(UtilityCommon.QUERY_EXECUTION_ERROR, e);
        } finally {
            if (closeConnection && connection != null) {
                closeConnection(connection);
            }
        }
        return affected_rows;
    }

    public int executeUpdateQuery(String query, HikariDataSource hikariDataSource) throws Exception {
        Connection connection = hikariDataSource.getConnection();
        return executeUpdateQuery(query, connection, true);
    }

    public int[] executeBatchUpdateQuery(Object[][] objects, String query, Connection connection, boolean closeConnection) throws Exception {
        QueryRunner queryRunner = new QueryRunner();
        int[] affected_rows_count_array;
        try {
            affected_rows_count_array = queryRunner.batch(connection, query, objects);
        } catch (Exception e) {
            throw new Exception(UtilityCommon.QUERY_EXECUTION_ERROR, e);
        } finally {
            if (closeConnection && connection != null) {
                closeConnection(connection);
            }
        }
        return affected_rows_count_array;
    }

    public void executeSelectInsertBatchMode(Connection sourceConnection, String sourceSelectQuery, Connection destinationConnection, String destinationInsertQuery, boolean closeConnection) throws Exception {
        ModakQueryRunner queryRunner = new ModakQueryRunner();
        queryRunner.executeSelectInsertBatchMode(sourceConnection, sourceSelectQuery, destinationConnection, destinationInsertQuery, closeConnection);

    }


    public int[] executeBatchUpdateQuery(Object[][] objects, String query, HikariDataSource hikariDataSource) throws Exception {
        Connection connection = hikariDataSource.getConnection();
        return executeBatchUpdateQuery(objects, query, connection, true);
    }

    public int[] executeBatchUpdateQuery(ArrayList<ArrayList<Object>> objects, String query, Connection connection, boolean closeConnection) throws Exception {
        int i = 0;
        Object[][] objectsArray = new Object[objects.size()][];
        for (List each_file_metadata : objects) {
            Object[] eachObject = each_file_metadata.toArray();
            objectsArray[i] = eachObject;
            i++;
        }
        return executeBatchUpdateQuery(objectsArray, query, connection, closeConnection);
    }

    public int[] executeBatchUpdateQuery(List<Object[]> objects, String query, Connection connection, boolean closeConnection) throws Exception {
        int i = 0;
        Object[][] objectsArray = new Object[objects.size()][];
        for (Object[] row : objects) {
            objectsArray[i++] = row;
        }
        return executeBatchUpdateQuery(objectsArray, query, connection, closeConnection);
    }

    public int[] executeBatchUpdateQuery(ArrayList<ArrayList<Object>> objects, String query, HikariDataSource hikariDataSource) throws Exception {
        Connection connection = hikariDataSource.getConnection();
        return executeBatchUpdateQuery(objects, query, connection, true);
    }

//    public void executeNamedParameterInsertQuery(Connection conn, boolean closeConnection, String query, HashMap<String,Object> params) throws Exception{
//        if(conn==null){
//            throw new NullPointerException(UtilityCommon.NULL_CONNECTION);
//        }
//        if(query==null){
//            if(closeConnection){
//                conn.close();
//            }
//            throw new NullPointerException(UtilityCommon.NULL_SQL_STATEMENT);
//        }
//        NamedParameterStatement nps=null;
//        try{
//            nps=new NamedParameterStatement(conn,query);
//            if(params!=null && params.size()>0){
//                for(Map.Entry<String,Object> inputParam: params.entrySet()){
//                    nps.setObject(inputParam.getKey(),inputParam.getValue());
//                }
//            }
//            nps.execute();
//        }
//        catch(Exception e){
//            throw new Exception(UtilityCommon.QUERY_EXECUTION_ERROR,e);
//        }
//        finally {
//            if(nps!=null){
//                nps.close();
//            }
//            if(closeConnection){
//                closeConnection(conn);
//            }
//        }
//    }
//
//    public void executeNamedParameterInsertQuery(HikariDataSource hikariDataSource,String query,HashMap<String,Object> params) throws Exception{
//        Connection connection=hikariDataSource.getConnection();
//        executeNamedParameterInsertQuery(connection,true,query,params);
//    }
//
//    public String executeParentChildRelationQuery(String inputJson,HikariDataSource hikariDataSource,HashMap<String,Object> templateConfigMap) throws Exception{
//        HashMap<String,Object> inputMap= JSONUtility.jsonToMap(inputJson);
//        ParentChildQueryUtil parentChildQueryUtil=new ParentChildQueryUtil(hikariDataSource,templateConfigMap);
//        List<Map<String,Object>> outputsMap=parentChildQueryUtil.executeParentChildRelationQuery(inputMap);
//        return JSONUtility.object2JsonString(MiscUtility.purifySingletonList(outputsMap));
//    }

    public void closeConnection(Connection connection) {
        try {
            connection.close();
        } catch (Exception e) {
            logger.info("failed to close connection", e);
        }
    }

    public List<Object[]> convertToObjectArray(List<HashMap<String, Object>> dataMapList) {
        List<Object[]> list_of_object_array = new ArrayList<Object[]>();
        for (int i = 0; i < dataMapList.size(); i++) {
            Collection<Object> values = dataMapList.get(i).values();
            list_of_object_array.add(values.toArray());
        }
        return list_of_object_array;
    }

    public void executeBatchUpdateQuery(HashMap<String, Object> dataMap, List<String> dependencykeyList, String query, Connection connection, boolean closeConnection) throws Exception {
        List<Object[]> list_of_objects_array = new ArrayList();
        if (dependencykeyList != null) {
            for (int i = 0; i < dependencykeyList.size(); i++) {
                list_of_objects_array.addAll(convertToObjectArray((List) dataMap.get(dependencykeyList.get(i))));
            }
            executeBatchUpdateQuery(list_of_objects_array, query, connection, closeConnection);
        }
    }

    public int[] executeBatchUpdateQuery(ArrayList<Map<String, Object>> mapListObjects, ArrayList<String> columnKeys, String query, HikariDataSource hikariDataSource) throws Exception {
        Object[][] objects = new Object[mapListObjects.size()][];
        int i = 0;
        while (i < mapListObjects.size()) {
            Object[] object = new Object[columnKeys.size()];
            Map<String, Object> map = mapListObjects.get(i);
            int j = 0;
            while (j < columnKeys.size()) {
                String columnKey = columnKeys.get(j);
                object[j] = map.get(columnKey);
                j++;
            }
            objects[i] = object;
            i++;
        }
        Connection connection = hikariDataSource.getConnection();
        return executeBatchUpdateQuery(objects, query, connection, true);
    }

//    public List<Object[]> executeInsertQuery(String query,HashMap<String,Object> dataMap,ArrayList<String> columns,HikariDataSource hikariDataSource)throws Exception{
//        Connection connection=null;
//        try{
//            Object[] dataArray=new Object[columns.size()];
//            int j=0;
//            while(j<columns.size()){
//                String columnKey=columns.get(j);
//                dataArray[j]=dataMap.get(columnKey);
//                j++;
//            }
//            QueryRunner queryRunner=new QueryRunner();
//            connection=hikariDataSource.getConnection();
//            logger.debug("query :" +query);
//            List<Object[]> output=queryRunner.insert(connection,query,new ArrayListHandler(),dataArray);
//            return output;
//        }
//        catch(Exception e){
//            throw new Exception("failed to execute insert query",e);
//        }
//        finally {
//            if(connection!=null){
//                closeConnection(connection);
//            }
//        }
//    }
}
