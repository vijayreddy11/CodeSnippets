package com.modak.utility.exception;

public class AuthException extends Exception {
    /**
     * This constructor defines the Bot specific Exception with String mesg as a Error message information
     *
     * @param mesg
     */
    public AuthException(String mesg) {
        super(mesg);
    }

    /**
     * This constructor defines the Bot speccific Exception with Throwable mesg object as a Error message information
     *
     * @param mesg
     */
    public AuthException(Throwable mesg) {
        super(mesg);
    }

    public AuthException(String mesg, Throwable exec) {
        super(mesg);
    }
}
