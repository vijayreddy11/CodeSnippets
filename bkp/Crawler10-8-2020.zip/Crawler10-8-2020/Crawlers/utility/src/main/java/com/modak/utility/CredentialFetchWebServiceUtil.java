package com.modak.utility;

import java.util.HashMap;
import java.util.Map;

import com.modak.utility.json.JSONUtils;

public class CredentialFetchWebServiceUtil {

    public static String getCredentials(String token, int credential_id, int credential_type_id, String end_point) {
        try {
            HashMap<String, String> headerMap = new HashMap<>();
            headerMap.put("Authorization", token);
            headerMap.put("Content-Type", "text/plain");
            headerMap.put("Accept", "application/json");
            HashMap payload = new HashMap();
            payload.put("credential_id", credential_id);
            payload.put("credential_type_id", credential_type_id);
            Map<String, Object> reponse = UniRestUtil.postRequestHandler(end_point, headerMap, JSONUtils.object2JsonString(payload), "JSON");
            return JSONUtils.object2JsonString(JSONUtils.jsonToMap(reponse.get("response").toString()).get("data"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
