package com.modak.utility;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroupFile;
import org.stringtemplate.v4.STGroupString;
import org.stringtemplate.v4.StringRenderer;

import java.util.HashMap;

public class StringTemplateUtility {
    private static Logger logger = LoggerFactory.getLogger(StringTemplateUtility.class);

    public static String renderTemplate(String templateGroupName, String templateName, String attributeName, Object inputMap) {
        STGroupFile stfile = new STGroupFile(templateGroupName, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        stfile.getImportedGroups();
        stfile.registerRenderer(String.class, new StringRenderer());
        ST temp = stfile.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + " " + stfile.getFileName());
        }
        temp.add(attributeName, inputMap);
        return temp.render();
    }

    public static String renderTemplate(String templateGroupName, String templateName, HashMap<String, Object> templateInputs) {
        STGroupFile stfile = new STGroupFile(templateGroupName, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        stfile.registerRenderer(String.class, new StringRenderer());
        ST temp = stfile.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + " " + stfile.getFileName());
        }
        if (templateInputs != null && templateInputs.size() > 0) {
            for (String attributeName : templateInputs.keySet()) {
                temp.add(attributeName, templateInputs.get(attributeName));
            }
        }
        return temp.render();
    }

    public static String renderTemplate(String templateGroupName, String templateName) {
        return renderTemplate(templateGroupName, templateName, null);
    }

    public static String renderTemplate2(String templateGroupName, String templateName, HashMap<String, Object> groupStrings, String attributeName, Object inputMap) {
        STGroupFile stfile = new STGroupFile(templateGroupName, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        stfile.registerRenderer(String.class, new StringRenderer());
        ST temp = stfile.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + " " + stfile.getFileName());
        }
        temp.add(attributeName, inputMap);
        return temp.render();
    }

    public static String renderTemplate2(String templateGroupName, String templateName, HashMap<String, Object> groupStrings, HashMap<String, Object> templateInputs) {
        STGroupFile stfile = new STGroupFile(templateGroupName, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        stfile.registerRenderer(String.class, new StringRenderer());
        ST temp = stfile.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + " " + stfile.getFileName());
        }
        if (templateInputs != null && templateInputs.size() > 0) {
            for (String attributeName : templateInputs.keySet()) {
                temp.add(attributeName, templateInputs.get(attributeName));
            }
        }
        return temp.render();
    }

    public static String renderGroupStringTemplate(String sourceName, String templateString, String templateName, String attributeName, Object inputMap) {
        STGroupString stGroupString = new STGroupString(sourceName, templateString, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        stGroupString.registerRenderer(String.class, new StringRenderer());
        ST temp = stGroupString.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + " " + stGroupString.getFileName());
        }
        temp.add(attributeName, inputMap);
        return temp.render();
    }

    public static String renderGroupStringTemplate(String sourceName, String templateString, String templateName, HashMap<String, Object> templateInputs) {
        STGroupString stGroupString = new STGroupString(sourceName, templateString, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        stGroupString.registerRenderer(String.class, new StringRenderer());
        ST temp = stGroupString.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + " " + stGroupString.getFileName());
        }
        if (templateInputs != null && templateInputs.size() > 0) {
            for (String attributeName : templateInputs.keySet()) {
                temp.add(attributeName, templateInputs.get(attributeName));
            }
        }
        return temp.render();
    }

    public static String renderGroupStringTemplate2(String groupName, String templateName, String attributeName, Object inputMap, HashMap<String, Object> stTemplateGroups) throws Exception {
        String templateString = stTemplateGroups.get(groupName) != null ? stTemplateGroups.get(groupName).toString() : null;
        return renderGroupStringTemplate(groupName, templateString, templateName, attributeName, inputMap);
    }

    public static String renderGroupStringTemplate2(String groupName, String templateName, HashMap<String, Object> templateInputs, HashMap<String, Object> stTemplateGroups) throws Exception {
        String templateString = stTemplateGroups.get(groupName) != null ? stTemplateGroups.get(groupName).toString() : null;
        return renderGroupStringTemplate(groupName, templateString, templateName, templateInputs);
    }

    public static String renderGroupStringTemplate2(String groupName, String templateName, HashMap<String, Object> stTemplateGroups) throws Exception {
        String templateString = stTemplateGroups.get(groupName) != null ? stTemplateGroups.get(groupName).toString() : null;
        return renderGroupStringTemplate(groupName, templateString, templateName, null);
    }

    public static String renderTemplateFromTemplateString(String sourceName, String templateString, String templateName, String attributeName, Object inputMap) {
        STGroupString stGroupString = new STGroupString(sourceName, templateString, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        ST temp = stGroupString.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + " " + stGroupString.getFileName());
        }
        temp.add(attributeName, inputMap);
        return temp.render();
    }

    public static String renderTemplateFromTemplateString(String sourceName, String templateString, String templateName, HashMap<String, Object> templateInputs) {
        STGroupString stGroupString = new STGroupString(sourceName, templateString, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        stGroupString.registerRenderer(String.class, new StringRenderer());
        ST temp = stGroupString.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + " " + stGroupString.getFileName());
        }
        if (templateInputs != null && templateInputs.size() > 0) {
            for (String attributeName : templateInputs.keySet()) {
                temp.add(attributeName, templateInputs.get(attributeName));
            }
        }
        return temp.render();
    }

    public static String renderTemplateFromTemplateString(String sourceName, String templateString, String templateName) {
        return renderTemplate(sourceName, templateString, templateName, null);
    }
}