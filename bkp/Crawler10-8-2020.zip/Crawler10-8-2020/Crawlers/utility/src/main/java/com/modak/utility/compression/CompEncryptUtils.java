package com.modak.utility.compression;

import com.modak.utils.compression.ByteArrayCompression;
import com.modak.utils.compression.StringCompression;
import com.modak.utils.encryption.EncryptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.PrivateKey;
import java.security.PublicKey;

public class CompEncryptUtils {
    private static final Logger logger = LoggerFactory.getLogger(CompEncryptUtils.class);

    public static byte[] compressAndEncryptString(String botMessage, PublicKey publicKey) throws Exception {
        if (botMessage != null && publicKey != null) {
            byte[] compressedBytes = StringCompression.compressUsingGZIP(botMessage);
            return EncryptionUtils.encryptLargeByteArrayUsingRSA(compressedBytes, publicKey);
        }
        return null;
    }

    public static String decryptAndUncompressString(byte[] encryptedBytes, PrivateKey privateKey) throws Exception {
        if (encryptedBytes != null && privateKey != null) {
            byte[] decryptedBytes = EncryptionUtils.decryptLargeByteArrayUsingRSA(encryptedBytes, privateKey);
            return StringCompression.uncompressUsingGZIP(decryptedBytes);
        }
        return null;
    }

    public static byte[] compressAndEncryptByteArray(byte[] botMessage, PublicKey publicKey) throws Exception {
        if (botMessage != null && publicKey != null) {
            byte[] compressedBytes = ByteArrayCompression.compressUsingGZIP(botMessage);
            return EncryptionUtils.encryptLargeByteArrayUsingRSA(compressedBytes, publicKey);
        }
        return null;
    }

    public static byte[] decryptAndUncompressByteArray(byte[] encryptedBytes, PrivateKey privateKey) throws Exception {
        if (encryptedBytes != null && privateKey != null) {
            byte[] decryptedBytes = EncryptionUtils.decryptLargeByteArrayUsingRSA(encryptedBytes, privateKey);
            return ByteArrayCompression.uncompressUsingGZIP(decryptedBytes);
        }
        return null;
    }
}