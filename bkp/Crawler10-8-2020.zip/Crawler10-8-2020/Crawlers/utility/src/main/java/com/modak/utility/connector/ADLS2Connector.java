package com.modak.utility.connector;

import com.azure.core.http.rest.PagedIterable;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.common.StorageSharedKeyCredential;
import com.azure.storage.file.datalake.DataLakeFileSystemClient;
import com.azure.storage.file.datalake.DataLakeServiceClientBuilder;
import com.azure.storage.file.datalake.models.ListPathsOptions;
import com.azure.storage.file.datalake.models.PathItem;
import com.modak.utility.HashMapUtility;
import com.modak.utility.UtilityCommon;

import java.util.HashMap;
import java.util.Iterator;

public class ADLS2Connector {
    private static final String ROOT_PATH = UtilityCommon.FILE_SEPARATOR;

    public DataLakeFileSystemClient getDataLakeFileSystemClient(HashMap<String, String> azureDataLakeCredMap, String containerName) throws Exception {
        try {
            String accountKey = azureDataLakeCredMap.get(UtilityCommon.ACCOUNT_KEY);
            String accountName = azureDataLakeCredMap.get(UtilityCommon.ACCOUNT_NAME);
            StorageSharedKeyCredential sharedKeyCredential = new StorageSharedKeyCredential(accountName, accountKey);
            DataLakeServiceClientBuilder builder = new DataLakeServiceClientBuilder();
            builder.credential(sharedKeyCredential);
            builder.endpoint(UtilityCommon.HTTPS + accountName + UtilityCommon.DFS_CORE_WINDOWS_NET);
            return builder.buildClient().getFileSystemClient(containerName);
        } catch (Exception e) {
            throw new Exception(e);
        }
    }


    public BlobClient getBlobClient(HashMap<String, Object> sourceAttributes, String filePath) throws Exception {
        try {
            String accountName = HashMapUtility.getString(sourceAttributes, UtilityCommon.ACCOUNT_NAME);
            String accountKey = HashMapUtility.getString(sourceAttributes, UtilityCommon.ACCOUNT_KEY);
            String connectStr = "DefaultEndpointsProtocol=https;AccountName=" + accountName + ";AccountKey=" + accountKey + ";EndpointSuffix=core.windows.net";
            BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().connectionString(connectStr).buildClient();
            BlobContainerClient blobContainerClient = blobServiceClient.getBlobContainerClient(accountName);
            return blobContainerClient.getBlobClient(filePath);
        } catch (Exception e) {
            throw new Exception(e);
        }
    }

    public void checkConnectionStatus(DataLakeFileSystemClient dataLakeFileSystemClient) throws Exception {
        try {
            ListPathsOptions options = new ListPathsOptions();
            options.setPath(ROOT_PATH);
            PagedIterable<PathItem> pagedIterable = dataLakeFileSystemClient.listPaths(options, null);
            Iterator<PathItem> iterator = pagedIterable.iterator();
            iterator.next();
        } catch (Exception e) {
            throw new Exception(e);
        }
    }

}
