package com.modak.utility.connector;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.modak.utility.HashMapUtility;
import com.modak.utility.UtilityCommon;
import com.modak.utils.VaultUtils;
import com.modak.utils.encryption.RSAEncryptionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

import java.io.InputStream;
import java.io.PrintWriter;
import java.util.HashMap;

/**
 * This Utility class consists of FTP/SFTP utility methods to connect and retrieve files
 */

public class FTPConnector {
    /**
     * @param source_url source url
     * @param userName   authentication userName
     * @param password   authentication password
     * @return configured ftpClient
     * @throws Exception failed to configure client
     */

    public FTPClient configureFTPClient(String source_url, String userName, String password) throws Exception {
        if (StringUtils.isEmpty(source_url) || StringUtils.isEmpty(userName)) {
            throw new Exception(UtilityCommon.EXP_EMPTY_OR_NULL_REQUIRED_VALUES + " source_url = " + source_url + "userName = " + userName);
        }
        if (StringUtils.isEmpty(password)) {
            throw new Exception(UtilityCommon.EMPTY_OR_NULL_PASSWORD);
        }

        FTPClient ftpClient = new FTPClient();
        ftpClient.connect(source_url);
        ftpClient.login(userName, password);
        ftpClient.enterLocalPassiveMode();
        ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
        return ftpClient;
    }

    /**
     * This is used to configure FTP clients using input map credentials.If proxy url is not null value it authenticates using proxy url
     *
     * @param configsMap input map of connection crdential
     * @return configured ftp cliennt
     * @throws Exception failed to configure client
     */
    public FTPClient configureFTPClient(HashMap<String, Object> configsMap) throws Exception {
        String sourceUrl = HashMapUtility.getString(configsMap, UtilityCommon.SOURCE_URL);

        HashMap<String, Object> credentialsMap = configsMap;
        String userName = HashMapUtility.getNonEmptyString(credentialsMap, UtilityCommon.USERNAME);
        String password = HashMapUtility.getNonEmptyString(credentialsMap, UtilityCommon.PASSWORD);
        String is_Encrypted = HashMapUtility.getString(configsMap, UtilityCommon.IS_Encrypted);
        String proxyUrl = HashMapUtility.getString(configsMap, UtilityCommon.PROXY_URL);

        if (is_Encrypted != null && is_Encrypted.equalsIgnoreCase(UtilityCommon.FLAG_YES)) {
            String privayeKeyPath = HashMapUtility.getString(configsMap, UtilityCommon.PRIVATE_KEY_FILE_PATH);
            password = RSAEncryptionUtils.decryptPassword(password, privayeKeyPath);
        }
        return StringUtils.isNotBlank(proxyUrl) ? configureFTPClient(sourceUrl, userName, password, proxyUrl) : configureFTPClient(sourceUrl, userName, password);
    }

    /**
     * This is used to configure  FTP clients with proxy using input credentials
     *
     * @param source_url source url
     * @param userName   authentication username
     * @param password   authentication [assword
     * @param proxyUrl   proxy urlused for configuring client
     * @return configured ftp client
     * @throws Exception failed to configure client
     */

    public FTPClient configureFTPClient(String source_url, String userName, String password, String proxyUrl) throws Exception {

        if (StringUtils.isEmpty(source_url) || StringUtils.isEmpty(userName) || StringUtils.isEmpty(proxyUrl)) {
            throw new Exception(
                    UtilityCommon.EXP_EMPTY_OR_NULL_REQUIRED_VALUES + " source_url = " + source_url
                            + " userName =" + userName + "proxy url " + proxyUrl);
        }
        if (StringUtils.isEmpty(password)) {
            throw new Exception(UtilityCommon.EMPTY_OR_NULL_PASSWORD);
        }
        FTPClient ftpClient = new FTPClient();
        ftpClient.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));
        //connect proxy
        String proxy_userName = userName + UtilityCommon.AT_THE_RATE + source_url;
        ftpClient.connect(proxyUrl);
        ftpClient.login(proxy_userName, password);
        ftpClient.enterLocalPassiveMode();
        ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
        return ftpClient;
    }


    /**
     *
     * @param configMap inputMap of connection credentials
     * @return configured ftpclient
     * @throws Exception failed to configure client
     */

//    public ChannelSftp configureSFTPClient(HashMap<String, Object> configMap) throws Exception{
//        String sourceUrl = HashMapUtility.getString(configMap, UtilityCommon.SOURCE_URL);
//      //  HashMap<String, Object> credentialMap = VaultUtils.getCredentialsMap(configMap);
//       // String userName = HashMapUtility.getNonEmptyString(credentialMap, UtilityCommon.USERNAME);
//       // String password = HashMapUtility.getNonEmptyString(credentialMap, UtilityCommon.PASSWORD);
//        String isEncrypted = HashMapUtility.getNonEmptyString(configMap, UtilityCommon.IS_Encrypted);
//        if(isEncrypted != null && isEncrypted.equalsIgnoreCase(UtilityCommon.FLAG_YES)){
//            String privateKeyPath = HashMapUtility.getString(configMap, UtilityCommon.PRIVATE_KEY_FILE_PATH);
//         //   password= RSAEncryptionUtils.decryptPassword(password, privateKeyPath);
//        }
//      / return  configureSFTPClient(sourceUrl, userName, password);
//    }

    /**
     * @param source_url source url
     * @param userName   authentication userName
     * @param password   authentication passwordd
     * @return configured ChannelSftp
     * @throws Exception failed to configure client
     */

    public ChannelSftp configureSFTPClient(String source_url, String userName, String password) throws Exception {
        if (StringUtils.isEmpty(source_url) || StringUtils.isEmpty(userName)) {
            throw new Exception(UtilityCommon.EXP_EMPTY_OR_NULL_REQUIRED_VALUES + " source_url = " + source_url + " userName =" + userName);
        }
        if (StringUtils.isEmpty(password)) {
            throw new Exception(UtilityCommon.EMPTY_OR_NULL_PASSWORD);
        }
        JSch jsch = new JSch();
        Session session = jsch.getSession(userName, source_url, 22);
        session.setPassword(password);
        session.setConfig(UtilityCommon.STRICTHOSTKEYCHECKING, UtilityCommon.NO);
        session.connect();
        ChannelSftp channelSftp = (ChannelSftp) session.openChannel(UtilityCommon.SFTP);
        channelSftp.connect();
        return channelSftp;
    }

    /**
     * Get sftp file as inputstream
     *
     * @param channelSftp ChannelSftp object
     * @param filePath    source file path
     * @return source file as input stream
     * @throws Exception failed to get file as input stream
     */
    public InputStream getSTPFile(ChannelSftp channelSftp, String filePath) throws Exception {
        if (StringUtils.isEmpty(filePath)) {
            throw new Exception(UtilityCommon.EXP_INVALID_FILE_PATH);
        }
        return channelSftp.get(filePath);
    }


    /**
     * Gets ftp file as inputstream
     *
     * @param ftpClient ftp client object with authentication details
     * @param filePath  source file path
     */

    public InputStream getFTPFile(FTPClient ftpClient, String filePath) throws Exception {
        if (StringUtils.isEmpty(filePath)) {
            throw new Exception(UtilityCommon.EXP_INVALID_FILE_PATH);
        }
        return ftpClient.retrieveFileStream(filePath);
    }

    /**
     * this method closes sftp connection
     *
     * @throws Exception if unable to close connection
     */
    public void closeSFTPConnection(ChannelSftp channelSftp) throws Exception {
        if (channelSftp != null) {
            try {
                channelSftp.disconnect();
            } catch (Exception e) {
                throw new Exception(UtilityCommon.EXP_CLOSING_CONNECTION, e);
            }
        }

    }

    /**
     * This method closes ftp connection
     *
     * @throws Exception if unable to close connection
     */
    public void closeFtpConnection(FTPClient ftpClient) throws Exception {
        if (ftpClient != null) {
            try {
                ftpClient.disconnect();
            } catch (Exception e) {
                throw new Exception(UtilityCommon.EXP_CLOSING_CONNECTION, e);
            }
        }
    }
}


