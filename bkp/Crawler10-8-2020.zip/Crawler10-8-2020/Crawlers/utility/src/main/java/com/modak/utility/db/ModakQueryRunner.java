package com.modak.utility.db;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;

import java.sql.*;
import java.util.ArrayList;

public class ModakQueryRunner extends QueryRunner {

    public <T> T query(Connection conn, String sql, ResultSetHandler<T> rsh, boolean readOnly) throws SQLException {
        return this.<T>query(conn, false, sql, rsh, readOnly, (Object[]) null);
    }

    public <T> T query(Connection conn, String sql, ResultSetHandler<T> rsh, boolean readOnly, Object... params) throws SQLException {
        return this.<T>query(conn, false, sql, rsh, readOnly, params);
    }

    private <T> T query(Connection conn, boolean closeConn, String sql, ResultSetHandler<T> rsh, boolean readOnly, Object... params) throws SQLException {
        if (conn == null) {
            throw new SQLException("Null connection");
        }

        if (sql == null) {
            if (closeConn) {
                close(conn);
            }
            throw new SQLException("Null SQL statement");
        }

        if (rsh == null) {
            if (closeConn) {
                close(conn);
            }
            throw new SQLException("Null ResultSetHandler");
        }

        PreparedStatement stmt = null;
        ResultSet rs = null;
        T result = null;
        boolean commit = conn.getAutoCommit();
        try {
            if (commit) {
                conn.setAutoCommit(false);
            }
            stmt = this.prepareStatement(conn, sql, readOnly);

            this.fillStatement(stmt, params);
            rs = this.wrap(stmt.executeQuery());
            result = rsh.handle(rs);

        } catch (SQLException e) {
            this.rethrow(e, sql, params);

        } finally {
            try {
                close(rs);
                conn.setAutoCommit(commit);
            } finally {
                close(stmt);
                if (closeConn) {
                    close(conn);
                }
            }
        }

        return result;
    }

    protected PreparedStatement prepareStatement(Connection conn, String sql, boolean readOnly) throws SQLException {
        if (readOnly) {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            stmt.setFetchSize(10000);
            return stmt;

        } else {
            return conn.prepareStatement(sql);
        }
    }

    protected Object[] toArray(ResultSet rs) throws SQLException {
        ResultSetMetaData meta = rs.getMetaData();
        int cols = meta.getColumnCount();
        Object[] result = new Object[cols];

        for (int i = 0; i < cols; ++i) {
            result[i] = rs.getObject(i + 1);
        }

        return result;
    }

    public void executeSelectInsertBatchMode(Connection sourceConnection, String sourceSelectQuery, Connection destinationConnection, String destinationInsertQuery, boolean closeConnection) throws Exception {
        if (sourceConnection == null) {
            throw new SQLException("Null source connection");
        }

        if (sourceSelectQuery == null) {
            if (closeConnection) {
                close(destinationConnection);
            }
            throw new SQLException("Null select SQL statement");
        }
        if (destinationConnection == null) {
            throw new SQLException("Null destination connection");
        }

        if (destinationInsertQuery == null) {
            if (closeConnection) {
                close(destinationConnection);
            }
            throw new SQLException("Null insert SQL statement");
        }

        PreparedStatement selectStmt = null;
        PreparedStatement insertStmt = null;
        ResultSet rs = null;
        boolean sourceCommit = sourceConnection.getAutoCommit();
        boolean destinationCommit = destinationConnection.getAutoCommit();
        try {
            if (sourceCommit) {
                sourceConnection.setAutoCommit(false);
            }
            if (destinationCommit) {
                destinationConnection.setAutoCommit(false);
            }

            selectStmt = this.prepareStatement(sourceConnection, sourceSelectQuery, true);
            insertStmt = this.prepareStatement(destinationConnection, destinationInsertQuery);
            this.fillStatement(selectStmt, null);
            rs = this.wrap(selectStmt.executeQuery());
            ArrayList<Object[]> resultFromSelectQuery = new ArrayList<>(1000);
            while (rs.next()) {
                Object[] row = toArray(rs);
                resultFromSelectQuery.add(row);
                if (resultFromSelectQuery.size() >= 1000) {
                    for (Object[] params : resultFromSelectQuery) {
                        this.fillStatement(insertStmt, params);
                        insertStmt.addBatch();
                    }
                    int[] rows = insertStmt.executeBatch();
                    resultFromSelectQuery.clear();
                }
            }

            if (resultFromSelectQuery.size() > 0) {
                for (Object[] params : resultFromSelectQuery) {
                    this.fillStatement(insertStmt, params);
                    insertStmt.addBatch();
                }
                int[] rows = insertStmt.executeBatch();
                resultFromSelectQuery.clear();
            }

        } catch (SQLException e) {
            throw (e);

        } finally {
            try {
                close(rs);
                sourceConnection.setAutoCommit(sourceCommit);
                destinationConnection.setAutoCommit(destinationCommit);
            } finally {
                close(selectStmt);
                close(insertStmt);
                if (closeConnection) {
                    close(destinationConnection);
                }
            }
        }
    }

}
