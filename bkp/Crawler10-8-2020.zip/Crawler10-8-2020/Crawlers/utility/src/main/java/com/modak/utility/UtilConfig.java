package com.modak.utility;

public class UtilConfig {


    public static final String REDIS_URL = "redis_url";
    ;
    public static final String RESPONSE = "response";
    public static final String MAP = "map";
    public static final String LIST = "list";

    public static final String STRING = "string";
    public static final String GET = "GET";
    public static final String POST = "POST";
    public static final String JSONARRAY = "jsonArray";
    public static final String DIR_AUTHENTICATION = "dir_authorisation";
    public static final String USERS = "users";
    public static final String GROUPS = "groups";

    public static final String DATA = "data";
    public static final String JSON = "json";

    private UtilConfig() {
        //Private constructor
    }

    public static final String INPUT_MAP_IS_NULL = "provided input map is null";
    public static final String KEY_IS_NULL = "provided key is null";
    public static String SS_METRICS = "ss_metrics";
    public static String COUNTERS = "counters";
    public static String COUNT = "count";
    public static String PIPELINE_BATCH_OUTPUT_RECORDS_COUNTER = "pipeline.batchOutputRecords.counter";
    public static String PIPELINE = "pipeline";
    public static String PIPELINECONFIG_PIPELINEID = "pipelineConfig.pipelineId";
    public static String TIME_OUT = "time_out";
    public static String START_WAIT_COUNTER = "start_wait_counter";
    public static String RUN_WAIT_TIME = "run_wait_time";
    public static String START_WAIT_TIME = "start_wait_time";
    public static String FAILED_PIPELINE = "Failed ";
    public static String PIPELINE_STATUS = " PipelineStatus : ";
    public static String EXECUTE_PIPELINE_MONITOR = "Execute Pipeline : Monitoring ";
    public static String PIPELINE_NAME = " PipelineName : ";
    public static String START_PIPELINE = "Start Of ExecutePipeline";
    public static String DELETE_PIPELINE = "Deleting Pipeline";
    public static String IMPORT_PIPELINE = "Importing Pipeline";
    public static String EXECUTE_PIPELINE = "Executed Pipeline";
    public static String FAILED_PROCESS_PIPELINE = "Failed to process pipeline";
    public static String BASE_URL = "base_url";
    public static String FINISHED = "FINISHED";
    public static String STOPPING = "STOPPING";
    public static String STOPPED = "STOPPED";
    public static String PIPELINE_STATUS_EDITED = "EDITED";
    public static String PIPELINE_STATUS_RUNNING = "RUNNING";
    public static String PIPELINE_STATUS_START_ERROR = "START_ERROR";
    public static String PIPELINE_STATUS_RUN_ERROR = "RUN_ERROR";
    public static String OBJECT_UUID = "object_uuid";
    public static final String JDBC_DRIVER = "jdbc_driver";
    public static final String JDBC_URL = "jdbc_url";
    public static final String USER_NAME = "username";
    public static final String PASS = "password";
    public static final String KEYTAB = "keytab";
    public static final String PUBLIC_KEY_FILE_PATH = "public_key_file_path";
    public static final String PRIVATE_KEY_FILE_PATH = "private_key_file_path";
    public static final String ENCRYPTED_PASS = "encrypted_password";
    public static final String YES = "Y";
    public static final String MIN_CONNECTION_PER_PARTITION = "minConnectionsPerPartition";
    public static final String MAX_CONNECTION_PER_PARTITION = "maxConnectionsPerPartition";
    public static final String LEAK_DETECTION_THRESHOLD = "leakDetectionThreshold";
    public static final String ENCRYPTED_PRIVATE_KEY = "privateKey";
    public static final String ENCRYPTED_PUBLIC_KEY = "publicKey";
    public static final String RSA_ENCRYPTION = "RSA";
    public static final String AES_ENCRYPTION = "AES";
    public static final String KEY_STORE_PASS = "key_store_password";
    public static final String TRUST_STORE_PASS = "trust_store_password";
    public static final String USER_ID = "uid";
    public static final String NAME_NODE_URL = "name_node";
    public static final String IS_NULL = "is_null";
    public static final String COMPRESSION_EXCEPTION = "Exception occured while compressing data";
    public static final String NULL_SQL_EXCEPTION = "Null SQL statement";
    public static final String NULL_CONNECTION_EXCEPTION = "Null connection statement";

    public static final String EXECUTE_QUERY_EXCEPTION = "Exception occured while executing query";
    public static final String EXECUTE_UPDATE_QUERY_EXCEPTION = "Exception occured while updating query";
    public static final String CONNECTION_EXCEPTION = "Exception occured while CONNECTING TO SOURCE";

    //HTTP UTILITY COMMON
    public static final String STATUS = "status";
    public static final String HTTP_RESPONSE = "http_response";
    public static final String HTTP_HEADERS = "http_headers";
    public static final String HEADER_ACCEPT = "accept";
    public static final String HEADER_AUTHORIZATION = "authorization";
    public static final String HEADER_CACHE_CONTROL = "cache-control";
    public static final String HEADER_CONTENT_TYPE = "Content-Type";
    public static final String HEADER_X_REQUESTED_BY = "X-Requested-By";
    public static final String HEADER_APPLICATION_JSON = "application/json";
    public static final String HEADER_BEARER = "Bearer";
    public static final String HEADER_NO_CACHE = "no-cache";
    public static final String HEADER_X_REQUESTED_BY_CONTENT_TYPE = "application/x-www-form-urlencoded";
    public static final String RESPONSE_FAILED = "failed to get response ";

    public static final String JWT_PUBLIC_KEY = "JWTPublicKey";
    public static final String JWT_PRIVATE_KEY = "JWTPrivateKey";
    public static final String JWT_AES_KEY = "JWTAESKey";
    public static final String AUTHORIZATION_HEADER = "authorization";
    public static final String EMPTY_STRING = " ";
    public static final String EXP = "exp";
    public static final String IAT = "iat";

    public static final String BEARER = "Bearer";
    public static final String USERID = "userId";
    public static final String PASSWORD = "password";
    public static final String SESSION_ID = "session_id";

}
