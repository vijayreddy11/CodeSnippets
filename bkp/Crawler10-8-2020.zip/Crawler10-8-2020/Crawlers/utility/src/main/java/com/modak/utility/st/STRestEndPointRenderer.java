package com.modak.utility.st;

import com.modak.utility.RestUtility;
import com.modak.utility.UtilityCommon;
import com.modak.utility.json.JSONUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroupString;
import org.stringtemplate.v4.StringRenderer;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class STRestEndPointRenderer implements STTemplateRenderer {

    private static Logger logger = LoggerFactory.getLogger(STRestEndPointRenderer.class);
    private HashMap<String, Object> templatesGroups = new HashMap<String, Object>();
    private String restEndPoint;

    public STRestEndPointRenderer(String restEndPoint) {
        this.restEndPoint = restEndPoint;
    }

    public synchronized void loadTemplateGroups(ArrayList<String> templateGroupNames) throws Exception {
        if (templateGroupNames != null && templateGroupNames.size() > 0) {
            HashMap<String, Object> templateGroups = loadTemplatesGroupFromEndPoint(templateGroupNames);
            templatesGroups.putAll(templateGroups);
        } else {
            throw new Exception("null or empty templateGroupstrings");
        }
    }

    private synchronized String getTemplateGroup(String templateGroupName) throws Exception {
        Object templateString = templatesGroups.get(templateGroupName);
        if (templateString == null) {
            ArrayList<String> newGroups = new ArrayList<String>();
            newGroups.add(templateGroupName);
            HashMap<String, Object> newTemplateGroups = loadTemplatesGroupFromEndPoint(newGroups);
            templateString = newTemplateGroups.get(templateGroupName);
            if (templateString == null) {
                throw new Exception("Failed to get stringGroup: " + templateGroupName);
            }
        }
        return templateString.toString();
    }

    private synchronized HashMap<String, Object> loadTemplatesGroupFromEndPoint(ArrayList<String> templateGroupNames) throws Exception {
        RestUtility restUtility = new RestUtility();
        HashMap<String, Object> postMap = new HashMap<String, Object>();
        postMap.put(UtilityCommon.KEY_REST_ST_GROUPID, templateGroupNames);
        long startTime = System.currentTimeMillis();
        HashMap<String, Object> responseMap = restUtility.postRequest(restEndPoint, JSONUtility.map2JsonString(postMap), null);
        String responseString = restUtility.extractResponseString(responseMap);
        if (responseString == null) {
            throw new Exception(MessageFormat.format("failed to template groups end point {} : input {}", restEndPoint,
                    JSONUtility.object2JsonString(postMap)));
        }
        long duration = (System.currentTimeMillis() - startTime);
        logger.debug("Time taken to fetch results: {} Milli {} sec", TimeUnit.MILLISECONDS.toMillis(duration));

        HashMap<String, Object> responseGroups = JSONUtility.jsonToMap(responseString);
        return responseGroups;
    }

    public String renderTemplate(String templateGroupName, String templateName, String attributeName, Object inputMap)
            throws Exception {
        String templateString = getTemplateGroup(templateGroupName);
        STGroupString stGroupString = new STGroupString(templateGroupName, templateString, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        stGroupString.registerRenderer(String.class, new StringRenderer());
        ST temp = stGroupString.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + " " + stGroupString.getFileName());
        }
        temp.add(attributeName, inputMap);
        return temp.render();
    }

    public String renderTemplate(String templateGroupName, String templateName, HashMap<String, Object> templateInputs)
            throws Exception {
        String templateString = getTemplateGroup(templateGroupName);
        STGroupString stGroupString = new STGroupString(templateGroupName, templateString, UtilityCommon.ST_DELIMITER, UtilityCommon.ST_DELIMITER);
        stGroupString.registerRenderer(String.class, new StringRenderer());
        ST temp = stGroupString.getInstanceOf(templateName);
        if (temp == null) {
            throw new NullPointerException(
                    UtilityCommon.TEMPLATE_NOT_DEFINED + templateName + "" + stGroupString.getFileName());
        }
        if (templateInputs != null && templateInputs.size() > 0) {
            for (String attributeName : templateInputs.keySet()) {
                temp.add(attributeName, templateInputs.get(attributeName));
            }
        }
        return temp.render();
    }

    public String renderTemplate(String templateGroupName, String templateName) throws Exception {
        return renderTemplate(templateGroupName, templateName, null);
    }
}