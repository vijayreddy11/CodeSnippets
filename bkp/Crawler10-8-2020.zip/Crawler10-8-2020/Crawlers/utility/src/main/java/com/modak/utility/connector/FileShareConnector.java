package com.modak.utility.connector;

import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.msdtyp.AccessMask;

import com.modak.utility.UtilityCommon;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.EnumSet;
import java.util.concurrent.TimeUnit;

public class FileShareConnector {
    private static final Logger logger = LoggerFactory.getLogger(FileShareConnector.class);
    private DiskShare diskShare = null;
    private Session session = null;
    private Connection smbCon = null;

    public void initShare(String hostName, String domain, String shareName, String userName, String password) throws Exception {
        if (StringUtils.isEmpty(hostName) || StringUtils.isEmpty(domain) || StringUtils.isEmpty(userName)) {
            throw new Exception("details not sufficient");
        }
        if (StringUtils.isEmpty(password)) {
            throw new Exception("empty_or_null_password");
        }
        URI uri = new URI(UtilityCommon.SMB_SCHEME + hostName);
        SmbConfig config = SmbConfig.builder()
                .withTimeout(5000000, TimeUnit.MILLISECONDS)
                .withSoTimeout(2147483640, TimeUnit.MILLISECONDS)
                .build();
        SMBClient client = new SMBClient(config);
        smbCon = client.connect(uri.getHost());
        AuthenticationContext ac = new AuthenticationContext(userName, password.toCharArray(), domain);
        session = smbCon.authenticate(ac);
        diskShare = (DiskShare) session.connectShare(shareName);
        logger.debug("share to be authenticated : {}  connection status : {}", hostName, diskShare.isConnected());
        String sourceName = hostName + "/" + shareName;
        if (!diskShare.isConnected()) {
            logger.error("Failed to connect to smb source : {}", sourceName);
            throw new Exception("Failed to connect smb source : " + sourceName);
        }
    }

//    public void initShare(HashMap<String, Object> cofigsMap,String creds) throws Exception {
//        String sourceName = HashMapUtility.getString(cofigsMap, UtilityCommon.SOURCE_NAME);
//        String domain = HashMapUtility.getString(cofigsMap, UtilityCommon.DOMAIN);
//        HashMap<String,Object> credentials=JSONUtils.jsonToMap(creds);
//        String userName=credentials.get(UtilityCommon.USER_NAME).toString();
//        if(userName==null){
//            throw new NullPointerException(UtilityCommon.USER_NAME+ UtilityCommon.IS_NULL);
//        }
//        String password = credentials.get(UtilityCommon.PASSWORD).toString();
//        if(password==null){
//            throw new NullPointerException(UtilityCommon.PASSWORD+  UtilityCommon.IS_NULL);
//        }
////        String isEncrypted = HashMapUtility.getString(cofigsMap, UtilityCommon.IS_Encrypted);
////        if (isEncrypted != null && isEncrypted.equalsIgnoreCase(UtilityCommon.FLAG_YES)) {
////            String privateKeyPath = HashMapUtility.getString(cofigsMap, UtilityCommon.PRIVATE_KEY_FILE_PATH);
////            password = RSAEncryptionUtils.decryptPassword(password, privateKeyPath);
////        }
//        initShare(, domain, userName, password);
//    }

    public InputStream getFileAsStream(String sourceFilePath) throws Exception {
        if (diskShare != null && diskShare.isConnected()) {
            com.hierynomus.smbj.share.File file = diskShare
                    .openFile(sourceFilePath, EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL,
                            SMB2CreateDisposition.FILE_OPEN, null);
            return new BufferedInputStream(file.getInputStream());
        } else {
            throw new Exception(UtilityCommon.EXP_DISKSHARE_NOT_INITIALIZED + diskShare);
        }
    }

    public DiskShare getDiskShare() {
        return this.diskShare;
    }

    public void closeResources() {
        if (diskShare != null) {
            try {
                diskShare.close();
            } catch (IOException e) {
                logger.error("failed to close diskshare", e);
            }
        }
        if (session != null) {
            try {
                session.close();
            } catch (IOException e) {
                logger.error("Failed to close session", e);
            }
        }
        if (smbCon != null) {
            try {
                smbCon.close();
            } catch (IOException e) {
                logger.error("failed to close smb connection", e);
            }
        }
    }
}
