package com.modak.utility.connector;


import com.google.api.gax.paging.Page;
import com.google.auth.Credentials;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.bigquery.*;
import org.apache.commons.lang3.StringUtils;
import com.modak.utility.UtilityCommon;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.sql.Timestamp;

public class BigQueryConnector {
    private String credentialsJson;
    private String projectId;
    private HashMap<String, Object> connectAttributes;
    public BigQuery bigQuery;

    public BigQueryConnector(HashMap<String, Object> connectAttributes) {
        this.connectAttributes = connectAttributes;
        this.credentialsJson = connectAttributes.get(UtilityCommon.CLIENT_CONFIGS).toString();
        this.projectId = connectAttributes.get(UtilityCommon.PROJECT_ID).toString();
    }

    public void initCredentials() throws Exception {
        try (InputStream serviceAccountStream = new ByteArrayInputStream(
                credentialsJson.getBytes(StandardCharsets.UTF_8))) {
            Credentials credentials = ServiceAccountCredentials.fromStream(serviceAccountStream);
            bigQuery = BigQueryOptions.newBuilder().setCredentials(credentials).setProjectId(projectId).build()
                    .getService();
        } catch (Exception e) {
            throw new Exception(e);
        }
    }

    public Object[] getTableMetadata(String schemaName, String tableName) throws Exception {
        try {
            tableName = StringUtils.trim(tableName);
            if (StringUtils.isNotEmpty(schemaName) && StringUtils.isNotEmpty(tableName)) {
                Table bigQueryTable = bigQuery.getTable(schemaName, tableName);
                StandardTableDefinition standardTableDefinition = bigQueryTable.getDefinition();
                List<Object> metadataList = new ArrayList<>();
                metadataList.add(connectAttributes.get(UtilityCommon.DATAPLACE_ID));
                metadataList.add(connectAttributes.get(UtilityCommon.SCHEMA_ID));
                metadataList.add(connectAttributes.get(UtilityCommon.DATAPLACE_COMPONENT_TYPE_ID));
                metadataList.add(connectAttributes.get(UtilityCommon.SCHEMA_NAME));
                metadataList.add(tableName);
                metadataList.add(connectAttributes.get(UtilityCommon.SCHEMA_NAME));
                metadataList.add(standardTableDefinition.getNumRows());
                Timestamp timestamp = new Timestamp(bigQueryTable.getCreationTime());
                metadataList.add(timestamp);
                Timestamp timestamp1 = new Timestamp(bigQueryTable.getLastModifiedTime());
                metadataList.add(timestamp1);
                metadataList.add(standardTableDefinition.getNumBytes());
                metadataList.add(UtilityCommon.SOURCE);
                metadataList.add(standardTableDefinition.getLocation());
                metadataList.add(UtilityCommon.BIGQUERY);
                if (standardTableDefinition.getType().name().equalsIgnoreCase(UtilityCommon.TABLE)) {
                    metadataList.add("T");
                } else
                    metadataList.add("V");
                return metadataList.toArray();
            } else {
                throw new Exception(UtilityCommon.EXP_TABLE_NOT_FOUND + schemaName + "," + tableName);
            }
        } catch (Exception e) {
            throw new Exception(e);
        }
    }



    public Long getTableCount() throws Exception {
        Long numberOfRows;
        try {
            Table bigQueryTable = bigQuery.getTable(connectAttributes.get(UtilityCommon.SCHEMA_NAME).toString(),
                    connectAttributes.get(UtilityCommon.TABLE_NAME).toString());
            StandardTableDefinition standardTableDefinition = bigQueryTable.getDefinition();
            numberOfRows = standardTableDefinition.getNumRows();
        } catch (Exception e) {
            throw new Exception(UtilityCommon.EXP_FAILED_GET_COUNTS, e);
        }
        return numberOfRows;
    }

    public List<String> getSchemaList() throws Exception {
        return listDatasets(projectId);
    }

    public List<String> listDatasets(String projectId) throws Exception {
        List<String> schemas = new ArrayList<>();
        try {
            Page<Dataset> datasets = bigQuery.listDatasets(projectId, BigQuery.DatasetListOption.pageSize(100));
            if (datasets == null) {
                throw new Exception(UtilityCommon.NO_MODELS_IN_DATASET);
            }
            datasets.iterateAll().forEach(dataset -> schemas.add(dataset.getDatasetId().getDataset()));
        } catch (Exception e) {
            throw new Exception(e);
        }
        return schemas;
    }
}