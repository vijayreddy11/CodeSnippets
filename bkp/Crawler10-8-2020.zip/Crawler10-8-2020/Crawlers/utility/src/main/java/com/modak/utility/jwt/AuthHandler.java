package com.modak.utility.jwt;

import org.redisson.api.RedissonClient;

import java.util.HashMap;
import java.util.Map;

public interface AuthHandler {
    void init(HashMap<String, Object> initMap) throws Exception;

    public String generateToken(Map<String, Object> userdetails, RedissonClient redissonClient);
}

