//package com.modak.spiderweb.crawlers;
//
//import com.azure.storage.blob.BlobClient;
//import com.azure.storage.blob.BlobContainerClient;
//import com.azure.storage.blob.BlobServiceClient;
//import com.azure.storage.blob.BlobServiceClientBuilder;
//import com.azure.storage.blob.models.BlobItem;
//import com.azure.storage.blob.specialized.BlobInputStream;
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.DelimitedFileFormatUtil;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.SemiStructuredUtils;
//import com.modak.utils.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.io.FilenameUtils;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.hadoop.conf.Configuration;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.apache.parquet.hadoop.ParquetFileReader;
//import org.apache.parquet.hadoop.util.HadoopInputFile;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.*;
//
//public class AzureBlobCrawler extends BaseCrawler {
//    private String connection_string;
//    private String sasToken;
//    private static String fetchCrawlType = null;
//    protected BlobServiceClient blobServiceClient = null;
//    private final int BATCH_SIZE = 1000;
//    protected SemiStructuredUtils semiStructuredUtils;
//    protected DelimitedFileFormatUtil delimitedFileFormatUtil;
//    private List<Object[]> columnMetadata = new ArrayList<>();
//    private final List<Object[]> list_of_objects_array = new ArrayList<>();
//    private static final Logger logger = LogManager.getLogger(AzureBlobCrawler.class);
//
//    @Override
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                String creds = this.getCredentialsForSource();
//                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
//                connection_string = HashMapUtility.getString(credentials, CrawlerCommon.CONNECTION_STRING);
//                if (connection_string == null) {
//                    throw new NullPointerException(CrawlerCommon.CONNECTION_STRING + CrawlerCommon.IS_NULL);
//                }
//                sasToken = HashMapUtility.getString(credentials, CrawlerCommon.SAS_TOKEN);
//                if (sasToken == null) {
//                    throw new NullPointerException(CrawlerCommon.SAS_TOKEN + CrawlerCommon.IS_NULL);
//                }
//
//                blobServiceClient = new BlobServiceClientBuilder().connectionString(connection_string).buildClient();
//                HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.SOURCE_INFO_DETAILS);
//                String containerName = HashMapUtility.getString(sourceInfo, CrawlerCommon.CONTAINER_NAME);
//                String fetchStatsType = HashMapUtility.getString(sourceInfo, CrawlerCommon.FETCH_STATS_TYPE);
//                String path = HashMapUtility.getString(sourceInfo, CrawlerCommon.PATH);
//                String accountName = HashMapUtility.getString(sourceInfo, CrawlerCommon.ACCOUNTNAME);
//                sourceAttributes.put(CrawlerCommon.ACCOUNTNAME, accountName);
//                sourceAttributes.put(CrawlerCommon.CONTAINER_NAME, containerName);
//                sourceAttributes.put(CrawlerCommon.FETCH_STATS_TYPE, fetchStatsType);
//                sourceAttributes.put(CrawlerCommon.DIRECTORY_NAME, containerName);
//                sourceAttributes.put(CrawlerCommon.PATH, path);
//                boolean fetchColumnMetadata = HashMapUtility.getBoolean(sourceInfo, CrawlerCommon.FETCH_COLUMN_METADATA);
//                sourceAttributes.put(CrawlerCommon.FETCH_COLUMN_METADATA, fetchColumnMetadata);
//
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        this.getDirectories();
//    }
//
//    @Override
//    public void doCrawling() {
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = HashMapUtility.getString(crawlingTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                        dataMap.put(templateName, list_of_map);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else {
//                        BlobContainerClient blobContainerClient = blobServiceClient.getBlobContainerClient(sourceAttributes.get(CrawlerCommon.CONTAINER_NAME).toString());
//                        String directory = null;
//                        String fetchStatsType = HashMapUtility.getString(sourceAttributes, CrawlerCommon.FETCH_STATS_TYPE);
//                        if (!fetchStatsType.equalsIgnoreCase(CrawlerCommon.CONTAINER)) {
//                            String containerName = HashMapUtility.getString(sourceAttributes, CrawlerCommon.CONTAINER_NAME);
//                            String path = HashMapUtility.getString(sourceAttributes, CrawlerCommon.PATH);
//                            directory = getFolderName(containerName, path, fetchStatsType);
//                        }
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_FILEMETADATA)) {
//                            fetchCrawlType = CrawlerCommon.STAGING_INSERT_FILEMETADATA;
//                            StorageIterator(blobContainerClient, directory, query);
//                            if (list_of_objects_array.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                list_of_objects_array.clear();
//                            }
//                        } else {
//                            if (HashMapUtility.getBoolean(sourceAttributes, CrawlerCommon.FETCH_COLUMN_METADATA)) {
//                                fetchCrawlType = CrawlerCommon.FETCH_COLUMN_METADATA;
//                                StorageIterator(blobContainerClient, directory, query);
//                                if (columnMetadata.size() > 0) {
//                                    jdbcUtility.executeBatchUpdateQuery(columnMetadata, query, dataSource.getConnection(), false);
//                                    columnMetadata.clear();
//                                }
//                            }
//                        }
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(sourceAttributes, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//    }
//
//
//    @Override
//    public void closeResources() {
//
//    }
//
//    public String getFolderName(String contain_name, String path, String fetchStatsType) {
//        String j = contain_name + "/";
//        String[] words = path.split(j);
//        String k;
//        if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.FILE)) {
//            k = words[words.length - 1];
//        } else {
//            k = words[words.length - 1] + "/";
//        }
//        return k;
//    }
//
//    public void StorageIterator(BlobContainerClient blobContainerClient, String directory, String query) throws Exception {
//        try {
//            for (BlobItem blobItem : blobContainerClient.listBlobsByHierarchy(directory)) {
//                Object blobItemPrefix = blobItem.isPrefix();
//                String blobItemName = blobItem.getName();
//                if (Boolean.TRUE.equals(blobItemPrefix)) {
//                    StorageIterator(blobContainerClient, blobItemName, query);
//                } else {
//                    if (fetchCrawlType.equals(CrawlerCommon.STAGING_INSERT_FILEMETADATA)) {
//                        list_of_objects_array.add(processFile(blobItemName, blobContainerClient));
//                        if (list_of_objects_array.size() >= BATCH_SIZE) {
//                            jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                            list_of_objects_array.clear();
//                        }
//                    } else {
//                        if (!blobItemName.endsWith(CrawlerCommon.FILE_SEPARATOR)) {
//                            String fileFormat = FilenameUtils.getExtension(blobItemName);
//                            if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.PARQUET) || fileFormat.equalsIgnoreCase(CrawlerCommon.AVRO) || fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                                processColumnMetadata(blobItemName, blobContainerClient, query);
//                            }
//                        }
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//
//    private Object[] processFile(String name, BlobContainerClient blobContainerClient) throws Exception {
//
//        BlobClient blobClient = blobContainerClient.getBlobClient(name);
//        String fileFormat = FilenameUtils.getExtension(name);
//        String relativePath = blobClient.getBlobName();
//        String path = blobClient.getBlobUrl();
//        String owner = blobClient.getAccountName();
//        Path filePath = Paths.get(relativePath);
//        String fileName = filePath.getFileName().toString();
//        BlobInputStream inputStream = null;
//        String delimiterFileFormat = null;
//        delimitedFileFormatUtil = new DelimitedFileFormatUtil();
//        if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//            inputStream = blobClient.openInputStream();
//            delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//        } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//            inputStream = blobClient.openInputStream();
//            delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//        }
//        String lastModifiedTime = new Date(blobClient.getProperties().getLastModified().toInstant().toEpochMilli()).toString();
//        long size = blobClient.getProperties().getBlobSize();
//
//        Object[] obj;
//        try {
//            obj = new Object[]{
//                    sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                    sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                    sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                    fileName,
//                    fileFormat,
//                    path,
//                    relativePath,
//                    lastModifiedTime,
//                    false,
//                    false,
//                    false,
//                    size,
//                    owner,
//                    owner,
//                    delimiterFileFormat,
//                    null
//            };
//            return obj;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null) {
//                    inputStream.close();
//                }
//            } catch (Exception e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    public String getblobname(String initname) {
//        String sample = initname;
//        String[] words = sample.split("/");
//        String blob_name = words[words.length - 1];
//        return blob_name;
//    }
//
//    public void processColumnMetadata(String blobItemName, BlobContainerClient blobContainerClient, String query) throws Exception {
//        BlobClient blobClient = blobContainerClient.getBlobClient(blobItemName);
//        InputStream inputStream = blobClient.openInputStream();
//        String fileFormat = FilenameUtils.getExtension(blobItemName);
//        semiStructuredUtils = new SemiStructuredUtils();
//        try {
//            if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                String delimiterFileFormat;
//                if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                    delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//                } else {
//                    delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//                }
//                HashMap<String, Object> delimiterFileFormatMap = com.modak.utility.json.JSONUtils.jsonToMap(delimiterFileFormat);
//                boolean header = (boolean) HashMapUtility.get(delimiterFileFormatMap, CrawlerCommon.HEADER);
//                if (header) {
//                    columnMetadata.addAll(getCSVMetadata(blobItemName, blobContainerClient));
//                }
//            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.AVRO)) {
//                columnMetadata.addAll(getAvroMetadata(blobItemName, blobContainerClient));
//            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.PARQUET)) {
//                columnMetadata.addAll(getParquetMetadata(blobItemName, blobContainerClient));
//            }
//            if (columnMetadata.size() >= BATCH_SIZE) {
//                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), false);
//                columnMetadata.clear();
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                inputStream.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    public List<Object[]> getParquetMetadata(String blobItemName, BlobContainerClient blobContainerClient) throws Exception {
//        ParquetFileReader reader = null;
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        String accountName = HashMapUtility.getString(sourceAttributes, CrawlerCommon.ACCOUNTNAME);
//        String containerName = HashMapUtility.getString(sourceAttributes, CrawlerCommon.CONTAINER_NAME);
//        Path filePath = Paths.get(blobItemName);
//        String fileName = filePath.getFileName().toString();
//        try {
//            BlobClient blobClient = blobContainerClient.getBlobClient(blobItemName);
//            Configuration con = new Configuration();
//            con.set("fs.azure.sas." + containerName + "." + accountName + ".blob.core.windows.net", sasToken);
//            con.set("fs.wasbs.impl", "org.apache.hadoop.fs.azure.NativeAzureFileSystem");
//            reader = ParquetFileReader.open(HadoopInputFile.fromPath(new org.apache.hadoop.fs.Path(CrawlerCommon.BLOB_PREFIX + containerName + "@" + accountName + CrawlerCommon.AZURE_BLOB_WINDOWS_NET + blobItemName), con));
//            List<LinkedHashMap<String, Object>> listMap = semiStructuredUtils.getParquetColMetadata(reader);
//            for (LinkedHashMap<String, Object> map : listMap) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        fileName,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        blobClient.getBlobUrl(),
//                        null,
//                        null,
//                        null,
//                        null,
//                        listMap.indexOf(map),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (reader != null) {
//                    reader.close();
//                }
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    public List<Object[]> getAvroMetadata(String blobItemName, BlobContainerClient blobContainerClient) throws Exception {
//        InputStream inputStream = null;
//        try {
//            List<Object[]> list_of_objects_array = new ArrayList<>();
//            BlobClient blobClient = blobContainerClient.getBlobClient(blobItemName);
//            inputStream = blobClient.openInputStream();
//            Path filePath = Paths.get(blobItemName);
//            String fileName = filePath.getFileName().toString();
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getAvroColMetadata(inputStream);
//            for (HashMap<String, Object> map : listMap) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        fileName,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        blobClient.getBlobUrl(),
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            if (inputStream != null) {
//                inputStream.close();
//            }
//        }
//    }
//
//    public List<Object[]> getCSVMetadata(String blobItemName, BlobContainerClient blobContainerClient) throws Exception {
//        BlobInputStream inputStream = null;
//        try {
//            List<Object[]> list_of_objects_array = new ArrayList<>();
//            BlobClient blobClient = blobContainerClient.getBlobClient(blobItemName);
//            inputStream = blobClient.openInputStream();
//            String format = FilenameUtils.getExtension(blobItemName);
//            Path filePath = Paths.get(blobItemName);
//            String fileName = filePath.getFileName().toString();
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getCSVColMetadata(inputStream, format);
//            for (HashMap<String, Object> map : listMap) {
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        fileName,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        blobClient.getBlobUrl(),
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            if (inputStream != null) {
//                inputStream.close();
//            }
//        }
//    }
//}
