package com.modak.spiderweb.crawlers;

import java.util.HashMap;

public class test {
    public static void main(String[] args) {
        HashMap hashMap=new HashMap();
        hashMap.put(1,1);

        HashMap hashMap2=new HashMap();
        hashMap2.putAll(hashMap);

        hashMap2.put(2,2);
        System.out.println(hashMap);
    }
}
