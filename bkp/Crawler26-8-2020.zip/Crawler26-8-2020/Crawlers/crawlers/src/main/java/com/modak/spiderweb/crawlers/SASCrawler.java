package com.modak.spiderweb.crawlers;

import com.dullesopen.jdbc.DataSetInfo;
import com.dullesopen.jdbc.bulk.JdbcSqlException;
import com.modak.spiderweb.BaseCrawler;
import com.modak.spiderweb.common.CrawlerCommon;
import com.modak.utility.HashMapUtility;
import com.modak.utility.db.ModakQueryRunner;
import org.apache.commons.dbutils.handlers.ArrayListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SASCrawler extends BaseCrawler {
    private static final Logger logger = LogManager.getLogger(SASCrawler.class);
    private Connection sourceConnection;
    private Connection sourceConnection_2;
    private LinkedList formats = new LinkedList();

    @Override
    public void initSourceConnection() {
        try {
            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
            if (connectToSource && !isErrored) {
                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
                HashMap<String, Object> additionalInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.ADDITIONAL_INFO);
                String jdbcDriver = additionalInfo.get(CrawlerCommon.JDBC_DRIVER).toString();
                sourceAttributes.put(CrawlerCommon.JDBC_DRIVER, jdbcDriver);

                Class.forName(sourceAttributes.get(CrawlerCommon.JDBC_DRIVER).toString());
                HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.SOURCE_INFO_DETAILS);
                String jdbcURL = (String) sourceAttributes.get(CrawlerCommon.JDBC_URL);
                String jdbcURL_2 = (String) sourceAttributes.get(CrawlerCommon.JDBC_URL_2);
                String directory = (String) sourceInfo.get(CrawlerCommon.LOCATION_PATH);
                if (directory.endsWith(CrawlerCommon.FILE_SEPARATOR)) {
                    directory = directory.substring(0, directory.length() - 1);
                }
                upperToLowerFileConversion(directory);
                jdbcURL = jdbcURL.replace(CrawlerCommon.UDIRECTORY, directory);
                jdbcURL_2 = jdbcURL_2.replace(CrawlerCommon.UDIRECTORY, directory);
                String locationPath = directory;
                String[] arrOfStr = locationPath.split(CrawlerCommon.FILE_SEPARATOR);
                String schemaName = arrOfStr[arrOfStr.length - 1];
                jdbcURL = jdbcURL.replace(CrawlerCommon.SCHEMANAME, schemaName);
                jdbcURL_2 = jdbcURL_2.replace(CrawlerCommon.SCHEMANAME, schemaName);
                sourceAttributes.put(CrawlerCommon.JDBC_URL, jdbcURL);
                sourceAttributes.put(CrawlerCommon.JDBC_URL_2, jdbcURL_2);
                sourceConnection = DriverManager.getConnection(jdbcURL, "", "");
                sourceConnection_2 = DriverManager.getConnection(jdbcURL_2, "", "");
                if (sourceConnection == null) {
                    throw new NullPointerException(CrawlerCommon.SOURCE_CONNECTION_OBJECT_ONE_IS_NULL);
                }
                if (sourceConnection_2 == null) {
                    throw new NullPointerException(CrawlerCommon.SOURCE_CONNECTION_OBJECT_TWO_IS_NULL);
                }
            } else {
                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
            }
        } catch (Exception e) {
            logger.error(ExceptionUtils.getStackTrace(e));
            insertError(e);
        }
    }

    @Override
    public void connectToSource() {
        this.getSchemas(sourceConnection_2);
    }

    @Override
    public void doCrawling() {
        Connection koshConnection = null;
        try {
            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
            if (doCrawling && !isErrored) {
                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
                String templateGroup = HashMapUtility.getString(crawlingTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
                for (String templateName : templateMap.keySet()) {
                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
                    String queryType = dependentMap.get(CrawlerCommon.QUERY_TYPE).toString();
                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
                        List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
                        dataMap.put(templateName, list_of_map);
                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT_INSERT)) {
                        HashMap<String, Object> tempMap = HashMapUtility.getMap(templateMap, templateName);
                        String connection_type = HashMapUtility.getString(tempMap, CrawlerCommon.CONNECTION_TYPE);
                        String selectQueryTemplate = HashMapUtility.getString(tempMap, CrawlerCommon.SELECT_QUERY);
                        String selectQuery = templateRenderer.renderTemplate(templateGroup, selectQueryTemplate, CrawlerCommon.DATA, dataMap);
                        String insertQueryTemplate = HashMapUtility.getString(tempMap, CrawlerCommon.INSERT_QUERY);
                        String insertQuery = templateRenderer.renderTemplate(templateGroup, insertQueryTemplate, CrawlerCommon.DATA, dataMap);
                        if (connection_type.equalsIgnoreCase(CrawlerCommon.SOURCE_KOSH)) {
                            jdbcUtility.executeSelectInsertBatchMode(sourceConnection, selectQuery, dataSource.getConnection(), insertQuery, true);
                        } else {
                            koshConnection = dataSource.getConnection();
                            jdbcUtility.executeSelectInsertBatchMode(koshConnection, selectQuery, dataSource.getConnection(), insertQuery, true);
                        }
                    } else {
                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_FORMATS)) {
                            formats = (LinkedList) getFormats(sourceConnection_2, query);
                            if (formats.size() > 0) {
                                jdbcUtility.executeBatchUpdateQuery((List<Object[]>) formats, query, dataSource.getConnection(), true);
                                formats.clear();
                            }
                        }
                    }
                }

                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
            } else {
                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
            }
        } catch (Exception e) {
            try {
                logger.error(ExceptionUtils.getStackTrace(e));
                insertError(e);
            } catch (Exception ex) {
                logger.error(ExceptionUtils.getStackTrace(ex));
            }
        } finally {
            try {
                if (koshConnection != null)
                    koshConnection.close();
            } catch (SQLException e) {
                logger.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }

    public List<Object[]> getFormats(Connection sourceConnection_2, String query) {
        try {
            DatabaseMetaData databaseMetaData = sourceConnection_2.getMetaData();
            ResultSet resultSetSchemas = databaseMetaData.getSchemas();
            while (resultSetSchemas.next()) {
                ResultSet resultSetTables = databaseMetaData.getTables(null, resultSetSchemas.getString(1), null, null);
                while (resultSetTables.next()) {
                    Statement statement = sourceConnection_2.createStatement();
                    ResultSet resultSet = statement.executeQuery("select * from " + resultSetTables.getString(3));

                    ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
                    ResultSet resultSetColumns = databaseMetaData.getColumns(null, resultSetSchemas.getString(1), resultSetTables.getString(3), null);
                    DataSetInfo info = resultSetMetaData.unwrap(DataSetInfo.class);
                    int i = 1;
                    while (resultSetColumns.next()) {
                        try {
                            Object[] obj = {resultSetTables.getString(3), resultSetColumns.getString(4), convertDataType(info.getVariableFormat(i)), info.getVariableLabel(i)};
                            formats.add(obj);
                            int BATCH_SIZE = 1000;
                            if (formats.size() >= BATCH_SIZE) {
                                jdbcUtility.executeBatchUpdateQuery((List<Object[]>) formats, query, dataSource.getConnection(), true);
                                formats.clear();
                            }
                            i++;
                        } catch (JdbcSqlException e) {
                            try {
                                logger.error(ExceptionUtils.getStackTrace(e));
                                insertSASFileConversionError(e);
                            } catch (Exception ex) {
                                logger.error(ExceptionUtils.getStackTrace(ex));
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error(ExceptionUtils.getStackTrace(e));
        }
        return formats;
    }

    public static String convertDataType(String s) {
        if (s != null) {
            Matcher m;
            String group;
            String group1;
            Pattern dec = Pattern.compile("[A-Z]*(\\d{0,2})\\.(.*)");
            m = dec.matcher(s);
            if (m.matches()) {
                group = m.group(1);
                int groupInt = Integer.parseInt(group);
                group1 = m.group(2).trim();
                if (group1.isEmpty()) {
                    if (groupInt < 5) {
                        s = "SMALLINT";
                    } else if (groupInt >= 5 && groupInt <= 9) {
                        s = "INT";
                    } else {
                        s = "BIGINT";
                    }
                } else {
                    s = "DECIMAL(" + m.group(1) + "," + m.group(2) + ")";

                }

                return s;
            } else {
                return s;
            }
        } else
            return null;
    }

    public void upperToLowerFileConversion(String directory) {
        File mainDir = new File(directory);
        if (mainDir.exists() && mainDir.isDirectory()) {
            File arr[] = mainDir.listFiles();
            RecursivePrint(arr, 0);
        }
    }

    public void RecursivePrint(File[] arr, int index) {
        if (index == arr.length)
            return;
        if (arr[index].isFile()) {
            File file = new File(arr[index].getAbsolutePath());
            String filename = file.getName();
            if (!filename.equals(filename.toLowerCase())) {
                String newFilePath = file.getAbsolutePath().replace(file.getName(), file.getName().toLowerCase());
                File newFile = new File(newFilePath);
                try {
                    FileUtils.moveFile(file, newFile);
                } catch (IOException e) {
                    try {
                        logger.error(ExceptionUtils.getStackTrace(e));
                        insertSASFileConversionError(e);
                    } catch (Exception ex) {
                        logger.error(ExceptionUtils.getStackTrace(ex));
                    }
                }
            }
        }
        RecursivePrint(arr, ++index);
    }

    @Override
    public void closeResources() {
        if (sourceConnection != null) {
            try {
                sourceConnection.close();
            } catch (SQLException e) {
                logger.error(ExceptionUtils.getStackTrace(e));
            }
        }
        if (sourceConnection_2 != null) {
            try {
                sourceConnection_2.close();
            } catch (SQLException e) {
                logger.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }
}
