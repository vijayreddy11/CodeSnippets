//package com.modak.spiderweb.crawlers;
//
//import com.jcraft.jsch.ChannelSftp;
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.DelimitedFileFormatUtil;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.SemiStructuredUtils;
//import com.modak.utility.TimeStampUtils;
//import com.modak.utility.connector.FTPConnector;
//import com.modak.utils.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.io.FilenameUtils;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.util.*;
//
//
//public class SFTPCrawler extends BaseCrawler {
//    private ChannelSftp sftpChannel;
//    private final int BATCH_SIZE = 1000;
//    private String path;
//    protected SFTPCrawler sftcrawler;
//    private FTPConnector sftpConnector;
//    protected SemiStructuredUtils semiStructuredUtils;
//    protected DelimitedFileFormatUtil delimitedFileFormatUtil;
//    private final List<Object[]> list_of_objects_array = new ArrayList<>();
//    private final List<Object[]> columnMetadata = new ArrayList<>();
//    private static final Logger logger = LogManager.getLogger(SFTPCrawler.class);
//
//    /**
//     * This method is used to establish source connection
//     */
//
//    @Override
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                String creds = this.getCredentialsForSource();
//                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
//                String userName = HashMapUtility.getString(credentials, (CrawlerCommon.USER_NAME));
//                if (userName == null) {
//                    throw new NullPointerException(CrawlerCommon.USER_NAME + CrawlerCommon.IS_NULL);
//                }
//                String password = HashMapUtility.getString(credentials, CrawlerCommon.PASSWORD);
//                if (password == null) {
//                    throw new NullPointerException(CrawlerCommon.PASSWORD + CrawlerCommon.IS_NULL);
//                }
//                HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.SOURCE_INFO_DETAILS);
//                String host_name = HashMapUtility.getString(sourceInfo, CrawlerCommon.HOST_NAME);
//                path = HashMapUtility.getString(sourceInfo, CrawlerCommon.PATH);
//                HashMapUtility.put(sourceAttributes, CrawlerCommon.PATH, path);
//                sftpConnector = new FTPConnector();
//                sftpChannel = sftpConnector.configureSFTPClient(host_name, userName, password);
//                if (sftpChannel != null) {
//                    logger.info(CrawlerCommon.SFTP_SERVER_CONNECTED_STATUS, host_name, sftpChannel.isConnected());
//                }
//                boolean fetchColumnMetadata = HashMapUtility.getBoolean(sourceInfo, CrawlerCommon.FETCH_COLUMN_METADATA);
//                sourceAttributes.put(CrawlerCommon.FETCH_COLUMN_METADATA, fetchColumnMetadata);
//                sourceAttributes.put(CrawlerCommon.FETCH_STATS_TYPE, HashMapUtility.getString(sourceInfo, CrawlerCommon.FETCH_STATS_TYPE));
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        this.getDirectories();
//    }
//
//
//    /**
//     * This method executes a set of queries sequentially  defined in json file
//     */
//    @Override
//    public void doCrawling() {
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = HashMapUtility.getString(crawlingTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                        dataMap.put(templateName, list_of_map);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else {
//                        String fetchStatsType = HashMapUtility.getString(sourceAttributes, CrawlerCommon.FETCH_STATS_TYPE);
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_FILEMETADATA)) {
//                            processDirectory(path, query, fetchStatsType);
//                            if (list_of_objects_array.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                list_of_objects_array.clear();
//                            }
//                        } else {
//                            if (HashMapUtility.getBoolean(sourceAttributes, CrawlerCommon.FETCH_COLUMN_METADATA)) {
//                                processColumnMetadata(query, fetchStatsType);
//                                if (columnMetadata.size() > 0) {
//                                    jdbcUtility.executeBatchUpdateQuery(columnMetadata, query, dataSource.getConnection(), true);
//                                    columnMetadata.clear();
//                                }
//                            }
//                        }
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//    }
//
//
//    private void processDirectory(String path, String query, String fetchStatsType) throws Exception {
//        try {
//            for (Object file : sftpChannel.ls(path)) {
//                ChannelSftp.LsEntry entry = (ChannelSftp.LsEntry) file;
//                boolean isDir = entry.getAttrs().isDir();
//                if (isDir) {
//                    if (!entry.getFilename().matches("^.") && !entry.getFilename().matches("^..")) {
//                        processDirectory(path + CrawlerCommon.FILE_SEPARATOR + entry.getFilename(), query, fetchStatsType);
//                    }
//                } else {
//                    Object[] obj = processFile(entry, path, fetchStatsType);
//                    if (obj != null) {
//                        list_of_objects_array.add(obj);
//                        if (list_of_objects_array.size() >= BATCH_SIZE) {
//                            jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                            list_of_objects_array.clear();
//                        }
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    private void processColumnMetadata(final String query, String fetchStatsType) throws Exception {
//        try {
//            for (Object file : sftpChannel.ls(path)) {
//                ChannelSftp.LsEntry entry = (ChannelSftp.LsEntry) file;
//                boolean isDir = entry.getAttrs().isDir();
//                if (isDir) {
//                    if (!entry.getFilename().matches("^.") && !entry.getFilename().matches("^..")) {
//                        processDirectory(path + CrawlerCommon.FILE_SEPARATOR + entry.getFilename(), query, fetchStatsType);
//                    }
//                } else {
//                    String filename = entry.getFilename();
//                    String fileFormat = FilenameUtils.getExtension(filename);
//                    String absolutePath;
//                    if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.FILE)) {
//                        absolutePath = path;
//                    } else {
//                        absolutePath = path + CrawlerCommon.FILE_SEPARATOR + filename;
//                    }
//
//                    if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                        InputStream inputStream = sftpChannel.get(absolutePath);
//
//                        String delimiterFileFormat;
//                        semiStructuredUtils = new SemiStructuredUtils();
//                        if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                            sftcrawler.processInputStream(inputStream);
//                            delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//                        } else {
//                            sftcrawler.processInputStream(inputStream);
//                            delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//                        }
//                        HashMap<String, Object> delimiterFileFormatMap = JSONUtils.jsonToMap(delimiterFileFormat);
//                        boolean header = (boolean) HashMapUtility.get(delimiterFileFormatMap, CrawlerCommon.HEADER);
//                        if (header) {
//                            columnMetadata.addAll(getCSVMetadata(absolutePath, filename, fileFormat));
//                        }
//                    } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.AVRO)) {
//                        columnMetadata.addAll(getAvroMetadata(absolutePath, filename));
//                    }
//                    if (columnMetadata.size() >= BATCH_SIZE) {
//                        jdbcUtility.executeBatchUpdateQuery(columnMetadata, query, dataSource.getConnection(), true);
//                        columnMetadata.clear();
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//
//    public List<Object[]> getCSVMetadata(String absolutePath, String nameOfFile, String fileFormat) throws Exception {
//        InputStream inputStream = null;
//
//        try {
//            List<Object[]> list_of_objects_array = new ArrayList<>();
//
//            inputStream = sftpChannel.get(absolutePath);
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getCSVColMetadata(inputStream, fileFormat);
//            for (HashMap<String, Object> map : listMap) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        nameOfFile,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    public List<Object[]> getAvroMetadata(String absolutePath, String nameOfFile) throws Exception {
//        InputStream inputStream = null;
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        try {
//
//            inputStream = sftpChannel.get(absolutePath);
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getAvroColMetadata(inputStream);
//
//            for (HashMap<String, Object> map : listMap) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        nameOfFile,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    private void processInputStream(InputStream stream) throws IOException {
//        stream.available();
//        stream.close();
//
//    }
//
//    private Object[] processFile(ChannelSftp.LsEntry sftpFile, String path, String fetchStatsType) throws Exception {
//        InputStream inputStream = null;
//        try {
//            if (sftpFile != null) {
//                String filename = sftpFile.getFilename();
//                int lastModifiedTime = sftpFile.getAttrs().getMTime();
//                String fileFormat = FilenameUtils.getExtension(filename);
//                String absolutePath;
//                String relativePath;
//                if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.FILE)) {
//                    absolutePath = path;
//                    relativePath = absolutePath.replaceFirst("/", "");
//                } else {
//                    absolutePath = path + CrawlerCommon.FILE_SEPARATOR + filename;
//                    relativePath = absolutePath.replace(sourceAttributes.get(CrawlerCommon.PATH).toString(), "");
//                    relativePath = relativePath.replaceFirst("/", "");
//                }
//
//                String delimiterFileFormat = null;
//                sftcrawler = new SFTPCrawler();
//                delimitedFileFormatUtil = new DelimitedFileFormatUtil();
//                inputStream = sftpChannel.get(absolutePath);
//                if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                    sftcrawler.processInputStream(inputStream);
//                    delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//
//                } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                    sftcrawler.processInputStream(inputStream);
//                    delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//
//                }
//
//                return new Object[]{
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        filename,
//                        fileFormat,
//                        absolutePath,
//                        relativePath,
//                        TimeStampUtils.changeToTimeStamp(lastModifiedTime * 1000l),
//                        false,
//                        sftpFile.getAttrs().isDir(),
//                        false,
//                        sftpFile.getAttrs().getSize(),
//                        sftpFile.getAttrs().getUId(),
//                        sftpFile.getAttrs().getGId(),
//                        delimiterFileFormat,
//                        null
//                };
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null) {
//                    inputStream.close();
//                }
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//        return null;
//    }
//
//
//    @Override
//    public void closeResources() {
//        try {
//            sftpConnector.closeSFTPConnection(sftpChannel);
//        } catch (Exception e) {
//            e.printStackTrace();
//            logger.error(e.getMessage(), e);
//        }
//    }
//}
