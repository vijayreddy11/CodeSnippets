//package com.modak.spiderweb.crawlers;
//
//import com.amazonaws.auth.AWSCredentials;
//import com.amazonaws.auth.AWSStaticCredentialsProvider;
//import com.amazonaws.auth.BasicAWSCredentials;
//import com.amazonaws.services.s3.AmazonS3;
//import com.amazonaws.services.s3.AmazonS3ClientBuilder;
//import com.amazonaws.services.s3.model.*;
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.DelimitedFileFormatUtil;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.SemiStructuredUtils;
//import com.modak.utility.TimeStampUtils;
//import com.modak.utils.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.io.FilenameUtils;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.hadoop.conf.Configuration;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.apache.parquet.hadoop.ParquetFileReader;
//import org.apache.parquet.hadoop.util.HadoopInputFile;
//
//import java.io.IOException;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.*;
//
//public class S3Crawler extends BaseCrawler {
//
//    private static final Logger logger = LogManager.getLogger(S3Crawler.class);
//    private AmazonS3 s3Client = null;
//    private String bucketName;
//    private String accesskeyid;
//    private String secretkey;
//    protected List<S3ObjectSummary> summaries = null;
//    protected SemiStructuredUtils semiStructuredUtils;
//    protected DelimitedFileFormatUtil delimitedFileFormatUtil;
//    private List<Object[]> list_of_objects_array = new ArrayList<>();
//
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                String creds = this.getCredentialsForSource();
//                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
//                accesskeyid = HashMapUtility.getString(credentials, CrawlerCommon.ACCESS_KEY);
//                if (accesskeyid == null) {
//                    throw new NullPointerException(CrawlerCommon.ACCESS_KEY + CrawlerCommon.IS_NULL);
//                }
//                secretkey = HashMapUtility.getString(credentials, CrawlerCommon.SECRET_KEY);
//                if (secretkey == null) {
//                    throw new NullPointerException(CrawlerCommon.SECRET_KEY + CrawlerCommon.IS_NULL);
//                }
//                HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.SOURCE_INFO_DETAILS);
//                bucketName = HashMapUtility.getString(sourceInfo, CrawlerCommon.BUCKET);
//                String path = HashMapUtility.getString(sourceInfo, CrawlerCommon.PATH);
//                String fetchStatsType = HashMapUtility.getString(sourceInfo, CrawlerCommon.FETCH_STATS_TYPE);
//                sourceAttributes.put(CrawlerCommon.DIRECTORY_NAME, bucketName);
//                sourceAttributes.put(CrawlerCommon.BUCKET_NAME, bucketName);
//                sourceAttributes.put(CrawlerCommon.PATH, path);
//                sourceAttributes.put(CrawlerCommon.FETCH_STATS_TYPE, fetchStatsType);
//                String region = HashMapUtility.getString(sourceInfo, CrawlerCommon.REGION);
//
//                AWSCredentials awsCredentials = new BasicAWSCredentials(accesskeyid, secretkey);
//
//                s3Client = AmazonS3ClientBuilder
//                        .standard()
//                        .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
//                        .withRegion(region)
//                        .build();
//
//                s3Client.listObjects(bucketName);
//
//                boolean fetchColumnMetadata = HashMapUtility.getBoolean(sourceInfo, CrawlerCommon.FETCH_COLUMN_METADATA);
//                sourceAttributes.put(CrawlerCommon.FETCH_COLUMN_METADATA, fetchColumnMetadata);
//
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            this.insertError(e);
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        this.getDirectories();
//    }
//
//    @Override
//    public void doCrawling() {
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = HashMapUtility.getString(crawlingTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                        dataMap.put(templateName, list_of_map);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else {
//                        int BATCH_SIZE = 1000;
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_FILEMETADATA)) {
//                            for (S3ObjectSummary fileObjectSummary : getMetadataFromS3(s3Client)) {
//                                if (!fileObjectSummary.getKey().endsWith(CrawlerCommon.FILE_SEPARATOR)) {
//                                    list_of_objects_array.add(processFile(s3Client, fileObjectSummary, bucketName));
//                                    if (list_of_objects_array.size() >= BATCH_SIZE) {
//                                        jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                        list_of_objects_array.clear();
//                                    }
//                                }
//                            }
//                            if (list_of_objects_array.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                list_of_objects_array.clear();
//                            }
//                        } else {
//                            if (HashMapUtility.getBoolean(sourceAttributes, CrawlerCommon.FETCH_COLUMN_METADATA)) {
//                                for (S3ObjectSummary objectSummary : getMetadataFromS3(s3Client)) {
//                                    if (!objectSummary.getKey().endsWith(CrawlerCommon.FILE_SEPARATOR)) {
//                                        String fileFormat = FilenameUtils.getExtension(objectSummary.getKey());
//                                        if (fileFormat.equalsIgnoreCase(CrawlerCommon.TSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.CSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.AVRO) || fileFormat.equalsIgnoreCase(CrawlerCommon.PARQUET))
//                                            list_of_objects_array.addAll(processColumnMetadata(objectSummary, fileFormat));
//                                        if (list_of_objects_array.size() >= BATCH_SIZE) {
//                                            jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                            list_of_objects_array.clear();
//                                        }
//                                    }
//                                }
//                                if (list_of_objects_array.size() > 0) {
//                                    jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                    list_of_objects_array.clear();
//                                }
//                            }
//                        }
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//    }
//
//
//    public List<S3ObjectSummary> getMetadataFromS3(AmazonS3 s3Client) throws Exception {
//        try {
//            String path = HashMapUtility.getString(sourceAttributes, CrawlerCommon.PATH);
//            String fetchStatsType = HashMapUtility.getString(sourceAttributes, CrawlerCommon.FETCH_STATS_TYPE);
//            if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.BUCKET)) {
//                ObjectListing listing = s3Client.listObjects(bucketName);
//                summaries = listing.getObjectSummaries();
//                while (listing.isTruncated()) {
//                    listing = s3Client.listNextBatchOfObjects(listing);
//                    summaries.addAll(listing.getObjectSummaries());
//                }
//            } else if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.DIRECTORY)) {
//                if (!path.endsWith(CrawlerCommon.FILE_SEPARATOR)) {
//                    path = path + CrawlerCommon.FILE_SEPARATOR;
//                }
//                getSummaries(bucketName, path);
//            } else if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.FILE)) {
//                getSummaries(bucketName, path);
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//        return summaries;
//    }
//
//    private void getSummaries(String bucketName, String path) throws Exception {
//        ListObjectsRequest listObjectsRequest = new ListObjectsRequest().withBucketName(bucketName).withPrefix(path).withDelimiter(CrawlerCommon.FILE_SEPARATOR);
//        ObjectListing objects = s3Client.listObjects(listObjectsRequest);
//        summaries = objects.getObjectSummaries();
//        while (objects.isTruncated()) {
//            objects = s3Client.listNextBatchOfObjects(objects);
//            summaries.addAll(objects.getObjectSummaries());
//        }
//    }
//
//
//    private Object[] processFile(AmazonS3 s3Client, S3ObjectSummary objectSummary, String bucketName) throws Exception {
//        String owner_id;
//        String owner_name;
//        String fileFormat = FilenameUtils.getExtension(objectSummary.getKey());
//        String relativePath = objectSummary.getKey();
//        Path filePath = Paths.get(relativePath);
//        String nameOfFile = filePath.getFileName().toString();
//        owner_id = objectSummary.getOwner().getId();
//        owner_name = objectSummary.getOwner().getDisplayName();
//
//        S3Object s3object = s3Client.getObject(bucketName, relativePath);
//        S3ObjectInputStream inputStream = s3object.getObjectContent();
//        String delimiterFileFormat = null;
//        delimitedFileFormatUtil = new DelimitedFileFormatUtil();
//        if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//            delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//        } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//            delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//        }
//
//
//        Object[] obj;
//        try {
//            obj = new Object[]{
//                    sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                    sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                    sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                    nameOfFile,
//                    fileFormat,
//                    s3Client.getUrl(bucketName, objectSummary.getKey()).toURI().toString(),
//                    objectSummary.getKey(),
//                    TimeStampUtils.changeToTimeStamp(objectSummary.getLastModified().getTime()),
//                    false,
//                    objectSummary.getKey().endsWith(CrawlerCommon.FILE_SEPARATOR),
//                    false,
//                    objectSummary.getSize(),
//                    owner_id,
//                    owner_name,
//                    delimiterFileFormat,
//                    null
//            };
//
//            return obj;
//
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null) {
//                    inputStream.close();
//                }
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//
//    private List<Object[]> processColumnMetadata(S3ObjectSummary objectSummary, String fileFormat) throws Exception {
//        S3ObjectInputStream inputStream = null;
//        String relativePath = objectSummary.getKey();
//        Path filePath = Paths.get(relativePath);
//        String nameOfFile = filePath.getFileName().toString();
//        List<Object[]> columnMetadata = new ArrayList<>();
//        semiStructuredUtils = new SemiStructuredUtils();
//        try {
//            if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                S3Object s3object = s3Client.getObject(bucketName, relativePath);
//                inputStream = s3object.getObjectContent();
//                String delimiterFileFormat;
//                if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                    delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//                } else {
//                    delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//                }
//                HashMap<String, Object> delimiterFileFormatMap = JSONUtils.jsonToMap(delimiterFileFormat);
//                boolean header = (boolean) HashMapUtility.get(delimiterFileFormatMap, CrawlerCommon.HEADER);
//                if (header) {
//                    columnMetadata = getCSVMetadata(relativePath, nameOfFile, fileFormat);
//                }
//
//            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.AVRO)) {
//                columnMetadata = getAvroMetadata(relativePath, nameOfFile);
//            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.PARQUET)) {
//                columnMetadata = getParquetMetadata(relativePath, nameOfFile);
//            }
//            return columnMetadata;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null) {
//                    inputStream.close();
//                }
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    public List<Object[]> getParquetMetadata(String relativePath, String nameOfFile) throws Exception {
//        ParquetFileReader reader = null;
//
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        try {
//            S3Object s3object = s3Client.getObject(bucketName, relativePath);
//            Configuration conf = new Configuration();
//            conf.set("fs.s3.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem");
//            conf.set("fs.s3.awsAccessKeyId", accesskeyid);
//            conf.set("fs.s3.awsSecretAccessKey", secretkey);
//
//            reader = ParquetFileReader.open(HadoopInputFile.fromPath(new org.apache.hadoop.fs.Path("s3://" + bucketName + CrawlerCommon.FILE_SEPARATOR + relativePath), conf));
//            List<LinkedHashMap<String, Object>> listMap = semiStructuredUtils.getParquetColMetadata(reader);
//            for (LinkedHashMap<String, Object> map : listMap) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        nameOfFile,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        s3Client.getUrl(bucketName, s3object.getKey()).toURI().toString(),
//                        null,
//                        null,
//                        null,
//                        null,
//                        listMap.indexOf(map),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (reader != null)
//                    reader.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    public List<Object[]> getAvroMetadata(String relativePath, String nameOfFile) throws Exception {
//        S3ObjectInputStream inputStream = null;
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        try {
//            S3Object s3object = s3Client.getObject(bucketName, relativePath);
//            inputStream = s3object.getObjectContent();
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getAvroColMetadata(inputStream);
//            for (HashMap<String, Object> map : listMap) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        nameOfFile,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        s3Client.getUrl(bucketName, s3object.getKey()).toURI().toString(),
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//
//        }
//    }
//
//    public List<Object[]> getCSVMetadata(String relativePath, String nameOfFile, String fileFormat) throws Exception {
//        S3ObjectInputStream inputStream = null;
//        S3Object s3object;
//        try {
//            List<Object[]> list_of_objects_array = new ArrayList<>();
//            s3object = s3Client.getObject(bucketName, relativePath);
//            inputStream = s3object.getObjectContent();
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getCSVColMetadata(inputStream, fileFormat);
//            for (HashMap<String, Object> map : listMap) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        nameOfFile,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        s3Client.getUrl(bucketName, s3object.getKey()).toURI().toString(),
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    public void closeResources() {
//        if (s3Client != null) {
//            s3Client.shutdown();
//        }
//    }
//}
