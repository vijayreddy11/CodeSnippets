//package com.modak.spiderweb.crawlers;
//
//import com.modak.utils.JSONUtils;
//import org.apache.commons.dbutils.handlers.ColumnListHandler;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.db.DBUtils;
//
//import java.sql.*;
//import java.util.*;
//
//public class AthenaCrawler extends BaseCrawler {
//
//    private static final Logger logger = LogManager.getLogger(AthenaCrawler.class);
//    private Connection sourceConnection;
//
//    @Override
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                HashMap<String, Object> additionalInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.ADDITIONAL_INFO);
//                String jdbcDriver = HashMapUtility.getString(additionalInfo, CrawlerCommon.JDBC_DRIVER);
//                sourceAttributes.put(CrawlerCommon.JDBC_DRIVER, jdbcDriver);
//                Class.forName(jdbcDriver);
//
//                String creds = this.getCredentialsForSource();
//                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
//                String accessKeyId = HashMapUtility.getString(credentials, CrawlerCommon.ACCESS_KEY);
//                if (accessKeyId == null) {
//                    throw new NullPointerException(CrawlerCommon.ACCESS_KEY + CrawlerCommon.IS_NULL);
//                }
//                String secretKey = HashMapUtility.getString(credentials, CrawlerCommon.SECRET_KEY);
//                if (secretKey == null) {
//                    throw new NullPointerException(CrawlerCommon.SECRET_KEY + CrawlerCommon.IS_NULL);
//                }
//
//                HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.SOURCE_INFO_DETAILS);
//                String jdbcURL = HashMapUtility.getString(sourceAttributes, CrawlerCommon.JDBC_URL);
//                String region_athena = HashMapUtility.getString(sourceInfo, CrawlerCommon.REGION);
//                String s3OutputLocation = "s3://" + HashMapUtility.getString(sourceInfo, CrawlerCommon.BUCKET) + "/athena-s3-result/";
//                String awsCredentialProviderClass = CrawlerCommon.AWS_CREDENTIAL_PROVIDER_CLASS;
//                String region = "AwsRegion=" + region_athena;
//                jdbcURL = jdbcURL.replace(CrawlerCommon.REGION, region) + ";";
//                sourceAttributes.put(CrawlerCommon.JDBC_URL, jdbcURL);
//                String databaseName = HashMapUtility.getString(sourceInfo, CrawlerCommon.DATABASE_NAME);
//                sourceAttributes.put(CrawlerCommon.DATABASE_NAME, databaseName);
//
//                Properties prop = new Properties();
//                System.setProperty("aws.accesskeyId", accessKeyId);
//                System.setProperty("aws.secretKey", secretKey);
//                prop.setProperty("s3OutputLocation", s3OutputLocation);
//                prop.setProperty("AwsCredentialProviderClass", awsCredentialProviderClass);
//                prop.put("UID", accessKeyId);
//                prop.put("PWD", secretKey);
//                sourceConnection = DriverManager.getConnection(jdbcURL, prop);
//                if (sourceConnection == null) {
//                    throw new NullPointerException(CrawlerCommon.SOURCE_CONNECTION_IS_NULL);
//                }
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            this.insertError(e);
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        this.getSchemas(sourceConnection);
//    }
//
//    @Override
//    public void doCrawling() {
//        Connection koshConnection = null;
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = HashMapUtility.getString(crawlingTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        String connection_type = HashMapUtility.getString(dependentMap, CrawlerCommon.CONNECTION_TYPE);
//                        if (connection_type.equalsIgnoreCase(CrawlerCommon.SOURCE)) {
//                            if (sourceConnection != null) {
//                                List<LinkedHashMap<String, Object>> listOfMaps = DBUtils.executeQuery(sourceConnection, query);
//                                dataMap.put(templateName, listOfMaps);
//                            } else {
//                                logger.error(CrawlerCommon.SOURCE_CONNECTION_OBJECT_IS_NULL);
//                            }
//                        } else {
//                            List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                            dataMap.put(templateName, list_of_map);
//                        }
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT_INSERT)) {
//                        HashMap<String, Object> tempMap = (HashMap<String, Object>) templateMap.get(templateName);
//                        String connection_type = HashMapUtility.getString(tempMap, CrawlerCommon.CONNECTION_TYPE);
//                        String selectQueryTemplate = HashMapUtility.getString(tempMap, CrawlerCommon.SELECT_QUERY);
//                        String selectQuery = templateRenderer.renderTemplate(templateGroup, selectQueryTemplate, CrawlerCommon.DATA, dataMap);
//                        String insertQueryTemplate = HashMapUtility.getString(tempMap, CrawlerCommon.INSERT_QUERY);
//                        String insertQuery = templateRenderer.renderTemplate(templateGroup, insertQueryTemplate, CrawlerCommon.DATA, dataMap);
//                        if (connection_type.equalsIgnoreCase(CrawlerCommon.SOURCE_KOSH)) {
//                            jdbcUtility.executeSelectInsertBatchMode(sourceConnection, selectQuery, dataSource.getConnection(), insertQuery, true);
//                        } else {
//                            koshConnection = dataSource.getConnection();
//                            jdbcUtility.executeSelectInsertBatchMode(koshConnection, selectQuery, dataSource.getConnection(), insertQuery, true);
//                        }
//                    } else {
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_ESTIMATED_ROWS)) {
//                            updateCountAndEncryption(sourceConnection, query);
//                        }
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        } finally {
//            try {
//                if (koshConnection != null)
//                    koshConnection.close();
//            } catch (SQLException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    private void updateCountAndEncryption(Connection sourceConnection, String insertQuery) throws Exception {
//        try {
//            Statement st = sourceConnection.createStatement();
//            String schemaName = HashMapUtility.getString(sourceAttributes, CrawlerCommon.SCHEMA_NAME);
//            String countQuery = "select count(table_name) from staging.athena_information_tables_from_dataplace_" + dataMap.get(CrawlerCommon.RESOURCE_ID);
//            List<String> tableCount = (List<String>) jdbcUtility
//                    .executeSelectQuery(countQuery, dataSource.getConnection(), true, new ColumnListHandler());
//            int count = Integer.valueOf(String.valueOf(tableCount.get(0)));
//            int i;
//            if (count % 1000 == 0) {
//                i = count / 1000;
//            } else {
//                i = count / 1000 + 1;
//            }
//            int limit = 1000;
//            int offset = 0;
//            List<Object[]> list_of_objects_array = new ArrayList<>();
//            for (int j = 0; j < i; j++) {
//                String selectQuery = "select table_name from staging.athena_information_tables_from_dataplace_" + dataMap.get(CrawlerCommon.RESOURCE_ID) + " limit " + limit + " offset " + offset;
//                List<String> tablesList = (List<String>) jdbcUtility
//                        .executeSelectQuery(selectQuery, dataSource.getConnection(), true, new ColumnListHandler());
//                for (String table : tablesList) {
//                    ResultSet rs = st.executeQuery("select count(*) as estimated_rows from " + schemaName + "." + table);
//                    while (rs.next()) {
//                        Object[] obj = {
//                                sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                                sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                                sourceAttributes.get(CrawlerCommon.SCHEMA_NAME),
//                                table,
//                                rs.getInt(CrawlerCommon.ESTIMATED_ROWS)
//                        };
//                        list_of_objects_array.add(obj);
//                    }
//                }
//                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, insertQuery, dataSource.getConnection(), true);
//                list_of_objects_array.clear();
//                offset = limit;
//                limit = limit + 1000;
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//
//    @Override
//    public void closeResources() {
//        if (sourceConnection != null) {
//            try {
//                sourceConnection.close();
//            } catch (SQLException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//}
