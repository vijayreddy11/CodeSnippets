//package com.modak.spiderweb.crawlers;
//
//import com.google.cloud.bigquery.*;
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.UtilityCommon;
//import com.modak.utility.connector.BigQueryConnector;
//import com.modak.utility.json.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.commons.lang3.StringUtils;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//
//public class BigQueryCrawler extends BaseCrawler {
//
//    private static final Logger logger = LogManager.getLogger(BigQueryCrawler.class);
//    protected BigQueryConnector bigQueryConnector;
//    protected List<Object[]> list_of_dba_all_tables = new ArrayList<>();
//    protected List<Object[]> list_of_all_table_cols = new ArrayList<>();
//    private final int BATCH_SIZE = 1000;
//    protected ArrayList<String> tablesList = new ArrayList<>();
//
//    @Override
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                String creds = this.getCredentialsForSource();
//                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
//                String credentialsJson = com.modak.utils.JSONUtils.map2JsonString(credentials);
//                sourceAttributes.put(CrawlerCommon.PROJECT_ID, HashMapUtility.get(credentials, CrawlerCommon.PROJECT_ID));
//                sourceAttributes.put(CrawlerCommon.CLIENT_CONFIGS, credentialsJson);
//                bigQueryConnector = new BigQueryConnector(sourceAttributes);
//                bigQueryConnector.initCredentials();
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        if (!isErrored) {
//            try {
//                List<String> schemas = bigQueryConnector.getSchemaList();
//                this.getSchemasForCloudRelationalSources(schemas);
//            } catch (Exception e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//                insertError(e);
//            }
//        }
//    }
//
//    @Override
//    public void doCrawling() {
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                String datasetId = HashMapUtility.getString(sourceAttributes, CrawlerCommon.SCHEMA_NAME);
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = HashMapUtility.getString(crawlingTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                        dataMap.put(templateName, list_of_map);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else {
//                        Dataset dataset = bigQueryConnector.bigQuery.getDataset(datasetId);
//                        if (dataset != null) {
//                            for (Table bigQueryTable : dataset.list().iterateAll()) {
//                                TableId bigQueryTableTableId = bigQueryTable.getTableId();
//                                tablesList.add(bigQueryTableTableId.getTable());
//                                if (tablesList.size() >= BATCH_SIZE) {
//                                    if (templateName.equals(CrawlerCommon.STAGING_INSERT_TABLEMETADATA)) {
//                                        list_of_dba_all_tables = fetchAllTablesMetadata(tablesList, datasetId);
//                                        jdbcUtility.executeBatchUpdateQuery(list_of_dba_all_tables, query, dataSource.getConnection(), true);
//                                        list_of_dba_all_tables.clear();
//                                    } else if (templateName.equals(CrawlerCommon.STAGING_INSERT_COLUMNMETADATA)) {
//                                        list_of_all_table_cols = fetchAllColumnsMetadata(tablesList, datasetId, query);
//                                        if (list_of_all_table_cols.size() > 0) {
//                                            jdbcUtility.executeBatchUpdateQuery(list_of_all_table_cols, query, dataSource.getConnection(), true);
//                                            list_of_all_table_cols.clear();
//                                        }
//                                    } else {
//                                        logger.info(CrawlerCommon.INVALID_QUERY_TYPE + queryType);
//                                    }
//                                    tablesList.clear();
//                                }
//                            }
//                            if (tablesList.size() > 0) {
//                                if (templateName.equals(CrawlerCommon.STAGING_INSERT_TABLEMETADATA)) {
//                                    list_of_dba_all_tables = fetchAllTablesMetadata(tablesList, datasetId);
//                                    jdbcUtility.executeBatchUpdateQuery(list_of_dba_all_tables, query, dataSource.getConnection(), true);
//                                    list_of_dba_all_tables.clear();
//
//                                } else if (templateName.equals(CrawlerCommon.STAGING_INSERT_COLUMNMETADATA)) {
//                                    list_of_all_table_cols = fetchAllColumnsMetadata(tablesList, datasetId, query);
//                                    if (list_of_all_table_cols.size() > 0) {
//                                        jdbcUtility.executeBatchUpdateQuery(list_of_all_table_cols, query, dataSource.getConnection(), true);
//                                        list_of_all_table_cols.clear();
//                                    }
//                                } else {
//                                    logger.info(CrawlerCommon.INVALID_QUERY_TYPE + queryType);
//                                }
//                                tablesList.clear();
//                            }
//                        }
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//    }
//
//    public List<Object[]> fetchAllTablesMetadata(ArrayList<String> tablesList, String schemaName) throws Exception {
//        if (tablesList == null || tablesList.isEmpty()) {
//            return null;
//        } else {
//            for (String table : tablesList) {
//                list_of_dba_all_tables.add(bigQueryConnector.getTableMetadata(schemaName, table));
//            }
//            return list_of_dba_all_tables;
//        }
//    }
//
//    public List<Object[]> fetchAllColumnsMetadata(ArrayList<String> tablesList, String schemaName, String query) throws Exception {
//        try {
//            for (String tableName : tablesList) {
//                tableName = StringUtils.trim(tableName);
//                if (StringUtils.isNotEmpty(tableName)) {
//                    Table bigQueryTable = bigQueryConnector.bigQuery.getTable(schemaName, tableName);
//                    StandardTableDefinition standardTableDefinition = bigQueryTable.getDefinition();
//                    Schema schema = standardTableDefinition.getSchema();
//                    if (schema != null) {
//                        FieldList fieldList = schema.getFields();
//                        for (int i = 0; i < fieldList.size(); i++) {
//                            List<Object> columnDetails = new ArrayList<>();
//                            Field field = fieldList.get(i);
//                            Field.Mode mode = field.getMode();
//                            StandardSQLTypeName standardSQLTypeName = field.getType().getStandardType();
//                            columnDetails.add(sourceAttributes.get(UtilityCommon.DATAPLACE_ID));
//                            columnDetails.add(sourceAttributes.get(UtilityCommon.SCHEMA_ID));
//                            columnDetails.add(sourceAttributes.get(UtilityCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                            columnDetails.add(sourceAttributes.get(UtilityCommon.SCHEMA_NAME));
//                            columnDetails.add(tableName); //table_name
//                            columnDetails.add(sourceAttributes.get(UtilityCommon.SCHEMA_NAME));
//                            columnDetails.add(field.getName()); //column_name
//                            String modifiedColumnDataType = mode == Field.Mode.REPEATED ? standardSQLTypeName + UtilityCommon.KEY_REPEATED : standardSQLTypeName.toString();
//                            columnDetails.add(modifiedColumnDataType); //data_type
//                            columnDetails.add(mode.toString()); //NULLABLE, REQUIRED, REPEATED
//                            columnDetails.add(i); //ordinal_position
//                            list_of_all_table_cols.add(columnDetails.toArray());
//                            if (list_of_all_table_cols.size() >= BATCH_SIZE) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_all_table_cols, query, dataSource.getConnection(), true);
//                                list_of_all_table_cols.clear();
//                            }
//                        }
//                    } else {
//                        throw new NullPointerException(UtilityCommon.EXP_NULL_SCHEMA + tableName);
//                    }
//                }
//            }
//            return list_of_all_table_cols;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//
//    @Override
//    public void closeResources() {
//    }
//}
