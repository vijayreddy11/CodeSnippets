//package com.modak.spiderweb.crawlers;
//
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.DelimitedFileFormatUtil;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.SemiStructuredUtils;
//import com.modak.utility.TimeStampUtils;
//import com.modak.utility.connector.FTPConnector;
//import com.modak.utility.db.DBUtils;
//import com.modak.utils.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.io.FilenameUtils;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.commons.net.ftp.FTPClient;
//import org.apache.commons.net.ftp.FTPFile;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.sql.Connection;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//public class FTPCrawler extends BaseCrawler {
//
//    private Connection sourceConnection;
//    private org.apache.commons.net.ftp.FTPClient ftpClient;
//    private String path;
//    protected DelimitedFileFormatUtil delimitedFileFormatUtil;
//    private List<Object[]> list_of_object_array = new ArrayList<>();
//    private List<Object[]> column_metadata_objects_array = new ArrayList<>();
//    private List<Map> list_of_path_for_column_metadata = new ArrayList<Map>();
//    private FTPConnector ftpConnector;
//
//    private final int BATCH_SIZE = 1000;
//    private static final Logger logger = LogManager.getLogger(FTPCrawler.class);
//
//
//    public void initSourceConnection() {
//        try {
//
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                String creds = this.getCredentialsForSource();
//                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
//                String userName = credentials.get("username").toString();
//                if (userName == null) {
//                    throw new NullPointerException(CrawlerCommon.USER_NAME + CrawlerCommon.IS_NULL);
//                }
//                String password = credentials.get("password").toString();
//                if (password == null) {
//                    throw new NullPointerException(CrawlerCommon.PASSWORD + CrawlerCommon.IS_NULL);
//                }
//                HashMap<String, Object> sourceInfo = (HashMap<String, Object>) sourceAttributes.get(CrawlerCommon.SOURCE_INFO_DETAILS);
//
//                if (sourceInfo.get(CrawlerCommon.PATH).toString() == null) {
//                    throw new NullPointerException(CrawlerCommon.PATH + CrawlerCommon.IS_NULL);
//                }
//                path = sourceInfo.get(CrawlerCommon.PATH).toString();
//
//                if (sourceInfo.get(CrawlerCommon.HOST_NAME).toString() == null) {
//                    throw new NullPointerException(CrawlerCommon.HOST_NAME + CrawlerCommon.IS_NULL);
//                }
//                sourceAttributes.put(CrawlerCommon.SOURCE_URL, sourceInfo.get(CrawlerCommon.HOST_NAME).toString());
//                String hostName = HashMapUtility.getString(sourceInfo, CrawlerCommon.HOST_NAME);
//                sourceAttributes.put(CrawlerCommon.SOURCE_URL, hostName);
//                sourceAttributes.put(CrawlerCommon.ROOT_LOCATION_PATH, path);
//                sourceAttributes.put(CrawlerCommon.USERNAME, userName);
//                sourceAttributes.put(CrawlerCommon.PASSWORD, password);
//                sourceAttributes.put(CrawlerCommon.PATH, path);
//                ftpConnector = new FTPConnector();
//                ftpClient = ftpConnector.configureFTPClient(sourceAttributes);
//                if (ftpClient.isConnected()) {
//                    logger.info("ftp server is  connected : " + ftpClient.isConnected());
//                } else {
//                    throw new NullPointerException(CrawlerCommon.NO_SOURCE_CONNECTION + CrawlerCommon.IS_NULL);
//                }
//                boolean fetchColumnMetadata = HashMapUtility.getBoolean(sourceInfo, CrawlerCommon.FETCH_COLUMN_METADATA);
//                sourceAttributes.put(CrawlerCommon.FETCH_COLUMN_METADATA, fetchColumnMetadata);
//
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            try {
//                logger.error(ExceptionUtils.getStackTrace(e));
//                insertError(e);
//            } catch (Exception ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    @Override
//    public void connectToSource() throws Exception {
//        this.getDirectories();
//    }
//
//
//    public void doCrawling() {
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = crawlingTemplateMap.get(CrawlerCommon.TEMPLATE_GROUP).toString();
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = dependentMap.get(CrawlerCommon.QUERY_TYPE).toString();
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                        dataMap.put(templateName, list_of_map);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else {
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_FILEMETADATA)) {
//                            processDirectory(path, query);
//                            if (list_of_object_array.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_object_array, query, dataSource.getConnection(), true);
//                                list_of_object_array.clear();
//                            }
//                        } else {
//                            if (queryType.equalsIgnoreCase(CrawlerCommon.BATCHUPDATE) && HashMapUtility.getBoolean(sourceAttributes, CrawlerCommon.FETCH_COLUMN_METADATA)) {
//
//
//                                for (int i = 0; i < list_of_path_for_column_metadata.size(); i++) {
//                                    List<Object[]> list_of_objects = new ArrayList<Object[]>;
//
//
//                                    if (FilenameUtils.getExtension(list_of_path_for_column_metadata.get(i).get("filename").toString()).equalsIgnoreCase(CrawlerCommon.TSV) || FilenameUtils.getExtension(list_of_path_for_column_metadata.get(i).get("filename").toString()).equalsIgnoreCase(CrawlerCommon.CSV) || FilenameUtils.getExtension(list_of_path_for_column_metadata.get(i).get("filename").toString()).equalsIgnoreCase(CrawlerCommon.AVRO)) {
//                                        list_of_objects = processColumnMetadata(list_of_path_for_column_metadata.get(i).get("filename").toString(), list_of_path_for_column_metadata.get(i).get("path").toString());
//
//
//                                        column_metadata_objects_array.addAll(list_of_objects);
//                                        if (column_metadata_objects_array.size() >= BATCH_SIZE) {
//                                            jdbcUtility.executeBatchUpdateQuery(column_metadata_objects_array, query, dataSource.getConnection(), true);
//                                            column_metadata_objects_array.clear();
//                                        }
//
//                                    }
//                                }
//
//                                if (column_metadata_objects_array.size() > 0) {
//                                    jdbcUtility.executeBatchUpdateQuery(column_metadata_objects_array, query, dataSource.getConnection(), true);
//                                }
//                            }
//                        }
//                    }
//                }
//                logger.info("Finished crawling ");
//            } else {
//                logger.info("crawling is disabled");
//            }
//        } catch (Exception e) {
//            isErrored = true;
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        } finally {
//            try {
//                closeResources();
//            } catch (Exception e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    private void processDirectory(String path, String query) {
//        try {
//            logger.info("path is : {}", path);
//
//            FTPFile[] files = ftpClient.listFiles(path);
//            logger.info("File list : {}", files.length);
//            for (FTPFile ftpFile : files) {
//                logger.debug("FtpFile is : {}", ftpFile);
//                if (ftpFile.isDirectory()) {
//                    logger.info("recursively processing directory : {}", path + ftpFile.getName().toString() + CrawlerCommon.FORWARD_SLASH, query);
//                    processDirectory(path + CrawlerCommon.FORWARD_SLASH + ftpFile.getName().toString(), query);
//                } else {
//                    Object[] obj = processFile(ftpFile, path);
//                    if (obj != null) {
//                        list_of_object_array.add(obj);
//                        if (list_of_object_array.size() >= BATCH_SIZE) {
//                            jdbcUtility.executeBatchUpdateQuery(list_of_object_array, query, sourceConnection, false);
//                            list_of_object_array.clear();
//
//                        }
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//        }
//    }
//
//
//    private Object[] processFile(FTPFile ftpFile, String path) {
//        try {
//
//            if (ftpFile != null) {
//                String filename = ftpFile.getName();
//                Map<String, Object> map_of_path = new HashMap<String, Object>();
//                map_of_path.put("filename", filename);
//                map_of_path.put("path", path);
//                list_of_path_for_column_metadata.add(map_of_path);
//                String fileFormat = FilenameUtils.getExtension(filename);
//                String delimiterFileFormat = null;
//                delimitedFileFormatUtil = new DelimitedFileFormatUtil();
//                InputStream inputStream = ftpClient.retrieveFileStream(path + CrawlerCommon.FILE_SEPARATOR + filename);
//
//                if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//
//                    delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//                } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                    delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//                }
//                ftpClient.completePendingCommand();
//                inputStream.close();
//                logger.debug("file_path is : {}", path + filename);
//                Object obj[] = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        filename,
//                        fileFormat,
//                        sourceAttributes.get(CrawlerCommon.SOURCE_URL).toString() + CrawlerCommon.FILE_SEPARATOR + path + filename,
//                        path + "/" + filename,
//                        TimeStampUtils.changeToTimeStamp(ftpFile.getTimestamp().getTimeInMillis()),
//                        false,
//                        ftpFile.isDirectory(),
//                        false,
//                        ftpFile.getSize(),
//                        ftpFile.getUser(),
//                        ftpFile.getGroup(),
//                        delimiterFileFormat,
//                        null
//                };
//                return obj;
//            }
//
//
//        } catch (Exception e1) {
//            logger.error(ExceptionUtils.getStackTrace(e1));
//            insertError(e1);
//        }
//
//        return null;
//    }
//
//    private List<Object[]> processColumnMetadata(String fileName, String filePath) throws Exception {
//        List<Object[]> columnMetadata = null;
//        String fileFormat = FilenameUtils.getExtension(fileName);
//        if (fileFormat.equals(CrawlerCommon.AVRO))
//            columnMetadata = getAvroMetadata(fileName, filePath);
//        if (fileFormat.equals(CrawlerCommon.CSV) || fileFormat.equals(CrawlerCommon.TSV)) {
//            String delimiterFileFormat;
//            InputStream inputStream = ftpClient.retrieveFileStream(path + fileName);
//            if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//            } else {
//                delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//
//            }
//            ftpClient.completePendingCommand();
//            inputStream.close();
//
//            HashMap<String, Object> delimiterFileFormatMap = com.modak.utility.json.JSONUtils.jsonToMap(delimiterFileFormat);
//
//            Object header = HashMapUtility.get(delimiterFileFormatMap, "hasHeader");
//
//            header = "true";
//            if (header == "true") {
//
//                columnMetadata = getCSVAndTSVMetadata(fileName, filePath);
//
//            }
//        }
//        return columnMetadata;
//    }
//
//
//    public List<Object[]> getAvroMetadata(String filename, String path) throws Exception {
//
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        try {
//
//            ftpClient.changeWorkingDirectory(path);
//            InputStream inputStream = ftpClient.retrieveFileStream(filename);
//            SemiStructuredUtils Object_semistruc = new SemiStructuredUtils();
//            List<Map> list_map = Object_semistruc.getAvroColMetadata(inputStream);
//
//            ftpClient.completePendingCommand();
//
//            for (Map map : list_map) {
//
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        filename,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        sourceAttributes.get(CrawlerCommon.SOURCE_URL).toString() + CrawlerCommon.FILE_SEPARATOR + path + filename,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//
//                };
//                list_of_objects_array.add(obj);
//
//            }
//            return list_of_objects_array;
//        } catch (IOException e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//        return null;
//    }
//
//    public List<Object[]> getCSVAndTSVMetadata(String filename, String path) throws Exception {
//
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        try {
//            ftpClient.changeWorkingDirectory(path);
//            InputStream inputStream1 = ftpClient.retrieveFileStream(filename);
//            SemiStructuredUtils object_semistruct = new SemiStructuredUtils();
//            List<Map> list_map = object_semistruct.getCSVColMetadata(inputStream1, FilenameUtils.getExtension(filename));
//
//
//            ftpClient.completePendingCommand();
//            inputStream1.close();
//
//            for (Map map : list_map) {
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        filename,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        sourceAttributes.get(CrawlerCommon.SOURCE_URL).toString() + CrawlerCommon.FILE_SEPARATOR + path + filename,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (IOException e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//        return null;
//    }
//
//
//    @Override
//    public void closeResources() {
//        if (sourceConnection != null) {
//            try {
//                sourceConnection.close();
//            } catch (SQLException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//}
