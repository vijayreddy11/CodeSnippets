//package com.modak.spiderweb.crawlers;
//
//import com.microsoft.azure.datalake.store.ADLStoreClient;
//import com.microsoft.azure.datalake.store.DirectoryEntry;
//import com.microsoft.azure.datalake.store.oauth2.AccessTokenProvider;
//import com.microsoft.azure.datalake.store.oauth2.ClientCredsTokenProvider;
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.DelimitedFileFormatUtil;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.SemiStructuredUtils;
//import com.modak.utils.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.io.FilenameUtils;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.hadoop.conf.Configuration;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.apache.parquet.hadoop.ParquetFileReader;
//import org.apache.parquet.hadoop.util.HadoopInputFile;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.*;
//
//public class AzureADLS1Crawler extends BaseCrawler {
//    private ADLStoreClient adlStoreClient;
//    HashMap<String, Object> credentials = null;
//    private static final Logger logger = LogManager.getLogger(AzureADLS1Crawler.class);
//    private static List<Object[]> list_of_file_objects_array = new ArrayList<>();
//    private static List<Object[]> list_of_column_objects_array = new ArrayList<>();
//    private static String fetchCrawlType = null;
//    protected DelimitedFileFormatUtil delimitedFileFormatUtil;
//
//    @Override
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                String creds = this.getCredentialsForSource();
//                credentials = JSONUtils.jsonToMap(creds);
//                HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.SOURCE_INFO_DETAILS);
//                String account_fqdn = HashMapUtility.getString(sourceInfo, CrawlerCommon.ACCOUNTFQDN);
//                String dataLakeName = HashMapUtility.getString(sourceInfo, CrawlerCommon.DATA_LAKE_NAME);
//                String fetchStatsType = HashMapUtility.getString(sourceInfo, CrawlerCommon.FETCH_STATS_TYPE);
//                String path = HashMapUtility.getString(sourceInfo, CrawlerCommon.PATH);
//                adlStoreClient = getADLStoreClient(credentials, dataLakeName);
//                adlStoreClient.enumerateDirectory(CrawlerCommon.ROOT_PATH);
//                sourceAttributes.put(CrawlerCommon.ACCOUNTFQDN, account_fqdn);
//                sourceAttributes.put(CrawlerCommon.DIRECTORY_NAME, dataLakeName);
//                sourceAttributes.put(CrawlerCommon.DATA_LAKE_NAME, dataLakeName);
//                sourceAttributes.put(CrawlerCommon.FETCH_STATS_TYPE, fetchStatsType);
//                sourceAttributes.put(CrawlerCommon.PATH, path);
//                boolean fetchColumnMetadata = HashMapUtility.getBoolean(sourceInfo, CrawlerCommon.FETCH_COLUMN_METADATA);
//                sourceAttributes.put(CrawlerCommon.FETCH_COLUMN_METADATA, fetchColumnMetadata);
//
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        this.getDirectories();
//    }
//
//    @Override
//    public void doCrawling() {
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = HashMapUtility.getString(crawlingTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                        dataMap.put(templateName, list_of_map);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else {
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_FILEMETADATA)) {
//                            fetchCrawlType = CrawlerCommon.STAGING_INSERT_FILEMETADATA;
//                            getMetadataFromAzureGenOne(query);
//                            if (list_of_file_objects_array.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_file_objects_array, query, dataSource.getConnection(), true);
//                                list_of_file_objects_array.clear();
//                            }
//                        } else {
//                            fetchCrawlType = CrawlerCommon.FETCH_COLUMN_METADATA;
//                            getMetadataFromAzureGenOne(query);
//                            if (list_of_column_objects_array.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_column_objects_array, query, dataSource.getConnection(), true);
//                                list_of_column_objects_array.clear();
//                            }
//                        }
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//    }
//
//    private ADLStoreClient getADLStoreClient(HashMap<String, Object> azureDataLakeCredMap, String dataLakeName) throws Exception {
//        AccessTokenProvider provider;
//        try {
//            provider = new ClientCredsTokenProvider(
//                    HashMapUtility.getString(azureDataLakeCredMap, CrawlerCommon.AUTH_TOKEN_ENDPOINT),
//                    HashMapUtility.getString(azureDataLakeCredMap, CrawlerCommon.CLIENTID),
//                    HashMapUtility.getString(azureDataLakeCredMap, CrawlerCommon.CLIENT_KEY));
//            return ADLStoreClient.createClient(dataLakeName + CrawlerCommon.AZURE_DATALAKE_STORE_NET, provider);
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//
//    private void getMetadataFromAzureGenOne(String query) throws Exception {
//        try {
//            String fetchStatsType = HashMapUtility.getString(sourceAttributes, CrawlerCommon.FETCH_STATS_TYPE);
//            if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.CONTAINER) || fetchStatsType.equalsIgnoreCase(CrawlerCommon.DIRECTORY) || fetchStatsType.equalsIgnoreCase(CrawlerCommon.FILE)) {
//                String relativePath = HashMapUtility.getString(sourceAttributes, CrawlerCommon.PATH);
//                if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.CONTAINER)) {
//                    fetchDataLakeStats(adlStoreClient, query);
//                } else if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.DIRECTORY)) {
//                    fetchFolderStats(adlStoreClient, relativePath, query);
//                } else {
//                    fetchFileStats(adlStoreClient, relativePath, query);
//                }
//            } else {
//                throw new Exception("Invalid configuration for fetchStatsType : (" + fetchStatsType + ")  validTypes:(" + CrawlerCommon.DATA_LAKE + "," + CrawlerCommon.DIRECTORY + "," + CrawlerCommon.FILE + ")");
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    private Object[] convertMapToObjectArray(Map<String, Object> map) throws Exception {
//        InputStream inputStream = null;
//        try {
//            String relativePath = map.get(CrawlerCommon.FILE_PATH).toString();
//            while (relativePath.startsWith(CrawlerCommon.FILE_SEPARATOR))
//                relativePath = relativePath.replaceFirst(CrawlerCommon.FILE_SEPARATOR, "");
//            String filename = map.get(CrawlerCommon.FILE_NAME).toString();
//            String absPath = CrawlerCommon.ADL_PREFIX + HashMapUtility.getString(sourceAttributes, CrawlerCommon.DATA_LAKE_NAME) + CrawlerCommon.AZURE_DATALAKE_STORE_NET + CrawlerCommon.FILE_SEPARATOR + relativePath;
//            String fileFormat = FilenameUtils.getExtension(filename);
//            delimitedFileFormatUtil = new DelimitedFileFormatUtil();
//            String delimiterFileFormat = null;
//            if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                inputStream = adlStoreClient.getReadStream(filename);
//                delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//
//            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                inputStream = adlStoreClient.getReadStream(filename);
//                delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//            }
//            return new Object[]{
//                    sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                    sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                    sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                    filename,
//                    fileFormat,
//                    absPath,
//                    relativePath,
//                    map.get(CrawlerCommon.FILE_LAST_MODIFIED).toString(),
//                    false,
//                    map.get(CrawlerCommon.IS_DIR),
//                    false,
//                    Integer.valueOf(map.get(CrawlerCommon.FILE_SIZE).toString()),
//                    map.get(CrawlerCommon.FILE_OWNER_ID),
//                    map.get(CrawlerCommon.FILE_OWNER_ID),
//                    delimiterFileFormat,
//                    null
//            };
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null) {
//                    inputStream.close();
//                }
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    private void fetchDataLakeStats(ADLStoreClient adlStoreClient, String query) throws Exception {
//        try {
//            for (DirectoryEntry directoryEntry : adlStoreClient.enumerateDirectory(CrawlerCommon.ROOT_PATH)) {
//                if (directoryEntry.type.toString().equals(CrawlerCommon.ADL_DIRECTORY)) {
//                    fetchFolderStats(adlStoreClient, directoryEntry.fullName, query);
//                } else {
//                    getFileStats(directoryEntry, query);
//                }
//            }
//
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    private void fetchFolderStats(ADLStoreClient adlStoreClient, String absoultePath, String query) throws Exception {
//        try {
//            for (DirectoryEntry directoryEntry : adlStoreClient.enumerateDirectory(CrawlerCommon.ROOT_PATH + absoultePath)) {
//                if (directoryEntry.type.toString().equals(CrawlerCommon.ADL_DIRECTORY)) {
//                    fetchFolderStats(adlStoreClient, directoryEntry.fullName, query);
//                } else {
//                    getFileStats(directoryEntry, query);
//                }
//            }
//
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    private void getFileStats(DirectoryEntry directoryEntry, String query) throws Exception {
//        HashMap<String, Object> stats = new HashMap<>();
//        try {
//            stats.put(CrawlerCommon.FILE_NAME, directoryEntry.name);
//            stats.put(CrawlerCommon.FILE_FORMAT, FilenameUtils.getExtension(directoryEntry.name));
//            stats.put(CrawlerCommon.FILE_PATH, directoryEntry.fullName);
//            stats.put(CrawlerCommon.FILE_LAST_MODIFIED, directoryEntry.lastModifiedTime);
//            stats.put(CrawlerCommon.FILE_SIZE, directoryEntry.length);
//            stats.put(CrawlerCommon.FILE_OWNER_ID, directoryEntry.user);
//            stats.put(CrawlerCommon.IS_DIR, directoryEntry.type.toString().equals(CrawlerCommon.ADL_DIRECTORY));
//
//            int BATCH_SIZE = 1000;
//            if (fetchCrawlType.equals(CrawlerCommon.STAGING_INSERT_FILEMETADATA)) {
//                list_of_file_objects_array.add(convertMapToObjectArray(stats));
//                if (list_of_file_objects_array.size() >= BATCH_SIZE) {
//                    jdbcUtility.executeBatchUpdateQuery(list_of_file_objects_array, query, dataSource.getConnection(), true);
//                    list_of_file_objects_array.clear();
//                }
//            } else {
//                if (HashMapUtility.getBoolean(sourceAttributes, CrawlerCommon.FETCH_COLUMN_METADATA)) {
//                    String fileFormat = FilenameUtils.getExtension(stats.get(CrawlerCommon.FILE_NAME).toString());
//                    if (fileFormat.equalsIgnoreCase(CrawlerCommon.TSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.CSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.AVRO) || fileFormat.equalsIgnoreCase(CrawlerCommon.PARQUET)) {
//                        list_of_column_objects_array.addAll(processColumnMetadata(stats));
//                        if (list_of_column_objects_array.size() >= BATCH_SIZE) {
//                            jdbcUtility.executeBatchUpdateQuery(list_of_column_objects_array, query, dataSource.getConnection(), true);
//                            list_of_column_objects_array.clear();
//                        }
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    private void fetchFileStats(ADLStoreClient adlStoreClient, String absoultePath, String query) throws Exception {
//        try {
//            getFileStats(adlStoreClient.getDirectoryEntry(CrawlerCommon.ROOT_PATH + absoultePath), query);
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    private List<Object[]> processColumnMetadata(Map<String, Object> directoryEntry) throws Exception {
//        InputStream inputStream = null;
//        try {
//            String fileFormat = directoryEntry.get(CrawlerCommon.FILE_FORMAT).toString();
//            String relativePath = directoryEntry.get(CrawlerCommon.FILE_NAME).toString();
//            while (relativePath.startsWith(CrawlerCommon.FILE_SEPARATOR))
//                relativePath = relativePath.replaceFirst(CrawlerCommon.FILE_SEPARATOR, "");
//            Path filePath = Paths.get(relativePath);
//            Path fileName = filePath.getFileName();
//            String nameOfFile = fileName.toString();
//            String absolutePath = CrawlerCommon.ADL_PREFIX + HashMapUtility.getString(sourceAttributes, CrawlerCommon.DATA_LAKE_NAME) + CrawlerCommon.AZURE_DATALAKE_STORE_NET + CrawlerCommon.FILE_SEPARATOR + relativePath;
//            List<Object[]> columnMetadata = null;
//            if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                inputStream = adlStoreClient.getReadStream(relativePath);
//                String delimiterFileFormat;
//                if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                    delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//                } else {
//                    delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//                }
//                HashMap<String, Object> delimiterFileFormatMap = JSONUtils.jsonToMap(delimiterFileFormat);
//                boolean header = (boolean) HashMapUtility.get(delimiterFileFormatMap, CrawlerCommon.HEADER);
//                if (header) {
//                    columnMetadata = getCSVMetadata(relativePath, nameOfFile, absolutePath);
//                }
//            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.AVRO)) {
//                columnMetadata = getAvroMetadata(relativePath, nameOfFile, absolutePath);
//            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.PARQUET)) {
//                columnMetadata = getParquetMetadata(relativePath, nameOfFile, absolutePath);
//            }
//            return columnMetadata;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null) {
//                    inputStream.close();
//                }
//            } catch (IOException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//
//    private List<Object[]> getParquetMetadata(String filename, String nameOfFile, String absolutePath) throws Exception {
//        ParquetFileReader reader = null;
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        try {
//            SemiStructuredUtils semiStructuredUtils = new SemiStructuredUtils();
//            Configuration conf = new Configuration();
//            conf.set("dfs.adls.oauth2.access.token.provider.type", "ClientCredential");
//            conf.set("dfs.adls.oauth2.refresh.url", credentials.get(CrawlerCommon.AUTH_TOKEN_ENDPOINT).toString());
//            conf.set("dfs.adls.oauth2.client.id", credentials.get(CrawlerCommon.CLIENTID).toString());
//            conf.set("dfs.adls.oauth2.credential", credentials.get(CrawlerCommon.CLIENT_KEY).toString());
//            conf.set("fs.adl.impl", "org.apache.hadoop.fs.adl.AdlFileSystem");
//            conf.set("fs.AbstractFileSystem.adl.impl", "org.apache.hadoop.fs.adl.Adl");
//            reader = ParquetFileReader.open(HadoopInputFile.fromPath(new org.apache.hadoop.fs.Path(CrawlerCommon.ADL_PREFIX + HashMapUtility.getString(sourceAttributes, CrawlerCommon.DATA_LAKE_NAME) + CrawlerCommon.AZURE_DATALAKE_STORE_NET + CrawlerCommon.FILE_SEPARATOR + filename), conf));
//            List<LinkedHashMap<String, Object>> listMap = semiStructuredUtils.getParquetColMetadata(reader);
//            for (LinkedHashMap<String, Object> map : listMap) {
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        nameOfFile,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        listMap.indexOf(map),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (reader != null)
//                    reader.close();
//            } catch (IOException ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    private List<Object[]> getAvroMetadata(String filename, String nameOfFile, String absolutePath) throws Exception {
//        InputStream inputStream = null;
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        try {
//            SemiStructuredUtils semiStructuredUtils = new SemiStructuredUtils();
//            inputStream = adlStoreClient.getReadStream(filename);
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getAvroColMetadata(inputStream);
//            for (HashMap<String, Object> map : listMap) {
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        nameOfFile,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    private List<Object[]> getCSVMetadata(String filename, String nameOfFile, String absolutePath) throws Exception {
//        InputStream inputStream = null;
//        try {
//            SemiStructuredUtils semiStructuredUtils = new SemiStructuredUtils();
//            List<Object[]> list_of_objects_array = new ArrayList<>();
//            String fileFormat = FilenameUtils.getBaseName(nameOfFile);
//            inputStream = adlStoreClient.getReadStream(filename);
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getCSVColMetadata(inputStream, fileFormat);
//            for (HashMap<String, Object> map : listMap) {
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        nameOfFile,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    @Override
//    public void closeResources() {
//
//    }
//}
