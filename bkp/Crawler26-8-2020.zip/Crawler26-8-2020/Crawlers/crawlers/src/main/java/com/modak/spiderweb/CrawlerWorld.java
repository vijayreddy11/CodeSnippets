package com.modak.spiderweb;


import com.modak.utils.JDBCConnectionManager;
import com.modak.utils.MiscUtils;
import com.modak.utils.encryption.RSAEncryptionUtils;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.dbutils.handlers.ColumnListHandler;
import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.modak.spiderweb.common.CrawlerCommon;
import com.modak.utility.HashMapUtility;
import com.modak.utility.KafkaUtility;
import com.modak.utility.compression.CompEncryptUtils;
import com.modak.utility.db.JDBCUtility;
import com.modak.utility.json.JSONUtility;
import com.modak.utility.st.STTemplateFactory;
import com.modak.utility.st.STTemplateRenderer;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CrawlerWorld {
    private CrawlerFactory crawlerFactory;
    private KafkaConsumer kafkaConsumer;
    private PrivateKey privateKey;
    private HashMap<String, Object> templateConfigMap = null;
    private HikariDataSource dataSource;
    private static String configurations_path;
    private HashMap<String, Object> stagingTablesConfigMap;
    private JDBCUtility jdbcUtility;
    private static HashMap<String, Object> crawlerConfigMap;
    STTemplateRenderer templateRenderer;

    private ExecutorService executors;
    private static final Logger logger = LogManager.getLogger(CrawlerWorld.class);

    public static void main(String[] args) throws Exception {

        try {
            configurations_path = null;
            //getting configurations filepath from arguments
            if (args.length == 1) {
                configurations_path = args[0];
            } else {
                logger.error(CrawlerCommon.CRAWLER_IS_NOT_SUPPLIED_WITH_CONFIGURATIONS_DIRECTORY_PATH);
                logger.error(CrawlerCommon.SO_COULD_NOT_START_THE_CRAWLER_WORLD_PROCESS);
                System.exit(1);
            }
            String logFileLocation =
                    args[0] + File.separator + CrawlerCommon.LOGGING + File.separator + CrawlerCommon.LOG4J2;
            try {
                logger.info(CrawlerCommon.LOGGER_CONFIG_FILE_IS_FOUND + logFileLocation);
            } catch (Exception ex) {
                logger.error(CrawlerCommon.LOGGER_CONFIG_FILE_LOG4J2_XML_IS_NOT_FOUND + logFileLocation);
            }

            String crawlerConfigPath = configurations_path + File.separator + CrawlerCommon.CRAWLER_CONFIG;

            //crawler config map has database config and kafka config
            crawlerConfigMap = JSONUtility
                    .jsonToMap(FileUtils.readFileToString(new File(crawlerConfigPath), Charset.defaultCharset()));


            HashMap<String, Object> kafkaConfig = HashMapUtility.getMap(crawlerConfigMap, CrawlerCommon.KAFKA_CONFIG);
            //StagingSchemaPoolsize indicates number of staging tables to be created in staging schema
            int stagingSchemaPoolSize = HashMapUtility.getInteger(crawlerConfigMap, CrawlerCommon.STAGINGSCHEMAPOOLSIZE);
            ArrayList<Integer> resources = new ArrayList<Integer>();
            for (int i = 0; i < stagingSchemaPoolSize; i++) {
                resources.add(i);
            }
            StagingSchemaPool<Integer> stagingSchemaPool = new StagingSchemaPool(resources);
            int mutliStagingSchemaPoolSize = HashMapUtility.getInteger(crawlerConfigMap, CrawlerCommon.MULTI_STAGING_SCHEMA_POOL_SIZE);
            ArrayList<Integer> schemaResources = new ArrayList<Integer>();
            for (int i = 0; i < mutliStagingSchemaPoolSize; i++) {
                schemaResources.add(i);
            }

            CrawlerWorld crawlerWorld = new CrawlerWorld();
            crawlerWorld.init(crawlerConfigMap);
            crawlerWorld.checkIfTableExistsInStaging(stagingSchemaPoolSize,mutliStagingSchemaPoolSize);
            crawlerWorld.initCrawlerFactory();
            crawlerWorld.initKafkaClient(kafkaConfig);
            crawlerWorld.fetchMessages(stagingSchemaPool);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(CrawlerCommon.FAILED_START_THE_CRAWLER_WORLD_PROCESS);
            logger.error(e.getMessage(), e);
            throw new Exception(CrawlerCommon.FAILED_START_THE_CRAWLER_WORLD_PROCESS);
        }
    }

    private void init(HashMap<String, Object> crawlerConfigMap) throws Exception {
        HashMap<String, Object> databaseConfig;

        if (crawlerConfigMap != null) {
            databaseConfig = HashMapUtility.getMap(crawlerConfigMap, CrawlerCommon.DATABASE_CONFIG);
            //Rest configuration to render templates from Database
            templateConfigMap = HashMapUtility.getMap(crawlerConfigMap, CrawlerCommon.KEY_TEMPLATE_CONFIG);

            privateKey = RSAEncryptionUtils
                    .getPrivateKey(HashMapUtility.getString(crawlerConfigMap, CrawlerCommon.PRIVATE_KEY));

            JDBCConnectionManager jdbcConnectionManager = new JDBCConnectionManager();
            //Configures Hikari Data Source Using Database Config and Vault

            if (databaseConfig != null) {
                jdbcConnectionManager.configureHikariDataSource(databaseConfig);
            } else {
                throw new NullPointerException(CrawlerCommon.DATABASE_CONFIG_NULL);
            }
            dataSource = jdbcConnectionManager.getHikariDataSource();
            int threadpool_size = HashMapUtility.getInteger(crawlerConfigMap, CrawlerCommon.THREADPOOL_SIZE);
            executors = Executors.newFixedThreadPool(threadpool_size);
        }
    }
    /* Ihis method creates CrawlerFactory object */

    private void initCrawlerFactory() {
        crawlerFactory = new CrawlerFactory();
    }

    /**
     * This method is used to create Kafka client and subscribe to a topic
     *
     * @param kafkaClientConfig this map consists of kafka client properties
     * @throws Exception if it fails to make kafka client
     */
    private void initKafkaClient(HashMap<String, Object> kafkaClientConfig) throws Exception {
        KafkaUtility kafkaUtility = new KafkaUtility();
        kafkaConsumer = kafkaUtility.createKafkaConsumer(kafkaClientConfig);
    }

    /*
     This method Create crawler objects of specific type based on the Kafka messages received and submit it to thread
     *executor service
     *
     *@param stagingTablePoolReference This parameter defines a reference to cocurrent staging pool
    */
    private void fetchMessages(StagingSchemaPool<Integer> stagingTablePoolReference) {
        while (true) {
            ConsumerRecords<String, byte[]> records = kafkaConsumer.poll(100);
            for (ConsumerRecord<String, byte[]> record : records) {
                byte[] kafkaMessage = record.value();
                try {
                    byte[] decryptedMessageBtArray = CompEncryptUtils
                            .decryptAndUncompressByteArray(kafkaMessage, privateKey);
                    logger.info(
                            CrawlerCommon.MESSAGE_RECEIVED_TOPIC, record.topic(), record.offset(), record.partition(),
                            decryptedMessageBtArray != null ? MiscUtils
                                    .formatString(new String(decryptedMessageBtArray, StandardCharsets.UTF_8), true) : null);

                    String message = new String(Objects.requireNonNull(decryptedMessageBtArray), StandardCharsets.UTF_8);

                    HashMap<String, Object> messageMap = JSONUtility.jsonToMap(message);

                    HashMap<String, Object> sourceAttributes = (HashMap<String, Object>) messageMap.
                            get(CrawlerCommon.SOURCE_INFO);
                    HashMap<String, Object> runAttributes = (HashMap<String, Object>) messageMap
                            .get(CrawlerCommon.RUN_ATTRIBUTES);
                    runAttributes.put(CrawlerCommon.RESOURCES_PATH, configurations_path);
                    Crawler crawler = crawlerFactory.getCrawlerInstance(sourceAttributes);

                    crawler.init(sourceAttributes, dataSource, runAttributes, stagingTablePoolReference, crawlerConfigMap);
                    // crawler.batchOperation(crawler);
                    executors.execute(crawler);
                    kafkaConsumer.commitSync();

                } catch (Exception sce) {
                    sce.printStackTrace();
                    logger.error(sce.getMessage(), sce);
                    logger.error(CrawlerCommon.FAILED_TO_FETCH_MESSAGES);
                }
            }
        }
    }

    /**
     * This method checks if dynamic staging tables exists or not in staging schema,if table does not exist
     * then it is created
     *
     * @param stagingTableId this indicates the staging table suffix
     */

    private void checkIfTableExistsInStaging(int stagingTableId,int mutliStagigTableId) throws Exception {
        try {
            logger.info(CrawlerCommon.CHECK_IF_TABLE_EXISTS_IN_STAGINGSCHEMA);
            jdbcUtility = new JDBCUtility();
            stagingTablesConfigMap = JSONUtility
                    .jsonToMap(FileUtils.readFileToString(
                            new File(configurations_path + File.separator + CrawlerCommon.STAGING_TABLES_FILE),
                            Charset.defaultCharset()));
            //This list contains of staging tables that are required
            ArrayList<String> stagingTableList = HashMapUtility
                    .getArrayList(stagingTablesConfigMap, CrawlerCommon.STAGING_TABLES);
            String templateGroup = stagingTablesConfigMap.get(CrawlerCommon.TEMPLATE_GROUP).toString();
            List<String> templateGroupList = new ArrayList<String>();
            templateGroupList.add(templateGroup);

            //connecting to a rest end point or loads files based on template config type
            templateRenderer = STTemplateFactory.getTemplateRenderer(templateConfigMap);
            templateRenderer.loadTemplateGroups((ArrayList<String>) templateGroupList);

            //query to fetch tables list from staging schema
            String query = templateRenderer
                    .renderTemplate(templateGroup, CrawlerCommon.GET_TABLES_LIST);

            List<String> koshStagingtablesList = (List<String>) jdbcUtility
                    .executeSelectQuery(query, dataSource.getConnection(), true, new ColumnListHandler());
            if (stagingTableList != null) {
                for (String tableName : stagingTableList) {
                    for (int j = 0; j < stagingTableId; j++) {
                        for(int k=0;k<mutliStagigTableId;k++) {
                            String stagingTableNameWithId = tableName + "_" + j + "_" +k;
                            if (koshStagingtablesList.contains(stagingTableNameWithId)) {
                                koshStagingtablesList.remove(stagingTableNameWithId);
                            } else {
                                createTableInStaging(j,k, tableName);
                            }
                        }
                    }
                }
            }
            dropTablesInStaging(koshStagingtablesList);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            throw new Exception(CrawlerCommon.FAILED_TO_CHECK_TABLES_IN_STAGING_SCHEMA);
        }
    }

    /**
     * This method is used to create required staging tables
     *
     * @param stagingId   this indicates the staging table suffix
     * @param templateName this indicates table to be created
     */
    private void createTableInStaging(int stagingId, int multiStagingId,String templateName) throws Exception {
        logger.info(CrawlerCommon.CREATING_TABLE_IN_SCHEMA);
        HashMap<String, Object> stagingIDMap = new HashMap<String, Object>();
        stagingIDMap.put(CrawlerCommon.RESOURCE_ID, stagingId+"_"+multiStagingId);
        String templateGroup = stagingTablesConfigMap.get(CrawlerCommon.TEMPLATE_GROUP).toString();

        String query = templateRenderer
                .renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, stagingIDMap);
        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);

    }

    /**
     * This tables is used to drop tables from staging schema
     *
     * @param tableList this parameter indicates list of tables to be deleted
     * @throws Exception throws exception if it fails to drop table
     */
    private void dropTablesInStaging(List<String> tableList) throws Exception {
        if (tableList.size() > 0) {
            HashMap<String, Object> dataMap = new HashMap<String, Object>();
            dataMap.put(CrawlerCommon.TABLELIST, tableList);
            String templateGroup = HashMapUtility.getString(stagingTablesConfigMap, CrawlerCommon.TEMPLATE_GROUP);
            String query = templateRenderer
                    .renderTemplate(templateGroup, CrawlerCommon.DROPTABLE, CrawlerCommon.DATA, dataMap);

            jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
            logger.info("Tables are deleted");

        } else {
            logger.info(CrawlerCommon.NO_TABLES_TO_DELETE);
        }
    }
}