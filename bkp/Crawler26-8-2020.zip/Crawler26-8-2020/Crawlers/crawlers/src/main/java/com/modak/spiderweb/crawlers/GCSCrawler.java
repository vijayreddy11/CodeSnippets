//package com.modak.spiderweb.crawlers;
//
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.connector.GCSConnector;
//import com.modak.utils.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import com.google.cloud.storage.*;
//
//import java.util.*;
//
//public class GCSCrawler extends BaseCrawler {
//    private static GCSConnector gcsConnector;
//    private static Storage storage;
//    private final int BATCH_SIZE = 1000;
//    private static final Logger logger = LogManager.getLogger(GCSCrawler.class);
//
//    @Override
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                String creds = this.getCredentialsForSource();
//                Map<String, Object> serviceAccountMap = JSONUtils.jsonToMap(creds);
//                gcsConnector = new GCSConnector();
//                storage = gcsConnector.getStorage(serviceAccountMap);
//                HashMap<String, Object> sourceInfo = (HashMap<String, Object>) sourceAttributes.get(CrawlerCommon.SOURCE_INFO_DETAILS);
//                String projectId = sourceInfo.get(CrawlerCommon.PROJECT_ID).toString();
//                String bucketName = sourceInfo.get(CrawlerCommon.BUCKET_NAME).toString();
//                String fetchStatsType = sourceInfo.get(CrawlerCommon.FETCH_STATS_TYPE).toString();
//                String path = sourceInfo.get(CrawlerCommon.PATH).toString();
//                sourceAttributes.put(CrawlerCommon.PROJECT_ID, projectId);
//                sourceAttributes.put(CrawlerCommon.DIRECTORY_NAME, bucketName);
//                sourceAttributes.put(CrawlerCommon.BUCKET_NAME, bucketName);
//                sourceAttributes.put(CrawlerCommon.FETCH_STATS_TYPE, fetchStatsType);
//                sourceAttributes.put(CrawlerCommon.PATH, path);
//                if (storage == null) {
//                    throw new NullPointerException(CrawlerCommon.SOURCE_CONNECTION_IS_NULL);
//                }
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            try {
//                logger.error(e.getMessage(), e);
//                insertError(e);
//            } catch (Exception e1) {
//                logger.error(e1.getMessage(), e1);
//            }
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        this.getDirectories();
//    }
//
//    @Override
//    public void doCrawling() {
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                dataMap.put(CrawlerCommon.SOURCEATTRIBUTES, sourceAttributes);
//
//                List<Map<String, Object>> list_of_map = null;
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = crawlingTemplateMap.get(CrawlerCommon.TEMPLATE_GROUP).toString();
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = dependentMap.get(CrawlerCommon.QUERY_TYPE).toString();
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                        dataMap.put(templateName, list_of_map);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else {
//                        List<Object[]> list_of_objects_array = new ArrayList<>();
//                        List<Map<String, Object>> fileMetadata = getFileMetadata();
//                        for (int i = 0; i < fileMetadata.size(); i++) {
//                            list_of_objects_array.add(convertMapToObjectArray(fileMetadata.get(i)));
//                            if (list_of_objects_array.size() >= BATCH_SIZE) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                                list_of_objects_array.clear();
//                            }
//                        }
//                        jdbcUtility.executeBatchUpdateQuery(list_of_objects_array, query, dataSource.getConnection(), true);
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            try {
//                insertError(e);
//            } catch (Exception e1) {
//                e1.printStackTrace();
//            }
//        }
//    }
//
//    @Override
//    public void closeResources() {
//
//    }
//
//    public List<Map<String, Object>> getFileMetadata() {
//        String fetchStatsType = sourceAttributes.get(CrawlerCommon.FETCH_STATS_TYPE).toString();
//        List<Map<String, Object>> fileStats = new ArrayList<>();
//        if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.BUCKET) || fetchStatsType.equalsIgnoreCase(CrawlerCommon.BLOB) || fetchStatsType.equalsIgnoreCase(CrawlerCommon.FILE)) {
//            String bucketName = sourceAttributes.get(CrawlerCommon.BUCKET_NAME).toString();
//            String absolutePath = sourceAttributes.get(CrawlerCommon.PATH).toString();
//            if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.BUCKET)) {
//                try {
//                    fileStats = gcsConnector.fetchBucketStats(storage, bucketName);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            } else if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.BLOB)) {
//                fileStats = gcsConnector.fetchBlobStats(storage, bucketName, absolutePath);
//            } else {
//                fileStats = gcsConnector.fetchFileStats(storage, bucketName, absolutePath);
//            }
//        }
//        return fileStats;
//
//    }
//
//    public Object[] convertMapToObjectArray(Map<String, Object> map) {
//
//        Object[] obj = {
//                sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                map.get(CrawlerCommon.FILE_NAME).toString(),
//                map.get(CrawlerCommon.FILE_FORMAT).toString(),
//                map.get(CrawlerCommon.ABSOLUTE_PATH).toString(),
//                map.get(CrawlerCommon.RELATIVE_PATH).toString(),
//                map.get(CrawlerCommon.FILE_LAST_MODIFIED).toString(),
//                false,
//                false,
//                false,
//                Integer.valueOf(map.get(CrawlerCommon.FILE_SIZE).toString()),
//                map.get(CrawlerCommon.FILE_OWNER_ID).toString(),
//                map.get(CrawlerCommon.FILE_OWNER_ID).toString(),
//                map.get(CrawlerCommon.ADDITIONAL_INFO),
//                null
//        };
//        return obj;
//    }
//
//}