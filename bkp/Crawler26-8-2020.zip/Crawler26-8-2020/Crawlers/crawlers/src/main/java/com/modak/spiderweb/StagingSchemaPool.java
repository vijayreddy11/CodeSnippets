package com.modak.spiderweb;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

public class StagingSchemaPool<T> {
    private ConcurrentLinkedQueue<T> stagingTablePoolReference;

    public StagingSchemaPool(ArrayList<T> stagingResources) {
        stagingTablePoolReference = new ConcurrentLinkedQueue<T>();
        for (T resource : stagingResources) {
            stagingTablePoolReference.add(resource);
        }
    }

    public T getStagingSchema() {
        T object = stagingTablePoolReference.poll();
        return object;
    }

    public void returnStagingSchema(T object) {
        if (object == null) {
            return;
        }
        this.stagingTablePoolReference.offer(object);
    }
}