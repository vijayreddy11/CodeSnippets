package com.modak.spiderweb;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

public class MultiStagingSchemaPool<T> {
    private ConcurrentLinkedQueue<T> stagingSchemaPoolReference;

    public MultiStagingSchemaPool(ArrayList<T> stagingResources) {
        stagingSchemaPoolReference = new ConcurrentLinkedQueue<T>();
        for (T resource : stagingResources) {
            stagingSchemaPoolReference.add(resource);
        }
    }
    public T getStagingSchema() {
        T object = stagingSchemaPoolReference.poll();
        return object;
    }
    public void returnStagingSchema(T object) {
        if (object == null) {
            return;
        }
        this.stagingSchemaPoolReference.offer(object);
    }
}

