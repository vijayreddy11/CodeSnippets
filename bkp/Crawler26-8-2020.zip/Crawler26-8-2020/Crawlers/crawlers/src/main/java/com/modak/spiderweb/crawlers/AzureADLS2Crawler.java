//package com.modak.spiderweb.crawlers;
//
//import com.azure.core.http.rest.PagedIterable;
//import com.azure.storage.blob.BlobClient;
//import com.azure.storage.file.datalake.DataLakeFileSystemClient;
//import com.azure.storage.file.datalake.models.ListPathsOptions;
//import com.azure.storage.file.datalake.models.PathItem;
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.DelimitedFileFormatUtil;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.SemiStructuredUtils;
//import com.modak.utility.connector.ADLS2Connector;
//import com.modak.utils.JSONUtils;
//import org.apache.commons.dbutils.handlers.MapListHandler;
//import org.apache.commons.io.FilenameUtils;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.*;
//
//
//public class AzureADLS2Crawler extends BaseCrawler {
//    DataLakeFileSystemClient dataLakeFileSystemClient;
//    protected ADLS2Connector adls2Connector;
//    private static String fetchCrawlType = null;
//    protected DelimitedFileFormatUtil delimitedFileFormatUtil;
//    private static List<Object[]> list_of_file_objects_array = new ArrayList<>();
//    private static List<Object[]> list_of_column_objects_array = new ArrayList<>();
//    private static final Logger logger = LogManager.getLogger(AzureADLS2Crawler.class);
//
//    @Override
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                String creds = this.getCredentialsForSource();
//                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
//                String key = HashMapUtility.getString(credentials, CrawlerCommon.ACCOUNT_KEY);
//                String name = HashMapUtility.getString(credentials, CrawlerCommon.ACCOUNT_NAME);
//                HashMap<String, String> azureDataLakeCredMap = new HashMap<>();
//                azureDataLakeCredMap.put(CrawlerCommon.ACCOUNT_NAME, name);
//                azureDataLakeCredMap.put(CrawlerCommon.ACCOUNT_KEY, key);
//                HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.SOURCE_INFO_DETAILS);
//                String containerName = HashMapUtility.getString(sourceInfo, CrawlerCommon.CONTAINER);
//                String fetchStatsType = HashMapUtility.getString(sourceInfo, CrawlerCommon.FETCH_STATS_TYPE);
//                String absolutePath = HashMapUtility.getString(sourceInfo, CrawlerCommon.PATH);
//                sourceAttributes.put(CrawlerCommon.ACCOUNT_NAME, name);
//                sourceAttributes.put(CrawlerCommon.ACCOUNT_KEY, key);
//                sourceAttributes.put(CrawlerCommon.FETCH_STATS_TYPE, fetchStatsType);
//                sourceAttributes.put(CrawlerCommon.PATH, absolutePath);
//                sourceAttributes.put(CrawlerCommon.CONTAINER, containerName);
//                sourceAttributes.put(CrawlerCommon.DIRECTORY_NAME, containerName);
//                boolean fetchColumnMetadata = HashMapUtility.getBoolean(sourceInfo, CrawlerCommon.FETCH_COLUMN_METADATA);
//                sourceAttributes.put(CrawlerCommon.FETCH_COLUMN_METADATA, fetchColumnMetadata);
//                adls2Connector = new ADLS2Connector();
//                dataLakeFileSystemClient = adls2Connector.getDataLakeFileSystemClient(azureDataLakeCredMap, containerName);
//                adls2Connector.checkConnectionStatus(dataLakeFileSystemClient);
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            this.insertError(e);
//        }
//    }
//
//
//    @Override
//    public void connectToSource() {
//        this.getDirectories();
//    }
//
//    @Override
//    public void doCrawling() {
//        try {
//            Boolean doCrawling = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (doCrawling && !isErrored) {
//                logger.info(CrawlerCommon.CRAWLING_STARTED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                HashMap<String, Object> crawlingTemplateMap = HashMapUtility.getMap(crawlerRulesMap, CrawlerCommon.CRAWLING);
//                String templateGroup = HashMapUtility.getString(crawlingTemplateMap, CrawlerCommon.TEMPLATE_GROUP);
//                HashMap<String, Object> templateMap = HashMapUtility.getMap(crawlingTemplateMap, CrawlerCommon.TEMPLATE_MAP);
//                String absolutePath = HashMapUtility.getString(sourceAttributes, CrawlerCommon.PATH);
//                for (String templateName : templateMap.keySet()) {
//                    String query = templateRenderer.renderTemplate(templateGroup, templateName, CrawlerCommon.DATA, dataMap);
//                    HashMap<String, Object> dependentMap = HashMapUtility.getMap(templateMap, templateName);
//                    String queryType = HashMapUtility.getString(dependentMap, CrawlerCommon.QUERY_TYPE);
//                    if (queryType.equalsIgnoreCase(CrawlerCommon.SELECT)) {
//                        List<Map<String, Object>> list_of_map = jdbcUtility.executeSelectQuery(query, dataSource.getConnection(), true, new MapListHandler());
//                        dataMap.put(templateName, list_of_map);
//                    } else if (queryType.equalsIgnoreCase(CrawlerCommon.UPDATE)) {
//                        jdbcUtility.executeUpdateQuery(query, dataSource.getConnection(), true);
//                    } else {
//                        if (templateName.equals(CrawlerCommon.STAGING_INSERT_FILEMETADATA)) {
//                            fetchCrawlType = CrawlerCommon.STAGING_INSERT_FILEMETADATA;
//                            getMetadataFromAzureGenTwo(absolutePath, query);
//                            if (list_of_file_objects_array.size() > 0) {
//                                jdbcUtility.executeBatchUpdateQuery(list_of_file_objects_array, query, dataSource.getConnection(), true);
//                                list_of_file_objects_array.clear();
//                            }
//                        } else {
//                            if (HashMapUtility.getBoolean(sourceAttributes, CrawlerCommon.FETCH_COLUMN_METADATA)) {
//                                fetchCrawlType = CrawlerCommon.STAGING_INSERT_COLUMNMETADATA;
//                                getMetadataFromAzureGenTwo(absolutePath, query);
//                                if (list_of_column_objects_array.size() > 0) {
//                                    jdbcUtility.executeBatchUpdateQuery(list_of_column_objects_array, query, dataSource.getConnection(), true);
//                                    list_of_column_objects_array.clear();
//                                }
//                            }
//                        }
//                    }
//                }
//                logger.info(CrawlerCommon.CRAWLING_COMPLETED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID), HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            } else {
//                logger.info(CrawlerCommon.CRAWLING_DISABLED, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//    }
//
//    @Override
//    public void closeResources() {
//
//    }
//
//    public void getMetadataFromAzureGenTwo(String absolutePath, String query) throws Exception {
//        try {
//            String fetchStatsType = HashMapUtility.getString(sourceAttributes, CrawlerCommon.FETCH_STATS_TYPE);
//            if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.CONTAINER) || fetchStatsType.equalsIgnoreCase(CrawlerCommon.DIRECTORY) || fetchStatsType.equalsIgnoreCase(CrawlerCommon.FILE)) {
//                if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.CONTAINER)) {
//                    fetchDataLakeContainerStats(dataLakeFileSystemClient, query);
//                } else if (fetchStatsType.equalsIgnoreCase(CrawlerCommon.DIRECTORY)) {
//                    fetchFolderStats(dataLakeFileSystemClient, absolutePath, query);
//                } else {
//                    fetchFileStats(dataLakeFileSystemClient, absolutePath, query);
//                }
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    public Object[] convertMapToObjectArray(Map<String, Object> map) throws Exception {
//        InputStream inputStream = null;
//        try {
//            String relativePath = map.get(CrawlerCommon.FILE_PATH).toString();
//            while (relativePath.startsWith(CrawlerCommon.FILE_SEPARATOR))
//                relativePath = relativePath.replaceFirst(CrawlerCommon.FILE_SEPARATOR, "");
//            String filename = map.get(CrawlerCommon.FILE_NAME).toString();
//            String absPath = CrawlerCommon.HTTPS + HashMapUtility.getString(sourceAttributes, CrawlerCommon.ACCOUNT_NAME) + CrawlerCommon.BLOB_CORE_WINDOWS_NET + HashMapUtility.getString(sourceAttributes, CrawlerCommon.CONTAINER) + CrawlerCommon.FILE_SEPARATOR + relativePath;
//            String fileFormat = FilenameUtils.getExtension(filename);
//            delimitedFileFormatUtil = new DelimitedFileFormatUtil();
//            String delimiterFileFormat = null;
//
//            BlobClient blobClient = adls2Connector.getBlobClient(sourceAttributes, map.get(CrawlerCommon.FILE_PATH).toString());
//            if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                inputStream = blobClient.openInputStream();
//                delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//
//            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                inputStream = blobClient.openInputStream();
//                delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//            }
//            return new Object[]{
//                    sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                    sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                    sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                    map.get(CrawlerCommon.FILE_NAME).toString(),
//                    map.get(CrawlerCommon.FILE_FORMAT).toString(),
//                    absPath,
//                    map.get(CrawlerCommon.FILE_PATH).toString(),
//                    map.get(CrawlerCommon.FILE_LAST_MODIFIED).toString(),
//                    CrawlerCommon.FALSE,
//                    map.get(CrawlerCommon.IS_DIR),
//                    CrawlerCommon.FALSE,
//                    Integer.valueOf(map.get(CrawlerCommon.FILE_SIZE).toString()),
//                    map.get(CrawlerCommon.FILE_OWNER_NAME).toString(),
//                    map.get(CrawlerCommon.FILE_OWNER_NAME).toString(),
//                    delimiterFileFormat,
//                    null
//            };
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null) {
//                    inputStream.close();
//                }
//            } catch (IOException ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    private String getFileNameInFolder(String name) {
//        String[] names = name.split(CrawlerCommon.FILE_SEPARATOR);
//        if (names.length <= 1) return name;
//        return names[names.length - 1];
//    }
//
//    private String getAbsoluteFolder(String name) {
//        String[] names = name.split(CrawlerCommon.FILE_SEPARATOR);
//        if (names.length <= 1) return name;
//        StringBuilder fileBlob = new StringBuilder(names[0]);
//        for (int i = 1; i < names.length - 1; i++) {
//            fileBlob.append(CrawlerCommon.FILE_SEPARATOR).append(names[i]);
//        }
//        return fileBlob.toString();
//    }
//
//    public void getFileStats(PathItem pathItem, Map<String, Object> stats, String query) throws Exception {
//        try {
//            stats.put(CrawlerCommon.FILE_NAME, getFileNameInFolder(pathItem.getName()));
//            stats.put(CrawlerCommon.FILE_FORMAT, getFileFormat(pathItem.getName()));
//            stats.put(CrawlerCommon.FILE_PATH, pathItem.getName());
//            stats.put(CrawlerCommon.FILE_MODIFIED_TIME, pathItem.getLastModified());
//            stats.put(CrawlerCommon.FILE_SIZE, pathItem.getContentLength());
//            stats.put(CrawlerCommon.FILE_OWNER_NAME, pathItem.getOwner());
//            stats.put(CrawlerCommon.IS_DIR, pathItem.isDirectory());
//
//            int BATCH_SIZE = 1000;
//            if (fetchCrawlType.equals(CrawlerCommon.STAGING_INSERT_FILEMETADATA)) {
//                list_of_file_objects_array.add(convertMapToObjectArray(stats));
//                if (list_of_file_objects_array.size() >= BATCH_SIZE) {
//                    jdbcUtility.executeBatchUpdateQuery(list_of_file_objects_array, query, dataSource.getConnection(), true);
//                    list_of_file_objects_array.clear();
//                }
//            } else {
//                String fileFormat = FilenameUtils.getExtension(stats.get(CrawlerCommon.FILE_NAME).toString());
//                if (fileFormat.equalsIgnoreCase(CrawlerCommon.TSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.CSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.AVRO)) {
//                    list_of_column_objects_array.addAll(processColumnMetadata(stats));
//                    if (list_of_column_objects_array.size() >= BATCH_SIZE) {
//                        jdbcUtility.executeBatchUpdateQuery(list_of_column_objects_array, query, dataSource.getConnection(), true);
//                        list_of_column_objects_array.clear();
//                    }
//                }
//            }
//
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    private String getFileFormat(String name) {
//        if (name.contains(".")) {
//            return name.split("\\.")[1];
//        }
//        return "";
//    }
//
//    private List<Object[]> processColumnMetadata(Map<String, Object> directoryEntry) throws Exception {
//        InputStream inputStream = null;
//        try {
//            String fileFormat = directoryEntry.get(CrawlerCommon.FILE_FORMAT).toString();
//            String relativePath = directoryEntry.get(CrawlerCommon.FILE_PATH).toString();
//            while (relativePath.startsWith(CrawlerCommon.FILE_SEPARATOR))
//                relativePath = relativePath.replaceFirst(CrawlerCommon.FILE_SEPARATOR, "");
//            Path filePath = Paths.get(relativePath);
//            Path fileName = filePath.getFileName();
//            String nameOfFile = fileName.toString();
//            String absolutePath = CrawlerCommon.HTTPS + HashMapUtility.getString(sourceAttributes, CrawlerCommon.ACCOUNT_NAME) + CrawlerCommon.BLOB_CORE_WINDOWS_NET + HashMapUtility.getString(sourceAttributes, CrawlerCommon.CONTAINER) + CrawlerCommon.FILE_SEPARATOR + relativePath;
//            List<Object[]> columnMetadata = new ArrayList<>();
//            if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV) || fileFormat.equalsIgnoreCase(CrawlerCommon.TSV)) {
//                BlobClient blobClient = adls2Connector.getBlobClient(sourceAttributes, relativePath);
//                inputStream = blobClient.openInputStream();
//                String delimiterFileFormat;
//                if (fileFormat.equalsIgnoreCase(CrawlerCommon.CSV)) {
//                    delimiterFileFormat = delimitedFileFormatUtil.getCSVFormat(inputStream);
//                } else {
//                    delimiterFileFormat = delimitedFileFormatUtil.getTSVFormat(inputStream);
//                }
//                HashMap<String, Object> delimiterFileFormatMap = com.modak.utility.json.JSONUtils.jsonToMap(delimiterFileFormat);
//                boolean header = (boolean) HashMapUtility.get(delimiterFileFormatMap, CrawlerCommon.HEADER);
//                if (header) {
//                    columnMetadata = getCSVMetadata(relativePath, nameOfFile, absolutePath);
//                }
//            } else if (fileFormat.equalsIgnoreCase(CrawlerCommon.AVRO)) {
//                columnMetadata = getAvroMetadata(relativePath, nameOfFile, absolutePath);
//            }
//
//            return columnMetadata;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null) {
//                    inputStream.close();
//                }
//            } catch (IOException ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    private List<Object[]> getAvroMetadata(String filename, String nameOfFile, String absolutePath) throws Exception {
//        InputStream inputStream = null;
//        List<Object[]> list_of_objects_array = new ArrayList<>();
//        try {
//            SemiStructuredUtils semiStructuredUtils = new SemiStructuredUtils();
//            BlobClient blobClient = adls2Connector.getBlobClient(sourceAttributes, filename);
//            inputStream = blobClient.openInputStream();
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getAvroColMetadata(inputStream);
//            for (HashMap<String, Object> map : listMap) {
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        nameOfFile,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//            } catch (IOException ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    private List<Object[]> getCSVMetadata(String filename, String nameOfFile, String absolutePath) throws Exception {
//        InputStream inputStream = null;
//        try {
//            SemiStructuredUtils semiStructuredUtils = new SemiStructuredUtils();
//            List<Object[]> list_of_objects_array = new ArrayList<>();
//            String fileFormat = FilenameUtils.getBaseName(nameOfFile);
//            BlobClient blobClient = adls2Connector.getBlobClient(sourceAttributes, filename);
//            inputStream = blobClient.openInputStream();
//            List<HashMap<String, Object>> listMap = semiStructuredUtils.getCSVColMetadata(inputStream, fileFormat);
//            for (HashMap<String, Object> map : listMap) {
//                Object[] obj = {
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_ID),
//                        sourceAttributes.get(CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID),
//                        sourceAttributes.get(CrawlerCommon.DIRECTORY_ID),
//                        nameOfFile,
//                        map.get(CrawlerCommon.COLUMN_NAME),
//                        map.get(CrawlerCommon.DATA_TYPE),
//                        absolutePath,
//                        null,
//                        null,
//                        null,
//                        null,
//                        map.get(CrawlerCommon.ORDINAL_POSITION),
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null,
//                        null
//                };
//                list_of_objects_array.add(obj);
//            }
//            return list_of_objects_array;
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        } finally {
//            try {
//                if (inputStream != null)
//                    inputStream.close();
//
//            } catch (IOException ex) {
//                logger.error(ExceptionUtils.getStackTrace(ex));
//            }
//        }
//    }
//
//    public void fetchDataLakeContainerStats(DataLakeFileSystemClient dataLakeFileSystemClient, String query) throws Exception {
//        try {
//            ListPathsOptions options = new ListPathsOptions();
//            options.setPath(CrawlerCommon.ROOT_PATH);
//            PagedIterable<PathItem> pagedIterable = dataLakeFileSystemClient.listPaths(options, null);
//            Iterator<PathItem> iterator = pagedIterable.iterator();
//            PathItem item = iterator.next();
//            while (item != null) {
//                if (item.isDirectory()) {
//                    fetchFolderStats(dataLakeFileSystemClient, item.getName(), query);
//                } else {
//                    getFileStats(item, new HashMap<String, Object>(), query);
//                }
//                if (!iterator.hasNext())
//                    break;
//                item = iterator.next();
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//
//    public void fetchFolderStats(DataLakeFileSystemClient dataLakeFileSystemClient, String absolutePath, String query) throws Exception {
//        try {
//            ListPathsOptions options = new ListPathsOptions();
//            options.setPath(absolutePath);
//            PagedIterable<PathItem> pagedIterable = dataLakeFileSystemClient.listPaths(options, null);
//            Iterator<PathItem> iterator = pagedIterable.iterator();
//            PathItem item = iterator.next();
//            while (item != null) {
//                if (item.isDirectory()) {
//                    fetchFolderStats(dataLakeFileSystemClient, item.getName(), query);
//                } else {
//                    getFileStats(item, new HashMap<String, Object>(), query);
//                }
//                if (!iterator.hasNext())
//                    break;
//                item = iterator.next();
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//
//    public void fetchFileStats(DataLakeFileSystemClient dataLakeFileSystemClient, String absoultePath, String query) throws Exception {
//        try {
//            ListPathsOptions options = new ListPathsOptions();
//            options.setPath(getAbsoluteFolder(absoultePath));
//            PagedIterable<PathItem> pagedIterable = dataLakeFileSystemClient.listPaths(options, null);
//            Iterator<PathItem> iterator = pagedIterable.iterator();
//            PathItem item = iterator.next();
//            while (item != null) {
//                if (absoultePath.equals(item.getName())) {
//                    getFileStats(item, new HashMap<String, Object>(), query);
//                    break;
//                }
//                if (!iterator.hasNext())
//                    break;
//                item = iterator.next();
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//            throw new Exception(e);
//        }
//    }
//}
