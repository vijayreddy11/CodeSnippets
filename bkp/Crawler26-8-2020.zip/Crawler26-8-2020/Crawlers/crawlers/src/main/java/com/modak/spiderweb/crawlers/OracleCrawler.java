package com.modak.spiderweb.crawlers;

import com.modak.spiderweb.BaseCrawler;
import com.modak.spiderweb.common.CrawlerCommon;
import com.modak.utility.HashMapUtility;
import com.modak.utils.JDBCConnectionManager;
import com.modak.utils.JSONUtils;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;

public class OracleCrawler extends BaseCrawler {

    private static final Logger logger = LogManager.getLogger(OracleCrawler.class);
    private Connection sourceConnection;
    private HikariDataSource sourceConnectionPool;

    @Override
    public void initSourceConnection() {
        try {
            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
            if (connectToSource && !isErrored) {
                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap1, CrawlerCommon.RESOURCE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
                HashMap<String, Object> additionalInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.ADDITIONAL_INFO);
                String jdbcDriver = HashMapUtility.getString(additionalInfo, CrawlerCommon.JDBC_DRIVER);
                sourceAttributes.put(CrawlerCommon.JDBC_DRIVER, jdbcDriver);
                Class.forName(jdbcDriver);

                String creds = this.getCredentialsForSource();
                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
                String userName = HashMapUtility.getString(credentials, CrawlerCommon.USER_NAME);
                if (userName == null) {
                    throw new NullPointerException(CrawlerCommon.USER_NAME + CrawlerCommon.IS_NULL);
                }
                String password = HashMapUtility.getString(credentials, CrawlerCommon.PASSWORD);
                if (password == null) {
                    throw new NullPointerException(CrawlerCommon.PASSWORD + CrawlerCommon.IS_NULL);
                }
                HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.SOURCE_INFO_DETAILS);
                String jdbcURL = HashMapUtility.getString(sourceAttributes, CrawlerCommon.JDBC_URL);
                String hostName = HashMapUtility.getString(sourceInfo, CrawlerCommon.HOST_NAME);
                String databaseName = HashMapUtility.getString(sourceInfo, CrawlerCommon.DATABASE_NAME);
                jdbcURL = jdbcURL.replace(CrawlerCommon.HOST_NAME, hostName);
                jdbcURL = jdbcURL.replace(CrawlerCommon.DATABASE_NAME, databaseName);
                sourceAttributes.put(CrawlerCommon.DATABASE_NAME, databaseName);
                sourceAttributes.put(CrawlerCommon.JDBC_URL, jdbcURL);

                String isEncrypted = HashMapUtility.get(sourceAttributes, "isEncrypted").toString();
                String maxConnectionsPerPartition = HashMapUtility.get(sourceAttributes, CrawlerCommon.MAX_CONNECTION_PER_PARTITION).toString();
                String minConnectionsPerPartition = HashMapUtility.get(sourceAttributes, CrawlerCommon.MIN_CONNECTION_PER_PARTITION).toString();
                HashMap<String, Object> jdbcConnectionMap = new HashMap<>();
                jdbcConnectionMap.put(CrawlerCommon.USER_NAME, userName);
                jdbcConnectionMap.put(CrawlerCommon.PASSWORD, password);
                jdbcConnectionMap.put(CrawlerCommon.ENCRYPTED_PASSWORD, isEncrypted);
                jdbcConnectionMap.put(CrawlerCommon.JDBC_DRIVER, jdbcDriver);
                jdbcConnectionMap.put(CrawlerCommon.JDBC_URL, jdbcURL);
                jdbcConnectionMap.put(CrawlerCommon.MAX_CONNECTION_PER_PARTITION, maxConnectionsPerPartition);
                jdbcConnectionMap.put(CrawlerCommon.MIN_CONNECTION_PER_PARTITION, minConnectionsPerPartition);
                JDBCConnectionManager jdbcConnectionManager = new JDBCConnectionManager();
                jdbcConnectionManager.configureHikariDataSource(jdbcConnectionMap);
                sourceConnectionPool = jdbcConnectionManager.getHikariDataSource();


//                sourceConnection = DriverManager.getConnection(jdbcURL, userName, password);
//                if (sourceConnection == null) {
//                    throw new NullPointerException(CrawlerCommon.SOURCE_CONNECTION_IS_NULL);
//                }
            } else {
                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
            }
        } catch (Exception e) {
            try {
                logger.error(ExceptionUtils.getStackTrace(e));
                this.insertError(e);
            } catch (Exception ex) {
                logger.error(ExceptionUtils.getStackTrace(ex));
            }
        }
    }

    @Override
    public void connectToSource() {
        this.getSchemas(sourceConnectionPool);
    }

    @Override
    public void doCrawling(HashMap<String, Object> dataMap) {
        try {
            this.executeListOfQueries(sourceHikariConnectionPool.getConnection(), dataMap);
        } catch (SQLException e) {
            logger.error(ExceptionUtils.getStackTrace(e));
            this.insertError(e);
        }
    }

    @Override
    public void closeResources() {
        if (sourceConnection != null) {
            try {
                sourceConnection.close();
            } catch (SQLException e) {
                logger.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }
}