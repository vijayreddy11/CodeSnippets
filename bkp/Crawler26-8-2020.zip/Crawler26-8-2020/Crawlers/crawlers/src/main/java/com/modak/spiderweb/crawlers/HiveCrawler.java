//package com.modak.spiderweb.crawlers;
//
//import com.modak.spiderweb.BaseCrawler;
//import com.modak.spiderweb.common.CrawlerCommon;
//import com.modak.utility.HashMapUtility;
//import com.modak.utility.json.JSONUtility;
//import com.modak.utils.JSONUtils;
//import org.apache.commons.io.FileUtils;
//import org.apache.commons.lang.exception.ExceptionUtils;
//import org.apache.hadoop.conf.Configuration;
//import org.apache.hadoop.security.UserGroupInformation;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//import java.io.File;
//import java.nio.charset.Charset;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//import java.util.HashMap;
//
//public class HiveCrawler extends BaseCrawler {
//
//    private static final Logger logger = LogManager.getLogger(HiveCrawler.class);
//    private Connection sourceConnection;
//
//    @Override
//    public void initSourceConnection() {
//        try {
//            Boolean connectToSource = (Boolean) HashMapUtility.get(runAttributes, CrawlerCommon.DOCRAWLING);
//            if (connectToSource && !isErrored) {
//                logger.info(CrawlerCommon.ESTABLISH_CONNECTION, HashMapUtility.get(dataMap, CrawlerCommon.RESOURCE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_ID),
//                        HashMapUtility.get(sourceAttributes, CrawlerCommon.DATAPLACE_COMPONENT_TYPE_ID));
//                HashMap<String, Object> additionalInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.ADDITIONAL_INFO);
//
//                HashMap<String, Object> sourceInfo = HashMapUtility.getMap(sourceAttributes, CrawlerCommon.SOURCE_INFO_DETAILS);
//                HashMap<String, Object> metastoreInfo = HashMapUtility.getMap(sourceInfo, CrawlerCommon.METASTORE_INFO);
//                String jdbcURL = HashMapUtility.getString(metastoreInfo, CrawlerCommon.JDBC_URL);
//                HashMap<String, Object> jdbcInfo = HashMapUtility.getMap(sourceInfo, CrawlerCommon.JDBC_INFO);
//                String databaseName = HashMapUtility.getString(jdbcInfo, CrawlerCommon.DATABASE_NAME);
//                sourceAttributes.put(CrawlerCommon.DATABASE_NAME, databaseName);
//
//
//                if (jdbcURL.contains(CrawlerCommon.JDBC_MYSQL)) {
//                    Class.forName(HashMapUtility.getString(additionalInfo, CrawlerCommon.MYSQL_JDBC_DRIVER));
//                    crawlerRulesMap = JSONUtility.jsonToMap(FileUtils.readFileToString(new File(runAttributes.get(CrawlerCommon.RESOURCES_PATH) +
//                            File.separator + CrawlerCommon.CRAWLER_RULES + File.separator + CrawlerCommon.HIVE_MYSQL_JSON), Charset.defaultCharset()));
//                } else if (jdbcURL.contains(CrawlerCommon.JDBC_POSTGRESQL)) {
//                    Class.forName(HashMapUtility.getString(additionalInfo, CrawlerCommon.POSTGRES_JDBC_DRIVER));
//                    crawlerRulesMap = JSONUtility.jsonToMap(FileUtils.readFileToString(new File(runAttributes.get(CrawlerCommon.RESOURCES_PATH) +
//                            File.separator + CrawlerCommon.CRAWLER_RULES + File.separator + CrawlerCommon.HIVE_POSTGRES_JSON), Charset.defaultCharset()));
//                } else if (jdbcURL.contains(CrawlerCommon.JDBC_ORACLE)) {
//                    Class.forName(HashMapUtility.getString(additionalInfo, CrawlerCommon.ORACLE_JDBC_DRIVER));
//                    crawlerRulesMap = JSONUtility.jsonToMap(FileUtils.readFileToString(new File(runAttributes.get(CrawlerCommon.RESOURCES_PATH) +
//                            File.separator + CrawlerCommon.CRAWLER_RULES + File.separator + CrawlerCommon.HIVE_ORACLE_JSON), Charset.defaultCharset()));
//                } else if (jdbcURL.contains(CrawlerCommon.JDBC_HIVE)) {
//                    Class.forName(HashMapUtility.getString(additionalInfo, CrawlerCommon.HIVE_JDBC_DRIVER));
//                } else {
//                    logger.info(CrawlerCommon.JDBC_URL_ERROR);
//                }
//                sourceAttributes.put(CrawlerCommon.CREDENTIAL_ID, HashMapUtility.get(metastoreInfo, CrawlerCommon.CREDENTIAL_ID));
//                sourceAttributes.put(CrawlerCommon.CREDENTIAL_TYPE_ID, HashMapUtility.get(metastoreInfo, CrawlerCommon.CREDENTIAL_TYPE_ID));
//                String creds = this.getCredentialsForSource();
//
//                HashMap<String, Object> credentials = JSONUtils.jsonToMap(creds);
//                if (!(jdbcURL.contains(CrawlerCommon.JDBC_HIVE))) {
//                    String userName = HashMapUtility.getString(credentials, CrawlerCommon.USER_NAME);
//                    if (userName == null) {
//                        throw new NullPointerException(CrawlerCommon.USER_NAME + CrawlerCommon.IS_NULL);
//                    }
//                    String password = HashMapUtility.getString(credentials, CrawlerCommon.PASSWORD);
//                    if (password == null) {
//                        throw new NullPointerException(CrawlerCommon.PASSWORD + CrawlerCommon.IS_NULL);
//                    }
//
//                    sourceAttributes.put(CrawlerCommon.JDBC_URL, jdbcURL);
//                    sourceConnection = DriverManager.getConnection(jdbcURL, userName, password);
//                } else {
//                    String keyTab = HashMapUtility.getString(credentials, CrawlerCommon.KEYTAB);
//                    String principal = HashMapUtility.getString(credentials, CrawlerCommon.PRINCIPAL);
//                    String trustStorePath = HashMapUtility.getString(credentials, CrawlerCommon.TRUSTSTORE_PATH);
//                    String trustStorePassword = HashMapUtility.getString(credentials, CrawlerCommon.TRUSTSTORE_PASSWORD);
//
//                    if (jdbcURL.endsWith(";")) {
//                        jdbcURL = jdbcURL + "httpPath=cliservice;serviceDiscoveryMode=zooKeeper;ssl=true;sslTrustStore=" + trustStorePath + ";trustStorePassword=" + trustStorePassword + ";transportMode=http;zooKeeperNamespace=hiveserver2";
//                    } else {
//                        jdbcURL = jdbcURL + ";httpPath=cliservice;serviceDiscoveryMode=zooKeeper;ssl=true;sslTrustStore=" + trustStorePath + ";trustStorePassword=" + trustStorePassword + ";transportMode=http;zooKeeperNamespace=hiveserver2";
//                    }
//
//                    Configuration conf = new Configuration();
//                    conf.set("hadoop.security.authentication", "Kerberos");
//                    UserGroupInformation.setConfiguration(conf);
//                    UserGroupInformation.loginUserFromKeytab(principal, keyTab);
//                    sourceConnection = DriverManager.getConnection(jdbcURL);
//
//                }
//                if (sourceConnection == null) {
//                    throw new NullPointerException(CrawlerCommon.SOURCE_CONNECTION_IS_NULL);
//                }
//            } else {
//                logger.info(CrawlerCommon.NO_SOURCE_CONNECTION);
//            }
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getStackTrace(e));
//            insertError(e);
//        }
//    }
//
//    @Override
//    public void connectToSource() {
//        this.getSchemas(sourceConnection);
//    }
//
//    @Override
//    public void doCrawling() {
//        this.executeListOfQueries(sourceConnection);
//    }
//
//    @Override
//    public void closeResources() {
//        if (sourceConnection != null) {
//            try {
//                sourceConnection.close();
//            } catch (SQLException e) {
//                logger.error(ExceptionUtils.getStackTrace(e));
//            }
//        }
//    }
//}