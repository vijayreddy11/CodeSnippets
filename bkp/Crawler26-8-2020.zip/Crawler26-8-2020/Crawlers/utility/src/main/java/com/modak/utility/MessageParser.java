package com.modak.utility;

import com.jayway.jsonpath.JsonPath;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class MessageParser {
    public static HashMap<String, Object> getTemplateGroupList(String message) {
        List<String> appTemplateGroupList = JsonPath.read(message, "$.actions[*].app_template.app_template_group");
        List<String> outputTemplateGroupList = JsonPath.read(message, "$.actions[*].output_templates[*].output_template_group");
        List<String> errorTemplateGroupList = JsonPath.read(message, "$.actions[*].error_templates[*].error_template_group");
        List<String> allGroupList = new ArrayList<String>();
        allGroupList.addAll(appTemplateGroupList);
        allGroupList.addAll(outputTemplateGroupList);
        allGroupList.addAll(errorTemplateGroupList);
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("groupId", allGroupList);
        return map;
    }
}