package com.modak.utility.exception;

public class SessionExpired extends Exception {
    public SessionExpired(String message) {
        super(message);
    }

}