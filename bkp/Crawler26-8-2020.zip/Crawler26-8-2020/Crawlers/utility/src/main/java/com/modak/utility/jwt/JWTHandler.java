package com.modak.utility.jwt;

import com.modak.utility.exception.SessionExpired;
import com.modak.utility.exception.UnAuthorizedServiceException;
import com.modak.utility.UtilConfig;
import com.modak.utility.MapUtils;
import io.jsonwebtoken.*;
import org.apache.commons.lang.RandomStringUtils;
import org.redisson.api.RMap;
import org.redisson.api.RedissonClient;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.modak.utility.UtilConfig.PASSWORD;
import static org.apache.hadoop.hdfs.web.oauth2.OAuth2Constants.BEARER;


public class JWTHandler implements AuthHandler {

    private static final String ALGORITHM_TYPE = "RSA";

    private static final String RSA_FILE_BEGIN_MARKER = "-----BEGIN RSA";

    private static final String RSA_FILE_END_MARKER = "-----END RSA";

    private static final String NOT_FOUND = " not found";


    private static final String JWT_ISSUER = "FIRESHOTS_APPLICATION";

    private static final String AUTH_KEY = "auth_key";


    PublicKey rsaPublicKey;
    PrivateKey rsaPrivateKey;
    String jwtTTL;

    @Override
    public void init(HashMap fireshotsConfigMap) {
        try {
            String publicKeypath = MapUtils.getString(fireshotsConfigMap, UtilConfig.JWT_PUBLIC_KEY);
            String privateKeyPath = MapUtils.getString(fireshotsConfigMap, UtilConfig.JWT_PRIVATE_KEY);
            rsaPublicKey = getPublicKey(publicKeypath);
            rsaPrivateKey = getPrivateKey(privateKeyPath);
            jwtTTL = MapUtils.get(fireshotsConfigMap, "JWT_TTL").toString();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public HashMap getUserMap(HttpServletRequest httpServletRequest) throws Exception {
        return getParsedToken(httpServletRequest.getHeader(UtilConfig.AUTHORIZATION_HEADER).replace(BEARER + UtilConfig.EMPTY_STRING, ""));
    }

    private HashMap<String, Object> getParsedToken(String token) throws Exception {
        Claims claims = null;
        try {
            claims = Jwts.parser()
                    .setSigningKey(rsaPublicKey)
                    .parseClaimsJws(token).getBody();
        } catch (MalformedJwtException mje) {
            throw new UnAuthorizedServiceException("user is not authorized : MalformedJwt token");
        } catch (SignatureException sje) {
            throw new UnAuthorizedServiceException("user is not authorized : Signature invalid token");
        } catch (ExpiredJwtException eje) {
            throw new SessionExpired("user session expired");
        } catch (Exception e) {
            throw e;
        }
        HashMap<String, Object> map = new HashMap<>();
        for (String key : claims.keySet()) {
            if (!(key.equals(UtilConfig.IAT) || key.equals(UtilConfig.EXP))) {
                map.put(key, claims.get(key));
            }
        }
        return map;
    }

    @Override
    public String generateToken(Map<String, Object> userdetails, RedissonClient redissonClient) {
//        userdetails.put(AUTH_KEY, AESUtils.encode(String.valueOf(userdetails.get(UtilConfig.PASSWORD)), aesKey));
        long issueTime = new Date().getTime();
        userdetails.put(UtilConfig.SESSION_ID, generateSessionId(userdetails, redissonClient, issueTime));
        userdetails.remove(PASSWORD);
        String token = Jwts.builder()
                .setClaims(userdetails)
                .setIssuer(JWT_ISSUER)
                .signWith(SignatureAlgorithm.RS256, rsaPrivateKey)
                .setIssuedAt(new Date(issueTime))
                .setExpiration(new Date(System.currentTimeMillis() + Integer.parseInt(jwtTTL)))
                .compact();
        redissonClient.shutdown();
        return token;
    }


    public Object extendUserSession(HashMap userDetails, RedissonClient redissonClient) {
        RMap<Object, RMap<String, Object>> authMap = redissonClient.getMap("authTokenBotMap");
        authMap.get(userDetails.get(UtilConfig.SESSION_ID)).expire(Integer.parseInt(jwtTTL), TimeUnit.MILLISECONDS);
        String token = Jwts.builder().setClaims(userDetails)
                .setIssuer(JWT_ISSUER)
                .signWith(SignatureAlgorithm.RS256, rsaPrivateKey)
                .setIssuedAt((Date) userDetails.get("iat"))
                .setExpiration(new Date(System.currentTimeMillis() + Integer.parseInt(jwtTTL)))
                .compact();
        return token;
    }

    public int generateSessionId(Map<String, Object> userDetailsMap, RedissonClient redissonClient, long issueTime) {
        int session_id;
        RMap<Object, RMap<String, Object>> authMap = redissonClient.getMap("authTokenBotMap");
        RMap<String, Object> userMap = redissonClient.getMap("userMap");
        for (String k : userDetailsMap.keySet()) {
            userMap.put(k, userDetailsMap.get(k));
        }
        session_id = (userDetailsMap.get("userId").toString() + issueTime + RandomStringUtils.randomAlphanumeric(30)).hashCode() & 0xfffffff;
        authMap.putIfAbsent(session_id, userMap);
        authMap.get(session_id).expire(Integer.parseInt(jwtTTL), TimeUnit.MILLISECONDS);
        return session_id;
    }

    public static PrivateKey getPrivateKey(String filePath) throws Exception {
        if (filePath != null) {
            File f = new File(filePath);
            if (f.exists()) {
                byte[] keyBytes = Files.readAllBytes((new File(filePath)).toPath());
                PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
                KeyFactory kf = KeyFactory.getInstance("RSA");
                return kf.generatePrivate(spec);
            } else {
                throw new Exception("File not found in location " + filePath);
            }
        } else {
            throw new NullPointerException("null file");
        }
    }

    public static PublicKey getPublicKey(String filePath) throws Exception {
        if (filePath != null) {
            File f = new File(filePath);
            if (f.exists()) {
                byte[] keyBytes = Files.readAllBytes((new File(filePath)).toPath());
                X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
                KeyFactory kf = KeyFactory.getInstance("RSA");
                return kf.generatePublic(spec);
            } else {
                throw new Exception("File not found in location " + filePath);
            }
        } else {
            throw new NullPointerException("null file");
        }
    }

    private byte[] getKeyFileContent(String keyFilePath) throws IOException {
        StringBuffer buf;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(keyFilePath)))) {
            String line = br.readLine();
            buf = new StringBuffer();

            while (line != null && !line.startsWith(RSA_FILE_BEGIN_MARKER)) {
                line = br.readLine();
            }

            if (line != null) {
                while ((line = br.readLine()) != null) {
                    if (line.indexOf(RSA_FILE_END_MARKER) != -1) {
                        break;
                    }
                    buf.append(line.trim());
                }

                if (line == null) {
                    throw new IOException(RSA_FILE_END_MARKER + NOT_FOUND);
                }
            }
        }
        return Base64.getDecoder().decode(buf.toString().getBytes());
    }
}

