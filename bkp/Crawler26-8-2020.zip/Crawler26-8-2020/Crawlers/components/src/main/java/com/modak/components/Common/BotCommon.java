package com.modak.components.common;

public class BotCommon {
    public static String DATA = "data";
    public static String KEY_JOB_ID = "job_id";
    public static String UNIQUE_ID = "unique_id";
    public static String KEY_BOT_NAME = "bot_name";
    public static String SCHEDULER = "scheduler";
    public static String KEY_BOT_UUID = "bot_uuid";
    public static String KEY_JOB_NAME = "job_name";
    public static String KEY_JOB_DESCRIPTION = "job_description";
    public static String KEY_TYPE_OF_JOB = "type_of_job";
    public static String KEY_FUNCTIONAL_ID = "functional_id";
    public static String MESSAGE_UUID = "message_uuid";
    public static String CURRENT_TIMESTAMP = "current_timestamp";
    public static String CURRENT_METADATA = "current_metadata";
    public static String MESSAGE_TOPIC_KEY = "metadata.topic";
    public static String PUBLIC_KEY = "public_key";
    public static String USER_NAME = "username";
    public static String PASSWORD = "password";
    public static String KEY_JOB_METADATA = "job_metadata";
    public static String KEY_JOB_STATUS = "job_status";
    public static String KEY_STATE_ID = "state_id";
    public static String MESSAGE_TYPE = "message_type";
    public static String MESSAGE_TYPE_JOB_STATUS = "job_status";
    public static String KEY_CREATED_TIMESTAMP = "created_timestamp";
    public static String KEY_HOSTNAME = "hostname";
    public static long DEFAULT_LONG_SLEEP = 10000L;
    public static long DEFAULT_SLEEP_INTERVAL = 1000;
    public static String KEY_GLOBAL_TOPICS = "global_topics";
    public static String KEY_CLIENT_TOPICS = "client_topics";
    public static String KEY_BOOTSTRAP_BROKERS = "bootstrap_brokers";
    public static String VAULT_KEY = "vault_key";
    public static String KEY_ACTION = "action";
    public static String ACTION_RESET = "reset_component";
    public static String ACTION_TERMINATE = "terminate_component";
    public static String STATUS_CONNECTED = "connected";
    public static String STATUS_NOT_CONNECTED = "not connected";
    public static String TOPIC_COMPONENT_STATUS = "info/heartbeat";
    public static int DEFAULT_QOS = 0;
    public static boolean DEFAULT_RETENTION = false;
    public static String PRIVATE_KEY = "private_key";
    public static String KAFKA_DELIVERY = "pull";
    public static String BOT_PUBLISH_MESSAGE_SIZE = "bot_publish_message_size";
    public static String TRUSTORE_FILE_PATH = "truststoreFilePath";
    public static String BOT_TYPE = "bot_type";
    public static String BOT_UUID = "bot_uuid";
    public static String BOT_PUBLISH_MESSAGE_SIZE_BYTES = "Message in Bytes :";
    public static String BOT_PUBLISH_MESSAGE_SIZE_EXCEPTION = "Publish message size exceeded 16MB, " + "OutputMessageSize :";

    public enum JobStatus {
        STARTED(5), FINISHED(6);
        private int statusId;

        JobStatus(int statusId) {
            this.statusId = statusId;
        }

        public int getStatusId() {
            return this.statusId;
        }
    }

}
