package com.modak.components.scheduler;

import com.zaxxer.hikari.HikariDataSource;
import com.modak.components.common.CPCommon;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.*;
import org.quartz.impl.matchers.GroupMatcher;
import com.modak.utility.HashMapUtility;
import com.modak.utility.db.JDBCUtility;
import com.modak.utility.json.JSONUtility;
import com.modak.utility.st.STTemplateFactory;
import com.modak.utility.st.STTemplateRenderer;

import java.util.*;

public class JobScheduler implements Job {

    private static final Logger logger = LogManager.getLogger(JobScheduler.class);
    Scheduler scheduler = null;
    private String configFileLocation = null;
    HikariDataSource hikariDataSource;
    HashMap<String, Object> templateConfigMap;


    public void execute(JobExecutionContext jobExecutionContext) {
        CronTrigger previousCronTrigger = null;
        try {
            JobDataMap jobDataMap = jobExecutionContext.getJobDetail().getJobDataMap();
            configFileLocation = jobDataMap.getString(CPCommon.CONFIG_FILE_PATH);
            scheduler = (Scheduler) jobDataMap.get(CPCommon.SCHEDULER);

            hikariDataSource = (HikariDataSource) jobDataMap.get(CPCommon.DATASOURCE);
            HashMap<String, Object> configMap = JSONUtility.loadJSONFile(configFileLocation);
            templateConfigMap = HashMapUtility.getMap(configMap, CPCommon.TEMPLATE_CONFIG);
            String templateGroup = HashMapUtility.getString(templateConfigMap, CPCommon.TEMPLATE_GROUP);
            String templateName = HashMapUtility.getString(templateConfigMap, CPCommon.TEMPLATE_NAME);
            STTemplateRenderer templateRenderer = STTemplateFactory.getTemplateRenderer(templateConfigMap);
            String query = templateRenderer.renderTemplate(templateGroup, templateName);

            JDBCUtility jdbcUtility = new JDBCUtility();
            List<Map<String, Object>> listOfSources = jdbcUtility.executeSelectQuery(query, hikariDataSource, new MapListHandler());
            for (Map eachSource : listOfSources) {
                //getting jobkeys based on job group
                Set<JobKey> jobKeySet = scheduler.getJobKeys(GroupMatcher.jobGroupEquals(eachSource.get(CPCommon.GROUP).toString()));
                if (jobKeySet.size() > 0) {
                    for (JobKey jobKey : jobKeySet) {
                        try {
                            if (jobKey.getName().equalsIgnoreCase(eachSource.get(CPCommon.GROUP).toString())) {
                                List triggersList = scheduler.getTriggersOfJob(jobKey);
                                for (Object cronTrigger : triggersList) {
                                    previousCronTrigger = (CronTrigger) cronTrigger;
                                }
                                String previousCronExpr = previousCronTrigger != null ? previousCronTrigger.getCronExpression() : "";
                                String currentCronExpr = eachSource.get(CPCommon.CRONPATTERN).toString();

                                if (previousCronExpr.equalsIgnoreCase(currentCronExpr)) {
                                    logger.info(CPCommon.JOB_SCHEDULED_AT_SAME_TIME, jobKey.getName(), currentCronExpr);
                                } else {
                                    logger.info(CPCommon.CHANGE_IN_JOB_SCHEDULED_TIME, jobKey.getName(),
                                            currentCronExpr, previousCronExpr);
                                    scheduler.deleteJob(jobKey);
                                    scheduleRefresh(eachSource);
                                }
                            } else {
                                scheduleRefresh(eachSource);
                            }
                        } catch (Exception e1) {
                            logger.error(CPCommon.FAILED_TO_SCHEDULE, e1);
                        }
                    }
                } else {
                    scheduleRefresh(eachSource);
                }
            }
        } catch (Exception e) {
            logger.error(CPCommon.FAILED_TO_SCHEDULE, e);
        }
    }

    private void scheduleRefresh(Map<String, Object> sourceMap) {
        String jobInfo = null;
        String cronPattern = null;
        JobDetail publishKafkaMsgJob = null;
        try {
            JobDataMap sourceDataMap = new JobDataMap();
            sourceDataMap.put(CPCommon.DATA, sourceMap);
            sourceDataMap.put(CPCommon.HIKARIDATASOURCE, hikariDataSource);
            sourceDataMap.put(CPCommon.TEMPLATE_CONFIG_MAP, templateConfigMap);

            if (sourceMap.get(CPCommon.PUBLISHER_CLASS_NAME).toString().equalsIgnoreCase(CPCommon.CRAWLERMESSAGESPUBLISHER)) {
                publishKafkaMsgJob = JobBuilder.newJob(CrawlerMessagesPublisher.class)
                        .withIdentity(sourceMap.get(CPCommon.JOB_KEY).toString(),
                                sourceMap.get(CPCommon.GROUP).toString())
                        .usingJobData(CPCommon.CONFIG_FILE_PATH, configFileLocation)
                        .usingJobData(sourceDataMap)
                        .build();
            } else {
                publishKafkaMsgJob = JobBuilder.newJob(JobMessagesPublisher.class)
                        .withIdentity(sourceMap.get(CPCommon.JOB_KEY).toString(),
                                sourceMap.get(CPCommon.GROUP).toString())
                        .usingJobData(CPCommon.CONFIG_FILE_PATH, configFileLocation)
                        .usingJobData(sourceDataMap)
                        .build();
            }
            cronPattern = sourceMap.get(CPCommon.CRONPATTERN).toString();
            CronTrigger trigger1 = TriggerBuilder.newTrigger()
                    .withIdentity(sourceMap.get(CPCommon.TRIGGER_KEY).toString(),
                            sourceMap.get(CPCommon.GROUP).toString())
                    .withSchedule(CronScheduleBuilder.cronSchedule(cronPattern)).build();
            jobInfo = publishKafkaMsgJob.getKey().getName();
            Date publishKafkaMsgJobTime = scheduler.scheduleJob(publishKafkaMsgJob, trigger1);
            scheduler.start();
            logger.info(" {} " + CPCommon.SCHEDULED_TO_RUN + publishKafkaMsgJobTime, jobInfo);
        } catch (Exception e) {
            if (!CronExpression.isValidExpression(cronPattern)) {
                logger.error(CPCommon.TRIGGER_WILL_NEVER_FIRE, cronPattern);
            }
        }
    }
}