package com.modak.components.scheduler;

import com.modak.utils.JDBCConnectionManager;
import com.modak.utils.JSONUtils;
import com.zaxxer.hikari.HikariDataSource;
import com.modak.components.common.CPCommon;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import com.modak.utility.HashMapUtility;

import java.io.File;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.HashMap;

public class JobChecker {
    private static final Logger logger = LogManager.getLogger(JobChecker.class);

    public static void main(String[] args) {
        String configFileLocation = null;
        String jobName = null;
        if (args.length == 1) {
            configFileLocation = args[0];
        } else {
            logger.error(CPCommon.INVALID_ARGUMENTS);
        }
        JobChecker jobSchedulerObject = new JobChecker();
        jobSchedulerObject.doJobScheduling(configFileLocation, jobName);
    }

    public void doJobScheduling(String configFilePath, String jobName) {
        try {
            HashMap<String, Object> schedulerInfoMap = JSONUtils.
                    jsonToMap(FileUtils.readFileToString(new File(configFilePath), Charset.defaultCharset()));
            String schedulerPropsFile = HashMapUtility.getString(schedulerInfoMap, CPCommon.QUARTZ_PROPS_FILE);
            int refreshFrequency = HashMapUtility.getInteger(schedulerInfoMap, CPCommon.REFRESH_FREQUENCY);
            SchedulerFactory sf = new StdSchedulerFactory(schedulerPropsFile);
            Scheduler scheduler = sf.getScheduler();

            HashMap<String, Object> databaseConfigMap = HashMapUtility.getMap(schedulerInfoMap,
                    CPCommon.DATABASE_CONFIG);
            JDBCConnectionManager connectionManager = new JDBCConnectionManager();
            connectionManager.configureHikariDataSource(databaseConfigMap);
            HikariDataSource dataSource = connectionManager.getHikariDataSource();
            JobDataMap jobDataMap = new JobDataMap();
            jobDataMap.put(CPCommon.DATASOURCE, dataSource);
            jobDataMap.put(CPCommon.SCHEDULER, scheduler);

            //Daily Checking for sources
            JobDetail dailyCheckingJob = JobBuilder.newJob(JobScheduler.class)
                    .withIdentity(CPCommon.DAILYCHECKINGJOB, CPCommon.DAILYCHECKINGJOBGROUP)
                    .usingJobData(CPCommon.CONFIG_FILE_PATH, configFilePath)
                    .usingJobData(CPCommon.JOB_NAME, jobName)
                    .usingJobData(jobDataMap)
                    .build();
            Trigger dailyCheckingTrigger = TriggerBuilder.newTrigger()
                    .withIdentity(CPCommon.DAILYCHECKINGTRIGGER, CPCommon.DAILYCHECKINGTRIGGERGROUP)
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(refreshFrequency).repeatForever())
                    .build();
            Date dailyCheckingScheduleTime = scheduler.scheduleJob(dailyCheckingJob, dailyCheckingTrigger);
            scheduler.start();
            logger.info(dailyCheckingJob.getKey().getName() + CPCommon.SCHEDULED_TO_RUN + dailyCheckingScheduleTime);
        } catch (Exception e) {
            logger.error(CPCommon.FAILED_TO_SCHEDULE, e);
        }
    }
}