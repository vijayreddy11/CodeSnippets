package com.modak.components.common;

public class CPCommon {
    public static final String INVALID_ARGUMENTS = "Invalid arguments";
    public static final String SCHEDULER_TOPIC = "topic";
    public static final String DATA = "data";
    public static final String QUARTZ_PROPS_FILE = "quartz_props_file";
    public static final String REFRESH_FREQUENCY = "refresh_frequency";
    public static final String VAULT_CONFIG = "vault_config";
    public static final String DATABASE_CONFIG = "database_config";
    public static final String DATASOURCE = "dataSource";
    public static final String SCHEDULER = "scheduler";
    public static final String DAILYCHECKINGJOB = "dailyCheckingJob";
    public static final String DAILYCHECKINGJOBGROUP = "dailyCheckingJobGroup";
    public static final String DAILYCHECKINGTRIGGER = "dailyCheckingTrigger";
    public static final String DAILYCHECKINGTRIGGERGROUP = "dailyCheckingTriggerGroup";
    public static final String HIKARIDATASOURCE = "hikariDataSource";
    public static final String TEMPLATE_CONFIG_MAP = "template_config_map";
    public static final String CONFIG_FILE_PATH = "config_file_path";
    public static final String JOB_NAME = "job_name";
    public static final String GROUP = "group";
    public static final String JOB_KEY = "job_key";
    public static final String CRONPATTERN = "cronPattern";
    public static final String PUBLISHER_CLASS_NAME = "publisher_class_name";
    public static final String CRAWLERMESSAGESPUBLISHER = "CrawlerMessagesPublisher";
    public static final String TRIGGER_KEY = "trigger_key";
    public static final String DATE_FORMAT = "yyMMddHHmm";
    public static final String TEMPLATE_CONFIG = "template_config";
    public static final String OUTPUT_TEMPLATE_GROUP = "output_template_group";
    public static final String OUTPUT_TEMPLATE_NAME = "output_template_name";
    public static final String JOB_METADATA = "job_metadata";
    public static final String JOB_METADATA_MAP = "job_metadata_map";
    public static final String JOB_SPEC_ID = "job_spec_id";
    public static final String KAFKA_CONFIG = "kafka_config";
    public static final String STATUS_TOPIC = "status_topic";
    public static final String DATAPLACE_ID = "dataplace_id";
    public static final String DATAPLACE_COMPONENT_TYPE_ID = "dataplace_component_type_id";
    public static final String VALID_JOB = "valid_job";
    public static final String JOB_SCHEDULED = " job: {} has scheduled to run next at:";
    public static final String FAILED_TO_CLOSE_KAFKA_PRODUCER = " Failed to close Kafka Producer";
    public static final String FAILED_TO_PUBLISH_MESSAGE = " failed to publish message ";
    public static final String FAILED_TO_PUBLISH_INITIAL_MESSAGE = " Failed to publish initial message";
    public static final String OUTPUT_MESSAGE = "output message :{}";
    public static final String PUBLISHED_MESSAGE = "Published Message";
    public static final String FAILED_TO_SCHEDULE = "Failed to schedule";
    public static final String SCHEDULED_TO_RUN = " has been scheduled to run at:";
    public static final String TEMPLATE_GROUP = "template_group";
    public static final String TEMPLATE_NAME = "template_name";
    public static final String JOB_SCHEDULED_AT_SAME_TIME = " job {} scheduled at same time {}";
    public static final String CHANGE_IN_JOB_SCHEDULED_TIME = " Change in job {} scheduled time {},Deleting previous scheduled job {} ";
    public static final String TRIGGER_WILL_NEVER_FIRE = " Based on configured schedule {},the given trigger will never fire";

    public static final String DATAPLACE_DELETION = " Data Place with dataplace_id:{} has been deleted, so the scheduled Job has been deleted ";


    public static final String KEY_PREFIX_JOB_STATUS_PUBLISHER = "job_status_publisher_";
    public static final Integer DEFAULT_QOS = 0;
    public static Boolean DEFAULT_RETENTION = false;
}
